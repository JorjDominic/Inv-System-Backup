<?php
session_start();
require_once 'config/database.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method.");
    }

    $inventoryID = $_POST['inventory_id'] ?? null;
    if (!$inventoryID) {
        throw new Exception("Missing inventory ID.");
    }

    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
        throw new Exception("User not authenticated.");
    }

    $userID = $_SESSION['user_id'];
    $username = $_SESSION['user_name'];
    $logTime = date('Y-m-d H:i:s');

    $conn->beginTransaction();

    // Fetch inventory and product info
    $stmt = $conn->prepare("
        SELECT i.InventoryID, i.ProductID, i.Quantity, i.DateReceived, i.ExpiryDate,
               p.ProductName, p.PurchasePrice, p.SellingPrice, p.CategoryID
        FROM Inventory i
        JOIN Product p ON i.ProductID = p.ProductID
        WHERE i.InventoryID = ?
    ");
    $stmt->execute([$inventoryID]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$data) {
        throw new Exception("Inventory item not found.");
    }

    // Move to DeletedItems table
    $archive = $conn->prepare("
        INSERT INTO DeletedItems (InventoryID, ProductName, Quantity, PurchasePrice, SellingPrice, DateReceived, ExpiryDate, CategoryID)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $archive->execute([
        $data['InventoryID'],
        $data['ProductName'],
        $data['Quantity'],
        $data['PurchasePrice'],
        $data['SellingPrice'],
        $data['DateReceived'],
        $data['ExpiryDate'],
        $data['CategoryID']
    ]);

    // ✅ Log inventory action BEFORE deletion
    $logStmt = $conn->prepare("
    INSERT INTO InventoryLogs (
        UserID, UsernameSnapshot, InventoryID, ProductNameSnapshot,
        Action, QuantityChanged, Remarks
    ) VALUES (?, ?, ?, ?, 'delete', ?, ?)
");

$remarks = "Deleted from inventory and archived";
$logStmt->execute([
    $userID,
    $_SESSION['user_name'],
    $inventoryID,
    $data['ProductName'],
    $data['Quantity'],
    $remarks
]);

    // Delete from Inventory
    $conn->prepare("DELETE FROM Inventory WHERE InventoryID = ?")->execute([$inventoryID]);

    // Check if other inventory exists for the same product
    $checkRemaining = $conn->prepare("SELECT COUNT(*) FROM Inventory WHERE ProductID = ?");
    $checkRemaining->execute([$data['ProductID']]);
    $remaining = $checkRemaining->fetchColumn();

    // If no more inventory AND no order history, delete from Product
    $checkOrders = $conn->prepare("SELECT COUNT(*) FROM OrderDetails WHERE ProductID = ?");
    $checkOrders->execute([$data['ProductID']]);
    $hasOrders = $checkOrders->fetchColumn() > 0;

    if ($remaining == 0 && !$hasOrders) {
        $conn->prepare("DELETE FROM Product WHERE ProductID = ?")->execute([$data['ProductID']]);
    }

    $conn->commit();

    header("Location: inventory.php?toast=success&msg=Item Deleted successfully");;
    exit;

} catch (Exception $e) {
    $conn->rollBack();
    echo "<script>
        alert('❌ Error: " . addslashes($e->getMessage()) . "');
        window.location.href = 'inventory.php';
    </script>";
    exit;
}
?>
