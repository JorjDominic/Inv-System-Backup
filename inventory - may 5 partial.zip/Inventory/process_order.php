<?php
session_start();
require('config/database.php');
require('notification.php');

// Read raw JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($_SESSION['user_id']) || empty($input['cart']) || empty($input['payment_method'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false, 
        "error" => "Invalid session or missing input.",
        "toast" => [
            "type" => "error",
            "message" => "Invalid session or missing input."
        ]
    ]);
    exit;
}

$userId = $_SESSION['user_id'];
$cart = $input['cart'];
$methodName = $input['payment_method'];
$orderDate = date('Y-m-d');
$orderDiscount = isset($input['discount']) ? floatval($input['discount']) : 0;

// Validate payment method against database options
$validMethods = ['Cash', 'Credit', 'GCash', 'Card', 'Maya', 'GrabPay', 'Other'];
if (!in_array($methodName, $validMethods)) {
    http_response_code(400);
    echo json_encode([
        "success" => false, 
        "error" => "Invalid payment method selected.",
        "toast" => [
            "type" => "error",
            "message" => "Please select a valid payment method."
        ]
    ]);
    exit;
}

// Optional customer info
$firstName = isset($input['first_name']) ? trim($input['first_name']) : null;
$lastName = isset($input['last_name']) ? trim($input['last_name']) : null;
$email = isset($input['email']) ? trim($input['email']) : null;
$customerId = null;

try {
    // Get PaymentMethodID - using prepared statement
    $stmt = $conn->prepare("SELECT PaymentMethodID, RequiresVerification FROM PaymentMethods WHERE MethodName = ?");
    $stmt->execute([$methodName]);
    $method = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$method) {
        http_response_code(400);
        echo json_encode(["success" => false, "error" => "Invalid payment method."]);
        exit;
    }

    $paymentMethodID = $method['PaymentMethodID'];
    $requiresVerification = $method['RequiresVerification'];

    $conn->beginTransaction();

    // Handle customer if provided
    if ($firstName && $lastName && $email) {
        $stmt = $conn->prepare("SELECT CustomerID FROM Customers WHERE Email = ?");
        $stmt->execute([$email]);
        $existingCustomer = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingCustomer) {
            $customerId = $existingCustomer['CustomerID'];
        } else {
            $stmt = $conn->prepare("INSERT INTO Customers (FirstName, LastName, Email) VALUES (?, ?, ?)");
            $stmt->execute([$firstName, $lastName, $email]);
            $customerId = $conn->lastInsertId();
        }
    }

    // Set initial order status based on payment method
    $orderStatus = $requiresVerification ? 'pending' : 'paid';

    // Insert into Orders with status - REMOVED PaymentMethodID from here
    $stmt = $conn->prepare("
        INSERT INTO Orders (UserID, CustomerID, OrderDate, OrderStatus) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([
        $userId,
        $customerId,
        $orderDate,
        $orderStatus
    ]);
    $orderId = $conn->lastInsertId();

    $subtotal = 0;
    $lowStockItems = [];

    foreach ($cart as $item) {
        $stmt = $conn->prepare("SELECT ProductID FROM Product WHERE ProductName = ? AND SellingPrice = ?");
        $stmt->execute([$item['name'], $item['price']]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            throw new Exception("Product not found: " . $item['name']);
        }

        $itemSubtotal = $item['price'] * $item['quantity'];
        $subtotal += $itemSubtotal;

        $stmt = $conn->prepare("
            INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $orderId,
            $product['ProductID'],
            $item['quantity'],
            $item['price']
        ]);

        // Inventory management (FIFO)
        $productId = $product['ProductID'];
        $quantityNeeded = $item['quantity'];

        $stmt = $conn->prepare("
            SELECT InventoryID, Quantity 
            FROM Inventory 
            WHERE ProductID = ? AND Quantity > 0 
            ORDER BY ExpiryDate ASC
        ");
        $stmt->execute([$productId]);
        $inventoryBatches = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($inventoryBatches as $batch) {
            if ($quantityNeeded <= 0) break;

            $deductQty = min($quantityNeeded, $batch['Quantity']);
            $stmt = $conn->prepare("UPDATE Inventory SET Quantity = Quantity - ? WHERE InventoryID = ?");
            $stmt->execute([$deductQty, $batch['InventoryID']]);
            $quantityNeeded -= $deductQty;
        }

        if ($quantityNeeded > 0) {
            throw new Exception("Insufficient stock for product: " . $item['name']);
        }
        
        // Check remaining stock
        $stmt = $conn->prepare("
            SELECT SUM(Quantity) as RemainingStock, p.ProductName
            FROM Inventory i
            JOIN Product p ON i.ProductID = p.ProductID
            WHERE i.ProductID = ?
            GROUP BY p.ProductID
        ");
        $stmt->execute([$productId]);
        $stockInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($stockInfo && $stockInfo['RemainingStock'] < 10) {
            $lowStockItems[] = [
                'name' => $stockInfo['ProductName'],
                'stock' => $stockInfo['RemainingStock']
            ];
        }
    }

    $finalTotal = max(0, $subtotal - $orderDiscount);

    // Update order with total amount
    $stmt = $conn->prepare("UPDATE Orders SET TotalAmount = ? WHERE OrderID = ?");
    $stmt->execute([$finalTotal, $orderId]);

    // Create transaction record
    $stmt = $conn->prepare("
        INSERT INTO Transactions (OrderID, Amount, TransactionType, PaymentMethodID, Status)
        VALUES (?, ?, 'walk_in', ?, ?)
    ");
    $stmt->execute([
        $orderId,
        $finalTotal,
        $paymentMethodID,
        $orderStatus === 'paid' ? 'completed' : 'pending'
    ]);
    $transactionId = $conn->lastInsertId();
    
    // Create walk-in transaction record
    $stmt = $conn->prepare("
        INSERT INTO WalkinTransactions (TransactionID, ProcessedBy)
        VALUES (?, ?)
    ");
    $stmt->execute([
        $transactionId,
        $userId
    ]);

    // Insert receipt
    $stmt = $conn->prepare("
        INSERT INTO Receipts (OrderID, TransactionID, CustomerID, UserID, TotalAmount, Discount, PaymentMethodID, DateIssued)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $orderId,
        $transactionId,
        $customerId,
        $userId,
        $finalTotal,
        $orderDiscount,
        $paymentMethodID,
        $orderDate
    ]);

    // Create order notification
    $orderMessage = "New order #$orderId processed for ₱" . number_format($finalTotal, 2);
    createNotificationForAllUsers($conn, 'order_status', $orderMessage, $userId);
    
    // Create low stock notifications if needed
    if (!empty($lowStockItems)) {
        foreach ($lowStockItems as $item) {
            $lowStockMessage = "Low stock alert: {$item['name']} has only {$item['stock']} units remaining";
            createNotificationForAllUsers($conn, 'low_stock', $lowStockMessage, $userId);
        }
    }

    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "✅ Order placed successfully.",
        "order_id" => $orderId,
        "transaction_id" => $transactionId,
        "subtotal" => $subtotal,
        "order_discount" => $orderDiscount,
        "total" => $finalTotal,
        "requires_verification" => $requiresVerification,
        "toast" => [
            "type" => "success",
            "message" => "Order #$orderId placed successfully!"
        ]
    ]);

} catch (Exception $e) {
    $conn->rollBack();
    http_response_code(500);
    error_log("Order Processing Error: " . $e->getMessage());
    echo json_encode([
        "success" => false, 
        "error" => $e->getMessage(),
        "toast" => [
            "type" => "error",
            "message" => "Error processing order: " . $e->getMessage()
        ]
    ]);
}