<?php
session_start();
require('config/database.php');
require('notification.php');

// Ensure only admins/staff can perform update
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header("Location: index.php?toast=error&msg=" . urlencode("Unauthorized access"));
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Fetch form values
$inventory_id     = $_POST['inventory_id'];
$product_name     = trim($_POST['product_name']);
$quantity         = (int)$_POST['quantity']; // Add quantity from form
$purchase_price   = $_POST['purchase_price'];
$selling_price    = $_POST['selling_price'];
$category_id      = $_POST['category_id'];
$date_received    = $_POST['date_received'];
$expiry_date      = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

try {
    $conn->beginTransaction();

    // ✅ Get user details for logging
    $userID = $_SESSION['user_id'];
    $username = $_SESSION['user_name'] ?? 'Unknown';
    $logTime = date('Y-m-d H:i:s');

    // Get current ProductID and Quantity from Inventory
    $stmt = $conn->prepare("SELECT i.ProductID, i.Quantity, p.ImageURL 
                           FROM Inventory i 
                           JOIN Product p ON i.ProductID = p.ProductID 
                           WHERE i.InventoryID = ?");
    $stmt->execute([$inventory_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        throw new Exception("Invalid inventory ID");
    }

    $product_id = $product['ProductID'];
    $old_quantity = $product['Quantity'];
    $quantity_change = $quantity - $old_quantity; // Calculate quantity change for logging
    $current_image = $product['ImageURL'];
    
    // Handle image upload
    $imageURL = $current_image; // Default to current image
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['product_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($ext), $allowed)) {
            // Create unique filename
            $newFilename = uniqid('product_') . '.' . $ext;
            $uploadDir = 'uploads/products/';
            
            // Create directory if it doesn't exist
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $destination = $uploadDir . $newFilename;
            
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $destination)) {
                $imageURL = $destination;
                
                // Delete old image if it exists and is not the default image
                if ($current_image && file_exists($current_image) && strpos($current_image, 'default') === false) {
                    @unlink($current_image);
                }
            } else {
                // Image upload failed, but continue with product update
                $uploadError = "Image upload failed. Product will be updated with the existing image.";
            }
        } else {
            // Invalid file type, but continue with product update
            $uploadError = "Invalid file type. Only JPG, JPEG, PNG and GIF are allowed.";
        }
    }

    // Update Product info with image
    $stmt = $conn->prepare("UPDATE Product SET ProductName = ?, PurchasePrice = ?, SellingPrice = ?, CategoryID = ?, ImageURL = ? WHERE ProductID = ?");
    $stmt->execute([$product_name, $purchase_price, $selling_price, $category_id, $imageURL, $product_id]);

    // Update Inventory info (now including Quantity)
    $stmt = $conn->prepare("UPDATE Inventory SET Quantity = ?, DateReceived = ?, ExpiryDate = ? WHERE InventoryID = ?");
    $stmt->execute([$quantity, $date_received, $expiry_date, $inventory_id]);

    // ✅ Log the edit to InventoryLogs
    $logStmt = $conn->prepare("
        INSERT INTO InventoryLogs (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks, Timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $action = 'edit';
    if ($quantity_change != 0) {
        $action = $quantity_change > 0 ? 'ADD' : 'REMOVE';
        $quantity_changed = abs($quantity_change);
        $remarks = "Edited product '$product_name' and " . ($quantity_change > 0 ? "added" : "removed") . " $quantity_changed units";
    } else {
        $quantity_changed = 0;
        $remarks = "Edited product '$product_name' (no quantity change)";
    }
    
    $logStmt->execute([$userID, $username, $product_name, $inventory_id, $action, $quantity_changed, $remarks, $logTime]);
    
    // Create notification for inventory updates for ALL users
    if ($quantity_change != 0) {
        // Get ALL users in the system
        $notifyStmt = $conn->prepare("SELECT UserID FROM Users");
        $notifyStmt->execute();
        $allUsers = $notifyStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $notificationMessage = "Inventory updated: " . ($quantity_change > 0 ? "Added" : "Removed") . " " . 
                              abs($quantity_change) . " units of $product_name";
        
        foreach ($allUsers as $user) {
            // Create notification for every user
            createNotification($conn, $user['UserID'], 'inventory_update', $notificationMessage);
        }
    }

    $conn->commit();

    $successMsg = "Item edited successfully";
    if (isset($uploadError)) {
        $successMsg .= ", but " . strtolower($uploadError);
    }
    
    header("Location: inventory.php?toast=success&msg=" . urlencode($successMsg));
    exit;

} catch (Exception $e) {
    $conn->rollBack();
    header("Location: inventory.php?toast=error&msg=" . urlencode("Error updating inventory: " . $e->getMessage()));
    exit;
}
?>