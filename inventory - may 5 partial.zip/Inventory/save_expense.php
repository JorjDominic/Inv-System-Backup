<?php
// Include your database connection
require_once 'config/database.php';

// Start the session to access session variables
session_start();

// Check if user is logged in (check if user_id exists in session)
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: login.php");
    exit;
}

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $description = $_POST['description'];
    $category = $_POST['category'];
    $amount = $_POST['amount'];
    $date = $_POST['date'];
    $userId = $_SESSION['user_id']; // Get the logged-in user's ID from session

    try {
        // Prepare and execute the SQL statement to insert expense
        $stmt = $conn->prepare("INSERT INTO Expenses (Description, Category, Amount, Date, UserID) 
                                VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$description, $category, $amount, $date, $userId]);

        // Redirect to a success page with a success message
        header("Location: expenses.php?msg_success=Expense added successfully!");
        exit;
    } catch (PDOException $e) {
        // Handle any error
        echo "Error: " . $e->getMessage();
    }
}
?>
