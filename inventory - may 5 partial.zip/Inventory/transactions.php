<?php
session_start();
require('config/database.php');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3)) {
  header("Location: index.php");
  exit;
}

$search = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

$conditions = [];
$params = [];

try {
  if (!empty($search)) {
    // 🔍 Find OrderIDs by username or product name
    $searchStmt = $conn->prepare("
      SELECT DISTINCT r.OrderID
      FROM Receipts r
      JOIN Orders o ON r.OrderID = o.OrderID
      JOIN Users u ON o.UserID = u.UserID
      JOIN OrderDetails od ON od.OrderID = o.OrderID
      JOIN Product p ON od.ProductID = p.ProductID
      WHERE u.Username LIKE ? OR p.ProductName LIKE ?
    ");
    $searchStmt->execute(["%$search%", "%$search%"]);
    $matchedOrders = $searchStmt->fetchAll(PDO::FETCH_COLUMN);

    if ($matchedOrders) {
      $placeholders = implode(',', array_fill(0, count($matchedOrders), '?'));
      $conditions[] = "r.OrderID IN ($placeholders)";
      $params = array_merge($params, $matchedOrders);
    } else {
      $conditions[] = "1 = 0"; // No matches, force empty result
    }
  }

  if (!empty($startDate)) {
    $conditions[] = "r.DateIssued >= ?";
    $params[] = $startDate;
  }
  if (!empty($endDate)) {
    $conditions[] = "r.DateIssued <= ?";
    $params[] = $endDate;
  }

  $whereClause = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

  // Get total count for pagination
  $countQuery = "SELECT COUNT(*) as total FROM Receipts r $whereClause";
  $countStmt = $conn->prepare($countQuery);
  $countStmt->execute($params);
  $totalTransactions = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];

  // Pagination
  $transactionsPerPage = 20;
  $totalPages = ceil($totalTransactions / $transactionsPerPage);
  $page = isset($_GET['page']) ? max(1, min($totalPages, intval($_GET['page']))) : 1;
  $offset = ($page - 1) * $transactionsPerPage;

  // Get transactions with pagination
  $stmt = $conn->prepare("
    SELECT 
      r.ReceiptID,
      r.OrderID,
      r.TotalAmount,
      r.Discount,
      pm.MethodName AS PaymentMethod,
      r.DateIssued,
      u.Username AS ProcessedBy,
      (SELECT SUM(od.Price * od.Quantity) 
       FROM OrderDetails od 
       WHERE od.OrderID = o.OrderID) AS Subtotal,
      (SELECT SUM(ri.QuantityRefunded * od.Price)
       FROM RefundedItems ri
       JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
       WHERE ri.OrderID = o.OrderID) AS RefundAmount,
      (SELECT COUNT(*) > 0
       FROM RefundedItems ri
       WHERE ri.OrderID = o.OrderID) AS HasRefunds
    FROM Receipts r
    JOIN Orders o ON r.OrderID = o.OrderID
    JOIN Users u ON o.UserID = u.UserID
    JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
    $whereClause
    GROUP BY r.ReceiptID
    ORDER BY r.DateIssued DESC
    LIMIT $transactionsPerPage OFFSET $offset
  ");
  $stmt->execute($params);
  $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // Get transaction statistics
  $statsQuery = "
    SELECT 
      COUNT(*) as TotalTransactions,
      SUM(r.TotalAmount) as GrossRevenue,
      (SELECT COALESCE(SUM(ri.QuantityRefunded * od.Price), 0)
       FROM RefundedItems ri
       JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
       WHERE ri.RefundedAt BETWEEN DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) AND CURRENT_DATE) as TotalRefunds,
      AVG(r.TotalAmount) as AverageTransaction,
      MAX(r.TotalAmount) as LargestTransaction
    FROM Receipts r
    WHERE r.DateIssued BETWEEN DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) AND CURRENT_DATE
";
  $statsStmt = $conn->query($statsQuery);
  $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

  // Get payment method breakdown
  $paymentMethodsQuery = "
    SELECT 
      pm.MethodName,
      COUNT(r.ReceiptID) as Count,
      SUM(r.TotalAmount) as Total
    FROM Receipts r
    JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
    WHERE r.DateIssued BETWEEN DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) AND CURRENT_DATE
    GROUP BY pm.MethodName
    ORDER BY Total DESC
  ";
  $paymentMethodsStmt = $conn->query($paymentMethodsQuery);
  $paymentMethods = $paymentMethodsStmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
  die("❌ Error loading transactions: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transaction Records</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="css/toast-notifications.css">
  <!-- Toastify CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
  <style>
    .discount-cell {
      color: #e74c3c;
      font-weight: bold;
    }
    .subtotal-cell {
      color: #3498db;
    }
    .transaction-row {
      cursor: pointer;
    }
    .transaction-row:hover {
      background-color: #f5f5f5;
    }
    .item-details-row {
      background-color: #f9f9f9;
    }
    .item-details-content {
      padding: 15px;
    }
    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.4);
    }
    .modal.show {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .modal-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      width: 80%;
      max-width: 500px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    .close:hover {
      color: black;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .form-group label {
      display: block;
      margin-bottom: 5px;
    }
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 20px;
    }
    #refundItemsTable {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    #refundItemsTable th, #refundItemsTable td {
      padding: 8px;
      border: 1px solid #ddd;
      text-align: left;
    }
    #refundItemsTable th {
      background-color: #f2f2f2;
    }
    .refund-qty-input {
      width: 60px;
    }
    .topcon{

      top: 100px;
      background: white;
      z-index: 1000;
      padding: 10px;
      border-bottom: 1px solid #ccc;
    }
    .refund-btn {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 5px 10px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.9rem;
    }
    .refund-btn:hover {
      background-color: #c0392b;
    }
    /* Button Styles */
.btn-export-pdf {
  background-color: #28a745; /* Green background */
  color: white; /* White text */
  font-size: 0.875rem; /* Medium text size */
  padding: 8px 16px; /* Padding around the text */
  border-radius: 5px; /* Rounded corners */
  border: none; /* Remove border */
  cursor: pointer; /* Pointer cursor on hover */
  transition: background-color 0.3s ease, transform 0.3s ease; /* Smooth hover effects */
  text-align: center; /* Center text inside the button */
  display: inline-block; /* Ensure it behaves like a block element, but allows other elements on the same line */
}

.btn-export-pdf:hover {
  background-color: #218838; /* Darker green on hover */
  transform: scale(1.05); /* Slightly enlarge button on hover */
}

.btn-export-pdf:active {
  background-color: #1e7e34; /* Even darker green when clicked */
}

.btn-export-pdf:focus {
  outline: none; /* Remove focus outline */
}

/* Button for small screens */
@media (max-width: 576px) {
  .btn-export-pdf {
    font-size: 0.75rem; /* Smaller font size for small screens */
    padding: 6px 12px; /* Adjust padding */
  }
}

/* Transaction Stats Dashboard */
.transaction-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.stat-card {
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  padding: 20px;
  text-align: center;
  transition: transform 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
}

.stat-card h3 {
  font-size: 1.8rem;
  margin: 0;
  color: #4a934a;
}

.stat-card p {
  color: #777;
  margin: 10px 0 0;
}

.payment-methods {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 20px;
}

.payment-method-card {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 15px;
  flex: 1;
  min-width: 150px;
}

.payment-method-card h4 {
  margin: 0 0 10px;
  color: #333;
}

.payment-method-card .amount {
  font-size: 1.2rem;
  font-weight: bold;
  color: #4a934a;
}

.payment-method-card .count {
  font-size: 0.9rem;
  color: #777;
  margin-top: 5px;
}

/* Pagination styles */
.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 5px;
}

.pagination a, .pagination span {
  padding: 8px 12px;
  border: 1px solid #ddd;
  color: #333;
  text-decoration: none;
  border-radius: 4px;
}

.pagination a:hover {
  background-color: #f5f5f5;
}

.pagination .active {
  background-color: #4a934a;
  color: white;
  border-color: #4a934a;
}

.pagination .disabled {
  color: #aaa;
  cursor: not-allowed;
}
.header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.damaged-items-container {
    margin-top: 10px;  /* Ensure the link is directly underneath */
}

.damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    display: block;
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}

  /* Refund indicator styles */
  .has-refunds {
    background-color: #fff8f8;
  }
  
  .refund-badge {
    display: inline-block;
    background-color: #e74c3c;
    color: white;
    font-size: 0.7rem;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: 5px;
    vertical-align: middle;
  }
  
  .original-amount {
    text-decoration: line-through;
    color: #999;
    display: block;
  }
  
  .refund-amount {
    color: #e74c3c;
    font-size: 0.9rem;
    display: block;
  }
  
  .net-amount {
    font-weight: bold;
    display: block;
  }
  
  .negative {
    color: #e74c3c;
  }
  </style>
</head>

<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>

<div class="main-content-wrapper">
  <main class="content">
    <div class="topcon">
      <h1>Transaction Records</h1>

      <a href="refundeditems.php" class="damaged-items-link">>>Refunded Items</a>

      <!-- Transaction Stats Dashboard -->
      <div class="transaction-stats">
        <div class="stat-card">
          <h3><?= number_format($stats['TotalTransactions']) ?></h3>
          <p>Transactions (30 days)</p>
        </div>
        
        <div class="stat-card">
          <h3>₱<?= number_format($stats['GrossRevenue'], 2) ?></h3>
          <p>Gross Revenue (30 days)</p>
        </div>
        
        <div class="stat-card">
          <h3 class="negative">₱<?= number_format($stats['TotalRefunds'], 2) ?></h3>
          <p>Total Refunds (30 days)</p>
        </div>
        
        <div class="stat-card">
          <h3>₱<?= number_format($stats['GrossRevenue'] - $stats['TotalRefunds'], 2) ?></h3>
          <p>Net Revenue (30 days)</p>
        </div>
      </div>
      

      <form method="GET" class="search-sort-container" style="margin-bottom: 20px;">
        <input type="text" name="search" placeholder="Search by user or product..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        
        <label>From: <input type="date" name="start_date" value="<?= $_GET['start_date'] ?? '' ?>"></label>
        <label>To: <input type="date" name="end_date" value="<?= $_GET['end_date'] ?? '' ?>"></label>
        
        <button type="submit" class="btn btn-primary">Filter</button>
      </form>
    </div>
    
    <div class="container">
      <table class="table">
        <thead>
          <tr>
            <th>Transaction #</th>
            <th>Processed By</th>
            <th>Receipt ID</th>
            <th>Order ID</th>
            <th>Subtotal</th>
            <th>Discount</th>
            <th>Total</th>
            <th>Payment Method</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($transactions): ?>
  <?php $counter = ($page - 1) * $transactionsPerPage + 1; ?>
  <?php foreach ($transactions as $row): 
    $netAmount = $row['TotalAmount'] - ($row['RefundAmount'] ?? 0);
    $refundClass = $row['HasRefunds'] ? 'has-refunds' : '';
  ?>
    <tr class="transaction-row <?= $refundClass ?>" data-order-id="<?= $row['OrderID'] ?>">
      <td><strong>#<?= $counter++ ?></strong></td>
      <td><?= htmlspecialchars($row['ProcessedBy']) ?></td>
      <td><?= htmlspecialchars($row['ReceiptID']) ?></td>
      <td><?= htmlspecialchars($row['OrderID']) ?></td>
      <td class="subtotal-cell">₱<?= number_format($row['Subtotal'], 2) ?></td>
      <td class="discount-cell">-₱<?= number_format($row['Discount'], 2) ?></td>
      <td>
        <?php if ($row['HasRefunds']): ?>
          <span class="original-amount">₱<?= number_format($row['TotalAmount'], 2) ?></span>
          <span class="refund-amount negative">-₱<?= number_format($row['RefundAmount'], 2) ?></span>
          <span class="net-amount">₱<?= number_format($netAmount, 2) ?></span>
          <span class="refund-badge">Refunded</span>
        <?php else: ?>
          ₱<?= number_format($row['TotalAmount'], 2) ?>
        <?php endif; ?>
      </td>
      <td><?= htmlspecialchars($row['PaymentMethod']) ?></td>
      <td><?= date('M d, Y', strtotime($row['DateIssued'])) ?></td>
      <td>
        <!-- Export Button -->
        <a href="generate_receipt.php?order_id=<?= $row['OrderID'] ?>" class="btn-export-pdf" target="_blank">
          Export 
        </a>
      </td>
    </tr>
    <tr class="item-details-row" style="display:none;">
      <td colspan="10">
        <div class="item-details-content">
          <table class="item-table" style="width:100%">
            <thead>
              <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Refunded</th>
                <th>Subtotal</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="items-<?= $row['OrderID'] ?>">
              <!-- Items will be loaded here -->
            </tbody>
          </table>
        </div>
      </td>
    </tr>
  <?php endforeach; ?>
<?php else: ?>
  <tr><td colspan="10">No transactions found.</td></tr>
<?php endif; ?>
        </tbody>
      </table>
      
      <!-- Pagination -->
      <?php if ($totalPages > 1): ?>
        <div class="pagination">
          <?php if ($page > 1): ?>
            <a href="?page=1<?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= !empty($startDate) ? '&start_date=' . urlencode($startDate) : '' ?><?= !empty($endDate) ? '&end_date=' . urlencode($endDate) : '' ?>">First</a>
            <a href="?page=<?= $page - 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= !empty($startDate) ? '&start_date=' . urlencode($startDate) : '' ?><?= !empty($endDate) ? '&_date=' . urlencode($endDate) : '' ?>">Previous</a>
          <?php else: ?>
            <span class="disabled">First</span>
            <span class="disabled">Previous</span>
          <?php endif; ?>
          
          <?php
          $startPage = max(1, $page - 2);
          $endPage = min($totalPages, $page + 2);
          
          for ($i = $startPage; $i <= $endPage; $i++): ?>
            <?php if ($i == $page): ?>
              <span class="active"><?= $i ?></span>
            <?php else: ?>
              <a href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= !empty($startDate) ? '&start_date=' . urlencode($startDate) : '' ?><?= !empty($endDate) ? '&_date=' . urlencode($endDate) : '' ?>"><?= $i ?></a>
            <?php endif; ?>
          <?php endfor; ?>
          
          <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= !empty($startDate) ? '&start_date=' . urlencode($startDate) : '' ?><?= !empty($endDate) ? '&_date=' . urlencode($endDate) : '' ?>">Next</a>
            <a href="?page=<?= $totalPages ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?><?= !empty($startDate) ? '&start_date=' . urlencode($startDate) : '' ?><?= !empty($endDate) ? '&_date=' . urlencode($endDate) : '' ?>">Last</a>
          <?php else: ?>
            <span class="disabled">Next</span>
            <span class="disabled">Last</span>
          <?php endif; ?>
        </div>
      <?php endif; ?>
      
      <div style="margin-top: 20px; text-align: center; color: #777;">
        Showing <?= count($transactions) ?> of <?= $totalTransactions ?> transactions
      </div>
    </div>
  </main>
</div>


<!-- Refund Modal -->
<div class="modal" id="refundModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('refundModal')">&times;</span>
    <h2>Refund Item</h2>
    <form id="refundForm" method="POST" action="process_refund.php">
      <input type="hidden" name="order_id" id="refund_order_id">
      <input type="hidden" name="product_id" id="refund_product_id">

      <p><strong>Product:</strong> <span id="refund_product_name"></span></p>
      <p><strong>Ordered:</strong> <span id="ordered_qty"></span> | <strong>Already Refunded:</strong> <span id="refunded_qty"></span></p>

      <div class="form-group">
        <label for="refund_qty">Quantity to Refund</label>
        <input type="number" id="refund_qty" name="refund_qty" min="1" value="1" required>
      </div>

      <div class="form-group">
        <label for="condition">Condition</label>
        <select name="condition" id="condition" required>
          <option value="">Select</option>
          <option value="PRISTINE">Pristine</option>
          <option value="DAMAGED">Damaged</option>
        </select>
      </div>

      <div class="form-actions">
  <button type="button" class="btn btn-secondary" onclick="closeModal('refundModal')">Cancel</button>
  <button type="button" class="btn btn-danger" onclick="submitRefundForm()">Confirm Refund</button>
</div>
    </form>
  </div>
</div>



<!-- Toast container will be created by the JS -->
<script src="js/toast-notifications.js"></script>
<script>
  function submitRefundForm() {
  const form = document.getElementById('refundForm');
  if (form) {
    form.submit(); // 🚀 This triggers a regular POST submit to process_refund.php
  } else {
    alert("Form not found!");
  }
}
document.addEventListener('DOMContentLoaded', function () {
  console.log('Page loaded, initializing scripts...');

  // Close modal function
  window.closeModal = function (modalId) {
    console.log('Closing modal:', modalId);
    document.getElementById(modalId).classList.remove('show');
  };

  // Toggle item details
  document.querySelectorAll('.transaction-row').forEach(row => {
    row.addEventListener('click', function (e) {
      if (e.target.tagName === 'BUTTON') return;

      const orderId = this.dataset.orderId;
      console.log('Toggling details for order:', orderId);
      const detailsRow = this.nextElementSibling;
      const detailsContainer = detailsRow.querySelector('.item-details-content');

      if (detailsRow.style.display === 'none') {
        detailsRow.style.display = 'table-row';

        if (!detailsContainer.dataset.loaded) {
          console.log('Loading items for order:', orderId);
          fetch(`get_order_items.php?order_id=${orderId}`)
            .then(res => res.text())
            .then(html => {
              detailsContainer.querySelector('tbody').innerHTML = html;
              detailsContainer.dataset.loaded = true;

              detailsContainer.querySelectorAll('.refund-btn').forEach(btn => {
                btn.addEventListener('click', function (e) {
                  e.preventDefault();
                  e.stopPropagation();
                  const { orderId, productId, orderedQty, refundedQty, productName } = this.dataset;
                  openItemRefundModal(orderId, productId, orderedQty, refundedQty, productName);
                });
              });
            })
            .catch(err => {
              console.error('Error loading items:', err);
              detailsContainer.querySelector('tbody').innerHTML = "<tr><td colspan='5'>❌ Failed to load items.</td></tr>";
            });
        }
      } else {
        detailsRow.style.display = 'none';
      }
    });
  });

  // Open refund modal
  window.openItemRefundModal = function (orderId, productId, orderedQty, refundedQty, productName) {
    console.log('Opening refund modal for:', { orderId, productId, productName });

    const maxRefundable = parseInt(orderedQty) - parseInt(refundedQty);
    if (maxRefundable <= 0) {
      toast.warning("This item has already been fully refunded.");
      return;
    }

    document.getElementById('refund_order_id').value = orderId;
    document.getElementById('refund_product_id').value = productId;
    document.getElementById('refund_product_name').textContent = productName;
    document.getElementById('ordered_qty').textContent = orderedQty;
    document.getElementById('refunded_qty').textContent = refundedQty;

    const qtyInput = document.getElementById('refund_qty');
    qtyInput.value = 1;
    qtyInput.max = maxRefundable;

    document.getElementById('refundModal').classList.add('show');
  };

  // Form submission handler
  const refundForm = document.getElementById('refundForm');
  if (refundForm) {
    refundForm.addEventListener('submit', function (e) {
      e.preventDefault();
      console.log('Submit button clicked');

      toast.info('Processing refund...', 'Please wait');

      const formData = new FormData(refundForm);
      for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
      }

      fetch('process_refund.php', {
        method: 'POST',
        body: formData
      })
      .then(response => {
        console.log('Response status:', response.status);
        return response.json();
      })
      .then(data => {
        console.log('Refund response:', data);
        if (data.success) {
          toast.success(data.message, 'Refund Successful');
          closeModal('refundModal');
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        } else {
          toast.error(data.message || 'Refund failed', 'Refund Error');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        toast.error('Unexpected error occurred.', 'System Error');
      });
    });
  } else {
    console.error('Refund form not found!');
  }

  // Optional test toast
  window.testToast = function () {
    toast.success('Test success message');
    setTimeout(() => toast.error('Test error message'), 1000);
    setTimeout(() => toast.info('Test info message'), 2000);
  };
});
</script>

</body>
</html>
