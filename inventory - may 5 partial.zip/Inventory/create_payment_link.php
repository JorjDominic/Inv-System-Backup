<?php
// create_payment_link.php
session_start();
require_once 'config/database.php';
require_once 'config/paymongo.php';

// Enable error logging
error_reporting(E_ALL);
ini_set('display_errors', 0);
error_log('Payment link creation started');

header('Content-Type: application/json');

// Check if order data exists
if (!isset($_SESSION['order_data'])) {
    echo json_encode(['success' => false, 'message' => 'No order data found']);
    exit;
}

$orderData = $_SESSION['order_data'];
error_log('Order data: ' . json_encode($orderData));

try {
    // Start transaction
    $conn->beginTransaction();
    
    // Get or create customer ID
    $isLoggedIn = isset($_SESSION['user_id']);
    $customerId = null;
    
    if ($isLoggedIn) {
        $stmt = $conn->prepare("SELECT CustomerID FROM Customers WHERE UserID = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($customer) {
            $customerId = $customer['CustomerID'];
        }
    }
    
    // If no customer record exists, create one
    if (!$customerId) {
        $nameParts = explode(' ', $orderData['customer_name'], 2);
        $firstName = $nameParts[0];
        $lastName = isset($nameParts[1]) ? $nameParts[1] : '';
        
        $stmt = $conn->prepare("
            INSERT INTO Customers (
                UserID, FirstName, LastName, Email, Phone
            ) VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $isLoggedIn ? $_SESSION['user_id'] : null,
            $firstName,
            $lastName,
            $orderData['email'],
            $orderData['contact_number']
        ]);
        
        $customerId = $conn->lastInsertId();
    }
    
    // Create order in database
    $stmt = $conn->prepare("
        INSERT INTO Orders (
            CustomerID, UserID, OrderDate, OrderStatus, 
            PickupDate, PickupCode, PickupNotes, TotalAmount
        ) VALUES (?, ?, NOW(), 'pending', ?, ?, ?, ?)
    ");
    
    $userId = $isLoggedIn ? $_SESSION['user_id'] : null;
    $stmt->execute([
        $customerId,
        $userId,
        $orderData['pickup_date'],
        $orderData['pickup_code'],
        $orderData['pickup_notes'] ?? '',
        $orderData['total_amount']
    ]);
    
    $orderId = $conn->lastInsertId();
    $_SESSION['current_order_id'] = $orderId;
    error_log('Order created with ID: ' . $orderId);
    
    // Insert order items
    $stmt = $conn->prepare("
        INSERT INTO OrderDetails (
            OrderID, ProductID, Quantity, Price
        ) VALUES (?, ?, ?, ?)
    ");
    
    foreach ($orderData['items'] as $item) {
        $stmt->execute([
            $orderId,
            $item['id'],
            $item['quantity'],
            $item['price']
        ]);
        
        // Update inventory (reduce quantity)
        $updateStmt = $conn->prepare("
            UPDATE Inventory 
            SET Quantity = Quantity - ? 
            WHERE ProductID = ? AND Quantity >= ?
        ");
        $updateStmt->execute([$item['quantity'], $item['id'], $item['quantity']]);
    }
    
    // Create PayMongo payment link
    $amount = intval($orderData['total_amount'] * 100); // Convert to cents
    $description = "Order #$orderId - " . date('Y-m-d H:i:s');
    
    // Generate URLs for success and failure redirects
    $successUrl = "payment_success.php?order_id=$orderId";
    $failedUrl = "payment_failed.php?order_id=$orderId";
    $backToMerchantUrl = "payment.php?order_id=$orderId";
    
    // Store these URLs in session for verification later
    $_SESSION['payment_success_url'] = $successUrl;
    $_SESSION['payment_failed_url'] = $failedUrl;
    $_SESSION['payment_merchant_url'] = $backToMerchantUrl;
    
    $curl = curl_init();
    
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.paymongo.com/v1/links",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode([
            'data' => [
                'attributes' => [
                    'amount' => $amount,
                    'description' => $description,
                    'remarks' => "Order #$orderId",
                    'currency' => 'PHP',
                    'billing' => [
                        'name' => $orderData['customer_name'],
                        'email' => $orderData['email'],
                        'phone' => $orderData['contact_number']
                    ],
                    // Add redirect URLs - these will work for both localhost and production
                    'success_url' => $successUrl,
                    'failed_url' => $failedUrl,
                    'back_to_merchant_url' => $backToMerchantUrl
                ]
            ]
        ]),
        CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "authorization: Basic " . base64_encode(PAYMONGO_SECRET_KEY . ":"),
            "content-type: application/json"
        ],
    ]);
    
    $apiResponse = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        throw new Exception("cURL Error: " . $err);
    }
    
    error_log('PayMongo API Response: ' . $apiResponse);
    $paymentLink = json_decode($apiResponse, true);
    
    if (!isset($paymentLink['data']) || !isset($paymentLink['data']['attributes']['checkout_url'])) {
        throw new Exception("Invalid response from PayMongo: " . $apiResponse);
    }
    
    // Check if PaymentLinks table exists
    $checkStmt = $conn->prepare("SHOW TABLES LIKE 'PaymentLinks'");
    $checkStmt->execute();
    $tableExists = $checkStmt->rowCount() > 0;
    
    if (!$tableExists) {
        // Create PaymentLinks table if it doesn't exist
        $conn->exec("
            CREATE TABLE IF NOT EXISTS PaymentLinks (
                PaymentLinkID INT AUTO_INCREMENT PRIMARY KEY,
                OrderID INT NOT NULL,
                LinkID VARCHAR(100) NOT NULL,
                ReferenceNumber VARCHAR(50) NOT NULL,
                CheckoutURL VARCHAR(255) NOT NULL,
                Amount DECIMAL(10,2) NOT NULL,
                Status VARCHAR(20) NOT NULL DEFAULT 'pending',
                CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
            )
        ");
    }
    
   // Store payment link details in database
   $stmt = $conn->prepare("
   INSERT INTO PaymentLinks (
       OrderID, LinkID, ReferenceNumber, CheckoutURL, Amount, Status
   ) VALUES (?, ?, ?, ?, ?, ?)
");

$stmt->execute([
   $orderId,
   $paymentLink['data']['id'],
   $paymentLink['data']['attributes']['reference_number'],
   $paymentLink['data']['attributes']['checkout_url'],
   $orderData['total_amount'],
   'pending'
]);

// Create transaction record
$stmt = $conn->prepare("
   INSERT INTO Transactions (
       OrderID, 
       Amount, 
       TransactionType, 
       PaymentMethodID, 
       Status
   ) VALUES (?, ?, 'online', ?, 'pending')
");

// Determine payment method ID (assuming PayMongo is method ID 3 - adjust as needed)
$paymentMethodId = 3; // This should match your PaymentMethods table ID for PayMongo

$stmt->execute([
   $orderId,
   $orderData['total_amount'],
   $paymentMethodId
]);

$transactionId = $conn->lastInsertId();

// Create Paymongo transaction record
$stmt = $conn->prepare("
   INSERT INTO PaymongoTransactions (
       TransactionID,
       PaymentIntentID,
       PaymentSourceID,
       PaymentMethod,
       CustomerID,
       CustomerName,
       CustomerEmail,
       CustomerPhone,
       Description
   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->execute([
   $transactionId,
   $paymentLink['data']['id'], // Using link ID as intent ID for now
   null, // Will be updated via webhook
   'payment_link', // Payment method type
   $customerId,
   $orderData['customer_name'],
   $orderData['email'],
   $orderData['contact_number'],
   $description
]);

// Store reference number in session for verification
$_SESSION['payment_reference'] = $paymentLink['data']['attributes']['reference_number'];
$_SESSION['payment_link_id'] = $paymentLink['data']['id'];
$_SESSION['transaction_id'] = $transactionId;

// Commit transaction
$conn->commit();

// Return success response
echo json_encode([
   'success' => true,
   'message' => 'Payment link created successfully',
   'checkout_url' => $paymentLink['data']['attributes']['checkout_url'],
   'reference_number' => $paymentLink['data']['attributes']['reference_number'],
   'order_id' => $orderId,
   'transaction_id' => $transactionId
]);

} catch (Exception $e) {
// Rollback transaction on error
$conn->rollBack();

error_log('Payment Link Error: ' . $e->getMessage());
error_log('Stack trace: ' . $e->getTraceAsString());

echo json_encode([
   'success' => false,
   'message' => 'Error creating payment link: ' . $e->getMessage()
]);
}
