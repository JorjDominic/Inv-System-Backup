<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3 && $_SESSION['role'] != 4)) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Get expired items count
$expiredCountQuery = "SELECT COUNT(*) as count FROM ExpiredItems";
$expiredCountStmt = $conn->query($expiredCountQuery);
$expiredCount = $expiredCountStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total loss value
$lossValueQuery = "SELECT SUM(e.Quantity * p.PurchasePrice) as total 
                  FROM ExpiredItems e 
                  JOIN Product p ON e.ProductID = p.ProductID";
$lossValueStmt = $conn->query($lossValueQuery);
$lossValue = $lossValueStmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

// Get expired items by month (for chart)
$monthlyExpiredQuery = "SELECT 
                        DATE_FORMAT(DateExpired, '%Y-%m') as month,
                        COUNT(*) as count
                      FROM ExpiredItems
                      WHERE DateExpired >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
                      GROUP BY month
                      ORDER BY month ASC";
$monthlyExpiredStmt = $conn->query($monthlyExpiredQuery);
$monthlyExpired = $monthlyExpiredStmt->fetchAll(PDO::FETCH_ASSOC);

// Get expired items by category
$categoryExpiredQuery = "SELECT 
                        c.CategoryName,
                        COUNT(*) as count,
                        SUM(e.Quantity) as total_quantity
                      FROM ExpiredItems e
                      JOIN Product p ON e.ProductID = p.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY c.CategoryName
                      ORDER BY count DESC";
$categoryExpiredStmt = $conn->query($categoryExpiredQuery);
$categoryExpired = $categoryExpiredStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Expired Items</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
  <style>
    .expired-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .stat-card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      padding: 20px;
      text-align: center;
      transition: transform 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
    }
    
    .stat-card h3 {
      font-size: 2rem;
      margin: 0;
      color: #e74c3c;
    }
    
    .stat-card p {
      color: #777;
      margin: 10px 0 0;
    }
    
    .chart-container {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 30px;
    }
    
    @media (max-width: 768px) {
      .chart-container {
        grid-template-columns: 1fr;
      }
    }
    
    .chart-card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      padding: 20px;
    }
    
    .chart-card h3 {
      margin-top: 0;
      color: #333;
      border-bottom: 2px solid #e74c3c;
      padding-bottom: 10px;
      margin-bottom: 20px;
    }
    
    tr.expired-item {
      background-color: #f8d7da !important;
    }
    
    .btn-back {
      background-color: #6c757d;
      color: white;
      margin-right: 10px;
    }
    
    .btn-back:hover {
      background-color: #5a6268;
    }
    
    .btn-report {
      background-color: #17a2b8;
      color: white;
    }
    
    .btn-report:hover {
      background-color: #138496;
    }
    .header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.damaged-items-container {
    margin-top: 10px;  /* Ensure the link is directly underneath */
}

.damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    display: block;
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}
.damaged-items-container {
    margin-top: 10px;  /* Ensure the link is directly underneath */
}

.header-container {
    display: flex;
    flex-direction: column; /* Stack the heading and the link vertically */
    justify-content: flex-start;
    align-items: flex-start;
    margin-bottom: 20px;
}

.damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    margin-top: 10px; /* Add space between the heading and the link */
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
<main class="content">
<div class="container">
  <div class="header-container">
    <h1>Expired Items Management</h1>
 
    <a href="inventory.php" class="damaged-items-link">Inventory<<</a>

  
  </div>

  <!-- Expired Items Stats Dashboard -->
  <div class="expired-stats">
    <div class="stat-card">
      <h3><?= $expiredCount ?></h3>
      <p>Total Expired Items</p>
    </div>
    
    <div class="stat-card">
      <h3>₱<?= number_format($lossValue, 2) ?></h3>
      <p>Total Loss Value</p>
    </div>
  </div>

  <!-- Charts Section -->
  <div class="chart-container">
    <div class="chart-card">
      <h3>Monthly Expired Items</h3>
      <canvas id="monthlyChart"></canvas>
    </div>
    
    <div class="chart-card">
      <h3>Expired Items by Category</h3>
      <canvas id="categoryChart"></canvas>
    </div>
  </div>

  <div class="search-sort-container">
    <div class="search-bar">
      <input type="text" id="searchInput" placeholder="Search expired items...">
      <button class="search-btn">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
        </svg>
      </button>
    </div>
    
    <div class="sort-options">
      <select id="sortSelect">
        <option value="">Sort By</option>
        <option value="date_desc">Date (Newest First)</option>
        <option value="date_asc">Date (Oldest First)</option>
        <option value="quantity_desc">Quantity (High-Low)</option>
        <option value="quantity_asc">Quantity (Low-High)</option>
      </select>
    </div>
  </div>
  
  <div class="table-container">
    <table class="table">
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Category</th>
          <th>Quantity</th>
          <th>Expiry Date</th>
          <th>Date Recorded</th>
          <th>Reported By</th>
          <th>Loss Value</th>
        </tr>
      </thead>
      <tbody>
        <?php
        try {
          $stmt = $conn->query("
            SELECT 
              e.ExpiredID,
              p.ProductName,
              c.CategoryName,
              e.Quantity,
              e.ExpiryDate,
              e.DateExpired,
              u.Username as ReportedBy,
              (e.Quantity * p.PurchasePrice) as LossValue,
              p.PurchasePrice
            FROM ExpiredItems e
            INNER JOIN Product p ON e.ProductID = p.ProductID
            INNER JOIN Category c ON p.CategoryID = c.CategoryID
            INNER JOIN Users u ON e.ReportedBy = u.UserID
            ORDER BY e.DateExpired DESC
          ");

          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr class='expired-item'>
              <td>" . htmlspecialchars($row['ProductName']) . "</td>
              <td>" . htmlspecialchars($row['CategoryName']) . "</td>
              <td>" . htmlspecialchars($row['Quantity']) . "</td>
              <td>" . htmlspecialchars($row['ExpiryDate']) . "</td>
              <td>" . htmlspecialchars($row['DateExpired']) . "</td>
              <td>" . htmlspecialchars($row['ReportedBy']) . "</td>
              <td>₱" . number_format($row['LossValue'], 2) . "</td>
            </tr>";
          }
        } catch (PDOException $e) {
          echo "<tr><td colspan='7'>❌ Error loading expired items: " . $e->getMessage() . "</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>
<?php include 'footer.php'; ?>
</main>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
  // Search functionality
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', filterItems);
  
  // Sort functionality
  const sortSelect = document.getElementById('sortSelect');
  sortSelect.addEventListener('change', sortItems);
  
  // Initialize charts
  initializeCharts();
});

// Filter items based on search input
function filterItems() {
  const searchValue = document.getElementById('searchInput').value.toLowerCase();
  const rows = document.querySelectorAll('.table tbody tr');
  
  rows.forEach(row => {
    const productName = row.cells[0].textContent.toLowerCase();
    const category = row.cells[1].textContent.toLowerCase();
    
    if (productName.includes(searchValue) || category.includes(searchValue)) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });
}

// Sort items based on selected option
function sortItems() {
  const sortValue = document.getElementById('sortSelect').value;
  const tbody = document.querySelector('.table tbody');
  const rows = Array.from(tbody.querySelectorAll('tr'));
  
  if (!sortValue) return;
  
  rows.sort((a, b) => {
    let aValue, bValue;
    
    if (sortValue === 'date_asc' || sortValue === 'date_desc') {
      aValue = new Date(a.cells[4].textContent);
      bValue = new Date(b.cells[4].textContent);
    } else if (sortValue === 'quantity_asc' || sortValue === 'quantity_desc') {
      aValue = parseInt(a.cells[2].textContent);
      bValue = parseInt(b.cells[2].textContent);
    }
    
    if (sortValue.endsWith('_asc')) {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Re-append sorted rows
  rows.forEach(row => tbody.appendChild(row));
}

// Initialize charts
function initializeCharts() {
  // Monthly chart data
  const monthlyData = <?= json_encode($monthlyExpired) ?>;
  const months = monthlyData.map(item => {
    const date = new Date(item.month + '-01');
    return date.toLocaleString('default', { month: 'short', year: 'numeric' });
  });
  const counts = monthlyData.map(item => item.count);
  
  // Category chart data
  const categoryData = <?= json_encode($categoryExpired) ?>;
  const categories = categoryData.map(item => item.CategoryName);
  const categoryCounts = categoryData.map(item => item.count);
  
  // Create monthly chart
  const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
  new Chart(monthlyCtx, {
    type: 'line',
    data: {
      labels: months,
      datasets: [{
        label: 'Expired Items',
        data: counts,
        backgroundColor: 'rgba(231, 76, 60, 0.2)',
        borderColor: 'rgba(231, 76, 60, 1)',
        borderWidth: 2,
        tension: 0.1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            precision: 0
          }
        }
      }
    }
  });
  
  // Create category chart
  const categoryCtx = document.getElementById('categoryChart').getContext('2d');
  new Chart(categoryCtx, {
    type: 'pie',
    data: {
      labels: categories,
      datasets: [{
        data: categoryCounts,
        backgroundColor: [
          'rgba(231, 76, 60, 0.7)',
          'rgba(241, 196, 15, 0.7)',
          'rgba(46, 204, 113, 0.7)',
          'rgba(52, 152, 219, 0.7)',
          'rgba(155, 89, 182, 0.7)',
          'rgba(230, 126, 34, 0.7)',
          'rgba(149, 165, 166, 0.7)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'right'
        }
      }
    }
  });
}
</script>
</body>
</html>
