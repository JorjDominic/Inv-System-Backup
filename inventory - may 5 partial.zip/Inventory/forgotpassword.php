<?php
require 'config/database.php';

// PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email']));

    // Check if user exists with that email
    $stmt = $conn->prepare("SELECT * FROM Users WHERE Email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $code = rand(100000, 999999); // Generate reset code

        // Store code in DB
        $update = $conn->prepare("UPDATE Users SET ResetCode = ? WHERE Email = ?");
        $update->execute([$code, $email]);

        // Send email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'b6664253@gmail.com';           // Your Gmail
            $mail->Password   = 'wbbkxuoxrvguckjj';             // App Password (no spaces)
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            $mail->setFrom('b6664253@gmail.com', "Adriana's Marketing");
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = "Reset your password - Adriana's Marketing";
            $mail->Body = "
                <p>Hi there,</p>
                <p>You requested a password reset at <strong>Adriana's Marketing</strong>.</p>
                <p>Your code is:</p>
                <h2>$code</h2>
                <p>Click below to reset:</p>
                <p><a href='http://localhost/php/Inventory/resetpassword.php'>Reset Password</a></p>
                <p>If you didn't request this, ignore this email.</p>
                <p style='font-size:14px;'>– Adriana's Marketing</p>
            ";
            $mail->AltBody = "Your code is $code. Visit http://localhost/php/Inventory/resetpassword.php to reset.";

            $mail->send();
            $message = "A reset code has been sent to $email";
            $messageType = "success";

        } catch (Exception $e) {
            $message = "Email sending failed: " . $mail->ErrorInfo;
            $messageType = "error";
        }
    } else {
        $message = "No account found with that email address.";
        $messageType = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Forgot Password - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/forgotpass.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
</head>
<body>
    <div class="container">
        <div class="screen">
            <!-- Background Shapes -->
            <div class="screen__background">
                <span class="screen__background__shape screen__background__shape4"></span>
                <span class="screen__background__shape screen__background__shape3"></span>
                <span class="screen__background__shape screen__background__shape2"></span>
                <span class="screen__background__shape screen__background__shape1"></span>
            </div>
            
            <!-- Forgot Password Form -->
            <div class="screen__content">
                <form class="forgot-form" method="POST">
                    <img src="logo.jpg" class="logo" alt="Adriana's Marketing Logo">
                    <h2>Forgot Password</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-envelope"></i>
                        <input type="email" name="email" class="login__input" placeholder="Enter your email" required>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Send Reset Code</span>
                        <i class="button__icon fas fa-paper-plane"></i>
                    </button>
                    
                    <p class="back-to-login">
                        <a href="index.php"><- Back to Login</a>
                    </p>
                    <p id="registerMessage" class="back-to-login">
                         <a href="resetpassword.php">Reset Password -></a>
                    </p>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script>
        // Show toast notification if there's a message
        <?php if ($message): ?>
            Toastify({
                text: "<?= addslashes($message) ?>",
                duration: 5000,
                gravity: "top",
                position: "center",
                backgroundColor: "<?= $messageType === 'success' ? '#4CAF50' : '#F44336' ?>",
                stopOnFocus: true,
                onClick: function() {
                    <?php if ($messageType === 'success'): ?>
                    window.location.href = "resetpassword.php";
                    <?php endif; ?>
                }
            }).showToast();
            
            <?php if ($messageType === 'success'): ?>
            // Add a small delay before showing the success action prompt
            setTimeout(function() {
                Toastify({
                    text: "Click here to continue to reset password",
                    duration: 5000,
                    gravity: "bottom",
                    position: "center",
                    backgroundColor: "#3498db",
                    stopOnFocus: true,
                    onClick: function() {
                        window.location.href = "resetpassword.php";
                    }
                }).showToast();
            }, 1000);
            <?php endif; ?>
        <?php endif; ?>
    </script>
</body>
</html>
