<?php
// payment_webhook.php
require_once 'config/database.php';
require_once 'config/paymongo.php';
require_once 'notification.php';

// Get the JSON payload
$payload = file_get_contents('php://input');
$event = json_decode($payload, true);

// Log the webhook for debugging
error_log('PayMongo Webhook Received: ' . $payload);

// Verify the event
if (!$event || !isset($event['data']) || !isset($event['data']['attributes'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid payload']);
    exit;
}

try {
    // Extract data from the event
    $data = $event['data'];
    $attributes = $data['attributes'];
    $eventType = $event['type'] ?? '';
    
    error_log('PayMongo Event Type: ' . $eventType);
    
    // Handle different event types
    if ($eventType === 'link.payment.paid' || $eventType === 'link.payment.failed') {
        // This is a payment link event
        $linkId = $attributes['link']['id'] ?? null;
        $isPaid = $eventType === 'link.payment.paid';
        
        if (!$linkId) {
            throw new Exception("Missing link ID in webhook payload");
        }
        
        error_log('Processing payment link event for link ID: ' . $linkId);
        
        // Find the order associated with this payment link
        $stmt = $conn->prepare("
            SELECT o.OrderID, o.CustomerID, o.TotalAmount 
            FROM PaymentLinks pl
            JOIN Orders o ON pl.OrderID = o.OrderID
            WHERE pl.LinkID = ?
        ");
        $stmt->execute([$linkId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            // Try to find by reference number as fallback
            $refNumber = $attributes['reference_number'] ?? null;
            if ($refNumber) {
                $stmt = $conn->prepare("
                    SELECT o.OrderID, o.CustomerID, o.TotalAmount 
                    FROM PaymentLinks pl
                    JOIN Orders o ON pl.OrderID = o.OrderID
                    WHERE pl.ReferenceNumber = ?
                ");
                $stmt->execute([$refNumber]);
                $order = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            if (!$order) {
                throw new Exception("Order not found for link ID: $linkId");
            }
        }
        
        error_log('Found order ID: ' . $order['OrderID']);
        
        // Update payment link status
        $stmt = $conn->prepare("
            UPDATE PaymentLinks 
            SET Status = ? 
            WHERE LinkID = ?
        ");
        $stmt->execute([$isPaid ? 'paid' : 'failed', $linkId]);
        
        // Update order status
        $stmt = $conn->prepare("
            UPDATE Orders 
            SET OrderStatus = ? 
            WHERE OrderID = ?
        ");
        $stmt->execute([$isPaid ? 'paid' : 'cancelled', $order['OrderID']]);
        
        // If payment was successful, send notification
        if ($isPaid) {
            // Get customer details
            $stmt = $conn->prepare("
                SELECT c.FirstName, c.LastName, c.Email, c.Phone
                FROM Customers c
                WHERE c.CustomerID = ?
            ");
            $stmt->execute([$order['CustomerID']]);
            $customer = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($customer && function_exists('send_notification')) {
                // Send payment confirmation notification
                $message = "Your payment for Order #{$order['OrderID']} has been received. Thank you for your purchase!";
                
                error_log('Payment notification sent to: ' . $customer['Email']);
            }
        }
    }
    
    // Log successful processing
    error_log('Webhook processed successfully');
    
    // Return success response
    http_response_code(200);
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    error_log('Webhook Error: ' . $e->getMessage());
    error_log('Stack trace: ' . $e->getTraceAsString());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}