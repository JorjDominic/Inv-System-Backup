<?php
session_start();
require('config/database.php');

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}

// Include TCPDF library
require_once('includes/tcpdf/tcpdf/tcpdf.php');

// Get parameters from URL
$reportType = $_GET['report_type'] ?? 'sales';
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Define report types
$reportTypes = [
    'sales' => 'Sales Report',
    'inventory' => 'Inventory Report',
    'expenses' => 'Expenses Report',
    'profit' => 'Profit & Loss Report',
    'expired' => 'Expired Items Report',
    'damaged' => 'Damaged Items Report',
    'low_stock' => 'Low Stock Report',
    'refunds' => 'Refunds Report'
];

// Create new PDF document
class MYPDF extends TCPDF {
    // Page header
    public function Header() {
        // Logo
        $image_file = 'images/logo.png';
        if (file_exists($image_file)) {
            $this->Image($image_file, 10, 10, 30, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        }
        
        // Set font
        $this->SetFont('helvetica', 'B', 16);
        // Title
        $this->Cell(0, 15, 'Adriana\'s Marketing', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        
        // Line break
        $this->Ln(20);
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

// Create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Adriana\'s Marketing');
$pdf->SetTitle($reportTypes[$reportType]);
$pdf->SetSubject($reportTypes[$reportType]);
$pdf->SetKeywords('Report, PDF, Inventory, Sales');

// Set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', 'B', 14);

// Report title
$pdf->Cell(0, 10, $reportTypes[$reportType], 0, 1, 'C');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 10, 'Period: ' . date('F d, Y', strtotime($startDate)) . ' to ' . date('F d, Y', strtotime($endDate)), 0, 1, 'C');
$pdf->Ln(5);

// Function to get report data based on type and date range
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            // Sales report query
            $query = "SELECT r.ReceiptID, r.TotalAmount, r.DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Receipts r
                      JOIN Orders o ON r.OrderID = o.OrderID
                      JOIN OrderDetails od ON o.OrderID = od.OrderID
                      JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                      JOIN Users u ON r.UserID = u.UserID
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY r.ReceiptID
                      ORDER BY r.DateIssued DESC";
            break;
            
        case 'inventory':
            // Inventory report query
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        case 'expenses':
            // Expenses report query
            $query = "SELECT e.ExpenseID, e.Description, e.Category, e.Amount, e.Date, 
                      CONCAT(u.FirstName, ' ', u.LastName) as RecordedBy
                      FROM Expenses e
                      JOIN Users u ON e.UserID = u.UserID
                      WHERE e.Date BETWEEN ? AND ?
                      ORDER BY e.Date DESC";
            break;
            
        case 'profit':
            // Profit & Loss report query
            $query = "SELECT 
                      (SELECT SUM(TotalAmount) FROM Receipts WHERE DateIssued BETWEEN ? AND ?) as GrossRevenue,
                      (SELECT SUM(Amount) FROM Expenses WHERE Date BETWEEN ? AND ?) as TotalExpenses,
                      (SELECT SUM(od.Price * ri.QuantityRefunded) 
                       FROM RefundedItems ri
                       JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                       WHERE ri.RefundedAt BETWEEN ? AND ?) as TotalRefunds,
                      (SELECT SUM(d.Quantity * p.PurchasePrice)
                       FROM DamagedItems d
                       JOIN Product p ON d.ProductID = p.ProductID
                       WHERE d.ReportedAt BETWEEN ? AND ?) as DamagedCost,
                      (SELECT SUM(LossValue)
                       FROM ExpiredItems
                       WHERE DateExpired BETWEEN ? AND ?) as ExpiredCost";
            break;
            
        case 'expired':
            // Expired items report query
            $query = "SELECT e.ExpiredID, p.ProductName, e.Quantity, e.ExpiryDate, 
                      e.DateExpired, CONCAT(u.FirstName, ' ', u.LastName) as ReportedBy, 
                      e.LossValue, c.CategoryName
                      FROM ExpiredItems e
                      JOIN Product p ON e.ProductID = p.ProductID
                      JOIN Users u ON e.ReportedBy = u.UserID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      WHERE e.DateExpired BETWEEN ? AND ?
                      ORDER BY e.DateExpired DESC";
            break;
            
        case 'damaged':
            // Damaged items report query
            $query = "SELECT d.DamageID, p.ProductName, d.Quantity, d.Reason, 
                      d.ReportedAt, CONCAT(u.FirstName, ' ', u.LastName) as ReportedBy, 
                      (d.Quantity * p.PurchasePrice) as LossAmount, c.CategoryName
                      FROM DamagedItems d
                      JOIN Product p ON d.ProductID = p.ProductID
                      JOIN Users u ON d.ReportedBy = u.UserID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      WHERE d.ReportedAt BETWEEN ? AND ?
                      ORDER BY d.ReportedAt DESC";
            break;
            
        case 'low_stock':
            // Low stock report query
            $lowStockThreshold = 10; // Define what "low stock" means
            $query = "SELECT p.ProductID, p.ProductName, SUM(i.Quantity) as TotalQuantity, 
                      c.CategoryName, p.PurchasePrice, p.SellingPrice
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      HAVING TotalQuantity <= ?
                      ORDER BY TotalQuantity ASC";
            break;
            
        case 'refunds':
            // Refunds report query
            $query = "SELECT ri.RefundID, p.ProductName, ri.QuantityRefunded, 
                      ri.ItemCondition, ri.RefundedAt, 
                      CONCAT(u.FirstName, ' ', u.LastName) as ProcessedBy,
                      (od.Price * ri.QuantityRefunded) as RefundAmount
                      FROM RefundedItems ri
                      JOIN Product p ON ri.ProductID = p.ProductID
                      JOIN Users u ON ri.ProcessedBy = u.UserID
                      JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                      WHERE ri.RefundedAt BETWEEN ? AND ?
                      ORDER BY ri.RefundedAt DESC";
            break;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        // Bind parameters based on report type
        switch ($reportType) {
            case 'inventory':
            case 'low_stock':
                if ($reportType === 'low_stock') {
                    $stmt->execute([10]); // Low stock threshold
                } else {
                    $stmt->execute();
                }
                break;
                
            case 'profit':
                $stmt->execute([$startDate, $endDate, $startDate, $endDate, $startDate, $endDate, $startDate, $endDate, $startDate, $endDate]);
                break;
                
            default:
                $stmt->execute([$startDate, $endDate]);
                break;
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        // Handle error
        echo "Error: " . $e->getMessage();
    }
    
    return $data;
}

// Get report data
$reportData = getReportData($conn, $reportType, $startDate, $endDate);

// Generate report content based on report type
switch ($reportType) {
    case 'sales':
        // Sales report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(20, 7, 'Receipt ID', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Date', 1, 0, 'C');
        $pdf->Cell(15, 7, 'Items', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Payment Method', 1, 0, 'C');
        $pdf->Cell(50, 7, 'Cashier', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalAmount = 0;
        foreach ($reportData as $sale) {
            $pdf->Cell(20, 6, $sale['ReceiptID'], 1, 0, 'C');
            $pdf->Cell(30, 6, date('M d, Y', strtotime($sale['DateIssued'])), 1, 0, 'C');
            $pdf->Cell(15, 6, $sale['ItemCount'], 1, 0, 'C');
            $pdf->Cell(30, 6, $sale['PaymentMethod'], 1, 0, 'C');
            $pdf->Cell(50, 6, $sale['Cashier'], 1, 0, 'L');
            $pdf->Cell(30, 6, 'PHP' . number_format($sale['TotalAmount'], 2), 1, 1, 'R');
            $totalAmount += $sale['TotalAmount'];
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(145, 7, 'Total Sales:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalAmount, 2), 1, 1, 'R');
        $pdf->Cell(145, 7, 'Transaction Count:', 1, 0, 'R');
        $pdf->Cell(30, 7, count($reportData), 1, 1, 'R');
        break;
        
    case 'inventory':
        // Inventory report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Product Name', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Category', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Quantity', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Purchase Price', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Total Value', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalValue = 0;
        $totalItems = 0;
        foreach ($reportData as $item) {
            $pdf->Cell(15, 6, $item['ProductID'], 1, 0, 'C');
            $pdf->Cell(60, 6, $item['ProductName'], 1, 0, 'L');
            $pdf->Cell(30, 6, $item['CategoryName'], 1, 0, 'C');
            $pdf->Cell(20, 6, $item['TotalQuantity'], 1, 0, 'C');
            $pdf->Cell(30, 6, 'PHP' . number_format($item['PurchasePrice'], 2), 1, 0, 'R');
            $pdf->Cell(30, 6, 'PHP' . number_format($item['TotalValue'], 2), 1, 1, 'R');
            $totalValue += $item['TotalValue'];
            $totalItems += $item['TotalQuantity'];
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(125, 7, 'Total Inventory Value:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalValue, 2), 1, 1, 'R');
        $pdf->Cell(125, 7, 'Total Items:', 1, 0, 'R');
        $pdf->Cell(30, 7, $totalItems, 1, 1, 'R');
        break;
        
    case 'expenses':
        // Expenses report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Description', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Category', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Date', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalExpenses = 0;
        foreach ($reportData as $expense) {
            $pdf->Cell(15, 6, $expense['ExpenseID'], 1, 0, 'C');
            $pdf->Cell(60, 6, $expense['Description'], 1, 0, 'L');
            $pdf->Cell(30, 6, $expense['Category'], 1, 0, 'C');
            $pdf->Cell(30, 6, date('M d, Y', strtotime($expense['Date'])), 1, 0, 'C');
            $pdf->Cell(30, 6, 'PHP' . number_format($expense['Amount'], 2), 1, 1, 'R');
            $totalExpenses += $expense['Amount'];
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(135, 7, 'Total Expenses:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalExpenses, 2), 1, 1, 'R');
        break;
        
    case 'profit':
        // Profit & Loss report
        if (!empty($reportData)) {
            $profitData = $reportData[0];
            $grossRevenue = $profitData['GrossRevenue'] ?? 0;
            $totalExpenses = $profitData['TotalExpenses'] ?? 0;
            $totalRefunds = $profitData['TotalRefunds'] ?? 0;
            $damagedCost = $profitData['DamagedCost'] ?? 0;
            $expiredCost = $profitData['ExpiredCost'] ?? 0;
            
            $netRevenue = $grossRevenue - $totalRefunds;
            $totalLosses = $damagedCost + $expiredCost;
            $netProfit = $netRevenue - $totalExpenses - $totalLosses;
            
            $pdf->SetFont('helvetica', 'B', 12);
            $pdf->Cell(0, 10, 'Profit & Loss Statement', 0, 1, 'C');
            $pdf->Ln(5);
            
            $pdf->SetFont('helvetica', 'B', 10);
            $pdf->Cell(100, 7, 'Revenue', 0, 1, 'L');
            
            $pdf->SetFont('helvetica', '', 10);
            $pdf->Cell(100, 7, 'Gross Revenue', 0, 0, 'L');
            $pdf->Cell(30, 7, 'PHP' . number_format($grossRevenue, 2), 0, 1, 'R');
            
            $pdf->Cell(100, 7, 'Total Refunds', 0, 0, 'L');
            $pdf->Cell(30, 7, 'PHP' . number_format($totalRefunds, 2), 0, 1, 'R');
            
            $pdf->SetFont('helvetica', 'B', 10);
            $pdf->Cell(100, 7, 'Net Revenue', 0, 0, 'L');
            $pdf->Cell(30, 7, 'PHP' . number_format($netRevenue, 2), 0, 1, 'R');
            $pdf->Ln(5);
            
            $pdf->Cell(100, 7, 'Expenses', 0, 1, 'L');
            
            $pdf->SetFont('helvetica', '', 10);
            $pdf->Cell(100, 7, 'Regular Expenses', 0, 0, 'L');
            $pdf->Cell(30, 7, 'PHP' . number_format($totalExpenses, 2), 0, 1, 'R');
            
            $pdf->Cell(100, 7, 'Damaged Inventory Cost', 0, 0, 'L');
            $pdf->Cell(30, 7, 'PHP' . number_format($damagedCost, 2), 0, 1, 'R');
            
            $pdf->Cell(100, 7, 'Expired Inventory Cost', 0, 0, 'L');
            $pdf->Cell(30, 7, 'PHP' . number_format($expiredCost, 2), 0, 1, 'R');
            
            $pdf->SetFont('helvetica', 'B', 10);
            $pdf->Cell(100, 7, 'Total Expenses & Losses', 0, 0, 'L');
            $pdf->Cell(30, 7, 'PHP' . number_format($totalExpenses + $totalLosses, 2), 0, 1, 'R');
            $pdf->Ln(5);
            
            $pdf->SetFont('helvetica', 'B', 12);
            $pdf->Cell(100, 10, 'Net Profit', 0, 0, 'L');
            $pdf->Cell(30, 10, 'PHP' . number_format($netProfit, 2), 0, 1, 'R');
            
            // Add profit margin calculation
            if ($netRevenue > 0) {
                $profitMargin = ($netProfit / $netRevenue) * 100;
                $pdf->SetFont('helvetica', '', 10);
                $pdf->Cell(100, 7, 'Profit Margin', 0, 0, 'L');
                $pdf->Cell(30, 7, number_format($profitMargin, 2) . '%', 0, 1, 'R');
            }
        } else {
            $pdf->Cell(0, 10, 'No profit data available for the selected period.', 0, 1, 'C');
        }
        break;
        
    case 'expired':
        // Expired items report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Product Name', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Quantity', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Expiry Date', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Loss Value', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalLoss = 0;
        $totalItems = 0;
        foreach ($reportData as $item) {
            $pdf->Cell(15, 6, $item['ExpiredID'], 1, 0, 'C');
            $pdf->Cell(60, 6, $item['ProductName'], 1, 0, 'L');
            $pdf->Cell(20, 6, $item['Quantity'], 1, 0, 'C');
            $pdf->Cell(30, 6, date('M d, Y', strtotime($item['ExpiryDate'])), 1, 0, 'C');
            $pdf->Cell(30, 6, 'PHP' . number_format($item['LossValue'], 2), 1, 1, 'R');
            $totalLoss += $item['LossValue'];
            $totalItems += $item['Quantity'];
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(125, 7, 'Total Loss Value:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalLoss, 2), 1, 1, 'R');
        $pdf->Cell(125, 7, 'Total Expired Items:', 1, 0, 'R');
        $pdf->Cell(30, 7, $totalItems, 1, 1, 'R');
        break;
        
    case 'damaged':
        // Damaged items report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Product Name', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Quantity', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Reported At', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Loss Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalLoss = 0;
        $totalItems = 0;
        foreach ($reportData as $item) {
            $pdf->Cell(15, 6, $item['DamageID'], 1, 0, 'C');
            $pdf->Cell(60, 6, $item['ProductName'], 1, 0, 'L');
            $pdf->Cell(20, 6, $item['Quantity'], 1, 0, 'C');
            $pdf->Cell(30, 6, date('M d, Y', strtotime($item['ReportedAt'])), 1, 0, 'C');
            $pdf->Cell(30, 6, 'PHP' . number_format($item['LossAmount'], 2), 1, 1, 'R');
            $totalLoss += $item['LossAmount'];
            $totalItems += $item['Quantity'];
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(125, 7, 'Total Loss Amount:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalLoss, 2), 1, 1, 'R');
        $pdf->Cell(125, 7, 'Total Damaged Items:', 1, 0, 'R');
        $pdf->Cell(30, 7, $totalItems, 1, 1, 'R');
        break;
        
    case 'low_stock':
        // Low stock report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Product Name', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Category', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Stock', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Purchase Price', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Selling Price', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalItems = 0;
        foreach ($reportData as $item) {
            $pdf->Cell(15, 6, $item['ProductID'], 1, 0, 'C');
            $pdf->Cell(60, 6, $item['ProductName'], 1, 0, 'L');
            $pdf->Cell(30, 6, $item['CategoryName'], 1, 0, 'C');
            $pdf->Cell(20, 6, $item['TotalQuantity'], 1, 0, 'C');
            $pdf->Cell(30, 6, 'PHP' . number_format($item['PurchasePrice'], 2), 1, 0, 'R');
            $pdf->Cell(30, 6, 'PHP' . number_format($item['SellingPrice'], 2), 1, 1, 'R');
            $totalItems += $item['TotalQuantity'];
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(125, 7, 'Total Low Stock Items:', 1, 0, 'R');
        $pdf->Cell(30, 7, count($reportData), 1, 1, 'R');
        $pdf->Cell(125, 7, 'Total Quantity:', 1, 0, 'R');
        $pdf->Cell(30, 7, $totalItems, 1, 1, 'R');
        break;
        
    case 'refunds':
        // Refunds report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Product Name', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Quantity', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Condition', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Refund Date', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalRefund = 0;
        $totalItems = 0;
        foreach ($reportData as $item) {
            $pdf->Cell(15, 6, $item['RefundID'], 1, 0, 'C');
            $pdf->Cell(60, 6, $item['ProductName'], 1, 0, 'L');
            $pdf->Cell(20, 6, $item['QuantityRefunded'], 1, 0, 'C');
            $pdf->Cell(20, 6, $item['ItemCondition'], 1, 0, 'C');
            $pdf->Cell(30, 6, date('M d, Y', strtotime($item['RefundedAt'])), 1, 0, 'C');
            $pdf->Cell(30, 6, 'PHP' . number_format($item['RefundAmount'], 2), 1, 1, 'R');
            $totalRefund += $item['RefundAmount'];
            $totalItems += $item['QuantityRefunded'];
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(125, 7, 'Total Refund Amount:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalRefund, 2), 1, 1, 'R');
        $pdf->Cell(125, 7, 'Total Refunded Items:', 1, 0, 'R');
        $pdf->Cell(30, 7, $totalItems, 1, 1, 'R');
        break;
}

// Add generation timestamp
$pdf->Ln(10);
$pdf->SetFont('helvetica', 'I', 8);
$pdf->Cell(0, 10, 'Report generated on: ' . date('F d, Y h:i A'), 0, 1, 'R');

// Output the PDF
$pdf->Output('Adrianas_Marketing_' . $reportTypes[$reportType] . '_' . date('Y-m-d') . '.pdf', 'D');
?>
