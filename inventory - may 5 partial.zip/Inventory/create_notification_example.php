<?php
// This is an example file showing how to create notifications
// You can use this as a reference for creating notifications in your application

session_start();
require('config/database.php');
require('notifications.php');

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}

// Example: Create a notification for a specific user
if (isset($_POST['create_notification'])) {
    $userID = $_POST['user_id'];
    $type = $_POST['notification_type'];
    $message = $_POST['message'];
    
    if (createNotification($conn, $userID, $type, $message)) {
        $success = "Notification created successfully!";
    } else {
        $error = "Failed to create notification.";
    }
}

// Example: Create a notification for all users
if (isset($_POST['create_notification_all'])) {
    $type = $_POST['notification_type_all'];
    $message = $_POST['message_all'];
    
    // Get all active users
    $stmt = $conn->prepare("SELECT UserID FROM Users WHERE Status = 1");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $successCount = 0;
    foreach ($users as $user) {
        if (createNotification($conn, $user['UserID'], $type, $message)) {
            $successCount++;
        }
    }
    
    if ($successCount > 0) {
        $success = "Created notifications for $successCount users!";
    } else {
        $error = "Failed to create notifications.";
    }
}

// Get all users for the dropdown
$stmt = $conn->prepare("SELECT UserID, FirstName, LastName FROM Users WHERE Status = 1");
$stmt->execute();
$allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Notifications - Adriana's Marketing</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/navbar.css">
    <style>
        .container {
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .card-header {
            margin-bottom: 20px;
        }
        
        .card-header h2 {
            margin: 0;
            color: var(--text-dark);
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: inherit;
        }
        
        .btn {
            padding: 10px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            background-color: var(--primary-color);
            color: white;
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>
    
    <div class="main-content-wrapper">
        <main class="content">
            <div class="container">
                <h1>Create Notifications</h1>
                
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>
                
                <div class="card">
                    <div class="card-header">
                        <h2>Create Notification for Specific User</h2>
                    </div>
                    <form method="POST">
                        <div class="form-group">
                            <label for="user_id">Select User</label>
                            <select name="user_id" id="user_id" class="form-control" required>
                                <option value="">-- Select User --</option>
                                <?php foreach ($allUsers as $user): ?>
                                    <option value="<?= $user['UserID'] ?>">
                                        <?= htmlspecialchars($user['FirstName'] . ' ' . $user['LastName']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="notification_type">Notification Type</label>
                            <select name="notification_type" id="notification_type" class="form-control" required>
                                <option value="">-- Select Type --</option>
                                <option value="inventory_update">Inventory Update</option>
                                <option value="order_status">Order Status</option>
                                <option value="low_stock">Low Stock Alert</option>
                                <option value="report_ready">Report Ready</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea name="message" id="message" class="form-control" rows="3" required></textarea>
                        </div>
                        <button type="submit" name="create_notification" class="btn">Create Notification</button>
                    </form>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h2>Create Notification for All Users</h2>
                    </div>
                    <form method="POST">
                        <div class="form-group">
                            <label for="notification_type_all">Notification Type</label>
                            <select name="notification_type_all" id="notification_type_all" class="form-control" required>
                                <option value="">-- Select Type --</option>
                                <option value="inventory_update">Inventory Update</option>
                                <option value="order_status">Order Status</option>
                                <option value="low_stock">Low Stock Alert</option>
                                <option value="report_ready">Report Ready</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message_all">Message</label>
                            <textarea name="message_all" id="message_all" class="form-control" rows="3" required></textarea>
                        </div>
                        <button type="submit" name="create_notification_all" class="btn">Create Notification for All Users</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
