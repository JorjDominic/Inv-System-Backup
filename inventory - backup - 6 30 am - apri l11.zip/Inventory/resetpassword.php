<?php
require 'config/database.php';
$alert = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $email = strtolower(trim($_POST['email']));
    $code = trim($_POST['code']);
    $newPassword = trim($_POST['new_password']);  // Store the submitted password in a variable

    try {
        // Fetch the user matching email and reset code
        $stmt = $conn->prepare("SELECT * FROM Users WHERE Email = ? AND ResetCode = ?");
        $stmt->execute([$email, $code]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            // Invalid email or reset code
            $alert = 'Invalid email or reset code';
        } elseif (password_verify($newPassword, $user['Password'])) {
            // Check if the new password is the same as the old password
            $alert = 'New password cannot match current password';
        } else {
            // Hash the new password and update the user record
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT); // Use the new password here
            $conn->prepare("UPDATE Users SET Password = ?, ResetCode = NULL WHERE Email = ?")
                 ->execute([$hashedPassword, $email]);
            
            // Show success message and redirect to login
            echo '<script>alert("Password reset!"); window.location.href="index.php";</script>';
            exit();
        }
    } catch (PDOException $e) {
        // Handle any database errors
        $alert = 'System error - try again later';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/resetpass.css" rel="stylesheet">
    <style>
.password-wrapper {
    position: relative;
    margin-bottom: 20px;
}

.password-wrapper input {
    width: 100%;
    padding: 12px 40px 12px 15px; /* Adjusted padding for the icon */
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.3s ease;
}

/* Remove border color when clicked, but still keep focus effect */
.password-wrapper input:focus {
    border-color: #4a934a;
    outline: none;
    box-shadow: 0 0 0 2px rgba(74, 147, 74, 0.2);
}

.password-toggle {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    width: 24px;
    height: 24px;
    cursor: pointer;
    background: none;
    border: none;
    padding: 0;
}

/* Eye icon styling */
.password-toggle::before {
    content: "";
    position: absolute;
    width: 18px;
    height: 10px;
    border: 2px solid #777;
    border-radius: 50% 50% 0 0;
    border-bottom: none;
    top: 5px;
    left: 3px;
}

.password-toggle::after {
    content: "";
    position: absolute;
    width: 4px;
    height: 4px;
    background: #777;
    border-radius: 50%;
    top: 8px;
    left: 10px;
}

/* Show state - when password is visible */
.password-toggle.show::before {
    border-color: #4a934a;
}

.password-toggle.show::after {
    background: #4a934a;
}

/* Tooltip for the password toggle */
.password-toggle .tooltip {
    position: absolute;
    bottom: 100%;
    left: 50%;
    transform: translateX(-50%);
    background: #333;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    white-space: nowrap;
    opacity: 0;
    transition: opacity 0.3s;
    pointer-events: none;
    margin-bottom: 5px;
}

/* Tooltip visibility on hover */
.password-toggle:hover .tooltip {
    opacity: 1;
}

/* Remove outline and reset the focus when the password toggle is clicked */
.password-wrapper input:focus + .password-toggle {
    outline: none;
    border: none;
}

    </style>
</head>
<body>
    <div class="reset-box">
        <h2>Reset Password</h2>
        
        <?php if ($alert): ?>
            <script>alert("<?= addslashes($alert) ?>");</script>
        <?php endif; ?>

        <form method="POST">
            <input type="email" name="email" placeholder="Your Email" required>
            <input type="text" name="code" placeholder="Reset Code" required>

            <div class="password-wrapper">
                <input type="password" name="new_password" id="new_password" placeholder="New Password (8+ characters)" required>
                <span class="password-toggle" onclick="togglePassword()"></span>
            </div>

            <button type="submit">Reset Password</button>
        </form>

        <a href="index.php" class="back-link">← Back to Login</a>
    </div>

    <script>
        // Function to toggle password visibility
        function togglePassword() {
            const passwordInput = document.getElementById('new_password');
            const toggleIcon = document.querySelector('.password-toggle');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';  // Show password
                toggleIcon.textContent = "Hide";  // Change icon or text
            } else {
                passwordInput.type = 'password';  // Hide password
                toggleIcon.textContent = "Show";  // Change icon or text
            }
        }
        
        document.querySelector('form').addEventListener('submit', function(e) {
            const pw = document.querySelector('[name="new_password"]').value;
            if (pw.length < 8) {
                alert("Password must be at least 8 characters");
                e.preventDefault();
            }
        });
    </script>
</body>
</html>
