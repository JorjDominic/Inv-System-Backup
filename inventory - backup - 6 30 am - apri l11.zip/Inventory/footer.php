<html>
    <style>
        footer {
            background-color: #A0D995;
  color: #1E1E2F;
  text-align: center;
  padding: 15px 0;
  font-size: 14px;
  width: 100%;
  margin-top: auto;
  box-shadow: 0 -1px 5px rgba(0, 0, 0, 0.05);
}
    </style>
<footer>
  <p>&copy; <?php echo date("Y"); ?> Adriana's Marketing. All rights reserved.</p>
</footer>
</html>