<?php
// checkout.php
session_start();
require('config/database.php');
require_once 'config/paymongo.php';
require_once 'notification.php';

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Check if cart is empty
if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

// No login required for checkout
// But we can track if user is logged in for personalized features
$isLoggedIn = isset($_SESSION['user_id']);
$isCustomer = $isLoggedIn && $_SESSION['role'] == 5; // Assuming role 5 is customer

// Calculate cart totals
$cartItems = [];
$subtotal = 0;
$itemCount = 0;

if (!empty($_SESSION['cart'])) {
    // Get all product IDs in the cart
    $productIds = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));
    
    // Fetch product details for all items in cart
    $stmt = $conn->prepare("
        SELECT 
            p.ProductID,
            p.ProductName,
            p.SellingPrice,
            p.ImageURL,
            SUM(i.Quantity) as AvailableQuantity
        FROM Product p
        LEFT JOIN Inventory i ON p.ProductID = i.ProductID
        WHERE p.ProductID IN ($placeholders)
        GROUP BY p.ProductID, p.ProductName, p.SellingPrice, p.ImageURL
    ");
    $stmt->execute($productIds);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Build cart items with product details
    foreach ($products as $product) {
        $productId = $product['ProductID'];
        $cartQuantity = $_SESSION['cart'][$productId]['quantity'];
        $itemTotal = $product['SellingPrice'] * $cartQuantity;
        
        $cartItems[] = [
            'id' => $productId,
            'name' => $product['ProductName'],
            'price' => $product['SellingPrice'],
            'quantity' => $cartQuantity,
            'total' => $itemTotal,
            'image' => $product['ImageURL'],
            'availableQuantity' => $product['AvailableQuantity']
        ];
        
        $subtotal += $itemTotal;
        $itemCount += $cartQuantity;
    }
}

// Calculate tax and total
$taxRate = 0.12; // 12% tax
$tax = $subtotal * $taxRate;
$total = $subtotal + $tax;

// Get customer info if logged in
$customerInfo = null;
if ($isLoggedIn) {
    $stmt = $conn->prepare("
        SELECT * FROM Customers WHERE UserID = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $customerInfo = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $pickupDate = $_POST['pickup_date'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    // Simple validation
    $errors = [];
    if (empty($firstName)) $errors[] = 'First name is required';
    if (empty($lastName)) $errors[] = 'Last name is required';
    if (empty($email)) $errors[] = 'Email is required';
    if (empty($phone)) $errors[] = 'Phone number is required';
    if (empty($pickupDate)) $errors[] = 'Pickup date is required';
    
    // Validate pickup date is in the future
    $currentDate = date('Y-m-d');
    if ($pickupDate < $currentDate) {
        $errors[] = 'Pickup date must be today or in the future';
    }
    
    if (empty($errors)) {
        // Generate a unique pickup code
        $pickupCode = generate_pickup_code();
        
        // Store order data in session for payment processing
        $_SESSION['order_data'] = [
            'customer_name' => $firstName . ' ' . $lastName,
            'email' => $email,
            'contact_number' => $phone,
            'pickup_date' => $pickupDate,
            'pickup_code' => $pickupCode,
            'pickup_notes' => $notes,
            'total_amount' => $total,
            'items' => $cartItems
        ];
        
        // Redirect to payment page
        header('Location: payment.php');
        exit;
    }
}

// Get available pickup dates (next 7 days)
$pickupDates = [];
$currentDate = new DateTime();
for ($i = 0; $i < 7; $i++) {
    $date = clone $currentDate;
    $date->modify("+$i day");
    $pickupDates[] = $date->format('Y-m-d');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    /* Checkout Styles */
    .checkout-container {
      display: grid;
      grid-template-columns: 1fr 400px;
      gap: 30px;
    }
    
    .checkout-form {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
    }
    
    .checkout-summary {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      align-self: start;
      position: sticky;
      top: 20px;
    }
    
    .form-section {
      margin-bottom: 30px;
    }
    
    .section-title {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 15px;
    }
    
    .form-group {
      margin-bottom: 15px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 500;
      font-size: 0.9rem;
    }
    
    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
    }
    
    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: #4a934a;
      box-shadow: 0 0 0 2px rgba(74, 147, 74, 0.2);
    }
    
    .error-message {
      color: #e74c3c;
      font-size: 0.9rem;
      margin-top: 5px;
    }
    
    /* Order Summary */
    .summary-header {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .summary-items {
      margin-bottom: 20px;
      max-height: 300px;
      overflow-y: auto;
    }
    
    .summary-item {
      display: flex;
      margin-bottom: 10px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .summary-item-image {
      width: 50px;
      height: 50px;
      margin-right: 10px;
      background-color: #f8f9fa;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      overflow: hidden;
    }
    
    .summary-item-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .summary-item-details {
      flex: 1;
    }
    
    .summary-item-name {
      font-weight: 500;
      margin-bottom: 3px;
    }
    
    .summary-item-price {
      font-size: 0.9rem;
      color: #666;
    }
    
    .summary-item-quantity {
      font-size: 0.9rem;
      color: #666;
    }
    
    .summary-item-total {
      font-weight: 600;
      text-align: right;
      min-width: 80px;
    }
    
    .summary-totals {
      margin-top: 20px;
    }
    
    .summary-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    
    .summary-label {
      color: #666;
    }
    
    .summary-value {
      font-weight: 500;
    }
    
    .summary-total {
      font-size: 1.2rem;
      font-weight: 600;
      margin-top: 15px;
      padding-top: 15px;
      border-top: 1px solid #eee;
    }
    
    .checkout-btn {
      display: block;
      width: 100%;
      background-color: #4a934a;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 12px;
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      margin-top: 20px;
      transition: background-color 0.2s;
    }
    
    .checkout-btn:hover {
      background-color: #3a7a3a;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .checkout-container {
        grid-template-columns: 1fr;
      }
      
      .form-row {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>Checkout</h1>
        <div class="link-container">
          <a href="cart.php" class="inventory-link">&lt;&lt; Back to Cart</a>
        </div>
      </div>
      
      <form method="post" action="">
        <div class="checkout-container">
          <div class="checkout-form">
            <?php if (isset($errors) && !empty($errors)): ?>
              <div class="alert alert-danger">
                <ul>
                  <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endif; ?>
            
            <div class="form-section">
              <h2 class="section-title">Contact Information</h2>
              <div class="form-row">
                <div class="form-group">
                  <label for="first_name">First Name</label>
                  <input type="text" id="first_name" name="first_name" value="<?= $customerInfo['FirstName'] ?? '' ?>" required>
                </div>
                <div class="form-group">
                  <label for="last_name">Last Name</label>
                  <input type="text" id="last_name" name="last_name" value="<?= $customerInfo['LastName'] ?? '' ?>" required>
                </div>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" id="email" name="email" value="<?= $customerInfo['Email'] ?? '' ?>" required>
                </div>
                <div class="form-group">
                  <label for="phone">Phone Number</label>
                  <input type="tel" id="phone" name="phone" value="<?= $customerInfo['Phone'] ?? '' ?>" required>
                </div>
              </div>
            </div>
            
            <div class="form-section">
              <h2 class="section-title">Pickup Information</h2>
              <div class="form-group">
                <label for="pickup_date">Pickup Date</label>
                <select id="pickup_date" name="pickup_date" required>
                  <option value="">Select a date</option>
                  <?php foreach ($pickupDates as $date): ?>
                    <option value="<?= $date ?>"><?= date('l, F j, Y', strtotime($date)) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group">
                <label for="notes">Special Instructions (Optional)</label>
                <textarea id="notes" name="notes" rows="3"></textarea>
              </div>
            </div>
            
            <div class="form-section">
              <h2 class="section-title">Pickup Policy</h2>
              <div class="policy-info">
                <p>Please note the following pickup policies:</p>
                <ul>
                  <li>Orders must be picked up during our business hours (9:00 AM - 5:00 PM).</li>
                  <li>Please bring a valid ID for verification.</li>
                  <li>Your unique pickup code will be provided after payment.</li>
                  <li>Orders not picked up within 24 hours may be cancelled.</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div class="checkout-summary">
            <h2 class="summary-header">Order Summary</h2>
            <div class="summary-items">
              <?php foreach ($cartItems as $item): ?>
                <div class="summary-item">
                  <div class="summary-item-image">
                    <?php if ($item['image']): ?>
                      <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                    <?php else: ?>
                      <i class="fas fa-image" style="color: #ccc;"></i>
                    <?php endif; ?>
                  </div>
                  <div class="summary-item-details">
                    <div class="summary-item-name"><?= htmlspecialchars($item['name']) ?></div>
                    <div class="summary-item-price">₱<?= number_format($item['price'], 2) ?></div>
                    <div class="summary-item-quantity">Qty: <?= $item['quantity'] ?></div>
                  </div>
                  <div class="summary-item-total">₱<?= number_format($item['total'], 2) ?></div>
                </div>
              <?php endforeach; ?>
            </div>
            
            <div class="summary-totals">
              <div class="summary-row">
                <div class="summary-label">Subtotal (<?= $itemCount ?> items)</div>
                <div class="summary-value">₱<?= number_format($subtotal, 2) ?></div>
              </div>
              <div class="summary-row">
                <div class="summary-label">Tax (12%)</div>
                <div class="summary-value">₱<?= number_format($tax, 2) ?></div>
              </div>
              <div class="summary-row summary-total">
                <div class="summary-label">Total</div>
                <div class="summary-value">₱<?= number_format($total, 2) ?></div>
              </div>
            </div>
            
            <button type="submit" class="checkout-btn">
              Continue to Payment
            </button>
          </div>
        </div>
      </form>
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Disable past dates in the pickup date dropdown
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('pickup_date').setAttribute('min', today);
  });
</script>
</body>
</html>