<?php
session_start();
require('config/database.php');

header('Content-Type: application/json');

// Check permissions
// Ensure only admins/staff can perform update
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header("Location: index.php?toast=error&msg=" . urlencode("Unauthorized access"));
    exit;
}

// Get pagination parameters
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Build base query
$query = "SELECT 
            i.InventoryID, 
            p.ProductID,
            p.ProductName, 
            c.CategoryID,
            c.CategoryName,
            i.Quantity, 
            p.SellingPrice, 
            p.PurchasePrice, 
            i.DateReceived, 
            i.ExpiryDate
          FROM Inventory i
          JOIN Product p ON i.ProductID = p.ProductID
          JOIN Category c ON p.CategoryID = c.CategoryID
          WHERE 1=1";

// Apply filters
$params = [];
if (!empty($_GET['search'])) {
    $query .= " AND (p.ProductName LIKE ? OR c.CategoryName LIKE ? OR i.InventoryID = ?)";
    $searchTerm = '%' . $_GET['search'] . '%';
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    if (is_numeric($_GET['search'])) {
        $params[] = intval($_GET['search']);
    } else {
        $params[] = 0; // Invalid ID
    }
}

if (!empty($_GET['category'])) {
    $query .= " AND c.CategoryID = ?";
    $params[] = $_GET['category'];
}

// Status filters
if (!empty($_GET['status'])) {
    switch ($_GET['status']) {
        case 'low':
            $query .= " AND i.Quantity < 10 AND i.Quantity > 0";
            break;
        case 'out':
            $query .= " AND i.Quantity <= 0";
            break;
        case 'normal':
            $query .= " AND i.Quantity >= 10";
            break;
    }
}

// Expiry filters
if (!empty($_GET['expiry'])) {
    switch ($_GET['expiry']) {
        case '30':
            $query .= " AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)";
            break;
        case '60':
            $query .= " AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 60 DAY)";
            break;
        case '90':
            $query .= " AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 90 DAY)";
            break;
        case 'expired':
            $query .= " AND i.ExpiryDate < CURRENT_DATE AND i.Quantity > 0";
            break;
    }
}

// Sorting
$sortOptions = [
    'name_asc' => 'p.ProductName ASC',
    'name_desc' => 'p.ProductName DESC',
    'quantity_asc' => 'i.Quantity ASC',
    'quantity_desc' => 'i.Quantity DESC',
    'price_asc' => 'p.SellingPrice ASC',
    'price_desc' => 'p.SellingPrice DESC',
    'expiry_asc' => 'i.ExpiryDate ASC',
    'expiry_desc' => 'i.ExpiryDate DESC'
];

if (!empty($_GET['sort']) && isset($sortOptions[$_GET['sort']])) {
    $query .= " ORDER BY " . $sortOptions[$_GET['sort']];
} else {
    $query .= " ORDER BY i.InventoryID DESC";
}

// Get total count
$countQuery = "SELECT COUNT(*) as total FROM ($query) as subquery";
$countStmt = $conn->prepare($countQuery);
$countStmt->execute($params);
$totalItems = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPages = ceil($totalItems / $perPage);

// Add pagination to main query
$query .= " LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;

// Execute main query
$stmt = $conn->prepare($query);
$stmt->execute($params);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Return JSON response
echo json_encode([
    'items' => $items,
    'pagination' => [
        'current_page' => $page,
        'total_pages' => $totalPages,
        'total' => $totalItems,
        'visible' => count($items)
    ]
]);
?>