<?php
session_start();
require_once 'config/database.php';

// Initialize response
$response = [
    'success' => false,
    'message' => '',
    'cartCount' => 0,
    'itemTotal' => 0,
    'cartTotal' => 0
];

// Get action from request
$action = isset($_POST['action']) ? $_POST['action'] : '';

// Handle clear cart action
if ($action === 'clear') {
    try {
        // Clear the cart
        $_SESSION['cart'] = [];
        
        $response['success'] = true;
        $response['message'] = 'Cart cleared successfully';
        $response['cartCount'] = 0;
        $response['cartTotal'] = 0;
        
        // Return JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}

// For other actions, we need a product ID
$productId = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

// Validate product ID for non-clear actions
if ($productId <= 0) {
    $response['message'] = 'Invalid product ID';
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Handle remove action
if ($action === 'remove') {
    try {
        // Check if cart exists
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        // Remove item from cart
        if (isset($_SESSION['cart'][$productId])) {
            unset($_SESSION['cart'][$productId]);
            $response['message'] = 'Item removed from cart';
            $response['success'] = true;
        } else {
            $response['message'] = 'Item not found in cart';
            $response['success'] = false;
        }
        
        // Calculate cart count and total
        $cartCount = 0;
        $cartTotal = 0;
        foreach ($_SESSION['cart'] as $id => $item) {
            $cartCount += $item['quantity'];
            $cartTotal += $item['quantity'] * $item['price'];
        }
        
        $response['cartCount'] = $cartCount;
        $response['cartTotal'] = $cartTotal;
        
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } catch (Exception $e) {
        $response['message'] = 'Error: ' . $e->getMessage();
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}

// Handle update action
try {
    // Check if cart exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // If quantity is 0, remove item from cart
    if ($quantity <= 0) {
        if (isset($_SESSION['cart'][$productId])) {
            unset($_SESSION['cart'][$productId]);
            $response['message'] = 'Item removed from cart';
        } else {
            $response['message'] = 'Item not found in cart';
        }
    } else {
        // Check if product exists and has enough stock
        $stmt = $conn->prepare("
            SELECT 
                p.ProductID,
                p.SellingPrice,
                SUM(i.Quantity) as AvailableQuantity
            FROM Product p
            LEFT JOIN Inventory i ON p.ProductID = i.ProductID
            WHERE p.ProductID = ?
            GROUP BY p.ProductID, p.SellingPrice
        ");
        $stmt->execute([$productId]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$product) {
            $response['message'] = 'Product not found';
            echo json_encode($response);
            exit;
        }
        
        if ($product['AvailableQuantity'] < $quantity) {
            $response['message'] = 'Not enough stock available';
            echo json_encode($response);
            exit;
        }
        
        // Update cart
        $_SESSION['cart'][$productId]['quantity'] = $quantity;
        $response['itemTotal'] = $quantity * $product['SellingPrice'];
        $response['message'] = 'Cart updated successfully';
    }
    
    // Calculate cart count and total
    $cartCount = 0;
    $cartTotal = 0;
    foreach ($_SESSION['cart'] as $id => $item) {
        $cartCount += $item['quantity'];
        $cartTotal += $item['quantity'] * $item['price'];
    }
    
    $response['success'] = true;
    $response['cartCount'] = $cartCount;
    $response['cartTotal'] = $cartTotal;
    
} catch (PDOException $e) {
    $response['message'] = 'Database error: ' . $e->getMessage();
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);