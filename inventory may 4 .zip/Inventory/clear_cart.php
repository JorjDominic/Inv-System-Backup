<?php
session_start();

// Initialize response
$response = [
    'success' => false,
    'message' => ''
];

try {
    // Check if cart exists in session
    if (isset($_SESSION['cart'])) {
        // Clear the cart
        $_SESSION['cart'] = [];
        
        $response['success'] = true;
        $response['message'] = 'Cart cleared successfully';
    } else {
        $response['success'] = true;
        $response['message'] = 'Cart is already empty';
    }
} catch (Exception $e) {
    $response['message'] = 'Error: ' . $e->getMessage();
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);