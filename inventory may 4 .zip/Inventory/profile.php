<?php
session_start();
require('config/database.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM Users WHERE UserID = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['FirstName']);
    $last_name = trim($_POST['LastName']);
    $current_password = trim($_POST['current_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    $errors = [];
    $success = [];
    
    // Update basic info
    if ($first_name != $user['FirstName'] || $last_name != $user['LastName']) {
        $stmt = $conn->prepare("UPDATE Users SET FirstName = ?, LastName = ? WHERE UserID = ?");
        $stmt->execute([$first_name, $last_name, $user_id]);
        $success[] = "Profile information updated successfully.";
    }
    
    // Password change
    if (!empty($current_password) || !empty($new_password) || !empty($confirm_password)) {
        if (empty($current_password)) {
            $errors[] = "Current password is required to change password.";
        } elseif (!password_verify($current_password, $user['Password'])) {
            $errors[] = "Current password is incorrect.";
        } elseif ($new_password != $confirm_password) {
            $errors[] = "New passwords do not match.";
        } elseif (strlen($new_password) < 8) {
            $errors[] = "Password must be at least 8 characters long.";
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE Users SET Password = ? WHERE UserID = ?");
            $stmt->execute([$hashed_password, $user_id]);
            $success[] = "Password updated successfully.";
        }
    }
    
    // Store messages in session
    if (!empty($errors)) {
        $_SESSION['error_messages'] = $errors;
    }
    if (!empty($success)) {
        $_SESSION['success_messages'] = $success;
    }
    
    // Refresh user data
    header("Location: profilepage.php");
    exit();
}
?>
