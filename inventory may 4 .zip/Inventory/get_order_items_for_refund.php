<?php
require 'config/database.php';

if (!isset($_GET['order_id']) || !is_numeric($_GET['order_id'])) {
    http_response_code(400);
    echo "Invalid order ID.";
    exit;
}

$orderId = $_GET['order_id'];

try {
    // Get order items with refund information
    $stmt = $conn->prepare("
        SELECT 
            od.ProductID,
            p.ProductName,
            od.Price,
            od.Quantity,
            COALESCE(SUM(ri.QuantityRefunded), 0) AS RefundedQty
        FROM OrderDetails od
        JOIN Product p ON od.ProductID = p.ProductID
        LEFT JOIN RefundedItems ri ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
        WHERE od.OrderID = ?
        GROUP BY od.ProductID, p.ProductName, od.Price, od.Quantity
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($items)) {
        echo "<tr><td colspan='5'>No products found for this order.</td></tr>";
        exit;
    }

    foreach ($items as $item) {
        $subtotal = $item['Price'] * $item['Quantity'];
        $availableToRefund = $item['Quantity'] - $item['RefundedQty'];
        
        echo "<tr>";
        echo "<td>" . htmlspecialchars($item['ProductName']) . "</td>";
        echo "<td>₱" . number_format($item['Price'], 2) . "</td>";
        echo "<td>" . $item['Quantity'] . "</td>";
        echo "<td>₱" . number_format($subtotal, 2) . "</td>";
        echo "<td>";
        
        if ($availableToRefund > 0) {
            echo "<button class='refund-btn' 
                data-order-id='{$orderId}' 
                data-product-id='{$item['ProductID']}' 
                data-ordered-qty='{$item['Quantity']}' 
                data-refunded-qty='{$item['RefundedQty']}' 
                data-product-name='" . htmlspecialchars($item['ProductName']) . "'>
                Refund
            </button>";
        } else {
            echo "<span style='color: #e74c3c;'>Fully Refunded</span>";
        }
        
        echo "</td>";
        echo "</tr>";
    }
} catch (PDOException $e) {
    echo "<tr><td colspan='5'>❌ Error loading items: " . $e->getMessage() . "</td></tr>";
}
?>