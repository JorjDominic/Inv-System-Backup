<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login & Register - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <?php include 'includes/toast-head.php'; ?>
</head>
<body>
    <div class="container">
        <div class="screen" id="screen">
            <!-- Background Shapes -->
            <div class="screen__background">
                <span class="screen__background__shape screen__background__shape4"></span>
                <span class="screen__background__shape screen__background__shape3"></span>
                <span class="screen__background__shape screen__background__shape2"></span>
                <span class="screen__background__shape screen__background__shape1"></span>
            </div>
            
            <!-- Login Form -->
            <div class="screen__content">
                <form id="loginForm" class="login" method="POST" action="login.php">
                    <img src="logo.jpg" class="logo" alt="Adriana's Marketing Logo">
                    <h2>Login</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user"></i>
                        <input type="text" name="username" class="login__input" placeholder="Username" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-lock"></i>
                        <input type="password" id="password" name="password" class="login__input" placeholder="Password" required>
                        <span id="loginToggle" class="password-toggle" onclick="togglePassword('password', 'loginToggle')"></span>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Log In Now</span>
                        <i class="button__icon fas fa-chevron-right"></i>
                    </button>
                    
                    <p class="forgot-password">
                        <a href="forgotpassword.php">Forgot Password?</a>
                    </p>
                    
                    <p id="loginMessage" class="switch-form">
                        Don't have an account? <a href="#" onclick="switchForm('register')">Register here</a>
                    </p>
                </form>
                
                <!-- Register Form -->
                <form id="registerForm" class="login" style="display: none;" onsubmit="proceedToVerification(); return false;">
                    <h2>Register</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user"></i>
                        <input type="text" id="username" class="login__input" placeholder="Username" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user-edit"></i>
                        <input type="text" id="firstname" class="login__input" placeholder="First Name" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user-edit"></i>
                        <input type="text" id="lastname" class="login__input" placeholder="Last Name" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-lock"></i>
                        <input type="password" id="regpassword" class="login__input" placeholder="Password" required>
                        <span id="registerToggle" class="password-toggle" onclick="togglePassword('regpassword', 'registerToggle')"></span>
                    </div>
                    
                    <div id="passwordStrength" class="strength-message">
                        <ul>
                            <li id="length" class="invalid"><span>✗</span> At least 8 characters</li>
                            <li id="lowercase" class="invalid"><span>✗</span> A lowercase letter</li>
                            <li id="uppercase" class="invalid"><span>✗</span> An uppercase letter</li>
                            <li id="number" class="invalid"><span>✗</span> A number</li>
                        </ul>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Proceed</span>
                        <i class="button__icon fas fa-chevron-right"></i>
                    </button>
                    
                    <p id="registerMessage" class="switch-form">
                        Already have an account? <a href="#" onclick="switchForm('login')">Go back to login</a>
                    </p>

                </form>
                
                <!-- Verification Form -->
                <form id="verifyForm" class="login" style="display: none;" onsubmit="verifyAndRegister(); return false;">
                    <h2>Email Verification</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-envelope"></i>
                        <input type="email" id="email" class="login__input" placeholder="Enter Email" required>
                    </div>
                    
                    <button type="button" class="verification-btn" onclick="sendVerificationCode()">
                        <span class="button__text">Send Code</span>
                        <i class="button__icon fas fa-paper-plane"></i>
                    </button>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-key"></i>
                        <input type="text" id="code" class="login__input" placeholder="Enter verification code" required>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Verify & Register</span>
                        <i class="button__icon fas fa-chevron-right"></i>
                    </button>
                    
                    <p class="switch-form">
                        <a href="#" onclick="switchForm('register')">Go back</a>
                    </p>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Switch between forms
        function switchForm(formType) {
            const loginForm = document.getElementById("loginForm");
            const registerForm = document.getElementById("registerForm");
            const verifyForm = document.getElementById("verifyForm");
            const screen = document.getElementById("screen");
            
            // Hide all forms first
            loginForm.style.display = "none";
            registerForm.style.display = "none";
            verifyForm.style.display = "none";
            
            // Show the requested form
            if (formType === "login") {
                loginForm.style.display = "block";
                screen.classList.remove("register-mode");
                screen.classList.remove("verify-mode");
            } else if (formType === "register") {
                registerForm.style.display = "block";
                screen.classList.add("register-mode");
                screen.classList.remove("verify-mode");
            } else if (formType === "verify") {
                verifyForm.style.display = "block";
                screen.classList.remove("register-mode");
                screen.classList.add("verify-mode");
            }
        }
        
        // Toggle password visibility
        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = document.getElementById(iconId);
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.add('show');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('show');
            }
        }
        
        // Proceed to verification
       // Proceed to verification
function proceedToVerification() {
    const username = $('#username').val();
    const firstname = $('#firstname').val();
    const lastname = $('#lastname').val();
    const password = $('#regpassword').val();

    // Validate username
    const usernameRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
    if (!usernameRegex.test(username)) {
        Toastify({
            text: "Username must be at least 8 characters long and contain at least one letter and one number.",
            duration: 3000,
            gravity: "top",
            position: "center",
            backgroundColor: "#e74c3c"
        }).showToast();
        return false;
    }
    
    // Validate names
    const nameRegex = /^[a-zA-Z]+$/;
    if (!nameRegex.test(firstname) || !nameRegex.test(lastname)) {
        Toastify({
            text: "First Name and Last Name should only contain letters.",
            duration: 3000,
            gravity: "top",
            position: "center",
            backgroundColor: "#e74c3c"
        }).showToast();
        return false;
    }
    
    // Validate password
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(password)) {
        Toastify({
            text: "Password must be at least 8 characters long and include:\n- 1 uppercase letter\n- 1 lowercase letter\n- 1 number",
            duration: 3000,
            gravity: "top",
            position: "center",
            backgroundColor: "#e74c3c"
        }).showToast();
        return false;
    }
    
    // Check if username exists
    $.post('check_username.php', { username }, function (res) {
        const response = JSON.parse(res);
        if (response.status === 'success') {
            Toastify({
                text: response.message,
                duration: 2000,
                gravity: "top",
                position: "center",
                backgroundColor: "#2ecc71"
            }).showToast();
            
            // Store data in session storage
            sessionStorage.setItem('username', username);
            sessionStorage.setItem('firstname', firstname);
            sessionStorage.setItem('lastname', lastname);
            sessionStorage.setItem('password', password);

            // Show verification form after a short delay
            setTimeout(() => {
                switchForm('verify');
            }, 2000);
        } else {
            Toastify({
                text: response.message,
                duration: 3000,
                gravity: "top",
                position: "center",
                backgroundColor: "#e74c3c"
            }).showToast();
        }
    });

    return false; // Prevent form submission
}
// Send verification code
function sendVerificationCode() {
    const email = $('#email').val();
    
    if (!email) {
        Toastify({
            text: "Please enter your email address",
            duration: 3000,
            gravity: "top",
            position: "center",
            backgroundColor: "#e74c3c"
        }).showToast();
        return;
    }

    // Show loading state
    const sendBtn = $('.verification-btn');
    const originalText = sendBtn.find('.button__text').text();
    sendBtn.find('.button__text').text('Sending...');
    sendBtn.prop('disabled', true);

    // Check if email exists first
    $.post('check_email.php', { email }, function(res) {
        try {
            // Parse the response properly
            let response;
            try {
                response = typeof res === 'string' ? JSON.parse(res) : res;
            } catch (e) {
                console.error('Failed to parse response:', res);
                throw new Error('Invalid server response');
            }

            if (response.status === 'success') {
                // Proceed to send code
                $.post('send_verification_code.php', { email }, function(response) {
                    Toastify({
                        text: "Verification code sent to your email",
                        duration: 3000,
                        gravity: "top",
                        position: "center",
                        backgroundColor: "#2ecc71"
                    }).showToast();
                    sessionStorage.setItem('email', email);
                }).fail(function(xhr, status, error) {
                    console.error('Error sending verification code:', error);
                    Toastify({
                        text: "Failed to send verification code. Please try again.",
                        duration: 3000,
                        gravity: "top",
                        position: "center",
                        backgroundColor: "#e74c3c"
                    }).showToast();
                }).always(function() {
                    // Reset button state
                    sendBtn.find('.button__text').text(originalText);
                    sendBtn.prop('disabled', false);
                });
            } else {
                Toastify({
                    text: response.message || "Email already in use",
                    duration: 3000,
                    gravity: "top",
                    position: "center",
                    backgroundColor: "#e74c3c"
                }).showToast();
            }
        } catch (e) {
            console.error('Error processing response:', e);
            Toastify({
                text: "Error processing response. Please try again.",
                duration: 3000,
                gravity: "top",
                position: "center",
                backgroundColor: "#e74c3c"
            }).showToast();
        } finally {
            // Reset button state
            sendBtn.find('.button__text').text(originalText);
            sendBtn.prop('disabled', false);
        }
    }).fail(function(xhr, status, error) {
        console.error('Server request failed:', error);
        Toastify({
            text: "Server request failed. Please check your connection.",
            duration: 3000,
            gravity: "top",
            position: "center",
            backgroundColor: "#e74c3c"
        }).showToast();
        // Reset button state
        sendBtn.find('.button__text').text(originalText);
        sendBtn.prop('disabled', false);
    });
}
// Verify and register
function verifyAndRegister() {
    const code = $('#code').val();
    const email = $('#email').val();

    // Show loading state
    const submitBtn = $('#verifyForm .login__submit');
    const originalText = submitBtn.find('.button__text').text();
    submitBtn.find('.button__text').text('Processing...');
    submitBtn.prop('disabled', true);

    const data = {
        code,
        email,
        username: sessionStorage.getItem('username'),
        firstname: sessionStorage.getItem('firstname'),
        lastname: sessionStorage.getItem('lastname'),
        password: sessionStorage.getItem('password')
    };

    $.post('verify_and_register.php', data)
        .done(function(res) {
            try {
                const response = typeof res === 'string' ? JSON.parse(res) : res;
                
                if (response.status === 'success') {
                    Toastify({
                        text: response.message,
                        duration: 3000,
                        gravity: "top",
                        position: "center",
                        backgroundColor: "#2ecc71",
                        callback: function() {
                            sessionStorage.clear();
                            window.location.href = 'index.php?toast=success&msg=' + encodeURIComponent(response.message);
                        }
                    }).showToast();
                } else {
                    Toastify({
                        text: response.message || "Registration failed",
                        duration: 3000,
                        gravity: "top",
                        position: "center",
                        backgroundColor: "#e74c3c"
                    }).showToast();
                }
            } catch (e) {
                console.error('Error parsing response:', e, res);
                Toastify({
                    text: "❌ Unexpected response from server",
                    duration: 3000,
                    gravity: "top",
                    position: "center",
                    backgroundColor: "#e74c3c"
                }).showToast();
            }
        })
        .fail(function(xhr, status, error) {
            console.error('Registration failed:', error);
            Toastify({
                text: "❌ Registration failed. Please try again.",
                duration: 3000,
                gravity: "top",
                position: "center",
                backgroundColor: "#e74c3c"
            }).showToast();
        })
        .always(function() {
            // Reset button state
            submitBtn.find('.button__text').text(originalText);
            submitBtn.prop('disabled', false);
        });
    
    return false; // Prevent form submission
}
        
        // Password strength indicator
        $(document).ready(function() {
            $('#regpassword').on('input', function() {
                const password = $(this).val();
                updatePasswordStrength(password);
            });
        });

        function updatePasswordStrength(password) {
            // Check each requirement
            const hasMinLength = password.length >= 8;
            const hasLowercase = /[a-z]/.test(password);
            const hasUppercase = /[A-Z]/.test(password);
            const hasNumber = /\d/.test(password);
            
            // Update UI for each requirement
            updateRequirement('#length', hasMinLength);
            updateRequirement('#lowercase', hasLowercase);
            updateRequirement('#uppercase', hasUppercase);
            updateRequirement('#number', hasNumber);
        }

        function updateRequirement(selector, isValid) {
            const $element = $(selector);
            $element.toggleClass('valid', isValid);
            $element.toggleClass('invalid', !isValid);
            
            // Update the icon
            $element.find('span').text(isValid ? '✓' : '✗');
        }
    </script>
   <script>
document.addEventListener("DOMContentLoaded", function () {
  const params = new URLSearchParams(window.location.search);
  const loginStatus = params.get("login");

  if (loginStatus === "success") {
    Toastify({
      text: "Login successful!",
      duration: 3000,
      gravity: "top",
      position: "center",
      backgroundColor: "#2ecc71",
      callback: function () {
        // ✅ Clear the login param after toast disappears
        clearLoginParam();
      }
    }).showToast();
  } else if (loginStatus === "failed") {
    Toastify({
      text: " Invalid username or password!",
      duration: 3000,
      gravity: "bottom",
      position: "center",
      backgroundColor: "#e74c3c",
      callback: function () {
        // ✅ Clear the login param after toast disappears
        clearLoginParam();
      }
    }).showToast();
  }

  function clearLoginParam() {
    if (window.history.replaceState) {
      const url = new URL(window.location);
      url.searchParams.delete('login');
      window.history.replaceState({}, document.title, url.toString());
    }
  }
});
</script>
</body>
</html>
