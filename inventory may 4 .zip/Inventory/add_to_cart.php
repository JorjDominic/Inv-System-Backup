<?php
session_start();
require_once 'config/database.php';

// Initialize response
$response = [
    'success' => false,
    'message' => '',
    'cartCount' => 0
];

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Get product ID and quantity from request
$productId = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

// Validate product ID and quantity
if ($productId <= 0) {
    $response['message'] = 'Invalid product ID';
    echo json_encode($response);
    exit;
}

if ($quantity <= 0) {
    $response['message'] = 'Quantity must be greater than 0';
    echo json_encode($response);
    exit;
}

try {
    // Check if product exists and has enough stock
    $stmt = $conn->prepare("
        SELECT 
            p.ProductID,
            p.ProductName,
            p.SellingPrice,
            SUM(i.Quantity) as AvailableQuantity
        FROM Product p
        LEFT JOIN Inventory i ON p.ProductID = i.ProductID
        WHERE p.ProductID = ?
        GROUP BY p.ProductID, p.ProductName, p.SellingPrice
    ");
    $stmt->execute([$productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        $response['message'] = 'Product not found';
        echo json_encode($response);
        exit;
    }
    
    if ($product['AvailableQuantity'] <= 0) {
        $response['message'] = 'Product is out of stock';
        echo json_encode($response);
        exit;
    }
    
    // Check if adding this quantity would exceed available stock
    $currentQuantity = isset($_SESSION['cart'][$productId]) ? $_SESSION['cart'][$productId]['quantity'] : 0;
    $newQuantity = $currentQuantity + $quantity;
    
    if ($newQuantity > $product['AvailableQuantity']) {
        $response['message'] = 'Not enough stock available';
        echo json_encode($response);
        exit;
    }
    
    // Add product to cart
    if (isset($_SESSION['cart'][$productId])) {
        // Update quantity if product already in cart
        $_SESSION['cart'][$productId]['quantity'] = $newQuantity;
    } else {
        // Add new product to cart
        $_SESSION['cart'][$productId] = [
            'quantity' => $quantity,
            'price' => $product['SellingPrice'],
            'name' => $product['ProductName']
        ];
    }
    
    // Calculate cart count
    $cartCount = 0;
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'];
    }
    
    // Set success response
    $response['success'] = true;
    $response['message'] = 'Product added to cart';
    $response['cartCount'] = $cartCount;
    
} catch (PDOException $e) {
    $response['message'] = 'Database error: ' . $e->getMessage();
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);