<?php
echo date_default_timezone_get();
?>
