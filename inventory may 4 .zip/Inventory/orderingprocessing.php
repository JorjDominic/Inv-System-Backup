<?php
// order_processing.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], [1, 2, 3, 4])) { // Owner, Developer, Cashier, Staff
    header('Location: login.php');
    exit;
}

// Process order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $orderId = $_POST['order_id'];
    $newStatus = $_POST['status'];
    $notes = $_POST['notes'] ?? '';
    
    // Validate status
    $validStatuses = ['preparing', 'ready_for_pickup', 'completed', 'cancelled'];
    if (!in_array($newStatus, $validStatuses)) {
        $_SESSION['error'] = 'Invalid order status';
        header('Location: orders.php');
        exit;
    }
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Update order status
        $stmt = $conn->prepare("
            UPDATE Orders 
            SET OrderStatus = ?, UpdatedAt = NOW() 
            WHERE OrderID = ?
        ");
        $stmt->execute([$newStatus, $orderId]);
        
        // Log the status change
        $stmt = $conn->prepare("
            INSERT INTO audit_trail (
                affected_username, changed_by, action, timestamp
            ) VALUES (
                (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
                (SELECT Username FROM Users WHERE UserID = ?),
                ?, 
                NOW()
            )
        ");
        $stmt->execute([
            $orderId,
            $_SESSION['user_id'],
            "Updated Order #$orderId status to " . ucfirst(str_replace('_', ' ', $newStatus)) . ($notes ? ": $notes" : '')
        ]);
        
        // Get customer info
        $stmt = $conn->prepare("
            SELECT o.CustomerID, c.UserID, c.Email, c.FirstName, c.Phone
            FROM Orders o
            JOIN Customers c ON o.CustomerID = c.CustomerID
            WHERE o.OrderID = ?
        ");
        $stmt->execute([$orderId]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Send notification based on new status
        if ($customer) {
            $notificationTitle = '';
            $notificationMessage = '';
            $smsMessage = '';
            
            switch ($newStatus) {
                case 'preparing':
                    $notificationTitle = 'Order Being Prepared';
                    $notificationMessage = "Your Order #$orderId is now being prepared. We'll notify you when it's ready for pickup.";
                    $smsMessage = "Hi {$customer['FirstName']}! Your Order #$orderId is now being prepared. We'll notify you when it's ready for pickup.";
                    break;
                    
                case 'ready_for_pickup':
                    // Get pickup code
                    $stmt = $conn->prepare("SELECT PickupCode FROM Orders WHERE OrderID = ?");
                    $stmt->execute([$orderId]);
                    $order = $stmt->fetch(PDO::FETCH_ASSOC);
                    $pickupCode = $order['PickupCode'];
                    
                    $notificationTitle = 'Order Ready for Pickup';
                    $notificationMessage = "Your Order #$orderId is now ready for pickup. Your pickup code is: $pickupCode";
                    $smsMessage = "Hi {$customer['FirstName']}! Your Order #$orderId is now ready for pickup. Please present this pickup code: $pickupCode";
                    break;
                    
                case 'completed':
                    $notificationTitle = 'Order Completed';
                    $notificationMessage = "Your Order #$orderId has been completed. Thank you for your business!";
                    $smsMessage = "Hi {$customer['FirstName']}! Your Order #$orderId has been completed. Thank you for your business!";
                    break;
                    
                case 'cancelled':
                    $notificationTitle = 'Order Cancelled';
                    $notificationMessage = "Your Order #$orderId has been cancelled. " . ($notes ? "Reason: $notes" : "Please contact us for more information.");
                    $smsMessage = "Hi {$customer['FirstName']}! Your Order #$orderId has been cancelled. " . ($notes ? "Reason: $notes" : "Please contact us for more information.");
                    break;
            }
            
            // Send in-app notification if user has an account
            if ($customer['UserID']) {
                createNotification(
                    $notificationTitle,
                    $notificationMessage,
                    'order_details.php?id=' . $orderId,
                    $customer['UserID']
                );
            }
            
            // Send SMS notification (implement your SMS gateway here)
            if ($customer['Phone'] && $smsMessage) {
                // Example SMS sending code (replace with your SMS gateway)
                // sendSMS($customer['Phone'], $smsMessage);
            }
        }
        
        $conn->commit();
        $_SESSION['success'] = 'Order status updated successfully';
        
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error'] = 'Error updating order status: ' . $e->getMessage();
    }
    
    header('Location: order_details.php?id=' . $orderId);
    exit;
}

// Get orders based on status filter
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'paid';
$validFilters = ['pending', 'paid', 'preparing', 'ready_for_pickup', 'completed', 'cancelled', 'all'];

if (!in_array($statusFilter, $validFilters)) {
    $statusFilter = 'paid';
}

$sql = "
    SELECT 
        o.OrderID, 
        o.OrderDate, 
        o.OrderStatus,
        o.PickupDate,
        o.PickupTime,
        o.PickupCode,
        o.TotalAmount,
        CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
        c.Phone AS CustomerPhone,
        c.Email AS CustomerEmail,
        COUNT(od.OrderDetailID) AS ItemCount,
        t.Status AS PaymentStatus
    FROM Orders o
    JOIN Customers c ON o.CustomerID = c.CustomerID
    JOIN OrderDetails od ON o.OrderID = od.OrderID
    LEFT JOIN Transactions t ON o.OrderID = t.OrderID
    WHERE 1=1
";

if ($statusFilter !== 'all') {
    $sql .= " AND o.OrderStatus = :status";
}

$sql .= "
    GROUP BY o.OrderID, o.OrderDate, o.OrderStatus, o.PickupDate, o.PickupTime, 
             o.PickupCode, o.TotalAmount, CustomerName, CustomerPhone, CustomerEmail, PaymentStatus
    ORDER BY 
        CASE 
            WHEN o.OrderStatus = 'paid' THEN 1
            WHEN o.OrderStatus = 'preparing' THEN 2
            WHEN o.OrderStatus = 'ready_for_pickup' THEN 3
            WHEN o.OrderStatus = 'pending' THEN 4
            WHEN o.OrderStatus = 'completed' THEN 5
            WHEN o.OrderStatus = 'cancelled' THEN 6
            ELSE 7
        END,
        o.OrderDate DESC
";

$stmt = $conn->prepare($sql);

if ($statusFilter !== 'all') {
    $stmt->bindParam(':status', $statusFilter);
}

$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Processing</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .order-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    
    .order-card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      transition: transform 0.2s;
    }
    
    .order-card:hover {
      transform: translateY(-5px);
    }
    
    .order-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .order-id {
      font-size: 1.2rem;
      font-weight: 600;
    }
    
    .order-status {
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 500;
    }
    
    .status-pending {
      background-color: #f0f0f0;
      color: #666;
    }
    
    .status-paid {
      background-color: #e3f2fd;
      color: #1976d2;
    }
    
    .status-preparing {
      background-color: #fff8e1;
      color: #f57f17;
    }
    
    .status-ready_for_pickup {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-completed {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-cancelled {
      background-color: #ffebee;
      color: #c62828;
    }
    
    .order-info {
      margin-bottom: 15px;
    }
    
    .info-row {
      display: flex;
      margin-bottom: 8px;
    }
    
    .info-label {
      width: 120px;
      color: #666;
      font-size: 0.9rem;
    }
    
    .info-value {
      flex: 1;
      font-weight: 500;
    }
    
    .pickup-code {
      background-color: #f5f5f5;
      padding: 8px;
      border-radius: 4px;
      text-align: center;
      font-size: 1.2rem;
      font-weight: 600;
      letter-spacing: 2px;
      margin: 10px 0;
    }
    
    .order-actions {
      display: flex;
      gap: 10px;
      margin-top: 15px;
    }
    
    .action-btn {
      flex: 1;
      padding: 8px;
      border: none;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .action-btn i {
      margin-right: 5px;
    }
    
    .btn-view {
      background-color: #e3f2fd;
      color: #1976d2;
    }
    
    .btn-view:hover {
      background-color: #bbdefb;
    }
    
    .btn-process {
      background-color: #fff8e1;
      color: #f57f17;
    }
    
    .btn-process:hover {
      background-color: #ffecb3;
    }
    
    .btn-ready {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .btn-ready:hover {
      background-color: #c8e6c9;
    }
    
    .btn-complete {
      background-color: #4a934a;
      color: white;
    }
    
    .btn-complete:hover {
      background-color: #3a7a3a;
    }
    
    .filter-tabs {
      display: flex;
      overflow-x: auto;
      gap: 10px;
      margin-bottom: 20px;
      padding-bottom: 10px;
    }
    
    .filter-tab {
      padding: 8px 16px;
      background-color: #f5f5f5;
      border-radius: 20px;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      transition: background-color 0.2s;
    }
    
    .filter-tab.active {
      background-color: #4a934a;
      color: white;
    }
    
    .filter-tab:hover:not(.active) {
      background-color: #e0e0e0;
    }
    
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }
    
    .modal.active {
      display: flex;
    }
    
    .modal-content {
      background-color: white;
      border-radius: 8px;
      max-width: 500px;
      width: 100%;
      padding: 20px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .modal-title {
      font-size: 1.2rem;
      font-weight: 600;
    }
    
    .modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #666;
    }
    
    .modal-body {
      margin-bottom: 20px;
    }
    
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    
    .empty-state {
      text-align: center;
      padding: 40px 0;
    }
    
    .empty-state i {
      font-size: 3rem;
      color: #ccc;
      margin-bottom: 20px;
    }
    
    .empty-state h3 {
      font-size: 1.2rem;
      margin-bottom: 10px;
      color: #666;
    }
    
    .empty-state p {
      color: #888;
      max-width: 400px;
      margin: 0 auto;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>Order Processing</h1>
      </div>
      
      <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
          <?= $_SESSION['success'] ?>
          <?php unset($_SESSION['success']); ?>
        </div>
      <?php endif; ?>
      
      <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
          <?= $_SESSION['error'] ?>
          <?php unset($_SESSION['error']); ?>
        </div>
      <?php endif; ?>
      
      <div class="filter-tabs">
        <a href="?status=all" class="filter-tab <?= $statusFilter === 'all' ? 'active' : '' ?>">
          All Orders
        </a>
        <a href="?status=paid" class="filter-tab <?= $statusFilter === 'paid' ? 'active' : '' ?>">
          Paid
        </a>
        <a href="?status=preparing" class="filter-tab <?= $statusFilter === 'preparing' ? 'active' : '' ?>">
          Preparing
        </a>
        <a href="?status=ready_for_pickup" class="filter-tab <?= $statusFilter === 'ready_for_pickup' ? 'active' : '' ?>">
          Ready for Pickup
        </a>
        <a href="?status=completed" class="filter-tab <?= $statusFilter === 'completed' ? 'active' : '' ?>">
          Completed
        </a>
        <a href="?status=cancelled" class="filter-tab <?= $statusFilter === 'cancelled' ? 'active' : '' ?>">
          Cancelled
        </a>
      </div>
      
      <?php if (empty($orders)): ?>
        <div class="empty-state">
          <i class="fas fa-shopping-bag"></i>
          <h3>No orders found</h3>
          <p>There are no orders with the selected status at this time.</p>
        </div>
      <?php else: ?>
        <div class="order-container">
          <?php foreach ($orders as $order): ?>
            <div class="order-card">
              <div class="order-header">
                <div class="order-id">Order #<?= $order['OrderID'] ?></div>
                <div class="order-status status-<?= $order['OrderStatus'] ?>">
                  <?= ucfirst(str_replace('_', ' ', $order['OrderStatus'])) ?>
                </div>
              </div>
              
              <div class="order-info">
                <div class="info-row">
                  <div class="info-label">Customer:</div>
                  <div class="info-value"><?= htmlspecialchars($order['CustomerName']) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Phone:</div>
                  <div class="info-value"><?= htmlspecialchars($order['CustomerPhone']) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Order Date:</div>
                  <div class="info-value"><?= date('M d, Y h:i A', strtotime($order['OrderDate'])) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Pickup Date:</div>
                  <div class="info-value"><?= date('M d, Y', strtotime($order['PickupDate'])) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Pickup Time:</div>
                  <div class="info-value"><?= date('h:i A', strtotime($order['PickupTime'])) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Items:</div>
                  <div class="info-value"><?= $order['ItemCount'] ?> items</div>
                </div>
                <div class="info-row">
                  <div class="info-label">Total:</div>
                  <div class="info-value">₱<?= number_format($order['TotalAmount'], 2) ?></div>
                </div>
              </div>
              
              <?php if ($order['PickupCode']): ?>
                <div class="pickup-code"><?= $order['PickupCode'] ?></div>
              <?php endif; ?>
              
              <div class="order-actions">
                <a href="order_details.php?id=<?= $order['OrderID'] ?>" class="action-btn btn-view">
                  <i class="fas fa-eye"></i> View Details
                </a>
                
                <?php if ($order['OrderStatus'] === 'paid'): ?>
                  <button class="action-btn btn-process" onclick="updateStatus(<?= $order['OrderID'] ?>, 'preparing')">
                    <i class="fas fa-utensils"></i> Start Preparing
                  </button>
                <?php elseif ($order['OrderStatus'] === 'preparing'): ?>
                  <button class="action-btn btn-ready" onclick="updateStatus(<?= $order['OrderID'] ?>, 'ready_for_pickup')">
                    <i class="fas fa-check"></i> Mark Ready
                  </button>
                <?php elseif ($order['OrderStatus'] === 'ready_for_pickup'): ?>
                  <button class="action-btn btn-complete" onclick="updateStatus(<?= $order['OrderID'] ?>, 'completed')">
                    <i class="fas fa-check-double"></i> Complete
                  </button>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </main>
</div>

<!-- Status Update Modal -->
<div id="statusModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 class="modal-title">Update Order Status</h2>
      <button class="modal-close" onclick="closeModal()">&times;</button>
    </div>
    <form id="statusForm" method="post" action="">
      <input type="hidden" id="order_id" name="order_id">
      <input type="hidden" id="status" name="status">
      
      <div class="modal-body">
        <div class="form-group">
          <label for="notes">Additional Notes (Optional)</label>
          <textarea id="notes" name="notes" rows="3" class="form-control"></textarea>
        </div>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Update Status</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
  function updateStatus(orderId, status) {
    document.getElementById('order_id').value = orderId;
    document.getElementById('status').value = status;
    
    // Set modal title based on status
    let title = 'Update Order Status';
    switch (status) {
      case 'preparing':
        title = 'Start Preparing Order';
        break;
      case 'ready_for_pickup':
        title = 'Mark Order as Ready for Pickup';
        break;
      case 'completed':
        title = 'Complete Order';
        break;
      case 'cancelled':
        title = 'Cancel Order';
        break;
    }
    
    document.querySelector('.modal-title').textContent = title;
    document.getElementById('statusModal').classList.add('active');
  }
  
  function closeModal() {
    document.getElementById('statusModal').classList.remove('active');
  }
  
  // Close modal when clicking outside
  window.addEventListener('click', function(event) {
    const modal = document.getElementById('statusModal');
    if (event.target === modal) {
      closeModal();
    }
  });
</script>
</body>
</html>

## 7. Payment Success Page

```php
<?php
// payment_success.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Check if we have an order ID in session
if (!isset($_SESSION['current_order_id'])) {
    header('Location: catalog.php');
    exit;
}

$orderId = $_SESSION['current_order_id'];

// Clear cart
$_SESSION['cart'] = [];
unset($_SESSION['order_data']);
unset($_SESSION['current_order_id']);
unset($_SESSION['current_transaction_id']);

// Get order details
$stmt = $conn->prepare("
    SELECT o.*, 
           c.FirstName, c.LastName, c.Email, c.Phone,
           t.Status AS PaymentStatus
    FROM Orders o
    LEFT JOIN Customers c ON o.CustomerID = c.CustomerID
    LEFT JOIN Transactions t ON o.OrderID = t.OrderID
    WHERE o.OrderID = ?
");
$stmt->execute([$orderId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

// Get order items
$stmt = $conn->prepare("
    SELECT od.*, p.ProductName, p.ImageURL
    FROM OrderDetails od
    JOIN Product p ON od.ProductID = p.ProductID
    WHERE od.OrderID = ?
");
$stmt->execute([$orderId]);
$orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$subtotal = 0;
foreach ($orderItems as $item) {
    $subtotal += $item['Price'] * $item['Quantity'];
}
$taxRate = 0.12; // 12% tax
$tax = $subtotal * $taxRate;
$total = $subtotal + $tax;
?>
&lt;!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Successful</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .success-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 30px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    
    .success-icon {
      font-size: 5rem;
      color: #4a934a;
      margin-bottom: 20px;
    }
    
    .success-title {
      font-size: 2rem;
      color: #333;
      margin-bottom: 15px;
    }
    
    .success-message {
      font-size: 1.1rem;
      color: #666;
      margin-bottom: 30px;
    }
    
    .pickup-details {
      background-color: #f9f9f9;
      border-radius: 8px;
      padding: 20px;
      margin-bottom: 30px;
      text-align: left;
    }
    
    .pickup-header {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      color: #333;
    }
    
    .pickup-info {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 20px;
    }
    
    .pickup-item {
      flex: 1;
      min-width: 200px;
    }
    
    .pickup-label {
      font-size: 0.9rem;
      color: #666;
      margin-bottom: 5px;
    }
    
    .pickup-value {
      font-size: 1.1rem;
      font-weight: 500;
    }
    
    .pickup-code {
      background-color: #e8f5e9;
      border: 1px dashed #4a934a;
      padding: 15px;
      border-radius: 8px;
      text-align: center;
      margin-top: 20px;
    }
    
    .pickup-code-label {
      font-size: 0.9rem;
      color: #4a934a;
      margin-bottom: 5px;
    }
    
    .pickup-code-value {
      font-size: 2rem;
      font-weight: 700;
      color: #4a934a;
      letter-spacing: 5px;
    }
    
    .order-details {
      background-color: #f9f9f9;
      border-radius: 8px;
      padding: 20px;
      margin-top: 30px;
      text-align: left;
    }
    
    .order-header {
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #eee;
      padding-bottom: 15px;
      margin-bottom: 15px;
    }
    
    .order-items {
      margin-bottom: 20px;
    }
    
    .order-item {
      display: flex;
      margin-bottom: 10px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .item-image {
      width: 60px;
      height: 60px;
      margin-right: 15px;
    }
    
    .item-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 4px;
    }
    
    .item-details {
      flex: 1;
    }
    
    .item-name {
      font-weight: 600;
    }
    
    .item-price {
      color: #666;
      font-size: 0.9rem;
    }
    
    .item-quantity {
      color: #666;
      font-size: 0.9rem;
    }
    
    .item-total {
      font-weight: 600;
      text-align: right;
      min-width: 100px;
    }
    
    .order-summary {
      margin-top: 20px;
      text-align: right;
    }
    
    .summary-row {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 5px;
    }
    
    .summary-label {
      width: 100px;
      color: #666;
      text-align: left;
      margin-right: 20px;
    }
    
    .summary-value {
      width: 100px;
      font-weight: 500;
    }
    
    .total-row {
      font-size: 1.2rem;
      font-weight: 600;
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid #ddd;
    }
    
    .buttons {
      margin-top: 30px;
    }
    
    .btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: #4a934a;
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 1rem;
      text-decoration: none;
      margin: 0 10px;
      transition: background-color 0.2s;
    }
    
    .btn:hover {
      background-color: #3a7a3a;
    }
    
    .btn-outline {
      background-color: transparent;
      border: 1px solid #4a934a;
      color: #4a934a;
    }
    
    .btn-outline:hover {
      background-color: #f0f8f0;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="success-container">
        <div class="success-icon">
          <i class="fas fa-check-circle"></i>
        </div>
        <h1 class="success-title">Payment Successful!</h1>
        <p class="success-message">Thank you for your order. Your payment has been processed successfully.</p>
        
        <div class="pickup-details">
          <h2 class="pickup-header">Pickup Information</h2>
          <div class="pickup-info">
            <div class="pickup-item">
              <div class="pickup-label">Pickup Date</div>
              <div class="pickup-value"><?= date('l, F j, Y', strtotime($order['PickupDate'])) ?></div>
            </div>
            <div class="pickup-item">
              <div class="pickup-label">Pickup Time</div>
              <div class="pickup-value"><?= date('h:i A', strtotime($order['PickupTime'])) ?></div>
            </div>
          </div>
          
          <div class="pickup-code">
            <div class="pickup-code-label">Your Pickup Code</div>
            <div class="pickup-code-value"><?= $order['PickupCode'] ?></div>
            <p>Please present this code when picking up your order</p>
          </div>
        </div>
        
        <div class="order-details">
          <div class="order-header">
            <div>
              <h2>Order #<?= $orderId ?></h2>
              <p>Date: <?= date('F j, Y', strtotime($order['OrderDate'])) ?></p>
            </div>
            <div>
              <p>Status: <strong><?= ucfirst(str_replace('_', ' ', $order['OrderStatus'])) ?></strong></p>
            </div>
          </div>
          
          <div class="order-items">
            <?php foreach ($orderItems as $item): ?>
              <div class="order-item">
                <div class="item-image">
                  <?php if ($item['ImageURL']): ?>
                    <img src="<?= htmlspecialchars($item['ImageURL']) ?>" alt="<?= htmlspecialchars($item['ProductName']) ?>">
                  <?php else: ?>
                    <div class="no-image"><i class="fas fa-image"></i></div>
                  <?php endif; ?>
                </div>
                <div class="item-details">
                  <div class="item-name"><?= htmlspecialchars($item['ProductName']) ?></div>
                  <div class="item-price">₱<?= number_format($item['Price'], 2) ?> each</div>
                  <div class="item-quantity">Quantity: <?= $item['Quantity'] ?></div>
                </div>
                <div class="item-total">₱<?= number_format($item['Price'] * $item['Quantity'], 2) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
          
          <div class="order-summary">
            <div class="summary-row">
              <div class="summary-label">Subtotal:</div>
              <div class="summary-value">₱<?= number_format($subtotal, 2) ?></div>
            </div>
            <div class="summary-row">
              <div class="summary-label">Tax (12%):</div>
              <div class="summary-value">₱<?= number_format($tax, 2) ?></div>
            </div>
            <div class="summary-row total-row">
              <div class="summary-label">Total:</div>
              <div class="summary-value">₱<?= number_format($total, 2) ?></div>
            </div>
          </div>
        </div>
        
        <div class="buttons">
          <a href="catalog.php" class="btn">Continue Shopping</a>
          <a href="#" onclick="window.print()" class="btn btn-outline">Print Receipt</a>
        </div>
      </div>
    </div>
  </main>
</div>
</body>
</html>