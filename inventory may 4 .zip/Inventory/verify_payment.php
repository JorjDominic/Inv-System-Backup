<?php
// verify_payment.php
session_start();
require_once 'config/database.php';
require_once 'config/paymongo.php';

// Enable error logging
error_reporting(E_ALL);
ini_set('display_errors', 0);
error_log('Payment verification started');

header('Content-Type: application/json');

// Check if reference number is provided
if (!isset($_POST['reference_number']) || empty($_POST['reference_number'])) {
    echo json_encode(['success' => false, 'message' => 'Reference number is required']);
    exit;
}

$referenceNumber = trim($_POST['reference_number']);
error_log('Verifying payment with reference: ' . $referenceNumber);

try {
    // First, check if we already have this payment recorded in our database
    $stmt = $conn->prepare("
        SELECT pl.*, o.OrderID 
        FROM PaymentLinks pl
        JOIN Orders o ON pl.OrderID = o.OrderID
        WHERE pl.ReferenceNumber = ?
    ");
    $stmt->execute([$referenceNumber]);
    $paymentLink = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$paymentLink) {
        echo json_encode(['success' => false, 'message' => 'Payment reference not found']);
        exit;
    }
    
    // Now, verify the payment status with PayMongo API
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.paymongo.com/v1/links?reference_number=" . urlencode($referenceNumber),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "authorization: Basic " . base64_encode(PAYMONGO_SECRET_KEY . ":"),
        ],
    ]);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        throw new Exception("cURL Error: " . $err);
    }
    
    $paymongoData = json_decode($response, true);
    error_log('PayMongo API Response: ' . $response);
    
    // Check if we got a valid response
    if (!isset($paymongoData['data']) || empty($paymongoData['data'])) {
        throw new Exception("Invalid response from PayMongo or payment not found");
    }
    
    // Get the payment status
    $paymentStatus = $paymongoData['data'][0]['attributes']['status'] ?? 'unknown';
    error_log('Payment status from PayMongo: ' . $paymentStatus);
    
    if ($paymentStatus === 'paid') {
        // Payment is successful, update our records
        
        // Update payment link status
        $stmt = $conn->prepare("UPDATE PaymentLinks SET Status = 'paid' WHERE PaymentLinkID = ?");
        $stmt->execute([$paymentLink['PaymentLinkID']]);
        
        // Update order status
        $stmt = $conn->prepare("UPDATE Orders SET OrderStatus = 'paid' WHERE OrderID = ?");
        $stmt->execute([$paymentLink['OrderID']]);
        
        // Store order ID in session
        $_SESSION['current_order_id'] = $paymentLink['OrderID'];
        
        // Return success
        echo json_encode([
            'success' => true,
            'message' => 'Payment verified successfully',
            'order_id' => $paymentLink['OrderID'],
            'status' => 'paid'
        ]);
    } else if ($paymentStatus === 'unpaid') {
        // Payment is still pending
        echo json_encode([
            'success' => false,
            'message' => 'Payment is still pending. Please complete the payment.',
            'status' => 'unpaid'
        ]);
    } else {
        // Payment failed or other status
        echo json_encode([
            'success' => false,
            'message' => 'Payment verification failed. Status: ' . $paymentStatus,
            'status' => $paymentStatus
        ]);
    }
    
} catch (Exception $e) {
    error_log('Payment Verification Error: ' . $e->getMessage());
    error_log('Stack trace: ' . $e->getTraceAsString());
    
    echo json_encode([
        'success' => false,
        'message' => 'Error verifying payment: ' . $e->getMessage()
    ]);
}