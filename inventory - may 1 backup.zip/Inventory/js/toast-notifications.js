/**
 * Toast Notification System
 * Standardized implementation for showing toast notifications across the application
 */

// Toast configuration options
const toastConfig = {
    duration: 3000,
    gravity: "bottom", // top or bottom
    position: "right", // left, center, or right
    stopOnFocus: true, // Stop timeout on hover
    className: "", // Additional CSS class
    offset: {
      x: 20, // horizontal offset
      y: 20, // vertical offset
    },
  }
  
  // Toast type colors
  const toastColors = {
    success: "#2ecc71", // Green
    error: "#e74c3c", // Red
    warning: "#f39c12", // Orange/Yellow
    info: "#3498db", // Blue
  }
  
  /**
   * Show a toast notification
   * @param {string} message - The message to display
   * @param {string} type - The type of toast (success, error, warning, info)
   * @param {Object} options - Optional configuration overrides
   */
  function showToast(message, type = "info", options = {}) {
    // Get background color based on type
    const backgroundColor = toastColors[type] || toastColors.info
  
    // Merge default config with provided options
    const config = {
      ...toastConfig,
      ...options,
      backgroundColor,
    }
  
    // Create and show the toast
    if (typeof Toastify !== "undefined") {
      Toastify({
        text: message,
        duration: config.duration,
        gravity: config.gravity,
        position: config.position,
        backgroundColor: config.backgroundColor,
        stopOnFocus: config.stopOnFocus,
        className: config.className,
        offset: config.offset,
        close: true,
      }).showToast()
    } else {
      console.error("Toastify is not defined. Make sure it's included in your project.")
    }
  }
  
  /**
   * Process URL parameters to show toast notifications
   * Supports both 'toast' + 'msg' and 'msg_success'/'msg_error' formats
   */
  function processToastParams() {
    const params = new URLSearchParams(window.location.search)
  
    // Handle toast + msg format
    if (params.has("toast") && params.has("msg")) {
      const toastType = params.get("toast")
      const message = decodeURIComponent(params.get("msg"))
      showToast(message, toastType)
      clearToastParams(["toast", "msg"])
    }
  
    // Handle login status format
    if (params.has("login")) {
      const loginStatus = params.get("login")
      if (loginStatus === "success") {
        showToast("Login successful!", "success")
      } else if (loginStatus === "failed") {
        showToast("Invalid username or password!", "error")
      }
      clearToastParams(["login"])
    }
  
    // Handle msg_success/msg_error format
    if (params.has("msg_success")) {
      showToast(decodeURIComponent(params.get("msg_success")), "success")
      clearToastParams(["msg_success"])
    }
  
    if (params.has("msg_error")) {
      showToast(decodeURIComponent(params.get("msg_error")), "error")
      clearToastParams(["msg_error"])
    }
  }
  
  /**
   * Clear toast parameters from URL
   * @param {Array} paramsToRemove - Array of parameter names to remove
   */
  function clearToastParams(paramsToRemove) {
    if (window.history.replaceState) {
      const url = new URL(window.location)
      paramsToRemove.forEach((param) => {
        url.searchParams.delete(param)
      })
      window.history.replaceState({}, document.title, url.toString())
    }
  }
  
  // Process toast parameters when DOM is loaded
  document.addEventListener("DOMContentLoaded", processToastParams)
  