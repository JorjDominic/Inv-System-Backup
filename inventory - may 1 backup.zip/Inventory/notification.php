<?php
// Notifications management functions

/**
 * Create a new notification
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID to send notification to
 * @param string $type Notification type
 * @param string $message Notification message
 * @return bool Success status
 */
function createNotification($conn, $userID, $type, $message) {
    try {
        $stmt = $conn->prepare("INSERT INTO Notifications (UserID, NotificationType, Message) 
                               VALUES (:userID, :type, :message)");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->bindParam(':type', $type, PDO::PARAM_STR);
        $stmt->bindParam(':message', $message, PDO::PARAM_STR);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error creating notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Create notifications for all users
 * 
 * @param PDO $conn Database connection
 * @param string $type Notification type
 * @param string $message Notification message
 * @param int $excludeUserID Optional user ID to exclude from notifications
 * @return int Number of notifications created
 */
function createNotificationForAllUsers($conn, $type, $message, $excludeUserID = null) {
    try {
        // Get all users
        $query = "SELECT UserID FROM Users";
        if ($excludeUserID !== null) {
            $query .= " WHERE UserID != :excludeUserID";
        }
        
        $stmt = $conn->prepare($query);
        if ($excludeUserID !== null) {
            $stmt->bindParam(':excludeUserID', $excludeUserID, PDO::PARAM_INT);
        }
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $count = 0;
        foreach ($users as $user) {
            if (createNotification($conn, $user['UserID'], $type, $message)) {
                $count++;
            }
        }
        
        return $count;
    } catch (PDOException $e) {
        error_log("Error creating notifications for all users: " . $e->getMessage());
        return 0;
    }
}

/**
 * Create notifications for users with specific roles
 * 
 * @param PDO $conn Database connection
 * @param array $roleIDs Array of role IDs to notify
 * @param string $type Notification type
 * @param string $message Notification message
 * @param int $excludeUserID Optional user ID to exclude from notifications
 * @return int Number of notifications created
 */
function createNotificationForRoles($conn, $roleIDs, $type, $message, $excludeUserID = null) {
    try {
        // Convert roleIDs to string for SQL IN clause
        $roleIDsStr = implode(',', array_map('intval', $roleIDs));
        
        // Get users with specified roles
        $query = "SELECT UserID FROM Users WHERE RoleID IN ($roleIDsStr)";
        if ($excludeUserID !== null) {
            $query .= " AND UserID != :excludeUserID";
        }
        
        $stmt = $conn->prepare($query);
        if ($excludeUserID !== null) {
            $stmt->bindParam(':excludeUserID', $excludeUserID, PDO::PARAM_INT);
        }
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $count = 0;
        foreach ($users as $user) {
            if (createNotification($conn, $user['UserID'], $type, $message)) {
                $count++;
            }
        }
        
        return $count;
    } catch (PDOException $e) {
        error_log("Error creating notifications for roles: " . $e->getMessage());
        return 0;
    }
}

/**
 * Get unread notifications for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @param int $limit Maximum number of notifications to return
 * @return array Notifications
 */
function getUnreadNotifications($conn, $userID, $limit = 5) {
    try {
        // Get ALL unread notifications for this user without filtering by type
        $stmt = $conn->prepare("SELECT * FROM Notifications 
                              WHERE UserID = :userID AND IsRead = 0 
                              ORDER BY CreatedAt DESC LIMIT :limit");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting unread notifications: " . $e->getMessage());
        return [];
    }
}

/**
 * Get all notifications for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @param int $limit Maximum number of notifications to return
 * @param int $offset Offset for pagination
 * @return array Notifications
 */
function getAllNotifications($conn, $userID, $limit = 20, $offset = 0) {
    try {
        // Get ALL notifications for this user without filtering by type
        $stmt = $conn->prepare("SELECT * FROM Notifications 
                              WHERE UserID = :userID 
                              ORDER BY CreatedAt DESC LIMIT :limit OFFSET :offset");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting all notifications: " . $e->getMessage());
        return [];
    }
}

/**
 * Get notifications for a user based on their role
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @param int $roleID User's role ID
 * @param int $limit Maximum number of notifications to return
 * @param int $offset Offset for pagination
 * @return array Notifications
 */
function getNotificationsForRole($conn, $userID, $roleID, $limit = 20, $offset = 0) {
    try {
        // Check if we need to create test notifications
        checkAndCreateTestNotifications($conn, $userID, $roleID);
        
        // Get ALL notifications for this user without filtering by type
        $stmt = $conn->prepare("SELECT * FROM Notifications 
                              WHERE UserID = :userID 
                              ORDER BY CreatedAt DESC LIMIT :limit OFFSET :offset");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting notifications for role: " . $e->getMessage());
        return [];
    }
}

/**
 * Count notifications for a user based on their role
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @param int $roleID User's role ID
 * @return int Number of notifications
 */
function countNotificationsForRole($conn, $userID, $roleID) {
    try {
        // Count ALL notifications for this user without filtering by type
        $stmt = $conn->prepare("SELECT COUNT(*) FROM Notifications WHERE UserID = :userID");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error counting notifications for role: " . $e->getMessage());
        return 0;
    }
}

/**
 * Mark a notification as read
 * 
 * @param PDO $conn Database connection
 * @param int $notificationID Notification ID
 * @param int $userID User ID (for security)
 * @return bool Success status
 */
function markNotificationAsRead($conn, $notificationID, $userID) {
    try {
        $stmt = $conn->prepare("UPDATE Notifications 
                               SET IsRead = 1 
                               WHERE NotificationID = :notificationID AND UserID = :userID");
        $stmt->bindParam(':notificationID', $notificationID, PDO::PARAM_INT);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error marking notification as read: " . $e->getMessage());
        return false;
    }
}

/**
 * Mark all notifications as read for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @return bool Success status
 */
function markAllNotificationsAsRead($conn, $userID) {
    try {
        $stmt = $conn->prepare("UPDATE Notifications 
                               SET IsRead = 1 
                               WHERE UserID = :userID AND IsRead = 0");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error marking all notifications as read: " . $e->getMessage());
        return false;
    }
}

/**
 * Count unread notifications for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @return int Number of unread notifications
 */
function countUnreadNotifications($conn, $userID) {
    try {
        // Count ALL unread notifications for this user without filtering by type
        $stmt = $conn->prepare("SELECT COUNT(*) FROM Notifications 
                              WHERE UserID = :userID AND IsRead = 0");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error counting unread notifications: " . $e->getMessage());
        return 0;
    }
}

/**
 * Get notification icon based on type
 * 
 * @param string $type Notification type
 * @return string SVG icon HTML
 */
function getNotificationIcon($type) {
    switch ($type) {
        case 'inventory_update':
            $color = "#9fce88"; // Green
            $path = "<path d=\"M440-183v-274L296-312l-56-56 240-240 240 240-56 56-144-145v274h-80ZM240-720v-80h480v80H240Z\"/>";
            break;
        case 'order_status':
            $color = "#63b3ed"; // Blue
            $path = "<path d=\"M280-280h280v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80ZM160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v480q0 33-23.5 56.5T800-160H160Z\"/>";
            break;
        case 'low_stock':
            $color = "#f56565"; // Red
            $path = "<path d=\"M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z\"/>";
            break;
        case 'report_ready':
            $color = "#d69e2e"; // Yellow
            $path = "<path d=\"M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm80-80h400v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80Zm-80 400v-560 560Z\"/>";
            break;
        case 'expiring_soon':
            $color = "#f1c40f"; // Amber
            $path = "<path d=\"M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z\"/>";
            break;
        default:
            $color = "#718096"; // Gray
            $path = "<path d=\"M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z\"/>";
    }
    
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"20px\" viewBox=\"0 -960 960 960\" width=\"20px\" fill=\"$color\">$path</svg>";
}

/**
 * Format notification time to human-readable format
 * 
 * @param string $timestamp MySQL timestamp
 * @return string Human-readable time
 */
function formatNotificationTime($timestamp) {
    $notificationTime = strtotime($timestamp);
    $currentTime = time();
    $timeDiff = $currentTime - $notificationTime;
    
    if ($timeDiff < 60) {
        return "Just now";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " minute" . ($minutes > 1 ? "s" : "") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " hour" . ($hours > 1 ? "s" : "") . " ago";
    } elseif ($timeDiff < 604800) {
        $days = floor($timeDiff / 86400);
        return $days . " day" . ($days > 1 ? "s" : "") . " ago";
    } else {
        return date("M j, Y", $notificationTime);
    }
}

/**
 * Get allowed notification types based on role
 * 
 * @param int $roleID User's role ID
 * @return array Array of allowed notification types
 */
function getAllowedNotificationTypes($roleID) {
    // Return ALL notification types for ALL roles - no filtering by role
    return ['inventory_update', 'order_status', 'low_stock', 'report_ready', 'expiring_soon'];
}

/**
 * Get user's role ID
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @return int Role ID
 */
function getUserRole($conn, $userID) {
    try {
        $stmt = $conn->prepare("SELECT RoleID FROM Users WHERE UserID = :userID");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error getting user role: " . $e->getMessage());
        return 0;
    }
}

/**
 * Check if user has notifications and create test ones if needed
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @param int $roleID User's role ID
 */
function checkAndCreateTestNotifications($conn, $userID, $roleID) {
    try {
        // Check if user has any notifications
        $stmt = $conn->prepare("SELECT COUNT(*) FROM Notifications WHERE UserID = :userID");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        $count = $stmt->fetchColumn();
        
        // If user has no notifications, create test ones based on role
        if ($count == 0) {
            $types = getAllowedNotificationTypes($roleID);
            $createdAt = date('Y-m-d H:i:s');
            
            foreach ($types as $type) {
                $message = "";
                switch ($type) {
                    case 'inventory_update':
                        $message = "Inventory has been updated with new products";
                        break;
                    case 'order_status':
                        $message = "New order #" . rand(1000, 9999) . " has been processed";
                        break;
                    case 'low_stock':
                        $message = "Low stock alert: Product XYZ has only " . rand(1, 10) . " units remaining";
                        break;
                    case 'report_ready':
                        $message = "Monthly sales report for " . date('F Y') . " is now available";
                        break;
                    case 'expiring_soon':
                        $message = "Products expiring soon: " . rand(2, 8) . " items will expire within 30 days";
                        break;
                }
                
                if (!empty($message)) {
                    // Insert directly to avoid circular reference with createNotification
                    $stmt = $conn->prepare("INSERT INTO Notifications (UserID, NotificationType, Message, CreatedAt) 
                                          VALUES (:userID, :type, :message, :createdAt)");
                    $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
                    $stmt->bindParam(':type', $type, PDO::PARAM_STR);
                    $stmt->bindParam(':message', $message, PDO::PARAM_STR);
                    $stmt->bindParam(':createdAt', $createdAt, PDO::PARAM_STR);
                    $stmt->execute();
                }
            }
        }
    } catch (PDOException $e) {
        error_log("Error creating test notifications: " . $e->getMessage());
    }
}

/**
 * Ensure the Notifications table exists in the database
 * 
 * @param PDO $conn Database connection
 * @return bool Success status
 */
function ensureNotificationsTableExists($conn) {
    try {
        // Check if table exists
        $stmt = $conn->query("SHOW TABLES LIKE 'Notifications'");
        if ($stmt->rowCount() == 0) {
            // Create table if it doesn't exist
            $sql = "CREATE TABLE IF NOT EXISTS Notifications (
                NotificationID INT AUTO_INCREMENT PRIMARY KEY,
                UserID INT,
                NotificationType VARCHAR(50) NOT NULL,
                Message TEXT NOT NULL,
                IsRead TINYINT(1) DEFAULT 0,
                CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX (UserID),
                INDEX (NotificationType),
                INDEX (IsRead)
            )";
            $conn->exec($sql);
            return true;
        }
        return true;
    } catch (PDOException $e) {
        error_log("Error ensuring Notifications table exists: " . $e->getMessage());
        return false;
    }
}
