<?php
session_start();
require 'config/database.php';

header('Content-Type: application/json'); // Set response type to JSON

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ Invalid request method.'
    ]);
    exit;
}

$postedCode = $_POST['code'] ?? '';
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);

$username = htmlspecialchars(trim($_POST['username'] ?? ''));
$firstname = htmlspecialchars(trim($_POST['firstname'] ?? ''));
$lastname = htmlspecialchars(trim($_POST['lastname'] ?? ''));
$password = $_POST['password'] ?? '';

// Validate inputs
if (empty($postedCode) || empty($email) || empty($username) || 
    empty($firstname) || empty($lastname) || empty($password)) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ All fields are required.'
    ]);
    exit;
}

if (!isset($_SESSION['verification_code']) || !isset($_SESSION['verification_email'])) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ Verification expired. Please try again.'
    ]);
    exit;
}

if ($_SESSION['verification_code'] != $postedCode || $_SESSION['verification_email'] != $email) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ Invalid verification code.'
    ]);
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

try {
    // Check if username already exists (just in case)
    $checkStmt = $conn->prepare("SELECT UserID FROM Users WHERE Username = ?");
    $checkStmt->execute([$username]);
    
    if ($checkStmt->rowCount() > 0) {
        echo json_encode([
            'status' => 'error',
            'message' => '❌ Username already taken.'
        ]);
        exit;
    }

    // Insert user
    $stmt = $conn->prepare("INSERT INTO Users (Username, Email, Password, FirstName, LastName, RoleID)
                            VALUES (?, ?, ?, ?, ?, 4)");
    $stmt->execute([$username, $email, $hashedPassword, $firstname, $lastname]);

    // Log audit
    $log = $conn->prepare("INSERT INTO audit_trail (affected_username, changed_by, action, timestamp) 
                           VALUES (?, ?, ?, NOW())");
    $log->execute([$username, $username, 'Account Registered']);

    // Clear session
    unset($_SESSION['verification_code']);
    unset($_SESSION['verification_email']);

    echo json_encode([
        'status' => 'success',
        'message' => '✅ Registration successful! You can now log in.'
    ]);
    exit; // Make sure to exit after sending JSON
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ Registration failed: ' . $e->getMessage()
    ]);
    exit; // Make sure to exit after sending JSON
}