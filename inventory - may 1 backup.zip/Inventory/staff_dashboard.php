<?php
session_start();
require('config/database.php');
require('notification.php'); // Include notification functions

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is a staff member (role 4)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 4) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

$userID = $_SESSION['user_id'];
$username = $_SESSION['user_name'];

// Get current date and time
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');

// Fetch items nearing expiry (within next 30 days)
$nearExpiryQuery = "SELECT p.ProductName, i.Quantity, i.ExpiryDate, 
                 DATEDIFF(i.ExpiryDate, CURRENT_DATE) as DaysRemaining
                 FROM Inventory i
                 JOIN Product p ON i.ProductID = p.ProductID
                 WHERE i.ExpiryDate IS NOT NULL 
                 AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)
                 ORDER BY i.ExpiryDate ASC
                 LIMIT 10";
$nearExpiryStmt = $conn->prepare($nearExpiryQuery);
$nearExpiryStmt->execute();
$nearExpiryItems = $nearExpiryStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch low stock items
$lowStockThreshold = 9; // Define what "low stock" means
$lowStockQuery = "SELECT p.ProductName, SUM(i.Quantity) as TotalQuantity, c.CategoryName
               FROM Product p
               JOIN Inventory i ON p.ProductID = i.ProductID
               JOIN Category c ON p.CategoryID = c.CategoryID
               GROUP BY p.ProductID
               HAVING TotalQuantity <= ?
               ORDER BY TotalQuantity ASC
               LIMIT 10";
$lowStockStmt = $conn->prepare($lowStockQuery);
$lowStockStmt->execute([$lowStockThreshold]);
$lowStockItems = $lowStockStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent orders (last 7 days)
$recentOrdersQuery = "SELECT o.OrderID, o.OrderDate, COUNT(od.OrderDetailID) as ItemCount, 
                   SUM(od.Price * od.Quantity) as TotalAmount
                   FROM Orders o
                   JOIN OrderDetails od ON o.OrderID = od.OrderID
                   WHERE o.OrderDate >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
                   GROUP BY o.OrderID
                   ORDER BY o.OrderDate DESC
                   LIMIT 10";
$recentOrdersStmt = $conn->prepare($recentOrdersQuery);
$recentOrdersStmt->execute();
$recentOrders = $recentOrdersStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent notifications
$recentNotificationsQuery = "SELECT * FROM Notifications 
                          WHERE UserID = :userID 
                          ORDER BY CreatedAt DESC 
                          LIMIT 10";
$recentNotificationsStmt = $conn->prepare($recentNotificationsQuery);
$recentNotificationsStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
$recentNotificationsStmt->execute();
$recentNotifications = $recentNotificationsStmt->fetchAll(PDO::FETCH_ASSOC);

// Count unread notifications
$unreadNotificationsCount = countUnreadNotifications($conn, $userID);

// Fetch today's tasks (placeholder - you would need a Tasks table)
$todayTasksQuery = "SELECT * FROM Tasks 
                 WHERE AssignedTo = :userID 
                 AND DueDate = CURRENT_DATE
                 AND Completed = 0
                 ORDER BY Priority DESC
                 LIMIT 5";
$hasTasks = false;
$todayTasks = [];

try {
    $todayTasksStmt = $conn->prepare($todayTasksQuery);
    $todayTasksStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
    $todayTasksStmt->execute();
    $todayTasks = $todayTasksStmt->fetchAll(PDO::FETCH_ASSOC);
    $hasTasks = true;
} catch (PDOException $e) {
    // Tasks table might not exist yet
    $hasTasks = false;
}

// Get top selling products of the week
$topProductsQuery = "SELECT p.ProductName, SUM(od.Quantity) as TotalSold
                  FROM OrderDetails od
                  JOIN Product p ON od.ProductID = p.ProductID
                  JOIN Orders o ON od.OrderID = o.OrderID
                  WHERE o.OrderDate >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
                  GROUP BY p.ProductID
                  ORDER BY TotalSold DESC
                  LIMIT 5";
$topProductsStmt = $conn->prepare($topProductsQuery);
$topProductsStmt->execute();
$topProducts = $topProductsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Dashboard - Adriana's Marketing</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/navbar.css">
    <?php include 'includes/toast-head.php'; ?>
    <style>
        /* Dashboard Styles */
        .dashboard-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        
        .dashboard-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-card h3 {
            margin-top: 0;
            color: var(--text-dark);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }
        
        .dashboard-card h3 svg {
            margin-right: 10px;
            width: 24px;
            height: 24px;
        }
        
        .dashboard-card.low-stock {
            border-left: 4px solid #f39c12;
        }
        
        .dashboard-card.orders {
            border-left: 4px solid #27ae60;
        }
        
        .dashboard-card.notifications {
            border-left: 4px solid #3498db;
        }
        
        .dashboard-card.tasks {
            border-left: 4px solid #e74c3c;
        }
        
        .dashboard-card.near-expiry {
            border-left: 4px solid #f1c40f;
        }
        
        .dashboard-card.top-products {
            border-left: 4px solid #2ecc71;
        }
        
        .welcome-header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            color: white;
            padding: 30px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            box-shadow: var(--shadow-md);
        }
        
        .welcome-header h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 600;
            color: white;
        }
        
        .welcome-header p {
            margin: 10px 0 0;
            opacity: 0.9;
            font-size: 1rem;
        }
        
        .stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .stat-card {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: var(--border-radius-sm);
            text-align: center;
        }
        
        .stat-card h3 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 700;
        }
        
        .stat-card p {
            margin: 5px 0 0;
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .item-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .item-list li {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .item-list li:last-child {
            border-bottom: none;
        }
        
        .item-name {
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .item-detail {
            color: var(--text-medium);
            font-size: 0.9rem;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-warning {
            background-color: #f39c12;
            color: #fff;
        }
        
        .badge-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .badge-info {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        
        .badge-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .badge-primary {
            background-color: #cce5ff;
            color: #004085;
        }
        
        .badge-yellow {
            background-color: #fdebd0;
            color: #b7950b;
        }
        
        .view-all {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .view-all:hover {
            text-decoration: underline;
        }
        
        .date-display {
            font-size: 1rem;
            color: rgba(255, 255, 255, 0.8);
            margin-top: 5px;
        }
        
        .empty-state {
            text-align: center;
            padding: 20px 0;
            color: var(--text-light);
            font-style: italic;
        }
        
        .task-item {
            display: flex;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .task-checkbox {
            margin-right: 10px;
        }
        
        .task-content {
            flex: 1;
        }
        
        .task-title {
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .task-due {
            font-size: 0.8rem;
            color: var(--text-medium);
        }
        
        .task-priority {
            margin-left: 10px;
        }
        
        .priority-high {
            color: #e74c3c;
        }
        
        .priority-medium {
            color: #f39c12;
        }
        
        .priority-low {
            color: #3498db;
        }
        
        @media (max-width: 768px) {
            .dashboard-container {
                grid-template-columns: 1fr;
            }
            
            .welcome-header {
                padding: 20px;
            }
            
            .welcome-header h1 {
                font-size: 1.5rem;
            }
            
            .stat-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>
    
    <div class="main-content-wrapper">
        <main class="content">
            <!-- Welcome Header with Stats -->
            <div class="welcome-header">
                <h1>Welcome,   <?= htmlspecialchars($username) ?></h1>
                <p class="date-display"><?= date('l, F j, Y') ?></p>
                
                <div class="stat-grid">
                    <div class="stat-card">
                        <h3><?= count($nearExpiryItems) ?></h3>
                        <p>Expiring Soon</p>
                    </div>
                    <div class="stat-card">
                        <h3><?= count($lowStockItems) ?></h3>
                        <p>Low Stock Items</p>
                    </div>
                    <div class="stat-card">
                        <h3><?= count($recentOrders) ?></h3>
                        <p>Recent Orders</p>
                    </div>
                    <div class="stat-card">
                        <h3><?= $unreadNotificationsCount ?></h3>
                        <p>Unread Notifications</p>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-container">
                <!-- Items Nearing Expiry Card -->
                <div class="dashboard-card near-expiry">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f1c40f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="6" x2="12" y2="12"></line>
                            <line x1="12" y1="16" x2="12.01" y2="16"></line>
                        </svg>
                        Items Nearing Expiry
                    </h3>
                    <?php if (count($nearExpiryItems) > 0): ?>
                        <ul class="item-list">
                            <?php foreach ($nearExpiryItems as $item): ?>
                                <li>
                                    <div>
                                        <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                                        <div class="item-detail">
                                            Expires: <?= date('M d, Y', strtotime($item['ExpiryDate'])) ?> • 
                                            <?= $item['Quantity'] ?> units
                                        </div>
                                    </div>
                                    <span class="badge badge-yellow"><?= $item['DaysRemaining'] ?> days left</span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="inventory.php" class="view-all">View All Expiring Items</a>
                    <?php else: ?>
                        <div class="empty-state">No items nearing expiry.</div>
                    <?php endif; ?>
                </div>
                
                <!-- Low Stock Items Card -->
                <div class="dashboard-card low-stock">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f39c12" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34"></path>
                            <path d="M3 7l9 6 9-6"></path>
                            <line x1="13" y1="17" x2="19" y2="11"></line>
                            <polyline points="19 17 19 11 13 11"></polyline>
                        </svg>
                        Low Stock Items
                    </h3>
                    <?php if (count($lowStockItems) > 0): ?>
                        <ul class="item-list">
                            <?php foreach ($lowStockItems as $item): ?>
                                <li>
                                    <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                                    <span class="badge badge-warning"><?= $item['TotalQuantity'] ?> left</span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="inventory.php" class="view-all">View All Inventory</a>
                    <?php else: ?>
                        <div class="empty-state">No low stock items at the moment.</div>
                    <?php endif; ?>
                </div>
                
                <!-- Recent Orders Card -->
                <div class="dashboard-card orders">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="12" y1="1" x2="12" y2="23"></line>
                            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                        </svg>
                        Recent Orders
                    </h3>
                    <?php if (count($recentOrders) > 0): ?>
                        <ul class="item-list">
                            <?php foreach ($recentOrders as $order): ?>
                                <li>
                                    <div>
                                        <span class="item-name">Order #<?= $order['OrderID'] ?></span>
                                        <div class="item-detail"><?= date('M d, Y', strtotime($order['OrderDate'])) ?> • <?= $order['ItemCount'] ?> items</div>
                                    </div>
                                    <span class="badge badge-success">₱<?= number_format($order['TotalAmount'], 2) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="orders.php" class="view-all">View All Orders</a>
                    <?php else: ?>
                        <div class="empty-state">No recent orders in the last 7 days.</div>
                    <?php endif; ?>
                </div>
                
                <!-- Today's Tasks Card -->
                <div class="dashboard-card tasks">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e74c3c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                        Today's Tasks
                    </h3>
                    <?php if ($hasTasks && count($todayTasks) > 0): ?>
                        <div class="task-list">
                            <?php foreach ($todayTasks as $task): ?>
                                <div class="task-item">
                                    <input type="checkbox" class="task-checkbox" id="task-<?= $task['TaskID'] ?>">
                                    <div class="task-content">
                                        <div class="task-title"><?= htmlspecialchars($task['Title']) ?></div>
                                        <div class="task-due">Due: <?= date('g:i A', strtotime($task['DueTime'])) ?></div>
                                    </div>
                                    <div class="task-priority priority-<?= strtolower($task['Priority']) ?>">
                                        <?= ucfirst(strtolower($task['Priority'])) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <a href="tasks.php" class="view-all">View All Tasks</a>
                    <?php else: ?>
                        <div class="empty-state">No tasks scheduled for today.</div>
                    <?php endif; ?>
                </div>
                
                <!-- Recent Notifications Card -->
                <div class="dashboard-card notifications">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                        </svg>
                        Recent Notifications
                    </h3>
                    <?php if (count($recentNotifications) > 0): ?>
                        <ul class="item-list">
                            <?php foreach ($recentNotifications as $notification): ?>
                                <li class="<?= $notification['IsRead'] ? '' : 'unread' ?>">
                                    <div>
                                        <span class="item-name"><?= htmlspecialchars($notification['Message']) ?></span>
                                        <div class="item-detail"><?= formatNotificationTime($notification['CreatedAt']) ?></div>
                                    </div>
                                    <?php if (!$notification['IsRead']): ?>
                                        <span class="badge badge-info">New</span>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="all_notification.php" class="view-all">View All Notifications</a>
                    <?php else: ?>
                        <div class="empty-state">No notifications at the moment.</div>
                    <?php endif; ?>
                </div>
                
                <!-- Top Selling Products Card -->
                <div class="dashboard-card top-products">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2ecc71" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                            <polyline points="17 6 23 6 23 12"></polyline>
                        </svg>
                        Top Selling Products
                    </h3>
                    <?php if (count($topProducts) > 0): ?>
                        <ul class="item-list">
                            <?php foreach ($topProducts as $product): ?>
                                <li>
                                    <span class="item-name"><?= htmlspecialchars($product['ProductName']) ?></span>
                                    <span class="badge badge-primary"><?= $product['TotalSold'] ?> sold</span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="inventory.php" class="view-all">View All Products</a>
                    <?php else: ?>
                        <div class="empty-state">No sales data available for this week.</div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Task checkbox functionality
            const taskCheckboxes = document.querySelectorAll('.task-checkbox');
            taskCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const taskItem = this.closest('.task-item');
                    if (this.checked) {
                        taskItem.style.opacity = '0.5';
                        taskItem.querySelector('.task-title').style.textDecoration = 'line-through';
                        
                        // In a real application, you would send an AJAX request to update the task status
                        // Example:
                        // const taskId = this.id.replace('task-', '');
                        // fetch('update_task.php', {
                        //     method: 'POST',
                        //     body: JSON.stringify({ taskId: taskId, completed: true }),
                        //     headers: { 'Content-Type': 'application/json' }
                        // });
                    } else {
                        taskItem.style.opacity = '1';
                        taskItem.querySelector('.task-title').style.textDecoration = 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>
