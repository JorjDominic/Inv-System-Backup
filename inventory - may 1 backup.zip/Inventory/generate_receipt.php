<?php
session_start();
require_once 'config/database.php';

// Check if TCPDF is available
$tcpdfPath = 'includes/tcpdf/tcpdf/tcpdf.php';
if (!file_exists($tcpdfPath)) {
    $tcpdfPath = 'tcpdf/tcpdf.php';
    if (!file_exists($tcpdfPath)) {
        die("TCPDF library not found. Please make sure it's installed correctly.");
    }
}
require_once $tcpdfPath;

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Get order ID from URL
$orderId = $_GET['order_id'] ?? null;
if (!$orderId || !is_numeric($orderId)) {
    header('Location: transactions.php?error=Invalid+or+missing+order+ID');
    exit;
}

try {
    // Fetch receipt header info
    $stmt = $conn->prepare("
        SELECT 
            r.ReceiptID,
            r.OrderID,
            r.TotalAmount,
            r.Discount,
            r.DateIssued,
            u.Username,
            pm.MethodName AS PaymentMethod
        FROM Receipts r
        JOIN Orders o ON r.OrderID = o.OrderID
        JOIN Users u ON o.UserID = u.UserID
        JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
        WHERE r.OrderID = ?
    ");
    $stmt->execute([$orderId]);
    $receipt = $stmt->fetch(PDO::FETCH_ASSOC);

    // If no receipt is found
    if (!$receipt) {
        header('Location: transactions.php?error=Receipt+not+found');
        exit;
    }

    // Fetch order item details, including refunded quantity
    $stmt = $conn->prepare("
        SELECT 
            p.ProductName,
            od.Price,
            od.Quantity,
            (od.Price * od.Quantity) AS Subtotal,
            COALESCE(SUM(ri.QuantityRefunded), 0) AS RefundedQty
        FROM OrderDetails od
        JOIN Product p ON od.ProductID = p.ProductID
        LEFT JOIN RefundedItems ri ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
        WHERE od.OrderID = ?
        GROUP BY p.ProductName, od.Price, od.Quantity
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Adjust quantities for refunded items
    $totalRefunded = 0;
    foreach ($items as &$item) {
        $effectiveQty = $item['Quantity'] - $item['RefundedQty'];
        $item['EffectiveQty'] = $effectiveQty;
        $item['EffectiveSubtotal'] = $effectiveQty * $item['Price'];
        $totalRefunded += $item['RefundedQty'] * $item['Price'];
    }

    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator('Adriana\'s Marketing');
    $pdf->SetAuthor('Adriana\'s Marketing');
    $pdf->SetTitle('Receipt #' . $receipt['ReceiptID']);
    $pdf->SetSubject('Receipt');
    $pdf->SetKeywords('Receipt, Order, Invoice');

    // Remove header/footer
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // Set margins
    $pdf->SetMargins(15, 15, 15);

    // Set auto page breaks
    $pdf->SetAutoPageBreak(TRUE, 15);

    // Set image scale factor
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

    // Set font subsetting to improve performance
    $pdf->setFontSubsetting(true);

    // Add a page
    $pdf->AddPage();

    // Set font - use DejaVu Sans which has better Unicode support
    $pdf->SetFont('dejavusans', 'B', 16);

    // Title
    $pdf->Cell(0, 10, 'Adriana\'s Marketing', 0, 1, 'C');
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 5, 'Official Receipt', 0, 1, 'C');
    $pdf->Ln(10);

    // Receipt details
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'Receipt Information', 0, 1);
    $pdf->SetFont('helvetica', '', 10);

    // Create a table for receipt info
    $html = '<table cellspacing="0" cellpadding="3" border="0">
        <tr>
            <td width="30%"><strong>Receipt ID:</strong></td>
            <td width="70%">' . $receipt['ReceiptID'] . '</td>
        </tr>
        <tr>
            <td><strong>Order ID:</strong></td>
            <td>' . $receipt['OrderID'] . '</td>
        </tr>
        <tr>
            <td><strong>Date:</strong></td>
            <td>' . date('F j, Y g:i A', strtotime($receipt['DateIssued'])) . '</td>
        </tr>
        <tr>
            <td><strong>Processed By:</strong></td>
            <td>' . $receipt['Username'] . '</td>
        </tr>
        <tr>
            <td><strong>Payment Method:</strong></td>
            <td>' . $receipt['PaymentMethod'] . '</td>
        </tr>
    </table>';

    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Ln(5);

    // Items table
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'Order Items', 0, 1);
    $pdf->SetFont('helvetica', '', 10);

    $html = '<table cellspacing="0" cellpadding="3" border="1">
        <tr style="background-color:#f2f2f2;">
            <th width="40%" align="center"><strong>Product</strong></th>
            <th width="15%" align="center"><strong>Price</strong></th>
            <th width="10%" align="center"><strong>Qty</strong></th>
            <th width="15%" align="center"><strong>Refunded</strong></th>
            <th width="20%" align="center"><strong>Subtotal</strong></th>
        </tr>';

    foreach ($items as $item) {
        $html .= '<tr>
            <td>' . $item['ProductName'] . '</td>
            <td align="right">PHP ' . number_format($item['Price'], 2) . '</td>
            <td align="center">' . $item['Quantity'] . '</td>
            <td align="center">' . $item['RefundedQty'] . '</td>
            <td align="right">PHP ' . number_format($item['Subtotal'], 2) . '</td>
        </tr>';
    }

    $html .= '</table>';
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Ln(5);

    // Summary
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, 'Summary', 0, 1);
    $pdf->SetFont('helvetica', '', 10);

    $subtotal = $receipt['TotalAmount'] + $receipt['Discount'];
    $finalTotal = $receipt['TotalAmount'] - $totalRefunded;

    $html = '<table cellspacing="0" cellpadding="3" border="0">
        <tr>
            <td width="70%" align="right"><strong>Subtotal:</strong></td>
            <td width="30%" align="right">PHP ' . number_format($subtotal, 2) . '</td>
        </tr>
        <tr>
            <td align="right"><strong>Discount:</strong></td>
            <td align="right">-PHP ' . number_format($receipt['Discount'], 2) . '</td>
        </tr>';
    
    if ($totalRefunded > 0) {
        $html .= '<tr>
            <td align="right"><strong>Refunded Amount:</strong></td>
            <td align="right">-PHP ' . number_format($totalRefunded, 2) . '</td>
        </tr>';
    }
    
    $html .= '<tr>
            <td align="right" style="border-top:1px solid #000;"><strong>Final Total:</strong></td>
            <td align="right" style="border-top:1px solid #000;">PHP ' . number_format($finalTotal, 2) . '</td>
        </tr>
    </table>';

    $pdf->writeHTML($html, true, false, true, false, '');

    // Footer
    $pdf->Ln(10);
    $pdf->SetFont('helvetica', 'I', 8);
    $pdf->Cell(0, 10, 'Thank you for your business!', 0, 1, 'C');
    $pdf->Cell(0, 5, 'This is a computer-generated receipt and requires no signature.', 0, 1, 'C');

    // Clean any content of the output buffer
    ob_end_clean();

    // Output the PDF
    $pdf->Output('receipt_' . $receipt['OrderID'] . '.pdf', 'D');
    exit;
    
} catch (Exception $e) {
    // Redirect back to transactions page with error
    header('Location: transactions.php?error=' . urlencode('Error generating receipt: ' . $e->getMessage()));
    exit;
}
?>
