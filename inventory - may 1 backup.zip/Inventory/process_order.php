<?php
session_start();
require('config/database.php');
require('notification.php'); // Add this line to include notifications functions

// Read raw JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($_SESSION['user_id']) || empty($input['cart']) || empty($input['payment_method'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false, 
        "error" => "Invalid session or missing input.",
        "toast" => [
            "type" => "error",
            "message" => "Invalid session or missing input."
        ]
    ]);
    exit;
}

$userId = $_SESSION['user_id'];
$cart = $input['cart'];
$methodName = $input['payment_method'];
$orderDate = date('Y-m-d');
$orderDiscount = isset($input['discount']) ? floatval($input['discount']) : 0;

// Optional customer info
$firstName = isset($input['first_name']) ? trim($input['first_name']) : null;
$lastName = isset($input['last_name']) ? trim($input['last_name']) : null;
$email = isset($input['email']) ? trim($input['email']) : null;
$customerId = null;

try {
    // Get PaymentMethodID
    $stmt = $conn->prepare("SELECT PaymentMethodID FROM PaymentMethods WHERE MethodName = ?");
    $stmt->execute([$methodName]);
    $method = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$method) {
        http_response_code(400);
        echo json_encode(["success" => false, "error" => "Invalid payment method."]);
        exit;
    }

    $paymentMethodID = $method['PaymentMethodID'];

    $conn->beginTransaction();

    // Handle customer if provided
    if ($firstName && $lastName && $email) {
        $stmt = $conn->prepare("SELECT CustomerID FROM Customers WHERE Email = ?");
        $stmt->execute([$email]);
        $existingCustomer = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingCustomer) {
            $customerId = $existingCustomer['CustomerID'];
        } else {
            $stmt = $conn->prepare("INSERT INTO Customers (FirstName, LastName, Email) VALUES (?, ?, ?)");
            $stmt->execute([$firstName, $lastName, $email]);
            $customerId = $conn->lastInsertId();
        }
    }

    // Insert into Orders
    $stmt = $conn->prepare("INSERT INTO Orders (UserID, OrderDate, PaymentMethodID) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $orderDate, $paymentMethodID]);
    $orderId = $conn->lastInsertId();

    $subtotal = 0;
    $lowStockItems = []; // Track low stock items for notifications

    foreach ($cart as $item) {
        $stmt = $conn->prepare("SELECT ProductID FROM Product WHERE ProductName = ? AND SellingPrice = ?");
        $stmt->execute([$item['name'], $item['price']]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            throw new Exception("Product not found: " . $item['name']);
        }

        $itemSubtotal = $item['price'] * $item['quantity'];
        $subtotal += $itemSubtotal;

        $stmt = $conn->prepare("
            INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $orderId,
            $product['ProductID'],
            $item['quantity'],
            $item['price']
        ]);

        // Deduct inventory using FIFO
        $productId = $product['ProductID'];
        $quantityNeeded = $item['quantity'];

        $stmt = $conn->prepare("
            SELECT InventoryID, Quantity 
            FROM Inventory 
            WHERE ProductID = ? AND Quantity > 0 
            ORDER BY ExpiryDate ASC
        ");
        $stmt->execute([$productId]);
        $inventoryBatches = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($inventoryBatches as $batch) {
            if ($quantityNeeded <= 0) break;

            $deductQty = min($quantityNeeded, $batch['Quantity']);
            $stmt = $conn->prepare("UPDATE Inventory SET Quantity = Quantity - ? WHERE InventoryID = ?");
            $stmt->execute([$deductQty, $batch['InventoryID']]);
            $quantityNeeded -= $deductQty;
        }

        if ($quantityNeeded > 0) {
            throw new Exception("Insufficient stock for product: " . $item['name']);
        }
        
        // Check remaining stock after order
        $stmt = $conn->prepare("
            SELECT SUM(Quantity) as RemainingStock, p.ProductName
            FROM Inventory i
            JOIN Product p ON i.ProductID = p.ProductID
            WHERE i.ProductID = ?
            GROUP BY p.ProductID
        ");
        $stmt->execute([$productId]);
        $stockInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // If stock is low (less than 10), add to notification list
        if ($stockInfo && $stockInfo['RemainingStock'] < 10) {
            $lowStockItems[] = [
                'name' => $stockInfo['ProductName'],
                'stock' => $stockInfo['RemainingStock']
            ];
        }
    }

    $finalTotal = max(0, $subtotal - $orderDiscount);

// Insert into Receipts with CustomerID and UserID (staff/cashier/owner who processed)
$stmt = $conn->prepare("
    INSERT INTO Receipts (OrderID, CustomerID, UserID, TotalAmount, Discount, PaymentMethodID, DateIssued)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $orderId,
    $customerId,
    $userId, // 👈 insert the logged-in user's ID who processed this
    $finalTotal,
    $orderDiscount,
    $paymentMethodID,
    $orderDate
]);

    // Create order notification for ALL users in the system
    $stmt = $conn->prepare("SELECT UserID FROM Users"); // Get ALL users
    $stmt->execute();
    $allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $orderMessage = "New order #$orderId processed for ₱" . number_format($finalTotal, 2);
    foreach ($allUsers as $user) {
        createNotification($conn, $user['UserID'], 'order_status', $orderMessage);
    }
    
    // Create low stock notifications if any items are low
    if (!empty($lowStockItems)) {
        foreach ($lowStockItems as $item) {
            $lowStockMessage = "Low stock alert: {$item['name']} has only {$item['stock']} units remaining";
            
            // Notify ALL users about low stock
            foreach ($allUsers as $user) {
                createNotification($conn, $user['UserID'], 'low_stock', $lowStockMessage);
            }
        }
    }

    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "✅ Order placed successfully.",
        "order_id" => $orderId,
        "subtotal" => $subtotal,
        "order_discount" => $orderDiscount,
        "total" => $finalTotal,
        "toast" => [
            "type" => "success",
            "message" => "Order #$orderId placed successfully!"
        ]
    ]);

} catch (Exception $e) {
    $conn->rollBack();
    http_response_code(500);
    echo json_encode([
        "success" => false, 
        "error" => $e->getMessage(),
        "toast" => [
            "type" => "error",
            "message" => "Error: " . $e->getMessage()
        ]
    ]);
}
?>
