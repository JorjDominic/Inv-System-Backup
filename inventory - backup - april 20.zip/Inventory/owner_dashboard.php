<?php

session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

?>

<!DOCTYPE html>
<html>
<head>

    <title>Owner Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
 /* Basic Reset */
 * {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            box-sizing: border-box;
        }

        html {
            line-height: 1.5rem;
        }

        /* Main Container */
        .container {
            padding: 1rem;
        }

        /* Grid Layout for Dashboard */
        .dashboard-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* Create 2 equal columns */
            grid-gap: 1rem; /* Space between columns */
        }

        /* Dashboard Cards */
        .dashboard-card {
            background-color: #f4f4f4; /* Light gray background for cards */
            border-radius: 8px; /* Rounded corners */
            padding: 1rem;
            margin: 1rem 0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }
        .date {
            font-size: 1rem;
            color: #666;
        }
        .dashboard-card h3 {
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
            color: #333;
        }

        .dashboard-card p {
            color: #666;
            font-size: 1rem;
        }

        /* Styling for different notification types */
        .low-stock {
            border-left: 5px solid #f39c12; /* Yellowish color for low stock */
        }

        .sales {
            border-left: 5px solid #27ae60; /* Green for sales */
        }

        .recent-activity {
            border-left: 5px solid #3498db; /* Blue for recent activity */
        }

        /* Placeholder Card (Fourth container) */
        .placeholder {
            border-left: 5px solid #e0e0e0; /* Light gray for placeholder */
            color: #999;
        }
    </style>
    
</head>
<body>

<?php include 'sidebar.php'; ?> 
<?php include 'navbar.php'; ?>
<main>
    <div class="container">
        <h2>Welcome, Owner <?= htmlspecialchars($_SESSION['user_name']) ?></h2>
        <div class="date"><?= date('l, F j, Y') ?></div>
    </div>

    <div class="dashboard-container">
        <!-- Low Stock Notification -->
        <div class="dashboard-card low-stock">
            <h3>Low Stock Warning</h3>
            <p>There are products that are running low in stock. Please check the inventory!</p>
        </div>

        <!-- Sales Notification -->
        <div class="dashboard-card sales">
            <h3>Recent Sales</h3>
            <p>Your recent sales are available. Check the stats to see how your store is performing.</p>
        </div>

        <!-- Recent Activity -->
        <div class="dashboard-card recent-activity">
            <h3>Recent Activity</h3>
            <p>See recent actions and updates in the system.</p>
        </div>

        <!-- Placeholder for future content -->
        <div class="dashboard-card placeholder">
            <h3>Placeholder</h3>
            <p>This is a placeholder for additional content or notifications.</p>
        </div>
    </div>
    <?php include 'footer.php'; ?>
    </main>
</body>
</html>
