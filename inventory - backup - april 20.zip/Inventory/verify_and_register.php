<?php
session_start();
require 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "❌ Invalid request method.";
    exit;
}

$postedCode = $_POST['code'];
$email      = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);

$username   = htmlspecialchars(trim($_POST['username']));
$firstname  = htmlspecialchars(trim($_POST['firstname']));
$lastname   = htmlspecialchars(trim($_POST['lastname']));
$password   = $_POST['password'];

if (!isset($_SESSION['verification_code']) || !isset($_SESSION['verification_email'])) {
    echo "❌ Verification expired. Please try again.";
    exit;
}

if ($_SESSION['verification_code'] != $postedCode || $_SESSION['verification_email'] != $email) {
    echo "❌ Invalid verification code.";
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

try {
    // Insert user
    $stmt = $conn->prepare("INSERT INTO Users (Username, Email, Password, FirstName, LastName, RoleID)
                            VALUES (?, ?, ?, ?, ?, 4)");
    $stmt->execute([$username, $email, $hashedPassword, $firstname, $lastname]);

    // Log audit
    $log = $conn->prepare("INSERT INTO audit_trail (affected_username, changed_by, action, timestamp) 
                           VALUES (?, ?, ?, NOW())");
    $log->execute([$username, $username, 'Account Registered']);

    // Clear session
    unset($_SESSION['verification_code']);
    unset($_SESSION['verification_email']);

    echo "✅ Registration successful! You can now log in. success";
} catch (PDOException $e) {
    echo "❌ Registration failed: " . $e->getMessage();
}
?>
