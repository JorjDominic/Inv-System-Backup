<?php
session_start();
require('config/database.php');

// 1. Check admin status
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header("Location: index.php");
    exit;
}

// 2. Handle missing username
if (!isset($_SESSION['username'])) {
    try {
        $stmt = $conn->prepare("SELECT Username FROM Users WHERE UserID = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $_SESSION['username'] = $user['Username'];
        } else {
            throw new Exception("User not found");
        }
    } catch (Exception $e) {
        session_destroy();
        header("Location: login.php?error=session_corrupt");
        exit;
    }
}

// 3. Validate deletion target
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid user ID");
}

$userIdToDelete = intval($_GET['id']);
$deletedBy = $_SESSION['username'];


try {
    // Fetch the user info for archival and logging
    $stmt = $conn->prepare("SELECT * FROM Users WHERE UserID = ?");
    $stmt->execute([$userIdToDelete]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo "User not found.";
        exit;
    }

    // Archive the user into DeletedUsers
    $archive = $conn->prepare("
        INSERT INTO DeletedUsers (UserID, Username, Email, FirstName, LastName, RoleID, DeletedBy)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $archive->execute([
        $user['UserID'],
        $user['Username'],
        $user['Email'],
        $user['FirstName'],
        $user['LastName'],
        $user['RoleID'],
        $deletedBy
    ]);

    // Delete from Users
    $delete = $conn->prepare("DELETE FROM Users WHERE UserID = ?");
    $delete->execute([$userIdToDelete]);

    // Insert into audit trail
    $change_time = date('Y-m-d H:i:s');
    $log_query = "
        INSERT INTO audit_trail (affected_username, changed_by, action, timestamp)
        VALUES (:affected_username, :changed_by, :action, :timestamp)
    ";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->bindParam(':affected_username', $user['Username']);
    $log_stmt->bindParam(':changed_by', $deletedBy);
    $log_stmt->bindValue(':action', 'Account Deleted');
    $log_stmt->bindParam(':timestamp', $change_time);
    $log_stmt->execute();

    // Redirect after success
    header("Location: accountmanagement.php?deleted=1");
    exit;
    
} catch (PDOException $e) {
    echo "Error deleting user: " . $e->getMessage();
    exit;
}