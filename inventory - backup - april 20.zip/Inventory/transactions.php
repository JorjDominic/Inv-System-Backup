<?php
session_start();
require('config/database.php');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
  header("Location: index.php");
  exit;
}

$search = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

$conditions = [];
$params = [];

$orderIdFilter = '';

try {
  if (!empty($search)) {
    // 🔍 Find OrderIDs by username or product name
    $searchStmt = $conn->prepare("
      SELECT DISTINCT r.OrderID
      FROM Receipts r
      JOIN Orders o ON r.OrderID = o.OrderID
      JOIN Users u ON o.UserID = u.UserID
      JOIN OrderDetails od ON od.OrderID = o.OrderID
      JOIN Product p ON od.ProductID = p.ProductID
      WHERE u.Username LIKE ? OR p.ProductName LIKE ?
    ");
    $searchStmt->execute(["%$search%", "%$search%"]);
    $matchedOrders = $searchStmt->fetchAll(PDO::FETCH_COLUMN);

    if ($matchedOrders) {
      $placeholders = implode(',', array_fill(0, count($matchedOrders), '?'));
      $conditions[] = "r.OrderID IN ($placeholders)";
      $params = array_merge($params, $matchedOrders);
    } else {
      $conditions[] = "1 = 0"; // No matches, force empty result
    }
  }

  if (!empty($startDate)) {
    $conditions[] = "r.DateIssued >= ?";
    $params[] = $startDate;
  }
  if (!empty($endDate)) {
    $conditions[] = "r.DateIssued <= ?";
    $params[] = $endDate;
  }

  $whereClause = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

  $stmt = $conn->prepare("
    SELECT 
      r.ReceiptID,
      r.OrderID,
      r.TotalAmount,
      r.Discount,
      pm.MethodName AS PaymentMethod,
      r.DateIssued,
      u.Username AS ProcessedBy,
      (SELECT SUM(od.Price * od.Quantity) 
       FROM OrderDetails od 
       WHERE od.OrderID = o.OrderID) AS Subtotal
    FROM Receipts r
    JOIN Orders o ON r.OrderID = o.OrderID
    JOIN Users u ON o.UserID = u.UserID
    JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
    $whereClause
    GROUP BY r.ReceiptID
    ORDER BY r.DateIssued DESC
  ");
  $stmt->execute($params);
  $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
  die("❌ Error loading transactions: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transaction Records</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <style>
    .discount-cell {
      color: #e74c3c;
      font-weight: bold;
    }
    .subtotal-cell {
      color: #3498db;
    }
    .transaction-row {
      cursor: pointer;
    }
    .transaction-row:hover {
      background-color: #f5f5f5;
    }
    .item-details-row {
      background-color: #f9f9f9;
    }
    .item-details-content {
      padding: 15px;
    }
  </style>
</head>

<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>

<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <h1>Transaction Records</h1>
      <form method="GET" class="search-sort-container" style="margin-bottom: 20px;">
  <input type="text" name="search" placeholder="Search by user or product..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
  
  <label>From: <input type="date" name="start_date" value="<?= $_GET['start_date'] ?? '' ?>"></label>
  <label>To: <input type="date" name="end_date" value="<?= $_GET['end_date'] ?? '' ?>"></label>
  
  <button type="submit" class="btn btn-primary">Filter</button>
</form>
      <table class="table">
        <thead>
          <tr>
          <th>Processed By</th>
            <th>Receipt ID</th>
            <th>Order ID</th>
            <th>Subtotal</th>
            <th>Discount</th>
            <th>Total</th>
            <th>Payment Method</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($transactions): ?>
            <?php foreach ($transactions as $row): ?>
              <tr class="transaction-row" data-order-id="<?= $row['OrderID'] ?>">
              <td><?= htmlspecialchars($row['ProcessedBy']) ?></td>
                <td><?= htmlspecialchars($row['ReceiptID']) ?></td>
                <td><?= htmlspecialchars($row['OrderID']) ?></td>
                <td class="subtotal-cell">₱<?= number_format($row['Subtotal'], 2) ?></td>
                <td class="discount-cell">-₱<?= number_format($row['Discount'], 2) ?></td>
                <td>₱<?= number_format($row['TotalAmount'], 2) ?></td>
                <td><?= htmlspecialchars($row['PaymentMethod']) ?></td>
                <td><?= date('M d, Y', strtotime($row['DateIssued'])) ?></td>
                <td><button class="btn btn-danger" disabled>Refund</button></td>
              </tr>
              <tr class="item-details-row" style="display:none;">
                <td colspan="8">
                  <div class="item-details-content">
                    <table class="item-table" style="width:100%">
                      <thead>
                        <tr>
                          <th>Product</th>
                          <th>Price</th>
                          <th>Qty</th>
                          <th>Discount</th>
                          <th>Subtotal</th>
                        </tr>
                      </thead>
                      <tbody id="items-<?= $row['OrderID'] ?>">
                        <!-- Items will be loaded here -->
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="8">No transactions found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<script>
document.querySelectorAll('.transaction-row').forEach(row => {
  row.addEventListener('click', function () {
    const orderId = this.dataset.orderId;
    const detailsRow = this.nextElementSibling;
    const detailsContainer = detailsRow.querySelector('.item-details-content');

    // Toggle visibility
    if (detailsRow.style.display === 'none') {
      detailsRow.style.display = 'table-row';

      // Fetch items only if not already loaded
      if (!detailsContainer.dataset.loaded) {
        fetch(`get_order_items.php?order_id=${orderId}`)
          .then(res => res.text())
          .then(html => {
            detailsContainer.innerHTML = html;
            detailsContainer.dataset.loaded = true;
          })
          .catch(err => {
            detailsContainer.innerHTML = "❌ Failed to load items.";
          });
      }
    } else {
      detailsRow.style.display = 'none';
    }
  });
});
</script>
</body>
</html>