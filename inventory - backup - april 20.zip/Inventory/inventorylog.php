<?php
session_start();
require('config/database.php');

// Only allow admin or dev
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
  header("Location: index.php");
  exit;
}

// Fetch Inventory Logs with joins
$stmt = $conn->prepare("
  SELECT 
    il.LogID,
    u.Username,
    p.ProductName,
    il.Action,
    il.QuantityChanged,
    il.Remarks,
    il.Timestamp
  FROM InventoryLogs il
  JOIN Users u ON il.UserID = u.UserID
  JOIN Inventory i ON il.InventoryID = i.InventoryID
  JOIN Product p ON i.ProductID = p.ProductID
  ORDER BY il.Timestamp DESC
");
$stmt->execute();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Inventory Logs</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <style>
    .log-action {
      font-weight: 600;
    }
    .log-restock { color: green; }
    .log-add { color: blue; }
    .log-deduct { color: red; }
    .log-adjustment { color: orange; }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>

<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>Inventory Logs</h1>
      </div>

      <table class="table">
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>User</th>
            <th>Product</th>
            <th>Action</th>
            <th>Qty Changed</th>
            <th>Remarks</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($logs): ?>
            <?php foreach ($logs as $log): ?>
              <tr>
                <td><?= htmlspecialchars(date('Y-m-d H:i', strtotime($log['Timestamp']))) ?></td>
                <td><?= htmlspecialchars($log['Username']) ?></td>
                <td><?= htmlspecialchars($log['ProductName']) ?></td>
                <td class="log-action log-<?= strtolower($log['Action']) ?>">
                  <?= ucfirst($log['Action']) ?>
                </td>
                <td><?= htmlspecialchars($log['QuantityChanged']) ?></td>
                <td><?= htmlspecialchars($log['Remarks']) ?: '—' ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="6">No logs available.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
