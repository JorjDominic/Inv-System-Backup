<?php
session_start();
require('config/database.php');

$orderId = $_GET['order_id'] ?? null;

if (!$orderId || !is_numeric($orderId)) {
    die("<div class='error-message'>❌ Invalid order ID.</div>");
}

try {
    // 1. Fetch order items (excluding discount)
    $stmt = $conn->prepare("
        SELECT 
            p.ProductName,
            od.Price,
            od.Quantity,
            (od.Price * od.Quantity) AS Subtotal
        FROM OrderDetails od
        JOIN Product p ON od.ProductID = p.ProductID
        WHERE od.OrderID = ?
        ORDER BY p.ProductName
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Fetch discount from Receipts
    $stmt = $conn->prepare("SELECT Discount FROM Receipts WHERE OrderID = ?");
    $stmt->execute([$orderId]);
    $receipt = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalDiscount = $receipt ? floatval($receipt['Discount']) : 0;

    if (!$items) {
        echo "<div class='error-message'>No items found for this order.</div>";
        exit;
    }

    $subtotal = 0;

    echo '<div class="order-items-container">';
    
    foreach ($items as $item) {
        $subtotal += $item['Subtotal'];
        echo '
        <div class="order-item">
            <div class="item-header">
                <h3 class="product-name">'.htmlspecialchars($item['ProductName']).'</h3>
                <span class="item-price">₱'.number_format($item['Price'], 2).'</span>
            </div>
            
            <div class="item-details">
                <div class="detail-row">
                    <span>Quantity:</span>
                    <span class="quantity">'.intval($item['Quantity']).'</span>
                </div>
                <div class="detail-row subtotal">
                    <span>Line Subtotal:</span>
                    <span>₱'.number_format($item['Subtotal'], 2).'</span>
                </div>
            </div>
        </div>';
    }

    $finalTotal = $subtotal - $totalDiscount;

    // Summary Block
    

    // Inline CSS
    echo '
    <style>
    .order-items-container {
        font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;
        max-width: 800px;
        margin: 0 auto;
    }
    
    .order-item {
        background: white;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        transition: transform 0.2s ease;
    }
    
    .order-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #eee;
        padding-bottom: 0.75rem;
        margin-bottom: 1rem;
    }
    
    .product-name {
        font-size: 1.1rem;
        color: #333;
        margin: 0;
    }
    
    .item-price {
        font-weight: bold;
        color: #2c3e50;
    }
    
    .item-details {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0.75rem;
    }
    
    .detail-row {
        display: flex;
        justify-content: space-between;
    }
    
    .detail-row span:first-child {
        color: #7f8c8d;
    }

    .detail-row.discount {
        color: #e74c3c;
    }

    .detail-row.total {
        background: #f8f9fa;
        padding: 0.75rem;
        border-radius: 4px;
        margin-top: 10px;
    }

    .detail-row.subtotal {
        border-top: 1px dashed #ccc;
        padding-top: 8px;
    }

    .summary-block {
        margin-top: 20px;
        padding: 1rem;
        background: #fdfdfd;
        border: 1px solid #eee;
        border-radius: 6px;
    }

    .error-message {
        color: #e74c3c;
        background: #fde8e8;
        padding: 1rem;
        border-radius: 4px;
        text-align: center;
        margin: 1rem 0;
    }

    @media (max-width: 600px) {
        .item-details {
            grid-template-columns: 1fr;
        }
    }
    </style>';

} catch (PDOException $e) {
    echo '<div class="error-message">Error loading items: '.htmlspecialchars($e->getMessage()).'</div>';
}
?>
