<?php
require('config/database.php');

$term = $_GET['term'] ?? '';

$stmt = $conn->prepare("
    SELECT ProductID, ProductName, CategoryID, PurchasePrice, SellingPrice 
    FROM Product 
    WHERE ProductName LIKE CONCAT('%', ?, '%') 
    LIMIT 10
");
$stmt->execute([$term]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($results);