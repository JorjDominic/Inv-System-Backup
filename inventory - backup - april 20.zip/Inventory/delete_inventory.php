<?php
session_start();
require_once 'config/database.php';

// ❌ Remove JSON header because you're outputting HTML (alert + redirect)
// header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method.");
    }

    $inventoryID = $_POST['inventory_id'] ?? null;
    if (!$inventoryID) {
        throw new Exception("Missing inventory ID.");
    }

    $conn->beginTransaction();

    // Fetch inventory and product info
    $stmt = $conn->prepare("
        SELECT i.InventoryID, i.ProductID, i.Quantity, i.DateReceived, i.ExpiryDate,
               p.ProductName, p.PurchasePrice, p.SellingPrice, p.CategoryID
        FROM Inventory i
        JOIN Product p ON i.ProductID = p.ProductID
        WHERE i.InventoryID = ?
    ");
    $stmt->execute([$inventoryID]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$data) {
        throw new Exception("Inventory item not found.");
    }

    // Move to DeletedItems
    $archive = $conn->prepare("
        INSERT INTO DeletedItems (InventoryID, ProductName, Quantity, PurchasePrice, SellingPrice, DateReceived, ExpiryDate, CategoryID)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $archive->execute([
        $data['InventoryID'],
        $data['ProductName'],
        $data['Quantity'],
        $data['PurchasePrice'],
        $data['SellingPrice'],
        $data['DateReceived'],
        $data['ExpiryDate'],
        $data['CategoryID']
    ]);

    // Delete from Inventory
    $conn->prepare("DELETE FROM Inventory WHERE InventoryID = ?")->execute([$inventoryID]);

    // Check if other inventory exists for the same product
    $checkRemaining = $conn->prepare("SELECT COUNT(*) FROM Inventory WHERE ProductID = ?");
    $checkRemaining->execute([$data['ProductID']]);
    $remaining = $checkRemaining->fetchColumn();

    // If no more inventory AND no order history, delete from Product
    $checkOrders = $conn->prepare("SELECT COUNT(*) FROM OrderDetails WHERE ProductID = ?");
    $checkOrders->execute([$data['ProductID']]);
    $hasOrders = $checkOrders->fetchColumn() > 0;

    if ($remaining == 0 && !$hasOrders) {
        $conn->prepare("DELETE FROM Product WHERE ProductID = ?")->execute([$data['ProductID']]);
    }

    $conn->commit();

    // ✅ Trigger alert and redirect (this works only with form submission, not AJAX)
    echo "<script>
        alert('✅ Inventory item deleted.');
        window.location.href = 'inventory.php';
    </script>";
    exit;

} catch (Exception $e) {
    $conn->rollBack();
    echo "<script>
        alert('❌ Error: " . addslashes($e->getMessage()) . "');
        window.location.href = 'inventory.php';
    </script>";
    exit;
}
?>
