<?php
session_start();
require('config/database.php');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
  header("Location: index.php");
  exit;
}


$search = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

$conditions = [];
$params = [];

$orderIdFilter = '';

try {
  if (!empty($search)) {
    // 🔍 Find OrderIDs by username or product name
    $searchStmt = $conn->prepare("
      SELECT DISTINCT r.OrderID
      FROM Receipts r
      JOIN Orders o ON r.OrderID = o.OrderID
      JOIN Users u ON o.UserID = u.UserID
      JOIN OrderDetails od ON od.OrderID = o.OrderID
      JOIN Product p ON od.ProductID = p.ProductID
      WHERE u.Username LIKE ? OR p.ProductName LIKE ?
    ");
    $searchStmt->execute(["%$search%", "%$search%"]);
    $matchedOrders = $searchStmt->fetchAll(PDO::FETCH_COLUMN);

    if ($matchedOrders) {
      $placeholders = implode(',', array_fill(0, count($matchedOrders), '?'));
      $conditions[] = "r.OrderID IN ($placeholders)";
      $params = array_merge($params, $matchedOrders);
    } else {
      $conditions[] = "1 = 0"; // No matches, force empty result
    }
  }

  if (!empty($startDate)) {
    $conditions[] = "r.DateIssued >= ?";
    $params[] = $startDate;
  }
  if (!empty($endDate)) {
    $conditions[] = "r.DateIssued <= ?";
    $params[] = $endDate;
  }

  $whereClause = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

  $stmt = $conn->prepare("
    SELECT 
      r.ReceiptID,
      r.OrderID,
      r.TotalAmount,
      r.Discount,
      pm.MethodName AS PaymentMethod,
      r.DateIssued,
      u.Username AS ProcessedBy,
      (SELECT SUM(od.Price * od.Quantity) 
       FROM OrderDetails od 
       WHERE od.OrderID = o.OrderID) AS Subtotal
    FROM Receipts r
    JOIN Orders o ON r.OrderID = o.OrderID
    JOIN Users u ON o.UserID = u.UserID
    JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
    $whereClause
    GROUP BY r.ReceiptID
    ORDER BY r.DateIssued DESC
  ");
  $stmt->execute($params);
  $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
  die("❌ Error loading transactions: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transaction Records</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <!-- Add this to the head section of your transactions.php file -->
<link rel="stylesheet" href="css/toast-notifications.css">
  <style>
    .discount-cell {
      color: #e74c3c;
      font-weight: bold;
    }
    .subtotal-cell {
      color: #3498db;
    }
    .transaction-row {
      cursor: pointer;
    }
    .transaction-row:hover {
      background-color: #f5f5f5;
    }
    .item-details-row {
      background-color: #f9f9f9;
    }
    .item-details-content {
      padding: 15px;
    }
    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.4);
    }
    .modal.show {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .modal-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      width: 80%;
      max-width: 500px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    .close:hover {
      color: black;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .form-group label {
      display: block;
      margin-bottom: 5px;
    }
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 20px;
    }
    #refundItemsTable {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    #refundItemsTable th, #refundItemsTable td {
      padding: 8px;
      border: 1px solid #ddd;
      text-align: left;
    }
    #refundItemsTable th {
      background-color: #f2f2f2;
    }
    .refund-qty-input {
      width: 60px;
    }
    .topcon{
      position: sticky;
      top: 100px;
  background: white; /* or match your page bg */
  z-index: 1000;
  padding: 10px;
  border-bottom: 1px solid #ccc;
    }

  </style>
</head>

<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>

<div class="main-content-wrapper">
  
  <main class="content">
  
    <div class = "topcon">
    <h1>Transaction Records</h1>
      <form method="GET" class="search-sort-container" style="margin-bottom: 20px;">
        <input type="text" name="search" placeholder="Search by user or product..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        
        <label>From: <input type="date" name="start_date" value="<?= $_GET['start_date'] ?? '' ?>"></label>
        <label>To: <input type="date" name="end_date" value="<?= $_GET['end_date'] ?? '' ?>"></label>
        
        <button type="submit" class="btn btn-primary">Filter</button>
  </div>
    <div class="container">

      
      <table class="table">
        <thead>
          <tr>
            <th>Processed By</th>
            <th>Receipt ID</th>
            <th>Order ID</th>
            <th>Subtotal</th>
            <th>Discount</th>
            <th>Total</th>
            <th>Payment Method</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($transactions): ?>
            <?php foreach ($transactions as $row): ?>
              <tr class="transaction-row" data-order-id="<?= $row['OrderID'] ?>">
                <td><?= htmlspecialchars($row['ProcessedBy']) ?></td>
                <td><?= htmlspecialchars($row['ReceiptID']) ?></td>
                <td><?= htmlspecialchars($row['OrderID']) ?></td>
                <td class="subtotal-cell">₱<?= number_format($row['Subtotal'], 2) ?></td>
                <td class="discount-cell">-₱<?= number_format($row['Discount'], 2) ?></td>
                <td>₱<?= number_format($row['TotalAmount'], 2) ?></td>
                <td><?= htmlspecialchars($row['PaymentMethod']) ?></td>
                <td><?= date('M d, Y', strtotime($row['DateIssued'])) ?></td>

              </tr>
              <tr class="item-details-row" style="display:none;">
                <td colspan="9">
                  <div class="item-details-content">
                    <table class="item-table" style="width:100%">
                      <thead>
                        <tr>
                          <th>Product</th>
                          <th>Price</th>
                          <th>Qty</th>
                          <th>Discount</th>
                          <th>Subtotal</th>
                        </tr>
                      </thead>
                      <tbody id="items-<?= $row['OrderID'] ?>">
                        <!-- Items will be loaded here -->
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="9">No transactions found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>

<!-- Refund Modal -->
<!-- Refund Modal -->
<div class="modal" id="refundModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('refundModal')">&times;</span>
    <h2>Refund Item</h2>
    <form method="POST" action="process_refund.php" id="refundForm">
      <input type="hidden" name="order_id" id="refund_order_id">
      <input type="hidden" name="product_id" id="refund_product_id">


      <p><strong>Product:</strong> <span id="refund_product_name"></span></p>
      <p><strong>Ordered:</strong> <span id="ordered_qty"></span> | <strong>Already Refunded:</strong> <span id="refunded_qty"></span></p>

      <div class="form-group">
        <label for="refund_qty">Quantity to Refund</label>
        <input type="number" id="refund_qty" name="refund_qty" min="1" value="1" required>
      </div>

      <div class="form-group">
        <label for="condition">Condition</label>
        <select name="condition" id="condition" required>
          <option value="">Select</option>
          <option value="PRISTINE">Pristine</option>
          <option value="DAMAGED">Damaged</option>
        </select>
      </div>

      <div class="form-group">
        <label for="refund_reason">Reason (optional)</label>
        <textarea name="refund_reason" id="refund_reason" rows="3"></textarea>
      </div>

      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('refundModal')">Cancel</button>
        <button type="submit" class="btn btn-danger">Confirm Refund</button>
      </div>
    </form>
  </div>
</div>

<script>
// Global variable to store order items
let orderItemsData = {};

// Load order items when Refund button is clicked
function loadOrderItems(orderId) {
  fetch(`get_order_items.php?order_id=${orderId}`)
    .then(res => res.json())
    .then(data => {
      orderItemsData[orderId] = data;
      populateRefundModal(orderId);
      document.getElementById('refundModal').classList.add('show');
    })
    .catch(err => {
      console.error('Error loading order items:', err);
      alert('Failed to load order items');
    });
}

// Populate the refund modal with order items
function populateRefundModal(orderId) {
  const items = orderItemsData[orderId];
  const tbody = document.getElementById('refundItemsBody');
  tbody.innerHTML = '';
  
  document.getElementById('refund_order_id').value = orderId;
  
  items.forEach(item => {
    const availableToRefund = item.quantity - (item.refunded_qty || 0);
    
    if (availableToRefund > 0) {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${item.product_name}</td>
        <td>${item.quantity}</td>
        <td>${item.refunded_qty || 0}</td>
        <td>${availableToRefund}</td>
        <td>
          <input type="number" class="refund-qty-input" name="refund_qty[${item.product_id}]" 
                 min="0" max="${availableToRefund}" value="0" 
                 onchange="validateRefundQty(this, ${availableToRefund})">
        </td>
        <td>
          <select name="condition[${item.product_id}]" required>
            <option value="">Select</option>
            <option value="PRISTINE">Pristine</option>
            <option value="DAMAGED">Damaged</option>
          </select>
        </td>
      `;
      tbody.appendChild(row);
    }
  });
  
  if (tbody.children.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6">No items available for refund</td></tr>';
    document.querySelector('#refundModal button[type="submit"]').disabled = true;
  } else {
    document.querySelector('#refundModal button[type="submit"]').disabled = false;
  }
}

// Validate refund quantity doesn't exceed available
function validateRefundQty(input, max) {
  if (parseInt(input.value) > max) {
    input.value = max;
    alert(`Cannot refund more than ${max} units`);
  }
  if (parseInt(input.value) < 0) {
    input.value = 0;
  }
}

// Close modal
function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('show');
}

// Toggle item details
document.querySelectorAll('.transaction-row').forEach(row => {
  row.addEventListener('click', function(e) {
    // Don't toggle if clicking on the refund button
    if (e.target.tagName === 'BUTTON') return;
    
    const orderId = this.dataset.orderId;
    const detailsRow = this.nextElementSibling;
    const detailsContainer = detailsRow.querySelector('.item-details-content');

    // Toggle visibility
    if (detailsRow.style.display === 'none') {
      detailsRow.style.display = 'table-row';

      // Fetch items only if not already loaded
      if (!detailsContainer.dataset.loaded) {
        fetch(`get_order_items.php?order_id=${orderId}`)
          .then(res => res.text())
          .then(html => {
            detailsContainer.innerHTML = html;
            detailsContainer.dataset.loaded = true;
          })
          .catch(err => {
            detailsContainer.innerHTML = "❌ Failed to load items.";
          });
      }
    } else {
      detailsRow.style.display = 'none';
    }
  });
});
function openItemRefundModal(orderId, productId, orderedQty, refundedQty, productName) {
  const maxRefundable = orderedQty - refundedQty;

  if (maxRefundable <= 0) {
    alert("This item has already been fully refunded.");
    return;
  }

  document.getElementById('refund_order_id').value = orderId;
  document.getElementById('refund_product_id').value = productId;
  document.getElementById('refund_product_name').textContent = productName;
  document.getElementById('ordered_qty').textContent = orderedQty;
  document.getElementById('refunded_qty').textContent = refundedQty;

  const qtyInput = document.getElementById('refund_qty');
  qtyInput.value = 1;
  qtyInput.max = maxRefundable;

  // Show modal
  document.getElementById('refundModal').classList.add('show');
}

document.getElementById('testSubmitBtn').addEventListener('click', function() {
  document.getElementById('refundForm').submit();
});
</script>
<!-- Add this right before the closing </body> tag -->
<script src="js/toast-notifications.js"></script>
<script>
// Fix the refund form submission
document.addEventListener('DOMContentLoaded', function() {
  const refundForm = document.getElementById('refundForm');
  
  if (refundForm) {
    refundForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Show loading toast
      toast.info('Processing refund...', 'Please wait');
      
      // Get form data
      const formData = new FormData(refundForm);
      
      // Send AJAX request
      fetch('process_refund_fixed.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Show success message
          toast.success(data.message, 'Refund Successful');
          
          // Close modal
          closeModal('refundModal');
          
          // Reload page after a short delay
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        } else {
          // Show error message
          toast.error(data.message, 'Refund Failed');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        toast.error('An unexpected error occurred. Please try again.', 'System Error');
      });
    });
  } else {
    console.error('Refund form not found!');
  }
  
  // Add a test button if needed
  const addTestButton = () => {
    const container = document.querySelector('.container');
    if (container) {
      const testBtn = document.createElement('button');
      testBtn.textContent = 'Test Toast Notifications';
      testBtn.className = 'btn btn-primary';
      testBtn.style.marginBottom = '20px';
      testBtn.onclick = function() {
        toast.success('This is a test success message');
        setTimeout(() => {
          toast.error('This is a test error message');
        }, 1000);
        setTimeout(() => {
          toast.info('This is a test info message');
        }, 2000);
        setTimeout(() => {
          toast.warning('This is a test warning message');
        }, 3000);
      };
      container.prepend(testBtn);
    }
  };
  
  // Uncomment this line to add a test button
  // addTestButton();
});

// Function to check if process_refund_fixed.php exists
function checkFileExists() {
  fetch('process_refund_fixed.php', { method: 'HEAD' })
    .then(response => {
      if (response.ok) {
        toast.success('process_refund_fixed.php file exists', 'File Check');
      } else {
        toast.error('process_refund_fixed.php file not found', 'File Check');
      }
    })
    .catch(error => {
      toast.error('Could not check file: ' + error.message, 'File Check');
    });
}

// Uncomment this line to check if the file exists
// setTimeout(checkFileExists, 1000);
</script>
</body>
</html>
