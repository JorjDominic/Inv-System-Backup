
<?php
session_start();
require('config/database.php');

// Only allow admin/staff access
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3)) {
  header('Location: index.php');
  exit;
}

// Fetch FIFO-stacked inventory items
$query = "
SELECT 
  p.ProductName,
  p.CategoryID,
  c.CategoryName,
  p.SellingPrice,
  SUM(i.Quantity) AS TotalQuantity,
  MIN(i.ExpiryDate) AS NearestExpiry
FROM Inventory i
JOIN Product p ON i.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
GROUP BY p.ProductName, p.CategoryID, p.SellingPrice
HAVING TotalQuantity > 0
ORDER BY NearestExpiry ASC
";

$stmt = $conn->query($query);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Inventory - FIFO View</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
</head>
<script src="js/inv.js" defer></script>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <h1>Order Inventory (FIFO)</h1>

      <div class="search-sort-container">
        <div class="search-bar">
          <input type="text" id="searchInput" placeholder="Search products...">
        </div>
        <div class="sort-options">
          <select id="sortSelect">
            <option value="">Sort By</option>
            <option value="name_asc">Name (A-Z)</option>
            <option value="name_desc">Name (Z-A)</option>
            <option value="price_asc">Price (Low-High)</option>
            <option value="price_desc">Price (High-Low)</option>
          </select>
        </div>
      </div>
      
      <table class="table">
        <thead>
          <tr>
            <th>Category</th>
            <th>Product Name</th>
            <th>Selling Price</th>
            <th>Total Quantity</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $item): ?>
            <tr>
              <td><?= htmlspecialchars($item['CategoryName']) ?></td>
              <td><?= htmlspecialchars($item['ProductName']) ?></td>
              <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
              <td><?= $item['TotalQuantity'] ?></td>
              <td> <button class="btn-order" 
                data-name="<?= htmlspecialchars($item['ProductName']) ?>"
                data-price="<?= $item['SellingPrice'] ?>">
                Add to Cart
                </button>
            </td>
              
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="modal" id="cartModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('cartModal')">&times;</span>
    <h2>Add to Cart</h2>
    <form id="cartForm" class="form-container">
      <input type="hidden" id="productId" name="product_id">
      <input type="hidden" id="productName" name="product_name">
      <input type="hidden" id="productPrice" name="product_price">
      
      <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" min="1" value="1" required>
      </div>
      
      <div class="form-group">
        <label>Product: <span id="modalProductName"></span></label>
      </div>
      
      <div class="form-group">
        <label>Price: ₱<span id="modalProductPrice"></span></label>
      </div>
      
      <div class="form-group">
        <label>Total: ₱<span id="modalTotalPrice">0.00</span></label>
      </div>
      
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('cartModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Add to Cart</button>
      </div>
    </form>
  </div>
</div>

<!-- Cart Summary Modal -->
<div class="modal" id="cartSummaryModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('cartSummaryModal')">&times;</span>
    <h2>Your Cart</h2>
    
    <div class="cart-content">
      <!-- Customer Details (Optional) -->
      <div class="form-group">
        <h4>Customer Info (Optional)</h4>
        <div class="form-row">
          <div class="form-group">
            <label for="customerFirstName">First Name</label>
            <input type="text" id="customerFirstName" name="customer_firstname" placeholder="e.g. Juan">
          </div>
          <div class="form-group">
            <label for="customerLastName">Last Name</label>
            <input type="text" id="customerLastName" name="customer_lastname" placeholder="e.g. Dela Cruz">
          </div>
        </div>
        <div class="form-group">
          <label for="customerEmail">Email (optional)</label>
          <input type="email" id="customerEmail" name="customer_email" placeholder="e.g. juan@email.com">
        </div>
      </div>

      <!-- Cart Items -->
      <div class="cart-items-section">
        <div id="cartItemsContainer" class="cart-items-container">
          <!-- Cart items will be dynamically inserted here -->
        </div>
      </div>
      
      <!-- Order Summary -->
      <div class="order-summary">
        <div class="form-group">
          <label for="discount">Discount (₱)</label>
          <input type="number" id="discount" min="0" value="0" step="0.01" oninput="updateCartTotal()">
        </div>
        
        <div class="form-group">
          <label for="paymentMethod">Payment Method</label>
          <select id="paymentMethod" class="form-control">
            <option value="Cash">Cash</option>
            <option value="GCash">GCash</option>
            <option value="Credit">Credit</option>
            <option value="Other">Other</option>
          </select>
        </div>
        
        <div class="summary-row total">
          <span>Total:</span>
          <span id="cartTotal">₱0.00</span>
        </div>
      </div>
    </div>
    
    <!-- Action Buttons -->
    <div class="cart-actions">
      <button type="button" class="btn btn-secondary" onclick="closeModal('cartSummaryModal')">
        Continue Shopping
      </button>
      <button type="button" class="btn btn-primary" onclick="checkout()">
        Checkout
      </button>
    </div>
  </div>
</div>
<!-- Cart Button (Add to header) -->
<div class="cart-button-container">
  <button class="btn btn-primary" onclick="openModal('cartSummaryModal')">
    <span class="icon"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-80q-33 0-56.5-23.5T200-160q0-33 23.5-56.5T280-240q33 0 56.5 23.5T360-160q0 33-23.5 56.5T280-80Zm400 0q-33 0-56.5-23.5T600-160q0-33 23.5-56.5T680-240q33 0 56.5 23.5T760-160q0 33-23.5 56.5T680-80ZM246-720l96 200h280l110-200H246Zm-38-80h590q23 0 35 20.5t1 41.5L692-482q-11 20-29.5 31T622-440H324l-44 80h480v80H280q-45 0-68-39.5t-2-78.5l54-98-144-304H40v-80h130l38 80Zm134 280h280-280Z"/></svg></span> 
    <span id="cartCount">0</span>
  </button>
</div>
  </main>
</div>
<script src="js/inv.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const toastType = urlParams.get("toast");
    const message = urlParams.get("msg");

    if (toastType && message) {
        let bgColor;

        switch (toastType) {
            case "success":
                bgColor = "#2ecc71"; // Green
                break;
            case "error":
                bgColor = "#e74c3c"; // Red
                break;
            case "info":
                bgColor = "#3498db"; // Blue
                break;
            case "warning":
                bgColor = "#f39c12"; // Yellow/Orange
                break;
            default:
                bgColor = "#34495e"; // Default gray
        }

        Toastify({
            text: decodeURIComponent(message),
            duration: 3000,
            gravity: "bottom",
            position: "right",
            backgroundColor: bgColor,
            close: true
        }).showToast();

        // Clean the URL after showing the toast
        if (window.history.replaceState) {
            const cleanUrl = window.location.href.split('?')[0];
            window.history.replaceState({}, document.title, cleanUrl);
        }
    }
});
</script>
</body>
</html>
