<?php
require 'config/database.php';

if (!isset($_GET['order_id']) || !is_numeric($_GET['order_id'])) {
    http_response_code(400);
    echo "Invalid order ID.";
    exit;
}

$orderId = $_GET['order_id'];

try {
    $stmt = $conn->prepare("
        SELECT 
            od.ProductID,
            p.ProductName,
            od.Price,
            od.Quantity
        FROM OrderDetails od
        JOIN Product p ON od.ProductID = p.ProductID
        WHERE od.OrderID = ?
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($items)) {
        echo "<tr><td colspan='5'>No products found for this order.</td></tr>";
        exit;
    }

    foreach ($items as $item) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($item['ProductName']) . "</td>";
        echo "<td>₱" . number_format($item['Price'], 2) . "</td>";
        echo "<td>" . $item['Quantity'] . "</td>";
        echo "<td>
                <select name='refund_condition[" . $item['ProductID'] . "]' required>
                    <option value=''>-- Condition --</option>
                    <option value='pristine'>Pristine</option>
                    <option value='damaged'>Damaged</option>
                </select>
              </td>";
        echo "<td>
                <input type='number' name='refund_quantity[" . $item['ProductID'] . "]' 
                       min='1' max='" . $item['Quantity'] . "' value='" . $item['Quantity'] . "' required>
              </td>";
        echo "</tr>";
    }
} catch (PDOException $e) {
    echo "<tr><td colspan='5'>❌ Error loading items: " . $e->getMessage() . "</td></tr>";
}
?>
