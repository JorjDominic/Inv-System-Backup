<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

// Fetch audit log
$query = "
    SELECT a.*, u.RoleID, r.RoleName
    FROM audit_trail a
    LEFT JOIN Users u ON LOWER(a.changed_by) = LOWER(u.Username)
    LEFT JOIN Roles r ON u.RoleID = r.RoleID
    ORDER BY a.timestamp DESC
";
$stmt = $conn->prepare($query);
$stmt->execute();
$audit_trail = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="css/accmanagement.css">
    <title>Audit Trail</title>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-wrapper">
<main class="content">
    <div class="audit-container">
        <h2>Audit Trail</h2>

        <div class="search-sort-bar" >
            <div class="search-bar" style="flex: 1;">
                <input type="text" id="searchInput" placeholder="Search by username, action, or role...">
            </div>
            <div class="sort-bar">
                <select id="roleFilter" style="padding: 0.65rem 1rem;">
                    <option value="">All Roles</option>
                    <option value="Owner">Owner</option>
                    <option value="Developer">Developer</option>
                    <option value="Cashier">Cashier</option>
                    <option value="Staff">Staff</option>
                </select>
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Account Affected</th>
                    <th>Changed By</th>
                    <th>Role</th>
                    <th>Action</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($audit_trail as $entry): ?>
                <tr>
                    <td><?= htmlspecialchars($entry['affected_username']) ?></td>
                    <td><?= htmlspecialchars($entry['changed_by']) ?></td>
                    <td>
                            <?php
                                if (isset($entry['RoleName']) && !empty($entry['RoleName'])) {
                                    echo htmlspecialchars($entry['RoleName']);
                                } else {
                                    $role = match ($entry['RoleID'] ?? null) {
                                        1 => 'Owner',
                                        2 => 'Developer',
                                        3 => 'Cashier',
                                        4 => 'Staff',
                                        null => 'User not found',
                                        default => 'Unknown (ID: ' . ($entry['RoleID'] ?? 'null') . ')'
                                    };
                                    echo $role;
                                }
                            ?>
                        </td>
                    <td><?= htmlspecialchars($entry['action']) ?></td>
                    <td class="timestamp"><?= htmlspecialchars($entry['timestamp']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php include 'footer.php'; ?>
</main>
</div>

<script>
document.getElementById("searchInput").addEventListener("keyup", filterAuditTrail);
document.getElementById("roleFilter").addEventListener("change", filterAuditTrail);

function filterAuditTrail() {
    const searchValue = document.getElementById("searchInput").value.toLowerCase();
    const selectedRole = document.getElementById("roleFilter").value;
    const rows = document.querySelectorAll(".table tbody tr");

    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        const role = row.children[2].innerText.trim(); // 3rd column is Role
        const matchesSearch = text.includes(searchValue);
        const matchesRole = !selectedRole || role === selectedRole;
        row.style.display = matchesSearch && matchesRole ? "" : "none";
    });
}
</script>
</body>
</html>
