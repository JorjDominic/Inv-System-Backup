<?php
session_start();
require('config/database.php');

// ✅ Permission check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2 && $_SESSION['role'] != 4)) {
    header('Location: index.php');
    exit;
}

// ✅ Validate input
if (!isset($_POST['inventory_id']) || !isset($_POST['quantity'])) {
    die("Invalid request.");
}

$inventoryId = intval($_POST['inventory_id']);
$quantity = intval($_POST['quantity']);
$expiryDate = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

// ✅ Session data
$userId = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Unknown User';

try {
    // ✅ Update inventory quantity and expiration
    $stmt = $conn->prepare("
        UPDATE Inventory 
        SET Quantity = Quantity + :quantity,
            ExpiryDate = COALESCE(:expiry_date, ExpiryDate)
        WHERE InventoryID = :inventory_id
    ");
    $stmt->execute([
        ':quantity' => $quantity,
        ':expiry_date' => $expiryDate,
        ':inventory_id' => $inventoryId
    ]);

    // ✅ Get product name for logging
    $productStmt = $conn->prepare("
        SELECT p.ProductName 
        FROM Inventory i 
        JOIN Product p ON i.ProductID = p.ProductID 
        WHERE i.InventoryID = ?
    ");
    $productStmt->execute([$inventoryId]);
    $product = $productStmt->fetch(PDO::FETCH_ASSOC);
    $productName = $product['ProductName'] ?? 'Unknown Product';

    // ✅ Insert into InventoryLogs
    $logStmt = $conn->prepare("
        INSERT INTO InventoryLogs 
        (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks) 
        VALUES 
        (:user_id, :username, :product_name, :inventory_id, 'restock', :quantity, :remarks)
    ");
    $remarks = "Manual restock of $quantity unit(s).";
    $logStmt->execute([
        ':user_id' => $userId,
        ':username' => $username,
        ':product_name' => $productName,
        ':inventory_id' => $inventoryId,
        ':quantity' => $quantity,
        ':remarks' => $remarks
    ]);

    // ✅ Redirect with toast notification
    header("Location: inventory.php?toast=success&msg=Item Restocked successfully");
    exit;

} catch (PDOException $e) {
    die("Error restocking item: " . $e->getMessage());
}
