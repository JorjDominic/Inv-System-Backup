<?php
session_start();
require('config/database.php');

// Ensure only admins/staff can perform update
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header("Location: index.php");
    exit;
}

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Fetch form values
$inventory_id     = $_POST['inventory_id'];
$product_name     = trim($_POST['product_name']);
$purchase_price   = $_POST['purchase_price'];
$selling_price    = $_POST['selling_price'];
$category_id      = $_POST['category_id'];
$date_received    = $_POST['date_received'];
$expiry_date      = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

try {
    $conn->beginTransaction();

    // ✅ Get user details for logging
    $userID = $_SESSION['user_id'];
    $username = $_SESSION['user_name'] ?? 'Unknown';
    $logTime = date('Y-m-d H:i:s');

    // Get current ProductID from Inventory
    $stmt = $conn->prepare("SELECT ProductID FROM Inventory WHERE InventoryID = ?");
    $stmt->execute([$inventory_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        throw new Exception("Invalid inventory ID");
    }

    $product_id = $product['ProductID'];

    // Update Product info
    $stmt = $conn->prepare("UPDATE Product SET ProductName = ?, PurchasePrice = ?, SellingPrice = ?, CategoryID = ? WHERE ProductID = ?");
    $stmt->execute([$product_name, $purchase_price, $selling_price, $category_id, $product_id]);

    // Update Inventory info (Quantity NOT updated in edit)
    $stmt = $conn->prepare("UPDATE Inventory SET DateReceived = ?, ExpiryDate = ? WHERE InventoryID = ?");
    $stmt->execute([$date_received, $expiry_date, $inventory_id]);

    // ✅ Log the edit to InventoryLogs
    $logStmt = $conn->prepare("
        INSERT INTO InventoryLogs (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks, Timestamp)
        VALUES (?, ?, ?, ?, 'edit', 0, ?, ?)
    ");
    $remarks = "Edited product '$product_name'";
    $logStmt->execute([$userID, $username, $product_name, $inventory_id, $remarks, $logTime]);

    $conn->commit();

    header("Location: inventory.php?toast=success&msg=Item Edited successfully");;
    exit;

} catch (Exception $e) {
    $conn->rollBack();
    echo "❌ Error updating inventory: " . $e->getMessage();
}
