<?php
session_start();
require 'config/database.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['order_id'], $_POST['product_id'], $_POST['refund_qty'], $_POST['condition'])) {
    die("❌ Invalid access.");
}

$orderId = intval($_POST['order_id']);
$productId = intval($_POST['product_id']);
$refundQty = intval($_POST['refund_qty']);
$condition = strtoupper(trim($_POST['condition']));
$reason = trim($_POST['refund_reason'] ?? 'Refund - damaged item');

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];

try {
    $conn->beginTransaction();

    if ($refundQty <= 0 || !in_array($condition, ['PRISTINE', 'DAMAGED'])) {
        throw new Exception("Invalid refund quantity or condition.");
    }

    // Validate ordered quantity
    $stmt = $conn->prepare("SELECT Quantity FROM OrderDetails WHERE OrderID = ? AND ProductID = ?");
    $stmt->execute([$orderId, $productId]);
    $orderItem = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$orderItem) throw new Exception("Product not found in order.");
    $orderedQty = $orderItem['Quantity'];

    // Check previously refunded
    $stmt = $conn->prepare("SELECT COALESCE(SUM(QuantityRefunded), 0) FROM RefundedItems WHERE OrderID = ? AND ProductID = ?");
    $stmt->execute([$orderId, $productId]);
    $alreadyRefunded = $stmt->fetchColumn();

    if ($alreadyRefunded + $refundQty > $orderedQty) {
        throw new Exception("Refund exceeds ordered quantity.");
    }

    // Insert refund record
    $stmt = $conn->prepare("INSERT INTO RefundedItems (OrderID, ProductID, QuantityRefunded, ItemCondition, ProcessedBy, RefundedAt)
                            VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$orderId, $productId, $refundQty, $condition, $userId]);

    // Fetch product name
    $prodStmt = $conn->prepare("SELECT ProductName FROM Products WHERE ProductID = ?");
    $prodStmt->execute([$productId]);
    $productName = $prodStmt->fetchColumn();
    if (!$productName) throw new Exception("Product not found.");

    if ($condition === 'PRISTINE') {
        // Restock
        $restockStmt = $conn->prepare("INSERT INTO Inventory (ProductID, Quantity, DateReceived, ExpiryDate)
                                       VALUES (?, ?, NOW(), NULL)");
        $restockStmt->execute([$productId, $refundQty]);
        $inventoryId = $conn->lastInsertId();

        // Log
        $remarks = "Refunded and restocked: $productName";
        $logStmt = $conn->prepare("INSERT INTO InventoryLogs (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks)
                                   VALUES (?, ?, ?, ?, 'restock_refund', ?, ?)");
        $logStmt->execute([$userId, $username, $productName, $inventoryId, $refundQty, $remarks]);

    } else {
        // Damaged log
        $remarks = "Refunded item marked as DAMAGED: $productName";
        $conn->prepare("INSERT INTO InventoryLogs (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks)
                        VALUES (?, ?, ?, NULL, 'refund_damaged', ?, ?)")
             ->execute([$userId, $username, $productName, $refundQty, $remarks]);

        // Add to DamagedItems
        $conn->prepare("INSERT INTO DamagedItems (ProductID, Quantity, Reason, ReportedBy)
                        VALUES (?, ?, ?, ?)")
             ->execute([$productId, $refundQty, $reason, $userId]);
    }

    $conn->commit();
    echo "<script>alert('✅ Refund processed successfully.'); window.location.href='transactions.php';</script>";
    exit;

} catch (Exception $e) {
    $conn->rollBack();
    echo "<script>alert('❌ Error: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
    exit;
}
?>
