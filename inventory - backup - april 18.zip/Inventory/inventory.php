<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2 && $_SESSION['role'] != 4)) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

ini_set('display_errors', 1);
error_reporting(E_ALL);

$categoryStmt = $conn->query("SELECT CategoryID, CategoryName FROM Category");
$categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inventory Management</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <script>
function openEditModal(button) {
  const modal = document.getElementById('editModal');
  modal.classList.add('show');

  document.getElementById('edit_inventory_id').value = button.dataset.id;
  document.getElementById('edit_product_name').value = button.dataset.name;
  document.getElementById('edit_quantity').value = button.dataset.qty;
  document.getElementById('edit_purchase_price').value = button.dataset.purchase;
  document.getElementById('edit_selling_price').value = button.dataset.selling;
  document.getElementById('edit_date_received').value = button.dataset.date;
  document.getElementById('edit_expiry_date').value = button.dataset.expiry;

  const select = document.getElementById('edit_category_id');
  for (const option of select.options) {
    option.selected = option.value === button.dataset.category;
  }
}

function openModal(id) {
  document.getElementById(id).classList.add('show');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('show');
}
</script>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="main-content-wrapper">
<main class="content">
<div class="container">
<div class="header-container">
  <h1>Inventory Management</h1>
  <button class="btn btn-primary" onclick="openModal('addModal')">
    <span class="icon">+</span> Add New Item
  </button>
</div>
<div class="search-sort-container">
  <div class="search-bar">
    <input type="text" id="searchInput" placeholder="Search products...">
    <button class="search-btn">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
      </svg>
    </button>
  </div>
  
  <div class="sort-options">
    <select id="sortSelect">
      <option value="">Sort By</option>
      <option value="name_asc">Name (A-Z)</option>
      <option value="name_desc">Name (Z-A)</option>
      <option value="quantity_asc">Quantity (Low-High)</option>
      <option value="quantity_desc">Quantity (High-Low)</option>
      <option value="price_asc">Price (Low-High)</option>
      <option value="price_desc">Price (High-Low)</option>
      <option value="expiry_soon">Expiring Soon</option>
    </select>
  </div>
</div>
<div class="table-container">
  <table class="table">
    <thead>
      <tr>
        <th>Category</th>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Selling Price</th>
        <th>Purchase Price</th>
        <th>Date Received</th>
        <th>Expiry Date</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      try {
        $stmt = $conn->query("
          SELECT 
            i.InventoryID,
            p.ProductName,
            p.PurchasePrice,
            p.SellingPrice,
            i.Quantity,
            i.DateReceived,
            i.ExpiryDate,
            c.CategoryName,
            p.CategoryID
          FROM Inventory i
          INNER JOIN Product p ON i.ProductID = p.ProductID
          INNER JOIN Category c ON p.CategoryID = c.CategoryID
          ORDER BY i.DateReceived DESC
        ");

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
          echo "<tr>
            <td>" . htmlspecialchars($row['CategoryName']) . "</td>
            <td>" . htmlspecialchars($row['ProductName']) . "</td>
            <td>" . htmlspecialchars($row['Quantity']) . "</td>
            <td>₱" . number_format($row['SellingPrice'], 2) . "</td>
            <td>₱" . number_format($row['PurchasePrice'], 2) . "</td>
            <td>" . htmlspecialchars($row['DateReceived']) . "</td>
            <td>" . ($row['ExpiryDate'] ? htmlspecialchars($row['ExpiryDate']) : '—') . "</td>
            <td class='actions'>
              <button class='btn btn-edit' onclick='openEditModal(this)'
                data-id='" . $row['InventoryID'] . "'
                data-name='" . htmlspecialchars($row['ProductName'], ENT_QUOTES) . "'
                data-qty='" . $row['Quantity'] . "'
                data-purchase='" . $row['PurchasePrice'] . "'
                data-selling='" . $row['SellingPrice'] . "'
                data-date='" . $row['DateReceived'] . "'
                data-expiry='" . $row['ExpiryDate'] . "'
                data-category='" . $row['CategoryID'] . "'>
                 Edit
              </button>
              <button class='btn btn-danger' onclick='openDeleteModal(" . $row['InventoryID'] . ")'>
                 Delete
              </button>
            </td>
          </tr>";
        }
      } catch (PDOException $e) {
        echo "<tr><td colspan='8'>❌ Error loading inventory: " . $e->getMessage() . "</td></tr>";
      }
      ?>
    </tbody>
  </table>
</div>

</div>
<?php include 'footer.php'; ?>
</main>
</div>

<!-- Add Modal -->
<div class="modal" id="addModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('addModal')">&times;</span>
    <h2>Add Inventory Item</h2>
    <form class="form-container" action="add_inventory.php" method="POST">
      <div class="form-group">
        <label for="product_name">Product Name</label>
        <input type="text" id="product_name" name="product_name" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="quantity">Quantity</label>
          <input type="number" id="quantity" name="quantity" required>
        </div>
        <div class="form-group">
          <label for="purchase_price">Purchase Price (₱)</label>
          <input type="number" step="0.01" id="purchase_price" name="purchase_price" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="selling_price">Selling Price (₱)</label>
          <input type="number" step="0.01" id="selling_price" name="selling_price" required>
        </div>
        <div class="form-group">
          <label for="category">Category</label>
          <select id="category" name="category_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['CategoryID'] ?>"><?= $cat['CategoryName'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="date_received">Date Received</label>
          <input type="date" id="date_received" name="date_received" required>
        </div>
        <div class="form-group">
          <label for="expiry_date">Expiry Date</label>
          <input type="date" id="expiry_date" name="expiry_date">
        </div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Item</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal" id="editModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('editModal')">&times;</span>
    <h2>Edit Inventory Item</h2>
    <form class="form-container" action="update_inventory.php" method="POST">
      <input type="hidden" id="edit_inventory_id" name="inventory_id">

      <div class="form-group">
        <label for="edit_product_name">Product Name</label>
        <input type="text" id="edit_product_name" name="product_name" required>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="edit_quantity">Quantity</label>
          <input type="number" id="edit_quantity" name="quantity" required>
        </div>
        <div class="form-group">
          <label for="edit_purchase_price">Purchase Price (₱)</label>
          <input type="number" step="0.01" id="edit_purchase_price" name="purchase_price" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="edit_selling_price">Selling Price (₱)</label>
          <input type="number" step="0.01" id="edit_selling_price" name="selling_price" required>
        </div>
        <div class="form-group">
          <label for="edit_category_id">Category</label>
          <select id="edit_category_id" name="category_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['CategoryID'] ?>"><?= $cat['CategoryName'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="edit_date_received">Date Received</label>
          <input type="date" id="edit_date_received" name="date_received" required>
        </div>
        <div class="form-group">
          <label for="edit_expiry_date">Expiry Date</label>
          <input type="date" id="edit_expiry_date" name="expiry_date">
        </div>
      </div>

      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Update Item</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete Modal -->
<div class="modal" id="deleteModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('deleteModal')">&times;</span>
    <h2>Confirm Deletion</h2>
    <form class="form-container" action="delete_inventory.php" method="POST">
      <p>Are you sure you want to delete this inventory item? This action cannot be undone.</p>
      <input type="hidden" name="inventory_id" value="">
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete Permanently</button>
      </div>
    </form>
  </div>
</div>

<?php if (isset($_GET['success'])): ?>
  <div style="background: #d4edda; color: #155724; padding: 10px; margin: 15px; border: 1px solid #c3e6cb;">
    ✅ Item successfully added to inventory.
  </div>
<?php endif; ?>

<script src="js/inv.js"></script>
</body>
</html>
