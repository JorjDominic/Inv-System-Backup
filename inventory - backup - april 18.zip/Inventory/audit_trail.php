<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

$query = "SELECT * FROM audit_trail ORDER BY timestamp DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$audit_trail = $stmt->fetchAll(PDO::FETCH_ASSOC);
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Trail</title>
    <style>
        :root {
            --primary-color: #4a934a;
            --primary-light: #9fce88;
            --primary-dark: #3a7a3a;
            --text-color: #333;
            --light-gray: #f5f5f5;
            --medium-gray: #e0e0e0;
            --dark-gray: #777;
            --white: #ffffff;
            --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.1);
            --shadow-md: 0 4px 12px rgba(0, 0, 0, 0.15);
            --transition: all 0.3s ease;
            --border-radius: 12px;
            --border-radius-sm: 8px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            display: grid;
            grid-template-columns: auto 1fr;
            background-color: #f8f9fa;
        }

        main {
            padding: 2rem;
            width: 100%;
            max-width: 1600px;
            margin: 0 auto;
        }

        .audit-container {
            background-color: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 2rem;
            margin-bottom: 2rem;
        }

        h2 {
            color: black;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
            border-bottom: 2px solid var(--primary-light);
            padding-bottom: 0.5rem;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-sm);
        }

        .table thead {
            background-color: var(--primary-light);
            color: var(--white);
        }

        .table th {
            padding: 1rem;
            text-align: left;
            font-weight: 600;
        }

        .table td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid var(--medium-gray);
        }

        .table tr:nth-child(even) {
            background-color: var(--light-gray);
        }

        .table tr:hover {
            background-color: rgba(159, 206, 136, 0.1);
        }

        .btn {
            display: inline-block;
            padding: 0.5rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            border: none;
            font-size: 0.9rem;
        }

        .btn-danger {
            background-color: #dc3545;
            color: var(--white);
        }

        .btn-danger:hover {
            background-color: #c82333;
            transform: translateY(-1px);
            box-shadow: var(--shadow-sm);
        }

        .timestamp {
            color: var(--dark-gray);
            font-size: 0.85rem;
        }

        @media (max-width: 768px) {
            body {
                grid-template-columns: 1fr;
            }
            
            .table {
                display: block;
                overflow-x: auto;
            }
            
            main {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    
    <main>
        <div class="audit-container">
            <h2>Audit Trail</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Action</th>
                        <th>Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($audit_trail as $entry): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($entry['username']); ?></td>
                        <td><?php echo htmlspecialchars($entry['action']); ?></td>
                        <td class="timestamp"><?php echo htmlspecialchars($entry['timestamp']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
        <?php include 'footer.php'; ?>
    </main>
   
</body>
</html>