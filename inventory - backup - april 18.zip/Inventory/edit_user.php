<?php
session_start();
require('config/database.php');

// Only allow admin to access this page
if ($_SESSION['role'] != 1 && $_SESSION['role'] != 2) {
    header('Location: index.php');
    exit;
}

// Handle form submission to update user
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = $_POST['user_id'];
    $username = htmlspecialchars(trim($_POST['username']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $role = $_POST['role'];

    // Prepare and execute the update query
    $stmt = $conn->prepare("UPDATE Users SET Username = ?, Email = ?, RoleID = ? WHERE UserID = ?");
    $stmt->execute([$username, $email, $role, $userId]);

    echo '<script>alert("User Edited!"); window.location.href="accountmanagement.php";</script>';
}
?>
