<?php
session_start();
require('config/database.php');

// Ensure only admins/staff can perform update
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header("Location: index.php");
    exit;
}

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Fetch form values
$inventory_id     = $_POST['inventory_id'];
$product_name     = trim($_POST['product_name']);
$quantity         = $_POST['quantity'];
$purchase_price   = $_POST['purchase_price'];
$selling_price    = $_POST['selling_price'];
$category_id      = $_POST['category_id'];
$date_received    = $_POST['date_received'];
$expiry_date      = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

try {
    // Get current ProductID from Inventory
    $stmt = $conn->prepare("SELECT ProductID FROM Inventory WHERE InventoryID = ?");
    $stmt->execute([$inventory_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        throw new Exception("Invalid inventory ID");
    }

    $product_id = $product['ProductID'];

    // Update Product
    $stmt = $conn->prepare("UPDATE Product SET ProductName = ?, PurchasePrice = ?, SellingPrice = ?, CategoryID = ? WHERE ProductID = ?");
    $stmt->execute([$product_name, $purchase_price, $selling_price, $category_id, $product_id]);

    // Update Inventory
    $stmt = $conn->prepare("UPDATE Inventory SET Quantity = ?, DateReceived = ?, ExpiryDate = ? WHERE InventoryID = ?");
    $stmt->execute([$quantity, $date_received, $expiry_date, $inventory_id]);

    // Redirect with success flag
    header("Location: inventory.php?success=1");
    exit;

} catch (Exception $e) {
    echo "❌ Error updating inventory: " . $e->getMessage();
}
?>
