

document.addEventListener('DOMContentLoaded', function () {
  // General modal open/close
  window.openModal = function (id) {
    const modal = document.getElementById(id);
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';

    if (id === 'cartSummaryModal') {
      displayCartItems();
    }
  };

  window.closeModal = function (id) {
    const modal = document.getElementById(id);
    modal.classList.remove('show');
    document.body.style.overflow = 'auto';
  };

  // Close modals by clicking outside
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function (e) {
      if (e.target === this) closeModal(this.id);
    });
  });

  // 🔍 Live Search
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      const searchTerm = this.value.toLowerCase();
      document.querySelectorAll('.table tbody tr').forEach(row => {
        const productName = row.cells[0].textContent.toLowerCase();
        row.style.display = productName.includes(searchTerm) ? '' : 'none';
      });
    });
  }

  // ⬇ Sorting
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', function () {
      const value = this.value;
      const tbody = document.querySelector('.table tbody');
      const rows = Array.from(tbody.querySelectorAll('tr'));

      rows.sort((a, b) => {
        const getPrice = (cell) => parseFloat(cell.textContent.replace(/[₱,]/g, ''));

        switch (value) {
          case 'name_asc':
            return a.cells[0].textContent.localeCompare(b.cells[0].textContent);
          case 'name_desc':
            return b.cells[0].textContent.localeCompare(a.cells[0].textContent);
          case 'price_asc':
            return getPrice(a.cells[2]) - getPrice(b.cells[2]);
          case 'price_desc':
            return getPrice(b.cells[2]) - getPrice(a.cells[2]);
          default:
            return 0;
        }
      });

      rows.forEach(row => tbody.appendChild(row));
    });
  }
  window.openDeleteModal = function (inventoryId) {
    const modal = document.getElementById('deleteModal');
    if (modal) {
      const input = modal.querySelector('input[name="inventory_id"]');
      input.value = inventoryId;
      openModal('deleteModal');
    }
  };
  // Order buttons
  document.querySelectorAll('.btn-order').forEach(button => {
    button.addEventListener('click', function () {
      const productName = button.getAttribute('data-name');
      const price = parseFloat(button.getAttribute('data-price'));
      openCartModal(productName, price);
    });
  });

  const qtyInput = document.getElementById('quantity');
  if (qtyInput) {
    qtyInput.addEventListener('input', updateTotalPrice);
  }
});

// Cart functionality
globalThis.cart = [];

function openCartModal(productName, price) {
  document.getElementById('modalProductName').textContent = productName;
  document.getElementById('modalProductPrice').textContent = price.toFixed(2);
  document.getElementById('quantity').value = 1;
  updateTotalPrice();
  openModal('cartModal');

  const form = document.getElementById('cartForm');
  form.onsubmit = null;
  form.onsubmit = function (e) {
    e.preventDefault();
    const quantity = parseInt(document.getElementById('quantity').value);
    addToCart(productName, price, quantity);
    closeModal('cartModal');
    return false;
  };
}

function updateTotalPrice() {
  const quantity = parseInt(document.getElementById('quantity').value) || 0;
  const price = parseFloat(document.getElementById('modalProductPrice').textContent) || 0;
  const total = (quantity * price).toFixed(2);
  document.getElementById('modalTotalPrice').textContent = total;
}

function addToCart(name, price, quantity) {
  const existingIndex = cart.findIndex(item => item.name === name && item.price === price);
  if (existingIndex >= 0) {
    cart[existingIndex].quantity += quantity;
  } else {
    cart.push({ name, price, quantity });
  }

  updateCartCount();
  displayCartItems();
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  document.getElementById('cartCount').textContent = count;
}

function displayCartItems() {
  const container = document.getElementById('cartItemsContainer');
  container.innerHTML = '';

  if (cart.length === 0) {
    container.innerHTML = '<p class="empty-cart-message">Your cart is empty</p>';
    document.getElementById('cartTotal').textContent = '0.00';
    return;
  }

  let total = 0;

  cart.forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const itemElement = document.createElement('div');
    itemElement.className = 'cart-item';
    itemElement.innerHTML = `
      <div class="cart-item-details">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-quantity">
          <button class="qty-btn" onclick="changeQuantity(${index}, -1)">−</button>
          <span>${item.quantity}</span>
          <button class="qty-btn" onclick="changeQuantity(${index}, 1)">+</button>
        </div>
      </div>
      <div class="cart-item-price">₱${itemTotal.toFixed(2)}</div>
    `;
    container.appendChild(itemElement);
  });

  document.getElementById('cartTotal').textContent = total.toFixed(2);
}

// Quantity change handler
function changeQuantity(index, delta) {
  cart[index].quantity += delta;

  if (cart[index].quantity <= 0) {
    cart.splice(index, 1);
  }

  updateCartCount();
  displayCartItems();

  let total = 0;
  cart.forEach(item => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const itemDiv = document.createElement('div');
    itemDiv.className = 'cart-item';
    itemDiv.innerHTML = `
      <div class="cart-item-details">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-quantity">Qty: ${item.quantity}</div>
      </div>
      <div class="cart-item-price">₱${itemTotal.toFixed(2)}</div>
    `;
    container.appendChild(itemDiv);
  });

  document.getElementById('cartTotal').textContent = total.toFixed(2);
}

function checkout() {
  if (cart.length === 0) {
    alert('Your cart is empty!');
    return;
  }

  alert('Order placed successfully!');
  cart = [];
  updateCartCount();
  displayCartItems();
  closeModal('cartSummaryModal');
}
