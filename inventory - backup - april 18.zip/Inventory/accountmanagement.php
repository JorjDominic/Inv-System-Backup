<?php

session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Only allow admins to access this page
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

// Fetch all users for display
$stmt = $conn->prepare("SELECT * FROM Users");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/accmanagement.css">
    <title>Account Management</title>

</head>
<body>
<?php include 'sidebar.php'; ?>
<main>
<div class="container">
    <h1>Account Management</h1>
 
    <!-- Table for displaying users -->
    <table class="table">
        <thead>
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>First Name </th>
                <th>Last Name</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['Username']) ?></td>
                    <td><?= htmlspecialchars($user['Email']) ?></td>
                    <td><?= htmlspecialchars($user['PhoneNumber']) ?></td>
                    <td><?= htmlspecialchars($user['FirstName']) ?></td>
                    <td><?= htmlspecialchars($user['LastName']) ?></td>

                    <td><?= $user['RoleID'] == 1 ? 'Admin' : ($user['RoleID'] == 2 ? 'Developer' : ($user['RoleID'] == 3 ? 'Cashier' : 'Staff')) ?></td>
                    <td>
                        <!-- Edit button to open the modal -->
                        <button class="btn btn-edit" onclick="openEditModal(<?= $user['UserID'] ?>, '<?= htmlspecialchars($user['Username']) ?>', '<?= htmlspecialchars($user['Email']) ?>', <?= $user['RoleID'] ?>)">Edit</button>
                        <!-- Delete button -->
                        <a href="delete_user.php?id=<?= $user['UserID'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal for Editing User -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>Edit User</h2>
        <form action="edit_user.php" method="POST">
            <input type="hidden" id="editUserId" name="user_id">
            <label for="editUsername">Username:</label>
            <input type="text" id="editUsername" name="username" required><br>

            <label for="editEmail">Email:</label>
            <input type="email" id="editEmail" name="email" required><br>

            <label for="editRole">Role:</label>
            <select id="editRole" name="role" required>
                <option value="1">Admin</option>
                <option value="2">Developer</option>
                <option value="3">Cashier</option>
                <option value="4">Staff</option>
            </select>

            <button type="submit">Save Changes</button>
        </form>
    </div>
</div>

<script>
    function openEditModal(id, username, email, role) {
        document.getElementById("editUserId").value = id;
        document.getElementById("editUsername").value = username;
        document.getElementById("editEmail").value = email;
        document.getElementById("editRole").value = role;

        document.getElementById("editModal").style.display = "block";
    }

    function closeModal() {
        document.getElementById("editModal").style.display = "none";
    }

    window.onclick = function(event) {
        if (event.target == document.getElementById("editModal")) {
            closeModal();
        }
    }
</script>
<?php include 'footer.php'; ?>
</main>

</body>
</html>
