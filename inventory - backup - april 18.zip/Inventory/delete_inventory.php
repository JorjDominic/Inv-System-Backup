<?php
session_start();
require_once 'config/database.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inventoryID = $_POST['inventory_id'] ?? null;

    if (!$inventoryID) {
        $_SESSION['error'] = "No inventory ID provided.";
        header("Location: inventory.php");
        exit;
    }

    try {
        $conn->beginTransaction();

        // Fetch inventory and product data
        $stmt = $conn->prepare("
            SELECT i.InventoryID, i.Quantity, i.DateReceived, i.ExpiryDate,
                   p.ProductName, p.PurchasePrice, p.SellingPrice, p.CategoryID
            FROM Inventory i
            JOIN Product p ON i.ProductID = p.ProductID
            WHERE i.InventoryID = ?
        ");
        $stmt->execute([$inventoryID]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$data) {
            throw new Exception("Item not found.");
        }

        // Insert into DeletedItems
        $archive = $conn->prepare("
            INSERT INTO DeletedItems (InventoryID, ProductName, Quantity, PurchasePrice, SellingPrice, DateReceived, ExpiryDate, CategoryID)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $archive->execute([
            $data['InventoryID'],
            $data['ProductName'],
            $data['Quantity'],
            $data['PurchasePrice'],
            $data['SellingPrice'],
            $data['DateReceived'],
            $data['ExpiryDate'],
            $data['CategoryID']
        ]);

        // Delete from Inventory and Product
        $conn->prepare("DELETE FROM Inventory WHERE InventoryID = ?")->execute([$inventoryID]);
        $conn->prepare("DELETE FROM Product WHERE ProductName = ?")->execute([$data['ProductName']]);

        $conn->commit();

        $_SESSION['success'] = "Item moved to Deleted Items.";
        header("Location: inventory.php");
        exit;

    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error'] = "❌ Error: " . $e->getMessage();
        header("Location: inventory.php");
        exit;
    }
}
?>
