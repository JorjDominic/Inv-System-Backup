<?php
session_start();
include('config/database.php');

$username = $_SESSION['user_name'];

$logout_time = date('Y-m-d H:i:s');
$log_query = "INSERT INTO audit_trail (username, action, timestamp) VALUES
(:username, 'logout', :timestamp)";
$log_stmt = $conn->prepare($log_query);
$log_stmt->bindParam(':username', $username);
$log_stmt->bindParam(':timestamp', $logout_time);
$log_stmt->execute();


session_destroy();

header('Location: index.php');

?>