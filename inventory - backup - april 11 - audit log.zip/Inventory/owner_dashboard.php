<?php

session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

$query = "SELECT * FROM audit_trail ORDER BY timestamp DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$audit_trail = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<h2>Audit Trail</h2>";
echo "<table class='table'>";
echo
"<thead><tr><th>Username</th><th>Action</th><th>Timestamp</th></tr></thead>
<tbody>";
foreach ($audit_trail as $entry) {
echo
"<tr><td>{$entry['username']}</td><td>{$entry['action']}</td><td>{$entry['timestamp']}</td></tr>";
}
echo "</tbody></table>";
echo '<form action="logout.php" method="POST">
<button type="submit" class="btn btn-danger">Logout</button>
</form>';
?>

<!DOCTYPE html>
<html>
<head><title>Owner Dashboard</title></head>
<body>
<h1>Owner Dashboard</h1>
<h2>Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?></h2>
<a href="user_profile.php">Update Profile</a>
<a href="logout.php">Logout</a>
</body>
</html>
