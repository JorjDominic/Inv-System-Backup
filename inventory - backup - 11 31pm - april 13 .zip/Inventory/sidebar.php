<?php
// Access session
if (!isset($_SESSION)) {
    session_start();
}

// Optional: fallback roleID if not set
$role = $_SESSION['role'] ?? null;
?>
<link rel="stylesheet" href="css/staff.css">
<script>
    window.onload = function () {
        const toggleButton = document.getElementById('toggle-btn');
        const sidebar = document.getElementById('sidebar');

        toggleButton.addEventListener('click', function () {
            sidebar.classList.toggle('close');
            toggleButton.classList.toggle('rotate');

            Array.from(sidebar.getElementsByClassName('show')).forEach(ul => {
                ul.classList.remove('show');
                ul.previousElementSibling.classList.remove('rotate');
            });
        });

        window.toggleSubMenu = function (button) {
            const submenu = button.nextElementSibling;
            submenu.classList.toggle('show');
            button.classList.toggle('rotate');

            if (sidebar.classList.contains('close')) {
                sidebar.classList.toggle('close');
                toggleButton.classList.toggle('rotate');
            }
        };
    };
</script>
<nav id="sidebar">
    <ul>
        <li>
            <span class="logo">Adriana's Marketing</span>
            <button id="toggle-btn">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                    <path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/>
                </svg>
            </button>
        </li>

        <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'owner_dashboard.php' && $_SESSION['role'] == 1) ||
                          (basename($_SERVER['PHP_SELF']) == 'customer_home.php' && $_SESSION['role'] == 2) ||
                          (basename($_SERVER['PHP_SELF']) == 'designer_home.php' && $_SESSION['role'] == 3) ||
                          (basename($_SERVER['PHP_SELF']) == 'staff_dashboard.php' && $_SESSION['role'] == 4) ? 'active' : ''; ?>">
            <a href="<?php
                // Dynamically set the home page link based on user role
                if ($_SESSION['role'] == 1) {
                    echo 'owner_dashboard.php';  // Admin home page
                } elseif ($_SESSION['role'] == 2) {
                    echo 'customer_home.php';  // Customer home page
                } elseif ($_SESSION['role'] == 3) {
                    echo 'designer_home.php';  // Designer home page
                } else {
                    echo 'staff_dashboard.php';  // Default to staff home page
                }
            ?>">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                    <path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/>
                </svg>
                <span>Home</span>
            </a>
        </li>

        <?php if ($role == 4 || $role == 1 || $role == 3): // Staff ?>
            <li>
                <button onclick="toggleSubMenu(this)" class="dropdown-btn">
                    <!-- Inventory -->
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="M160-200h80v-320h480v320h80v-426L480-754 160-626v426Zm-80 80v-560l400-160 400 160v560H640v-320H320v320H80Zm280 0v-80h80v80h-80Zm80-120v-80h80v80h-80Zm80 120v-80h80v80h-80ZM240-520h480-480Z"/>
                    </svg>
                    <span>Inventory</span>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="M480-360 280-560h400L480-360Z"/>
                    </svg>
                </button>
                <ul class="sub-menu">
                    <div>
                        <li><a href="staff_home.php">Order</a></li>
                        <li><a href="staff_home.php">Stocks</a></li>
                        <li><a href="staff_home.php">Transactions</a></li>
                    </div>
                </ul>
            </li>

            <li>
                <button onclick="toggleSubMenu(this)" class="dropdown-btn">
                    <!-- Records -->
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M560-564v-68q33-14 67.5-21t72.5-7q26 0 51 4t49 10v64q-24-9-48.5-13.5T700-600q-38 0-73 9.5T560-564Zm0 220v-68q33-14 67.5-21t72.5-7q26 0 51 4t49 10v64q-24-9-48.5-13.5T700-380q-38 0-73 9t-67 27Zm0-110v-68q33-14 67.5-21t72.5-7q26 0 51 4t49 10v64q-24-9-48.5-13.5T700-490q-38 0-73 9.5T560-454ZM260-320q47 0 91.5 10.5T440-278v-394q-41-24-87-36t-93-12q-36 0-71.5 7T120-692v396q35-12 69.5-18t70.5-6Zm260 42q44-21 88.5-31.5T700-320q36 0 70.5 6t69.5 18v-396q-33-14-68.5-21t-71.5-7q-47 0-93 12t-87 36v394Zm-40 118q-48-38-104-59t-116-21q-42 0-82.5 11T100-198q-21 11-40.5-1T40-234v-482q0-11 5.5-21T62-752q46-24 96-36t102-12q58 0 113.5 15T480-740q51-30 106.5-45T700-800q52 0 102 12t96 36q11 5 16.5 15t5.5 21v482q0 23-19.5 35t-40.5 1q-37-20-77.5-31T700-240q-60 0-116 21t-104 59ZM280-494Z"/></svg>
                    </svg>
                    <span>Records</span>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="M480-360 280-560h400L480-360Z"/>
                    </svg>
                </button>
                <ul class="sub-menu">
                    <div>
                        <li><a href="staff_home.php">Reports</a></li>
                        <li><a href="staff_home.php">Expenses</a></li>
                        <li><a href="staff_home.php">Statistics</a></li>
                    </div>
                </ul>
            </li>
        <?php endif; ?>
        <?php if ($role == 1): // Admin only ?>
    <li>
        <button onclick="toggleSubMenu(this)" class="dropdown-btn">
            <!-- Security -->
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-80q-139-35-229.5-159.5T160-516v-244l320-120 320 120v244q0 152-90.5 276.5T480-80Zm0-84q97-30 162-118.5T718-480H480v-315l-240 90v207q0 7 2 18h238v316Z"/></svg>
            <span>Security</span>
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                <path d="M480-360 280-560h400L480-360Z"/>
            </svg>
        </button>
        <ul class="sub-menu">
            <div>
                <li><a href="audit_trail.php">Audit Trails</a></li>
            </div>
        </ul>
    </li>
<?php endif; ?>
        <li>
            <a href="logout.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>                <span>Logout</span>
            </a>
        </li>
    </ul>
</nav>