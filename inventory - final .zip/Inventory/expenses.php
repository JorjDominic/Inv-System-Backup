<?php
session_start();
require('config/database.php');

// Check if user is logged in and has appropriate permissions
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3)) {
    header('Location: index.php');
    exit;
}

// Apply filters if provided
$whereClause = "1=1"; // Always true condition to start with
$params = [];

// Filter logic for search
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = $_GET['search'];
    $whereClause .= " AND (e.Description LIKE ? OR e.Category LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Filter logic for start and end date
if (isset($_GET['start_date']) && !empty($_GET['start_date'])) {
    $startDate = $_GET['start_date'];
    $whereClause .= " AND e.Date >= ?";
    $params[] = $startDate;
}

if (isset($_GET['end_date']) && !empty($_GET['end_date'])) {
    $endDate = $_GET['end_date'];
    $whereClause .= " AND e.Date <= ?";
    $params[] = $endDate;
}

// Fetching the expenses from the database along with the user who processed it
$query = "SELECT e.ExpenseID, e.Description, e.Category, e.Amount, e.Date, u.Username as ProcessedBy
          FROM Expenses e
          JOIN Users u ON e.UserID = u.UserID
          WHERE $whereClause
          ORDER BY e.Date DESC";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Other queries for damaged items, refunded items, and expired items
// These queries remain as is from your original code...

// Calculate total expenses for the filtered results
$totalQuery = "SELECT SUM(e.Amount) as TotalAmount FROM Expenses e WHERE $whereClause";
$totalStmt = $conn->prepare($totalQuery);
$totalStmt->execute($params);
$totalExpenses = $totalStmt->fetch(PDO::FETCH_ASSOC)['TotalAmount'] ?? 0;

// Get expense categories for dropdown
$categoryQuery = "SELECT DISTINCT Category FROM Expenses ORDER BY Category";
$categoryStmt = $conn->prepare($categoryQuery);
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expenses Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
</head>
<style>
    .header-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    .search-sort-container {
        margin-bottom: 20px;
    }

    .table-responsive {
        margin-top: 20px;
    }
    .damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    display: block;
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}
    /* Modal and other styles for your page go here */
</style>

<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="container">
                <div class="header-container">
                    <h1>Expenses Management</h1>
                    
                    <?php if ($_SESSION['role'] == 1): ?> <!-- Only role 1 can access this button -->
                        <button class="btn btn-primary" onclick="openModal('addExpenseModal')">
                            <span class="icon">+</span> Add New Expense
                        </button>
                    <?php endif; ?>
                </div>
                <?php if ($role == 1): ?>
                <a href="expense_analytics.php" class="damaged-items-link">>>View Expense Analytics</a>
                <?php endif; ?>
                <!-- Search and Filter Form -->
                <form method="GET" class="search-sort-container">
                    <div class="search-bar">
                        <input type="text" name="search" placeholder="Search by description or category..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                        
                    </div>
                    <div class="date-filters">
                        <label>From: <input type="date" name="start_date" value="<?= $_GET['start_date'] ?? '' ?>"></label>
                        <label>To: <input type="date" name="end_date" value="<?= $_GET['end_date'] ?? '' ?>"></label>
                    </div>
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <?php if (!empty($_GET)): ?>
                        <a href="expenses.php" class="btn btn-secondary">Clear Filters</a>
                    <?php endif; ?>
                </form>

                <!-- Summary Card -->
                <div class="summary-card" style="background-color: red; color: white; padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem;">
                    <h3>Regular Expenses: ₱<?= number_format($totalExpenses, 2) ?></h3>
                    <p>
                        <?php if (isset($_GET['start_date']) && isset($_GET['end_date'])): ?>
                            For period: <?= date('M d, Y', strtotime($_GET['start_date'])) ?> to <?= date('M d, Y', strtotime($_GET['end_date'])) ?>
                        <?php elseif (isset($_GET['start_date'])): ?>
                            From <?= date('M d, Y', strtotime($_GET['start_date'])) ?> onwards
                        <?php elseif (isset($_GET['end_date'])): ?>
                            Up to <?= date('M d, Y', strtotime($_GET['end_date'])) ?>
                        <?php else: ?>
                            All time
                        <?php endif; ?>
                    </p>
                </div>

                <!-- Expenses Table -->
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Description</th>
                                <th>Category</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Processed By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($expenses)): ?>
                                <tr>
                                    <td colspan="7" style="text-align: center; padding: 2rem;">No expenses found. Add a new expense to get started.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($expenses as $expense): ?>
                                    <tr>
                                        <td><?= $expense['ExpenseID'] ?></td>
                                        <td><?= htmlspecialchars($expense['Description']) ?></td>
                                        <td><?= htmlspecialchars($expense['Category']) ?></td>
                                        <td>₱<?= number_format($expense['Amount'], 2) ?></td>
                                        <td><?= date('M d, Y', strtotime($expense['Date'])) ?></td>
                                        <td><?= htmlspecialchars($expense['ProcessedBy']) ?></td>
                                        <td class="actions">
                                        <?php if ($_SESSION['role'] == 1): ?> <!-- Only role 1 can access edit and delete -->
                                                <button class="btn btn-edit" onclick="openEditModal(<?= $expense['ExpenseID'] ?>)">Edit</button>
                                                <button class="btn btn-danger" onclick="openDeleteModal(<?= $expense['ExpenseID'] ?>)">Delete</button>
                                            <?php else: ?>
                                                <span style="color: gray;">View Only</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Add Expense Modal -->
    <div id="addExpenseModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addExpenseModal')">&times;</span>
            <h2>Add Expense</h2>
            <form action="save_expense.php" method="POST" class="form-container">
                <div class="form-group">
                    <label for="description">Expense Description</label>
                    <input type="text" id="description" name="description" required placeholder="Enter description of the expense" />
                </div>
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" required>
                        <option value="">-- Select Category --</option>
                        <option value="Utilities">Utilities</option>
                        <option value="Payroll">Payroll</option>
                        <option value="Office Supplies">Office Supplies</option>
                        <option value="Repairs & Maintenance">Repairs & Maintenance</option>
                        <option value="Miscellaneous">Miscellaneous</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= htmlspecialchars($category) ?>"><?= htmlspecialchars($category) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="amount">Amount (₱)</label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" required placeholder="Enter expense amount" />
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" id="date" name="date" required value="<?= date('Y-m-d') ?>" />
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('addExpenseModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Expense</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).classList.add('show');
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }

        function showToast(type, message) {
            Toastify({
                text: message,
                duration: 5000,
                close: true,
                gravity: "bottom", 
                position: "right", 
                backgroundColor: type === 'success' ? "#4a934a" : "#dc3545",
                stopOnFocus: true
            }).showToast();
        }

        // Check for success/error messages in URL
        const urlParams = new URLSearchParams(window.location.search);
        const successMessage = urlParams.get('msg_success');
        const errorMessage = urlParams.get('msg_error');
        
        if (successMessage) {
            showToast('success', decodeURIComponent(successMessage));
        }
        
        if (errorMessage) {
            showToast('error', decodeURIComponent(errorMessage));
        }
    </script>
</body>
</html>
