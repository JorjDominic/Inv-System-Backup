<?php
// Access session
if (!isset($_SESSION)) {
    session_start();
}

// Optional: fallback roleID if not set
$role = $_SESSION['role'] ?? null;
?>



<html>
<link rel="stylesheet" href="css/sidebar.css">
<script>
    window.onload = function () {
        const toggleButton = document.getElementById('toggle-btn');
        const sidebar = document.getElementById('sidebar');

        toggleButton.addEventListener('click', function () {
            sidebar.classList.toggle('close');
            toggleButton.classList.toggle('rotate');

            Array.from(sidebar.getElementsByClassName('show')).forEach(ul => {
                ul.classList.remove('show');
                ul.previousElementSibling.classList.remove('rotate');
            });
        });

        window.toggleSubMenu = function (button) {
            const submenu = button.nextElementSibling;
            submenu.classList.toggle('show');
            button.classList.toggle('rotate');

            if (sidebar.classList.contains('close')) {
                sidebar.classList.toggle('close');
                toggleButton.classList.toggle('rotate');
            }
        };
        
        window.showLogoutModal = function(e) {
            e.preventDefault();
            document.getElementById('logoutModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        window.hideLogoutModal = function() {
            document.getElementById('logoutModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        document.getElementById('logoutModal').addEventListener('click', function(e) {
            if (e.target === this) {
                hideLogoutModal();
            }
        });
    };
</script>
<body>
<div id="logoutModal" class="logout-modal">
    <div class="logout-modal-content">
        <h2>Confirm Logout</h2>
        <p>Are you sure you want to log out?</p>
        <div class="logout-modal-actions">
            <button onclick="hideLogoutModal()" class="logout-btn-cancel">Cancel</button>
            <a href="logout.php" class="logout-btn-confirm">Logout</a>
        </div>
    </div>
</div>

<?php include 'includes/logout_modal.php'; ?>
<nav id="sidebar">
    <!-- Sidebar Content -->
    <ul class="sidebar-menu">
        <li class="sidebar-header">
            <span class="logo">Adriana's Marketing</span>
            <button id="toggle-btn">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                    <path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/>
                </svg>
            </button>
        </li>
        
        <!-- Profile Link -->
        <li>
            <a href="profilepage.php">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M234-276q51-39 114-61.5T480-360q69 0 132 22.5T726-276q35-41 54.5-93T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 59 19.5 111t54.5 93Zm246-164q-59 0-99.5-40.5T340-580q0-59 40.5-99.5T480-720q59 0 99.5 40.5T620-580q0 59-40.5 99.5T480-440Zm0 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q53 0 100-15.5t86-44.5q-39-29-86-44.5T480-280q-53 0-100 15.5T294-220q39 29 86 44.5T480-160Zm0-360q26 0 43-17t17-43q0-26-17-43t-43-17q-26 0-43 17t-17 43q0 26 17 43t43 17Zm0-60Zm0 360Z"/></svg>            
                <span>Profile</span>
            </a>
        </li>
        
        <!-- Home Link -->
        <li class="<?php echo (basename($_SERVER['PHP_SELF']) == 'owner_dashboard.php' && $_SESSION['role'] == 1) ||
                      (basename($_SERVER['PHP_SELF']) == 'customer_home.php' && $_SESSION['role'] == 2) ||
                      (basename($_SERVER['PHP_SELF']) == 'designer_home.php' && $_SESSION['role'] == 3) ||
                      (basename($_SERVER['PHP_SELF']) == 'staff_dashboard.php' && $_SESSION['role'] == 4) ? 'active' : ''; ?>">
            <a href="<?php
                if ($_SESSION['role'] == 1) {
                    echo 'owner_dashboard.php';
                } elseif ($_SESSION['role'] == 2) {
                    echo 'devdashboard.php';
                } elseif ($_SESSION['role'] == 3) {
                    echo 'cashierdashboard.php';
                } else {
                    echo 'staff_dashboard.php';
                }
            ?>">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                    <path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/>
                </svg>
                <span>Home</span>
            </a>
        </li>
        
        <?php if ($role == 4 || $role == 1 || $role == 3): ?>
            <!-- Inventory Menu -->
            <li>
                <button onclick="toggleSubMenu(this)" class="dropdown-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="M160-200h80v-320h480v320h80v-426L480-754 160-626v426Zm-80 80v-560l400-160 400 160v560H640v-320H320v320H80Zm280 0v-80h80v80h-80Zm80-120v-80h80v80h-80Zm80 120v-80h80v80h-80ZM240-520h480-480Z"/>
                    </svg>
                    <span>Inventory</span>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="M480-360 280-560h400L480-360Z"/>
                    </svg>
                </button>
                <ul class="sub-menu">
                    <div>
                    <?php if ($_SESSION['role'] == 1||$_SESSION['role'] == 3): ?>
                        <li><a href="orderingpage.php">Order</a></li>
                        <?php endif; ?>
                        <li><a href="inventory.php">Stocks</a></li>
                        <?php if ($_SESSION['role'] == 1||$_SESSION['role'] == 3): ?>
                        <li><a href="transactions.php">Transactions</a></li>
                        <?php endif; ?>
                        <?php if ($_SESSION['role'] == 1): ?>
                        <li><a href="inventorylog.php">Inventory Logs</a></li>
                        <?php endif; ?>
                    </div>
                </ul>
            </li>
            
            <?php if ($role == 1 || $role == 3): ?>
                <!-- Records Menu -->
                <li>
                    <button onclick="toggleSubMenu(this)" class="dropdown-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M560-564v-68q33-14 67.5-21t72.5-7q26 0 51 4t49 10v64q-24-9-48.5-13.5T700-600q-38 0-73 9.5T560-564Zm0 220v-68q33-14 67.5-21t72.5-7q26 0 51 4t49 10v64q-24-9-48.5-13.5T700-380q-38 0-73 9t-67 27Zm0-110v-68q33-14 67.5-21t72.5-7q26 0 51 4t49 10v64q-24-9-48.5-13.5T700-490q-38 0-73 9.5T560-454ZM260-320q47 0 91.5 10.5T440-278v-394q-41-24-87-36t-93-12q-36 0-71.5 7T120-692v396q35-12 69.5-18t70.5-6Zm260 42q44-21 88.5-31.5T700-320q36 0 70.5 6t69.5 18v-396q-33-14-68.5-21t-71.5-7q-47 0-93 12t-87 36v394Zm-40 118q-48-38-104-59t-116-21q-42 0-82.5 11T100-198q-21 11-40.5-1T40-234v-482q0-11 5.5-21T62-752q46-24 96-36t102-12q58 0 113.5 15T480-740q51-30 106.5-45T700-800q52 0 102 12t96 36q11 5 16.5 15t5.5 21v482q0 23-19.5 35t-40.5 1q-37-20-77.5-31T700-240q-60 0-116 21t-104 59ZM280-494Z"/></svg>
                        <span>Records</span>
                        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                            <path d="M480-360 280-560h400L480-360Z"/>
                        </svg>
                    </button>
                    <ul class="sub-menu">
                        <div>
                        <li><a href="expenses.php">Expenses</a></li>
                        <?php if ($role == 1): ?>
                            <li><a href="reports.php">Reports</a></li>
                            <?php endif; ?>
                        </div>
                    </ul>
                </li>
            <?php endif; ?>
        <?php endif; ?>
        
        <?php if ($role == 1 || $role == 2): ?>
            <!-- Security Menu -->
            <li>
                <button onclick="toggleSubMenu(this)" class="dropdown-btn">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-80q-139-35-229.5-159.5T160-516v-244l320-120 320 120v244q0 152-90.5 276.5T480-80Zm0-84q97-30 162-118.5T718-480H480v-315l-240 90v207q0 7 2 18h238v316Z"/></svg>
                    <span>Security</span>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3">
                        <path d="M480-360 280-560h400L480-360Z"/>
                    </svg> 
                </button>
                <ul class="sub-menu">
                    <div>
                        <li><a href="accountmanagement.php">Account Management</a></li>
                        <li><a href="audit_trail.php">Audit Trails</a></li>
                    </div>
                </ul>
            </li>
        <?php endif; ?>
        
        <?php if ($role == 2): ?>
            <!-- Maintenance Link -->
            <li>
                <a href="">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M42-120v-112q0-33 17-62t47-44q51-26 115-44t141-18q77 0 141 18t115 44q30 15 47 44t17 62v112H42Zm80-80h480v-32q0-11-5.5-20T582-266q-36-18-92.5-36T362-320q-71 0-127.5 18T142-266q-9 5-14.5 14t-5.5 20v32Zm240-240q-66 0-113-47t-47-113h-10q-9 0-14.5-5.5T172-620q0-9 5.5-14.5T192-640h10q0-45 22-81t58-57v38q0 9 5.5 14.5T302-720q9 0 14.5-5.5T322-740v-54q9-3 19-4.5t21-1.5q11 0 21 1.5t19 4.5v54q0 9 5.5 14.5T422-720q9 0 14.5-5.5T442-740v-38q36 21 58 57t22 81h10q9 0 14.5 5.5T552-620q0 9-5.5 14.5T532-600h-10q0 66-47 113t-113 47Zm0-80q33 0 56.5-23.5T442-600H282q0 33 23.5 56.5T362-520Zm300 160-6-30q-6-2-11.5-4.5T634-402l-28 10-20-36 22-20v-24l-22-20 20-36 28 10q4-4 10-7t12-5l6-30h40l6 30q6 2 12 5t10 7l28-10 20 36-22 20v24l22 20-20 36-28-10q-5 5-10.5 7.5T708-390l-6 30h-40Zm20-70q12 0 21-9t9-21q0-12-9-21t-21-9q-12 0-21 9t-9 21q0 12 9 21t21 9Zm72-130-8-42q-9-3-16.5-7.5T716-620l-42 14-28-48 34-30q-2-5-2-8v-16q0-3 2-8l-34-30 28-48 42 14q6-6 13.5-10.5T746-798l8-42h56l8 42q9 3 16.5 7.5T848-780l42-14 28 48-34 30q2 5 2 8v16q0 3-2 8l34 30-28 48-42-14q-6 6-13.5 10.5T818-602l-8 42h-56Zm28-90q21 0 35.5-14.5T832-700q0-21-14.5-35.5T782-750q-21 0-35.5 14.5T732-700q0 21 14.5 35.5T782-650ZM362-200Z"/></svg>            
                    <span>Maintenance</span>
                </a>
            </li>
            
            <!-- Bug Report Link -->
            <li>
                <a href="">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M480-200q66 0 113-47t47-113v-160q0-66-47-113t-113-47q-66 0-113 47t-47 113v160q0 66 47 113t113 47Zm-80-120h160v-80H400v80Zm0-160h160v-80H400v80Zm80 40Zm0 320q-65 0-120.5-32T272-240H160v-80h84q-3-20-3.5-40t-.5-40h-80v-80h80q0-20 .5-40t3.5-40h-84v-80h112q14-23 31.5-43t40.5-35l-64-66 56-56 86 86q28-9 57-9t57 9l88-86 56 56-66 66q23 15 41.5 34.5T688-640h112v80h-84q3 20 3.5 40t.5 40h80v80h-80q0 20-.5 40t-3.5 40h84v80H688q-32 56-87.5 88T480-120Z"/></svg>            
                    <span>Bug Report</span>
                </a>
            </li>
        <?php endif; ?>
        
        <!-- Logout Link -->
        <li>
            <a href="logout.php" onclick="showLogoutModal(event)">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>                
                <span>Logout</span>
            </a>
        </li>
    </ul>
    
    <!-- Navbar Content -->
   
</nav>
        </body>
</html>