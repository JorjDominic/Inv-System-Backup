<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
  header('Location: index.php');
  exit;
}
session_regenerate_id(true);

// Define report types
$reportTypes = [
    'sales' => 'Sales Report',
    'inventory' => 'Inventory Report',
    'cashier_performance' => 'Cashier Performance Report',
    'daily_sales' => 'Daily Sales Report',
    'monthly_sales' => 'Monthly Sales Report'
];

// Get current date
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

// Default date range (current month)
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : $firstDayOfMonth;
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : $currentDate;

// Process form submission for report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportType = $_POST['report_type'] ?? 'sales';
    $startDate = $_POST['start_date'] ?? $firstDayOfMonth;
    $endDate = $_POST['end_date'] ?? $currentDate;
    
    // If export to PDF is requested
    if (isset($_POST['action']) && $_POST['action'] === 'export_pdf') {
        // Redirect to PDF generator with parameters
        header("Location: generate_pdf.php?report_type=$reportType&start_date=$startDate&end_date=$endDate");
        exit;
    }
}

// Function to get report data based on type and date range
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            // Sales report query
            $query = "SELECT r.ReceiptID, r.TotalAmount, r.DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Receipts r
                      JOIN Orders o ON r.OrderID = o.OrderID
                      JOIN OrderDetails od ON o.OrderID = od.OrderID
                      JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                      JOIN Users u ON r.UserID = u.UserID
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY r.ReceiptID
                      ORDER BY r.DateIssued DESC";
            break;
            
        case 'inventory':
            // Inventory report query
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        case 'expenses':
            // Expenses report query
            $query = "SELECT e.ExpenseID, e.Description, e.Category, e.Amount, e.Date, 
                      CONCAT(u.FirstName, ' ', u.LastName) as RecordedBy
                      FROM Expenses e
                      JOIN Users u ON e.UserID = u.UserID
                      WHERE e.Date BETWEEN ? AND ?
                      ORDER BY e.Date DESC";
            break;
            
        case 'profit':
            // Profit & Loss report query
            $query = "SELECT 
                      (SELECT SUM(TotalAmount) FROM Receipts WHERE DateIssued BETWEEN ? AND ?) as GrossRevenue,
                      (SELECT SUM(Amount) FROM Expenses WHERE Date BETWEEN ? AND ?) as TotalExpenses,
                      (SELECT SUM(od.Price * ri.QuantityRefunded) 
                       FROM RefundedItems ri
                       JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                       WHERE ri.RefundedAt BETWEEN ? AND ?) as TotalRefunds,
                      (SELECT SUM(d.Quantity * p.PurchasePrice)
                       FROM DamagedItems d
                       JOIN Product p ON d.ProductID = p.ProductID
                       WHERE d.ReportedAt BETWEEN ? AND ?) as DamagedCost,
                      (SELECT SUM(LossValue)
                       FROM ExpiredItems
                       WHERE DateExpired BETWEEN ? AND ?) as ExpiredCost";
            break;
            
        case 'expired':
            // Expired items report query
            $query = "SELECT e.ExpiredID, p.ProductName, e.Quantity, e.ExpiryDate, 
                      e.DateExpired, CONCAT(u.FirstName, ' ', u.LastName) as ReportedBy, 
                      e.LossValue, c.CategoryName
                      FROM ExpiredItems e
                      JOIN Product p ON e.ProductID = p.ProductID
                      JOIN Users u ON e.ReportedBy = u.UserID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      WHERE e.DateExpired BETWEEN ? AND ?
                      ORDER BY e.DateExpired DESC";
            break;
            
        case 'damaged':
            // Damaged items report query
            $query = "SELECT d.DamageID, p.ProductName, d.Quantity, d.Reason, 
                      d.ReportedAt, CONCAT(u.FirstName, ' ', u.LastName) as ReportedBy, 
                      (d.Quantity * p.PurchasePrice) as LossAmount, c.CategoryName
                      FROM DamagedItems d
                      JOIN Product p ON d.ProductID = p.ProductID
                      JOIN Users u ON d.ReportedBy = u.UserID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      WHERE d.ReportedAt BETWEEN ? AND ?
                      ORDER BY d.ReportedAt DESC";
            break;
            
        case 'low_stock':
            // Low stock report query
            $lowStockThreshold = 10; // Define what "low stock" means
            $query = "SELECT p.ProductID, p.ProductName, SUM(i.Quantity) as TotalQuantity, 
                      c.CategoryName, p.PurchasePrice, p.SellingPrice
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      HAVING TotalQuantity <= ?
                      ORDER BY TotalQuantity ASC";
            break;
            
        case 'refunds':
            // Refunds report query
            $query = "SELECT ri.RefundID, p.ProductName, ri.QuantityRefunded, 
                      ri.ItemCondition, ri.RefundedAt, 
                      CONCAT(u.FirstName, ' ', u.LastName) as ProcessedBy,
                      (od.Price * ri.QuantityRefunded) as RefundAmount
                      FROM RefundedItems ri
                      JOIN Product p ON ri.ProductID = p.ProductID
                      JOIN Users u ON ri.ProcessedBy = u.UserID
                      JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                      WHERE ri.RefundedAt BETWEEN ? AND ?
                      ORDER BY ri.RefundedAt DESC";
            break;
            
        case 'category_sales':
            // Category sales report query
            $query = "SELECT c.CategoryName, COUNT(od.OrderDetailID) as ItemsSold, 
                      SUM(od.Quantity) as TotalQuantity, SUM(od.Price * od.Quantity) as Revenue
                      FROM OrderDetails od
                      JOIN Product p ON od.ProductID = p.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      JOIN Orders o ON od.OrderID = o.OrderID
                      WHERE o.OrderDate BETWEEN ? AND ?
                      GROUP BY c.CategoryID
                      ORDER BY Revenue DESC";
            break;
            
        case 'cashier_performance':
            // Cashier performance report query
            $query = "SELECT u.UserID, CONCAT(u.FirstName, ' ', u.LastName) as CashierName, 
                      COUNT(r.ReceiptID) as TransactionCount, SUM(r.TotalAmount) as TotalSales,
                      AVG(r.TotalAmount) as AverageTransaction
                      FROM Receipts r
                      JOIN Users u ON r.UserID = u.UserID
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY u.UserID
                      ORDER BY TotalSales DESC";
            break;
            
        case 'payment_methods':
            // Payment methods report query
            $query = "SELECT pm.MethodName, COUNT(r.ReceiptID) as TransactionCount, 
                      SUM(r.TotalAmount) as TotalAmount, 
                      (COUNT(r.ReceiptID) / (SELECT COUNT(*) FROM Receipts WHERE DateIssued BETWEEN ? AND ?)) * 100 as Percentage
                      FROM Receipts r
                      JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY pm.PaymentMethodID
                      ORDER BY TotalAmount DESC";
            break;
            
        case 'hourly_sales':
            // Hourly sales report query
            $query = "SELECT HOUR(r.DateIssued) as Hour, 
                      COUNT(r.ReceiptID) as TransactionCount, 
                      SUM(r.TotalAmount) as TotalSales
                      FROM Receipts r
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY HOUR(r.DateIssued)
                      ORDER BY Hour";
            break;
            
        case 'daily_sales':
            // Daily sales report query
            $query = "SELECT DATE(r.DateIssued) as SaleDate, 
                      COUNT(r.ReceiptID) as TransactionCount, 
                      SUM(r.TotalAmount) as TotalSales
                      FROM Receipts r
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY DATE(r.DateIssued)
                      ORDER BY SaleDate";
            break;
            
        case 'monthly_sales':
            // Monthly sales report query
            $query = "SELECT DATE_FORMAT(r.DateIssued, '%Y-%m') as Month, 
                      COUNT(r.ReceiptID) as TransactionCount, 
                      SUM(r.TotalAmount) as TotalSales
                      FROM Receipts r
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY DATE_FORMAT(r.DateIssued, '%Y-%m')
                      ORDER BY Month";
            break;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        // Bind parameters based on report type
        switch ($reportType) {
            case 'inventory':
                $stmt->execute();
                break;
                
            case 'low_stock':
                $stmt->execute([10]); // Low stock threshold
                break;
                
            case 'profit':
                $stmt->execute([$startDate, $endDate, $startDate, $endDate, $startDate, $endDate, $startDate, $endDate, $startDate, $endDate]);
                break;
                
            case 'payment_methods':
                $stmt->execute([$startDate, $endDate, $startDate, $endDate]);
                break;
                
            default:
                $stmt->execute([$startDate, $endDate]);
                break;
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary data for certain report types
        if ($reportType === 'sales') {
            $totalSales = array_sum(array_column($data, 'TotalAmount'));
            $data['summary'] = [
                'totalSales' => $totalSales,
                'transactionCount' => count($data)
            ];
        } elseif ($reportType === 'expenses') {
            $totalExpenses = array_sum(array_column($data, 'Amount'));
            $data['summary'] = [
                'totalExpenses' => $totalExpenses
            ];
        } elseif ($reportType === 'inventory') {
            $totalValue = array_sum(array_column($data, 'TotalValue'));
            $totalItems = array_sum(array_column($data, 'TotalQuantity'));
            $data['summary'] = [
                'totalValue' => $totalValue,
                'totalItems' => $totalItems
            ];
        } elseif ($reportType === 'category_sales') {
            $totalRevenue = array_sum(array_column($data, 'Revenue'));
            $totalItems = array_sum(array_column($data, 'TotalQuantity'));
            $data['summary'] = [
                'totalRevenue' => $totalRevenue,
                'totalItems' => $totalItems
            ];
        } elseif ($reportType === 'cashier_performance') {
            $totalSales = array_sum(array_column($data, 'TotalSales'));
            $totalTransactions = array_sum(array_column($data, 'TransactionCount'));
            $data['summary'] = [
                'totalSales' => $totalSales,
                'totalTransactions' => $totalTransactions
            ];
        }
        
    } catch (PDOException $e) {
        // Handle error
        echo "Error: " . $e->getMessage();
    }
    
    return $data;
}

// Get report data if a report type is selected
$reportData = [];
$selectedReportType = $_POST['report_type'] ?? 'sales';

// Check if form was submitted (either for generating report or exporting PDF)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportData = getReportData($conn, $selectedReportType, $startDate, $endDate);
}

// Get chart data for the selected report type
$chartData = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($selectedReportType) {
        case 'sales':
            // Get daily sales for chart
            $dailySalesQuery = "SELECT DATE(DateIssued) as SaleDate, SUM(TotalAmount) as DailyRevenue
                             FROM Receipts
                             WHERE DateIssued BETWEEN ? AND ?
                             GROUP BY DATE(DateIssued)
                             ORDER BY SaleDate";
            $dailySalesStmt = $conn->prepare($dailySalesQuery);
            $dailySalesStmt->execute([$startDate, $endDate]);
            $chartData['dailySales'] = $dailySalesStmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        case 'expenses':
            // Get expense categories for chart
            $expenseCategoriesQuery = "SELECT Category, SUM(Amount) as TotalAmount
                                    FROM Expenses
                                    WHERE Date BETWEEN ? AND ?
                                    GROUP BY Category
                                    ORDER BY TotalAmount DESC";
            $expenseCategoriesStmt = $conn->prepare($expenseCategoriesQuery);
            $expenseCategoriesStmt->execute([$startDate, $endDate]);
            $chartData['expenseCategories'] = $expenseCategoriesStmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        case 'category_sales':
            // Chart data is already in the report data
            $chartData['categorySales'] = $reportData;
            break;
            
        case 'payment_methods':
            // Chart data is already in the report data
            $chartData['paymentMethods'] = $reportData;
            break;
            
        case 'hourly_sales':
            // Chart data is already in the report data
            $chartData['hourlySales'] = $reportData;
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Enhanced Reports - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .reports-container {
            padding: 20px;
        }
        
        .report-form {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-sm);
            font-family: 'Poppins', sans-serif;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        
        .report-results {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            overflow-x: auto;
        }
        
        .report-title {
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--text-dark);
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .report-table th, .report-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .report-table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .report-table tr:last-child td {
            border-bottom: none;
        }
        
        .report-summary {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .summary-label {
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .summary-value {
            font-weight: 600;
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: var(--text-medium);
            font-style: italic;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        
        .report-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .report-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
        }
        
        .report-card h3 {
            margin-top: 0;
            color: var(--text-dark);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .metric-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .metric-label {
            font-size: 0.9rem;
            color: var(--text-medium);
        }
        
        .positive {
            color: #28a745;
        }
        
        .negative {
            color: #dc3545;
        }
        
        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
            }
            
            .btn-group {
                flex-direction: column;
            }
            
            .report-grid {
                grid-template-columns: 1fr;
            }
        }
        .damaged-items-container {
    margin-top: 10px;  /* Ensure the link is directly underneath */
}

.damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    display: block;
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="reports-container">
                <h1 class="report-title"> Reports</h1>
                <a href="business_analytics.php" class="damaged-items-link">>>View Business Analytics</a>
                <div class="report-form">
                    <form method="POST" action="">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="report_type">Report Type</label>
                                <select name="report_type" id="report_type" class="form-control">
                                    <?php foreach ($reportTypes as $value => $label): ?>
                                        <option value="<?= $value ?>" <?= ($selectedReportType === $value) ? 'selected' : '' ?>>
                                            <?= $label ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" 
                                       value="<?= $startDate ?>" max="<?= $currentDate ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" 
                                       value="<?= $endDate ?>" max="<?= $currentDate ?>">
                            </div>
                        </div>
                        <div class="btn-group">
                            <button type="submit" name="action" value="generate_report" class="btn btn-primary">Generate Report</button>
                            <button type="submit" name="action" value="export_pdf" class="btn btn-success">Export to PDF</button>
                            
                        </div>
                    </form>
                </div>
                
                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($reportData)): ?>
                    <div class="report-results">
                        <h2 class="report-title"><?= $reportTypes[$selectedReportType] ?></h2>
                        <p>Period: <?= date('F d, Y', strtotime($startDate)) ?> to <?= date('F d, Y', strtotime($endDate)) ?></p>
                        
                        <?php if ($selectedReportType === 'sales'): ?>
                            <!-- Sales Report Chart -->
                            <div class="chart-container">
                                <canvas id="salesChart"></canvas>
                            </div>
                            
                            <!-- Sales Report Metrics -->
                            <div class="report-grid">
                                <div class="report-card">
                                    <h3>Total Sales</h3>
                                    <div class="metric-value">₱<?= number_format($reportData['summary']['totalSales'] ?? 0, 2) ?></div>
                                </div>
                                <div class="report-card">
                                    <h3>Transaction Count</h3>
                                    <div class="metric-value"><?= number_format($reportData['summary']['transactionCount'] ?? 0) ?></div>
                                </div>
                                <div class="report-card">
                                    <h3>Average Transaction</h3>
                                    <div class="metric-value">₱<?= number_format(($reportData['summary']['totalSales'] ?? 0) / max(($reportData['summary']['transactionCount'] ?? 1), 1), 2) ?></div>
                                </div>
                            </div>
                            
                            <!-- Sales Report Table -->
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Receipt ID</th>
                                            <th>Date</th>
                                            <th>Items</th>
                                            <th>Payment Method</th>
                                            <th>Cashier</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalAmount = 0;
                                        foreach ($reportData as $key => $sale): 
                                            if ($key !== 'summary'):
                                                $totalAmount += $sale['TotalAmount'];
                                        ?>
                                            <tr>
                                                <td><?= $sale['ReceiptID'] ?></td>
                                                <td><?= date('M d, Y', strtotime($sale['DateIssued'])) ?></td>
                                                <td><?= $sale['ItemCount'] ?></td>
                                                <td><?= $sale['PaymentMethod'] ?></td>
                                                <td><?= $sale['Cashier'] ?></td>
                                                <td>₱<?= number_format($sale['TotalAmount'], 2) ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'category_sales'): ?>
                            <!-- Category Sales Chart -->
                            <div class="chart-container">
                                <canvas id="categorySalesChart"></canvas>
                            </div>
                            
                            <!-- Category Sales Table -->
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Items Sold</th>
                                            <th>Total Quantity</th>
                                            <th>Revenue</th>
                                            <th>% of Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalRevenue = array_sum(array_column($reportData, 'Revenue'));
                                        foreach ($reportData as $category): 
                                        ?>
                                            <tr>
                                                <td><?= htmlspecialchars($category['CategoryName']) ?></td>
                                                <td><?= number_format($category['ItemsSold']) ?></td>
                                                <td><?= number_format($category['TotalQuantity']) ?></td>
                                                <td>₱<?= number_format($category['Revenue'], 2) ?></td>
                                                <td><?= number_format(($category['Revenue'] / $totalRevenue) * 100, 2) ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'cashier_performance'): ?>
                            <!-- Cashier Performance Chart -->
                            <div class="chart-container">
                                <canvas id="cashierPerformanceChart"></canvas>
                            </div>
                            
                            <!-- Cashier Performance Table -->
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Cashier</th>
                                            <th>Transactions</th>
                                            <th>Total Sales</th>
                                            <th>Average Transaction</th>
                                            <th>% of Total Sales</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalSales = array_sum(array_column($reportData, 'TotalSales'));
                                        foreach ($reportData as $cashier): 
                                        ?>
                                            <tr>
                                                <td><?= htmlspecialchars($cashier['CashierName']) ?></td>
                                                <td><?= number_format($cashier['TransactionCount']) ?></td>
                                                <td>₱<?= number_format($cashier['TotalSales'], 2) ?></td>
                                                <td>₱<?= number_format($cashier['AverageTransaction'], 2) ?></td>
                                                <td><?= number_format(($cashier['TotalSales'] / $totalSales) * 100, 2) ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'payment_methods'): ?>
                            <!-- Payment Methods Chart -->
                            <div class="chart-container">
                                <canvas id="paymentMethodsChart"></canvas>
                            </div>
                            
                            <!-- Payment Methods Table -->
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Payment Method</th>
                                            <th>Transactions</th>
                                            <th>Total Amount</th>
                                            <th>% of Transactions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($reportData as $method): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($method['MethodName']) ?></td>
                                                <td><?= number_format($method['TransactionCount']) ?></td>
                                                <td>₱<?= number_format($method['TotalAmount'], 2) ?></td>
                                                <td><?= number_format($method['Percentage'], 2) ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'hourly_sales'): ?>
                            <!-- Hourly Sales Chart -->
                            <div class="chart-container">
                                <canvas id="hourlySalesChart"></canvas>
                            </div>
                            
                            <!-- Hourly Sales Table -->
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Hour</th>
                                            <th>Transactions</th>
                                            <th>Total Sales</th>
                                            <th>% of Total Sales</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalSales = array_sum(array_column($reportData, 'TotalSales'));
                                        foreach ($reportData as $hour): 
                                        ?>
                                            <tr>
                                                <td><?= sprintf('%02d:00 - %02d:59', $hour['Hour'], $hour['Hour']) ?></td>
                                                <td><?= number_format($hour['TransactionCount']) ?></td>
                                                <td>₱<?= number_format($hour['TotalSales'], 2) ?></td>
                                                <td><?= number_format(($hour['TotalSales'] / $totalSales) * 100, 2) ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'daily_sales' || $selectedReportType === 'monthly_sales'): ?>
                            <!-- Daily/Monthly Sales Chart -->
                            <div class="chart-container">
                                <canvas id="timeSalesChart"></canvas>
                            </div>
                            
                            <!-- Daily/Monthly Sales Table -->
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th><?= $selectedReportType === 'daily_sales' ? 'Date' : 'Month' ?></th>
                                            <th>Transactions</th>
                                            <th>Total Sales</th>
                                            <th>Average Transaction</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($reportData as $period): ?>
                                            <tr>
                                                <td>
                                                    <?php if ($selectedReportType === 'daily_sales'): ?>
                                                        <?= date('M d, Y', strtotime($period['SaleDate'])) ?>
                                                    <?php else: ?>
                                                        <?= date('F Y', strtotime($period['Month'] . '-01')) ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= number_format($period['TransactionCount']) ?></td>
                                                <td>₱<?= number_format($period['TotalSales'], 2) ?></td>
                                                <td>₱<?= number_format($period['TotalSales'] / $period['TransactionCount'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'expenses'): ?>
                            <!-- Expenses Chart -->
                            <?php if (!empty($chartData['expenseCategories'])): ?>
                                <div class="chart-container">
                                    <canvas id="expensesChart"></canvas>
                                </div>
                            <?php endif; ?>
                            
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Description</th>
                                            <th>Category</th>
                                            <th>Date</th>
                                            <th>Recorded By</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalExpenses = 0;
                                        foreach ($reportData as $key => $expense): 
                                            if ($key !== 'summary'):
                                                $totalExpenses += $expense['Amount'];
                                        ?>
                                            <tr>
                                                <td><?= $expense['ExpenseID'] ?></td>
                                                <td><?= htmlspecialchars($expense['Description']) ?></td>
                                                <td><?= htmlspecialchars($expense['Category']) ?></td>
                                                <td><?= date('M d, Y', strtotime($expense['Date'])) ?></td>
                                                <td><?= htmlspecialchars($expense['RecordedBy']) ?></td>
                                                <td>₱<?= number_format($expense['Amount'], 2) ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Expenses:</span>
                                    <span class="summary-value">₱<?= number_format($totalExpenses, 2) ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'inventory'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Quantity</th>
                                            <th>Purchase Price</th>
                                            <th>Selling Price</th>
                                            <th>Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalValue = 0;
                                        $totalItems = 0;
                                        foreach ($reportData as $key => $item): 
                                            if ($key !== 'summary'):
                                                $totalValue += $item['TotalValue'];
                                                $totalItems += $item['TotalQuantity'];
                                        ?>
                                            <tr>
                                                <td><?= $item['ProductID'] ?></td>
                                                <td><?= htmlspecialchars($item['ProductName']) ?></td>
                                                <td><?= htmlspecialchars($item['CategoryName']) ?></td>
                                                <td><?= $item['TotalQuantity'] ?></td>
                                                <td>₱<?= number_format($item['PurchasePrice'], 2) ?></td>
                                                <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
                                                <td>₱<?= number_format($item['TotalValue'], 2) ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Inventory Value:</span>
                                    <span class="summary-value">₱<?= number_format($totalValue, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Items:</span>
                                    <span class="summary-value"><?= $totalItems ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'profit'): ?>
                            <?php 
                                $profitData = $reportData[0] ?? [];
                                $grossRevenue = $profitData['GrossRevenue'] ?? 0;
                                $totalExpenses = $profitData['TotalExpenses'] ?? 0;
                                $totalRefunds = $profitData['TotalRefunds'] ?? 0;
                                $damagedCost = $profitData['DamagedCost'] ?? 0;
                                $expiredCost = $profitData['ExpiredCost'] ?? 0;
                                
                                $netRevenue = $grossRevenue - $totalRefunds;
                                $totalLosses = $damagedCost + $expiredCost;
                                $netProfit = $netRevenue - $totalExpenses - $totalLosses;
                                
                                // Calculate profit margin
                                $profitMargin = $netRevenue > 0 ? ($netProfit / $netRevenue) * 100 : 0;
                            ?>
                            
                            <!-- Profit & Loss Chart -->
                            <div class="chart-container">
                                <canvas id="profitLossChart"></canvas>
                            </div>
                            
                            <!-- Profit & Loss Metrics -->
                            <div class="report-grid">
                                <div class="report-card">
                                    <h3>Net Revenue</h3>
                                    <div class="metric-value">₱<?= number_format($netRevenue, 2) ?></div>
                                </div>
                                <div class="report-card">
                                    <h3>Total Expenses</h3>
                                    <div class="metric-value negative">₱<?= number_format($totalExpenses + $totalLosses, 2) ?></div>
                                </div>
                                <div class="report-card">
                                    <h3>Net Profit</h3>
                                    <div class="metric-value <?= $netProfit >= 0 ? 'positive' : 'negative' ?>">
                                        ₱<?= number_format($netProfit, 2) ?>
                                    </div>
                                </div>
                                <div class="report-card">
                                    <h3>Profit Margin</h3>
                                    <div class="metric-value <?= $profitMargin >= 0 ? 'positive' : 'negative' ?>">
                                        <?= number_format($profitMargin, 2) ?>%
                                    </div>
                                </div>
                            </div>
                            
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Gross Revenue:</span>
                                    <span class="summary-value">₱<?= number_format($grossRevenue, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Refunds:</span>
                                    <span class="summary-value">₱<?= number_format($totalRefunds, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Net Revenue:</span>
                                    <span class="summary-value">₱<?= number_format($netRevenue, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Regular Expenses:</span>
                                    <span class="summary-value">₱<?= number_format($totalExpenses, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Damaged Inventory Cost:</span>
                                    <span class="summary-value">₱<?= number_format($damagedCost, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Expired Inventory Cost:</span>
                                    <span class="summary-value">₱<?= number_format($expiredCost, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Losses:</span>
                                    <span class="summary-value">₱<?= number_format($totalLosses, 2) ?></span>
                                </div>
                                <div class="summary-item" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
                                    <span class="summary-label" style="font-size: 1.1rem;">Net Profit:</span>
                                    <span class="summary-value" style="font-size: 1.1rem; color: <?= $netProfit >= 0 ? '#28a745' : '#dc3545' ?>;">
                                        ₱<?= number_format($netProfit, 2) ?>
                                    </span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'expired' || $selectedReportType === 'damaged' || $selectedReportType === 'low_stock' || $selectedReportType === 'refunds'): ?>
                            <!-- Include the original report content for these types -->
                            <?php include 'reports_original_content.php'; ?>
                            
                        <?php endif; ?>
                    </div>
                <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="report-results">
                        <div class="no-data">No data available for the selected criteria.</div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        // Initialize Chart.js
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($reportData)): ?>
            <?php if ($selectedReportType === 'sales' && !empty($chartData['dailySales'])): ?>
                // Sales Chart
                const salesCtx = document.getElementById('salesChart').getContext('2d');
                new Chart(salesCtx, {
                    type: 'line',
                    data: {
                        labels: <?= json_encode(array_map(function($item) { return date('M d', strtotime($item['SaleDate'])); }, $chartData['dailySales'])) ?>,
                        datasets: [{
                            label: 'Daily Sales',
                            data: <?= json_encode(array_column($chartData['dailySales'], 'DailyRevenue')) ?>,
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 2,
                            tension: 0.1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return '₱' + value.toLocaleString('en-PH');
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return '₱' + context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
            
            <?php if ($selectedReportType === 'category_sales'): ?>
                // Category Sales Chart
                const categoryCtx = document.getElementById('categorySalesChart').getContext('2d');
                new Chart(categoryCtx, {
                    type: 'pie',
                    data: {
                        labels: <?= json_encode(array_column($reportData, 'CategoryName')) ?>,
                        datasets: [{
                            data: <?= json_encode(array_column($reportData, 'Revenue')) ?>,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.7)',
                                'rgba(54, 162, 235, 0.7)',
                                'rgba(255, 206, 86, 0.7)',
                                'rgba(75, 192, 192, 0.7)',
                                'rgba(153, 102, 255, 0.7)',
                                'rgba(255, 159, 64, 0.7)',
                                'rgba(201, 203, 207, 0.7)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const value = context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((context.raw / total) * 100).toFixed(2);
                                        return `${context.label}: ₱${value} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
            
            <?php if ($selectedReportType === 'cashier_performance'): ?>
                // Cashier Performance Chart
                const cashierCtx = document.getElementById('cashierPerformanceChart').getContext('2d');
                new Chart(cashierCtx, {
                    type: 'bar',
                    data: {
                        labels: <?= json_encode(array_column($reportData, 'CashierName')) ?>,
                        datasets: [{
                            label: 'Total Sales',
                            data: <?= json_encode(array_column($reportData, 'TotalSales')) ?>,
                            backgroundColor: 'rgba(54, 162, 235, 0.7)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return '₱' + value.toLocaleString('en-PH');
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return '₱' + context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
            
            <?php if ($selectedReportType === 'payment_methods'): ?>
                // Payment Methods Chart
                const paymentCtx = document.getElementById('paymentMethodsChart').getContext('2d');
                new Chart(paymentCtx, {
                    type: 'doughnut',
                    data: {
                        labels: <?= json_encode(array_column($reportData, 'MethodName')) ?>,
                        datasets: [{
                            data: <?= json_encode(array_column($reportData, 'TotalAmount')) ?>,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.7)',
                                'rgba(54, 162, 235, 0.7)',
                                'rgba(255, 206, 86, 0.7)',
                                'rgba(75, 192, 192, 0.7)',
                                'rgba(153, 102, 255, 0.7)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const value = context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((context.raw / total) * 100).toFixed(2);
                                        return `${context.label}: ₱${value} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
            
            <?php if ($selectedReportType === 'hourly_sales'): ?>
                // Hourly Sales Chart
                const hourlyCtx = document.getElementById('hourlySalesChart').getContext('2d');
                new Chart(hourlyCtx, {
                    type: 'bar',
                    data: {
                        labels: <?= json_encode(array_map(function($item) { return sprintf('%02d:00', $item['Hour']); }, $reportData)) ?>,
                        datasets: [{
                            label: 'Sales by Hour',
                            data: <?= json_encode(array_column($reportData, 'TotalSales')) ?>,
                            backgroundColor: 'rgba(153, 102, 255, 0.7)',
                            borderColor: 'rgba(153, 102, 255, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return '₱' + value.toLocaleString('en-PH');
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return '₱' + context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
            
            <?php if ($selectedReportType === 'daily_sales' || $selectedReportType === 'monthly_sales'): ?>
                // Time-based Sales Chart
                const timeCtx = document.getElementById('timeSalesChart').getContext('2d');
                new Chart(timeCtx, {
                    type: 'bar',
                    data: {
                        labels: <?= json_encode(array_map(function($item) use ($selectedReportType) { 
                            if ($selectedReportType === 'daily_sales') {
                                return date('M d', strtotime($item['SaleDate']));
                            } else {
                                return date('F Y', strtotime($item['Month'] . '-01'));
                            }
                        }, $reportData)) ?>,
                        datasets: [{
                            label: 'Total Sales',
                            data: <?= json_encode(array_column($reportData, 'TotalSales')) ?>,
                            backgroundColor: 'rgba(75, 192, 192, 0.7)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return '₱' + value.toLocaleString('en-PH');
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return '₱' + context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
            
            <?php if ($selectedReportType === 'expenses' && !empty($chartData['expenseCategories'])): ?>
                // Expenses Chart
                const expensesCtx = document.getElementById('expensesChart').getContext('2d');
                new Chart(expensesCtx, {
                    type: 'pie',
                    data: {
                        labels: <?= json_encode(array_column($chartData['expenseCategories'], 'Category')) ?>,
                        datasets: [{
                            data: <?= json_encode(array_column($chartData['expenseCategories'], 'TotalAmount')) ?>,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.7)',
                                'rgba(54, 162, 235, 0.7)',
                                'rgba(255, 206, 86, 0.7)',
                                'rgba(75, 192, 192, 0.7)',
                                'rgba(153, 102, 255, 0.7)',
                                'rgba(255, 159, 64, 0.7)',
                                'rgba(201, 203, 207, 0.7)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const value = context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((context.raw / total) * 100).toFixed(2);
                                        return `${context.label}: ₱${value} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
            
            <?php if ($selectedReportType === 'profit'): ?>
                // Profit & Loss Chart
                const profitCtx = document.getElementById('profitLossChart').getContext('2d');
                new Chart(profitCtx, {
                    type: 'bar',
                    data: {
                        labels: ['Revenue', 'Expenses', 'Profit'],
                        datasets: [{
                            label: 'Profit & Loss',
                            data: [
                                <?= $netRevenue ?>,
                                <?= $totalExpenses + $totalLosses ?>,
                                <?= $netProfit ?>
                            ],
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.7)',
                                'rgba(255, 99, 132, 0.7)',
                                <?= $netProfit >= 0 ? "'rgba(54, 162, 235, 0.7)'" : "'rgba(255, 159, 64, 0.7)'" ?>
                            ],
                            borderColor: [
                                'rgba(75, 192, 192, 1)',
                                'rgba(255, 99, 132, 1)',
                                <?= $netProfit >= 0 ? "'rgba(54, 162, 235, 1)'" : "'rgba(255, 159, 64, 1)'" ?>
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return '₱' + value.toLocaleString('en-PH');
                                    }
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return '₱' + context.raw.toLocaleString('en-PH', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        });
                                    }
                                }
                            }
                        }
                    }
                });
            <?php endif; ?>
        <?php endif; ?>
    </script>
</body>
</html>
