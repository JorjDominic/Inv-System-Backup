<?php
require 'config/database.php';

$username = trim($_POST['username'] ?? '');

if (!$username) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ No username received.'
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT UserID FROM Users WHERE Username = ?");
$stmt->execute([$username]);

if ($stmt->rowCount() > 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Username already taken!'
    ]);
} else {
    echo json_encode([
        'status' => 'success',
        'message' => 'Username available!'
    ]);
}
?>