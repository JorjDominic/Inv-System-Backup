<?php
require 'config/database.php';

header('Content-Type: application/json'); // Set response type to JSON

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['email'])) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ Invalid request'
    ]);
    exit;
}

$email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ Please enter a valid email address'
    ]);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT UserID FROM Users WHERE Email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'status' => 'error',
            'message' => '❌ Email already in use'
        ]);
    } else {
        echo json_encode([
            'status' => 'success',
            'message' => 'Email available'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => '❌ Database error: ' . $e->getMessage()
    ]);
}
?>