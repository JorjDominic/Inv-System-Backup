<?php
session_start();
require('config/database.php');
require_once 'notification.php'; // Include notification system

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3 && $_SESSION['role'] != 4)) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

ini_set('display_errors', 1);
error_reporting(E_ALL);

$categoryStmt = $conn->query("SELECT CategoryID, CategoryName FROM Category");
$categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);

// Get low stock items count
$lowStockQuery = "SELECT COUNT(*) as count FROM Inventory i JOIN Product p ON i.ProductID = p.ProductID WHERE i.Quantity < 10 AND i.Quantity > 0";
$lowStockStmt = $conn->query($lowStockQuery);
$lowStockCount = $lowStockStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get out of stock items count
$outOfStockQuery = "SELECT COUNT(*) as count FROM Inventory i WHERE i.Quantity <= 0";
$outOfStockStmt = $conn->query($outOfStockQuery);
$outOfStockCount = $outOfStockStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total inventory value
$inventoryValueQuery = "SELECT SUM(i.Quantity * p.PurchasePrice) as total FROM Inventory i JOIN Product p ON i.ProductID = p.ProductID";
$inventoryValueStmt = $conn->query($inventoryValueQuery);
$inventoryValue = $inventoryValueStmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

// Get total inventory items
$totalItemsQuery = "SELECT COUNT(*) as count FROM Inventory";
$totalItemsStmt = $conn->query($totalItemsQuery);
$totalItems = $totalItemsStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get expiring soon items count (items expiring in the next 30 days)
$expiringQuery = "SELECT COUNT(*) as count FROM Inventory 
                 WHERE ExpiryDate IS NOT NULL 
                 AND ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)
                 AND Quantity > 0";
$expiringStmt = $conn->query($expiringQuery);
$expiringCount = $expiringStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get current date for validation
$today = date('Y-m-d');
$minExpiryDate = date('Y-m-d', strtotime('+3 days'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inventory Management</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    /* General Styles */
    :root {
      --primary-color: #4a934a;
      --danger-color: #e74c3c;
      --warning-color: #f39c12;
      --info-color: #3498db;
      --expiring-color: #17a2b8;
      --light-gray: #f8f9fa;
      --border-color: #dee2e6;
      --text-color: #333;
      --text-muted: #6c757d;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: var(--text-color);
    }
    
    /* Dashboard Cards */
    .inventory-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .stat-card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      padding: 20px;
      text-align: center;
      transition: transform 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
    }
    
    .stat-card h3 {
      font-size: 2rem;
      margin: 0;
      color: var(--primary-color);
    }
    
    .stat-card p {
      color: var(--text-muted);
      margin: 10px 0 0;
    }
    
    .stat-card.warning h3 {
      color: var(--warning-color);
    }
    
    .stat-card.danger h3 {
      color: var(--danger-color);
    }
    
    .stat-card.info h3 {
      color: var(--info-color);
    }
    
    .stat-card.expiring h3 {
      color: var(--expiring-color);
    }
    
    /* Header and Controls */
    .header-container {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      margin-bottom: 20px;
    }
    
    .link-container {
      margin-top: 10px;
      display: flex;
      gap: 15px;
    }
    
    .inventory-link {
      font-size: 1rem;
      color: var(--info-color);
      font-weight: 600;
      text-decoration: none;
    }
    
    .inventory-link:hover {
      text-decoration: underline;
    }
    
    .search-sort-container {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      margin-bottom: 20px;
      align-items: center;
      justify-content: space-between;
      width: 100%;
    }
    
    .search-bar {
      flex: 1;
      min-width: 250px;
    }
    
    .search-bar input {
      width: 100%;
      padding: 10px 15px;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      font-size: 1rem;
    }
    
    .sort-options select {
      padding: 10px 15px;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      font-size: 1rem;
      min-width: 180px;
    }
    
    /* Filter Buttons */
    .filter-options {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 20px;
    }
    
    .filter-btn {
      padding: 8px 15px;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      background-color: white;
      cursor: pointer;
      transition: all 0.2s;
      font-size: 0.9rem;
    }
    
    .filter-btn:hover, .filter-btn.active {
      background-color: #f0f0f0;
    }
    
    .filter-btn.active {
      font-weight: bold;
    }
    
    .filter-btn.expiring {
      border-color: var(--expiring-color);
      color: var(--expiring-color);
    }
    
    .filter-btn.expiring.active {
      background-color: var(--expiring-color);
      color: white;
    }
    
    .filter-btn.low-stock {
      border-color: var(--warning-color);
      color: var(--warning-color);
    }
    
    .filter-btn.low-stock.active {
      background-color: var(--warning-color);
      color: white;
    }
    
    .filter-btn.out-of-stock {
      border-color: var(--danger-color);
      color: var(--danger-color);
    }
    
    .filter-btn.out-of-stock.active {
      background-color: var(--danger-color);
      color: white;
    }
    
    /* View Toggle */
    .view-toggle {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 20px;
    }
    
    .view-toggle-btn {
      padding: 8px 15px;
      background-color: white;
      border: 1px solid var(--border-color);
      cursor: pointer;
    }
    
    .view-toggle-btn:first-child {
      border-radius: 4px 0 0 4px;
    }
    
    .view-toggle-btn:last-child {
      border-radius: 0 4px 4px 0;
    }
    
    .view-toggle-btn.active {
      background-color: var(--primary-color);
      color: white;
      border-color: var(--primary-color);
    }
    
    /* Product Grid */
    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .product-card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      display: flex;
      flex-direction: column;
    }
    
    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .product-card.out-of-stock {
      border-left: 4px solid var(--danger-color);
      background-color: #fff5f5;
    }
    
    .product-card.low-stock {
      border-left: 4px solid var(--warning-color);
      background-color: #fff9f0;
    }
    
    .product-card.expiring-soon {
      border-left: 4px solid var(--expiring-color);
      background-color: #f0f9fc;
    }
    
    .product-image {
      height: 180px;
      background-color: #f8f9fa;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      position: relative;
    }
    
    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .product-image .no-image {
      color: #ccc;
      font-size: 3rem;
    }
    
    .product-status {
      position: absolute;
      top: 10px;
      right: 10px;
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 0.8rem;
      font-weight: bold;
      color: white;
    }
    
    .status-out {
      background-color: var(--danger-color);
    }
    
    .status-low {
      background-color: var(--warning-color);
    }
    
    .status-expiring {
      background-color: var(--expiring-color);
    }
    
    .product-details {
      padding: 15px;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }
    
    .product-category {
      font-size: 0.8rem;
      color: var(--text-muted);
      margin-bottom: 5px;
      text-transform: uppercase;
    }
    
    .product-name {
      font-size: 1.1rem;
      font-weight: bold;
      margin-bottom: 10px;
      line-height: 1.3;
    }
    
    .product-info {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
      font-size: 0.9rem;
    }
    
    .info-label {
      color: var(--text-muted);
    }
    
    .info-value {
      font-weight: 500;
      text-align: right;
    }
    
    .product-actions {
      padding: 15px;
      background-color: #f8f9fa;
      display: flex;
      gap: 8px;
      justify-content: space-between;
    }
    
    .action-btn {
      padding: 8px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 1;
      transition: background-color 0.2s;
    }
    
    .action-btn i {
      margin-right: 5px;
    }
    
    .btn-restock {
      background-color: #e3f2fd;
      color: #0d6efd;
    }
    
    .btn-restock:hover {
      background-color: #cce5ff;
    }
    
    .btn-edit {
      background-color: #e8f5e9;
      color: #28a745;
    }
    
    .btn-edit:hover {
      background-color: #d4edda;
    }
    
    .btn-delete {
      background-color: #fbeae9;
      color: #dc3545;
    }
    
    .btn-delete:hover {
      background-color: #f8d7da;
    }
    
    /* Table View */
    .table-container {
      overflow-x: auto;
      margin-bottom: 30px;
      display: none;
    }
    
    .table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .table th, .table td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid var(--border-color);
    }
    
    .table th {
      background-color: #f8f9fa;
      font-weight: 600;
    }
    
    .table tr:hover {
      background-color: #f8f9fa;
    }
    
    .table tr.out-of-stock {
      background-color: #fff5f5;
    }
    
    .table tr.low-stock {
      background-color: #fff9f0;
    }
    
    .table tr.expiring-soon {
      background-color: #f0f9fc;
    }
    
    .table .actions {
      display: flex;
      gap: 5px;
    }
    
    .table .btn {
      padding: 5px 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.8rem;
    }
    
    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 50px 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    .empty-state i {
      font-size: 3rem;
      color: #ccc;
      margin-bottom: 20px;
    }
    
    .empty-state h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }
    
    .empty-state p {
      color: var(--text-muted);
    }
    
    /* Modals */
    .modal-content {
      max-width: 600px;
    }
    
    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
    }
    
    /* Image Upload */
    .image-upload {
      margin-bottom: 15px;
    }
    
    .image-preview {
      width: 100%;
      height: 200px;
      border: 2px dashed #ddd;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 10px;
      overflow: hidden;
      position: relative;
    }
    
    .image-preview img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
    
    .image-preview .placeholder {
      color: #ccc;
      font-size: 3rem;
    }
    
    .image-upload-btn {
      display: block;
      width: 100%;
      padding: 10px;
      background-color: #f8f9fa;
      border: 1px solid #ddd;
      border-radius: 4px;
      text-align: center;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    
    .image-upload-btn:hover {
      background-color: #e9ecef;
    }
    
    .image-upload input[type="file"] {
      display: none;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
      .search-sort-container {
        flex-direction: column;
        align-items: stretch;
      }
      
      .search-bar, .sort-options {
        width: 100%;
      }
      
      .form-row {
        grid-template-columns: 1fr;
      }
    }
    
    /* Toast customization */
    .toastify {
      padding: 12px 20px;
      color: white;
      display: inline-block;
      box-shadow: 0 3px 6px -1px rgba(0, 0, 0, 0.12), 0 10px 36px -4px rgba(0, 0, 0, 0.3);
      background: linear-gradient(to right, #00b09b, #96c93d);
      position: fixed;
      opacity: 0;
      transition: all 0.4s cubic-bezier(0.215, 0.61, 0.355, 1);
      border-radius: 2px;
      cursor: pointer;
      text-decoration: none;
      max-width: calc(50% - 20px);
      z-index: 2147483647;
    }
    
    .toastify.on {
      opacity: 1;
    }
    
    .toast-close {
      background: transparent;
      border: 0;
      color: white;
      cursor: pointer;
      font-family: inherit;
      font-size: 1em;
      opacity: 0.4;
      padding: 0 5px;
    }
    
    .toastify-right {
      right: 15px;
    }
    
    .toastify-left {
      left: 15px;
    }
    
    .toastify-top {
      top: 15px;
    }
    
    .toastify-bottom {
      bottom: 15px;
    }
    
    .toastify-rounded {
      border-radius: 25px;
    }
    
    .toastify-avatar {
      width: 1.5em;
      height: 1.5em;
      margin: -7px 5px;
      border-radius: 2px;
    }
    
    .toastify-center {
      margin-left: auto;
      margin-right: auto;
      left: 0;
      right: 0;
      max-width: fit-content;
      max-width: -moz-fit-content;
    }
    
    /* Toast confirmation dialog */
    .toast-confirm {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
    }
    
    .toast-confirm-buttons {
      display: flex;
      gap: 8px;
      margin-left: 15px;
    }
    
    .toast-confirm-btn {
      padding: 4px 8px;
      border-radius: 4px;
      border: none;
      cursor: pointer;
      font-weight: bold;
      font-size: 0.8rem;
    }
    
    .toast-confirm-btn.yes {
      background-color: #fff;
      color: #e74c3c;
    }
    
    .toast-confirm-btn.no {
      background-color: rgba(255, 255, 255, 0.3);
      color: #fff;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>Inventory Management</h1>
        <div class="link-container">
          <a href="expired_items.php" class="inventory-link">>>Expired Items</a>
        </div>
      </div>
  
      <!-- Inventory Stats Dashboard -->
      <div class="inventory-stats">
        <div class="stat-card">
          <h3><?= $totalItems ?></h3>
          <p>Total Items</p>
        </div>
        
        <div class="stat-card warning">
          <h3><?= $lowStockCount ?></h3>
          <p>Low Stock Items</p>
        </div>
        
        <div class="stat-card danger">
          <h3><?= $outOfStockCount ?></h3>
          <p>Out of Stock</p>
        </div>
        
        <div class="stat-card expiring">
          <h3><?= $expiringCount ?></h3>
          <p>Expiring Soon</p>
        </div>
        
        <div class="stat-card info">
          <h3>₱<?= number_format($inventoryValue, 2) ?></h3>
          <p>Inventory Value</p>
        </div>
      </div>

      <div class="search-sort-container">
        <div class="search-bar">
          <input type="text" id="searchInput" placeholder="Search products...">
        </div>
        
        <div class="sort-options">
          <select id="sortSelect">
            <option value="">Sort By</option>
            <option value="name_asc">Name (A-Z)</option>
            <option value="name_desc">Name (Z-A)</option>
            <option value="quantity_asc">Quantity (Low-High)</option>
            <option value="quantity_desc">Quantity (High-Low)</option>
            <option value="price_asc">Price (Low-High)</option>
            <option value="price_desc">Price (High-Low)</option>
            <option value="expiry_asc">Expiry Date (Soonest)</option>
          </select>
        </div>

        <div>
          <button class="btn btn-danger" onclick="showFlushConfirmation()">Discard Expired Items</button>
          <?php if ($_SESSION['role'] == 1): ?>
            <button class="btn btn-primary" onclick="openModal('addModal')">
              <i class="fas fa-plus"></i> Add New Item
            </button>
          <?php endif; ?>
        </div>
      </div>
      
      <!-- Filter buttons -->
      <div class="filter-options">
        <button class="filter-btn active" data-filter="all" onclick="filterInventory('all')">All Items</button>
        <button class="filter-btn expiring" data-filter="expiring-soon" onclick="filterInventory('expiring-soon')">
          <i class="fas fa-calendar-alt"></i> Expiring Soon
        </button>
        <button class="filter-btn low-stock" data-filter="low-stock" onclick="filterInventory('low-stock')">
          <i class="fas fa-exclamation-triangle"></i> Low Stock
        </button>
        <button class="filter-btn out-of-stock" data-filter="out-of-stock" onclick="filterInventory('out-of-stock')">
          <i class="fas fa-ban"></i> Out of Stock
        </button>
      </div>
      
      <!-- View Toggle -->
      <div class="view-toggle">
        <button class="view-toggle-btn active" data-view="grid" onclick="toggleView('grid')">
          <i class="fas fa-th"></i> Grid
        </button>
        <button class="view-toggle-btn" data-view="table" onclick="toggleView('table')">
          <i class="fas fa-list"></i> Table
        </button>
      </div>

      <!-- Product Grid View -->
      <div id="gridView" class="product-grid">
        <?php
        try {
          $stmt = $conn->query("
            SELECT 
              i.InventoryID,
              p.ProductID,
              p.ProductName,
              p.PurchasePrice,
              p.SellingPrice,
              p.ImageURL,
              i.Quantity,
              i.DateReceived,
              i.ExpiryDate,
              c.CategoryName,
              p.CategoryID,
              CASE 
                WHEN i.ExpiryDate IS NOT NULL AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY) THEN 1
                ELSE 0
              END as IsExpiringSoon,
              CASE 
                WHEN i.ExpiryDate IS NOT NULL THEN DATEDIFF(i.ExpiryDate, CURRENT_DATE)
                ELSE NULL
              END as DaysUntilExpiry
            FROM Inventory i
            INNER JOIN Product p ON i.ProductID = p.ProductID
            INNER JOIN Category c ON p.CategoryID = c.CategoryID
            ORDER BY i.DateReceived DESC
          ");

          $hasProducts = false;
          
          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $hasProducts = true;
            $stockClass = '';
            $statusBadge = '';
            
            if ($row['Quantity'] <= 0) {
              $stockClass = 'out-of-stock';
              $statusBadge = '<div class="product-status status-out">Out of Stock</div>';
            } elseif ($row['Quantity'] < 10) {
              $stockClass = 'low-stock';
              $statusBadge = '<div class="product-status status-low">Low Stock: ' . $row['Quantity'] . '</div>';
            }
            
            // Add expiring soon class (takes precedence if item is also low stock)
            if ($row['IsExpiringSoon'] == 1 && $row['Quantity'] > 0) {
              $stockClass = 'expiring-soon';
              $statusBadge = '<div class="product-status status-expiring">Expires in ' . $row['DaysUntilExpiry'] . ' days</div>';
            }
        ?>
            <div class="product-card <?= $stockClass ?>" data-category="<?= htmlspecialchars($row['CategoryName']) ?>" data-name="<?= htmlspecialchars($row['ProductName']) ?>">
              <div class="product-image">
                <?php if ($row['ImageURL']): ?>
                  <img src="<?= htmlspecialchars($row['ImageURL']) ?>" alt="<?= htmlspecialchars($row['ProductName']) ?>">
                <?php else: ?>
                  <div class="no-image"><i class="fas fa-image"></i></div>
                <?php endif; ?>
                <?= $statusBadge ?>
              </div>
              <div class="product-details">
                <div class="product-category"><?= htmlspecialchars($row['CategoryName']) ?></div>
                <h3 class="product-name"><?= htmlspecialchars($row['ProductName']) ?></h3>
                <div class="product-info">
                  <div class="info-label">Quantity:</div>
                  <div class="info-value"><?= htmlspecialchars($row['Quantity']) ?></div>
                  
                  <div class="info-label">Selling Price:</div>
                  <div class="info-value">₱<?= number_format($row['SellingPrice'], 2) ?></div>
                  
                  <div class="info-label">Purchase Price:</div>
                  <div class="info-value">₱<?= number_format($row['PurchasePrice'], 2) ?></div>
                  
                  <div class="info-label">Received:</div>
                  <div class="info-value"><?= htmlspecialchars($row['DateReceived']) ?></div>
                  
                  <?php if ($row['ExpiryDate']): ?>
                  <div class="info-label">Expires:</div>
                  <div class="info-value"><?= htmlspecialchars($row['ExpiryDate']) ?></div>
                  <?php endif; ?>
                </div>
              </div>
              <div class="product-actions">
                <?php if ($_SESSION['role'] == 1): ?>
                  <button class="action-btn btn-restock" onclick="openRestockModal(this)"
                    data-id="<?= $row['InventoryID'] ?>"
                    data-name="<?= htmlspecialchars($row['ProductName'], ENT_QUOTES) ?>">
                    <i class="fas fa-sync-alt"></i> Restock
                  </button>
                  <button class="action-btn btn-edit" onclick="openEditModal(this)"
                    data-id="<?= $row['InventoryID'] ?>"
                    data-name="<?= htmlspecialchars($row['ProductName'], ENT_QUOTES) ?>"
                    data-qty="<?= $row['Quantity'] ?>"
                    data-purchase="<?= $row['PurchasePrice'] ?>"
                    data-selling="<?= $row['SellingPrice'] ?>"
                    data-date="<?= $row['DateReceived'] ?>"
                    data-expiry="<?= $row['ExpiryDate'] ?>"
                    data-category="<?= $row['CategoryID'] ?>"
                    data-image="<?= $row['ImageURL'] ?>">
                    <i class="fas fa-edit"></i> Edit
                  </button>
                  <button class="action-btn btn-delete" onclick="openDeleteModal(<?= $row['InventoryID'] ?>)">
                    <i class="fas fa-trash"></i> Delete
                  </button>
                <?php else: ?>
                  <span class="action-btn" style="background-color: #f8f9fa; color: #6c757d; cursor: default;">
                    <i class="fas fa-eye"></i> View Only
                  </span>
                <?php endif; ?>
              </div>
            </div>
        <?php
          }
          
          if (!$hasProducts) {
            echo '<div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>No products found</h3>
                    <p>Try adjusting your search or filter criteria</p>
                  </div>';
          }
        } catch (PDOException $e) {
          echo '<div class="empty-state">
                  <i class="fas fa-exclamation-triangle"></i>
                  <h3>Error loading inventory</h3>
                  <p>' . $e->getMessage() . '</p>
                </div>';
        }
        ?>
      </div>

      <!-- Table View -->
      <div id="tableView" class="table-container" style="display: none;">
        <table class="table">
          <thead>
            <tr>
              <th>Category</th>
              <th>Product Name</th>
              <th>Quantity</th>
              <th>Selling Price</th>
              <th>Purchase Price</th>
              <th>Date Received</th>
              <th>Expiry Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php
          try {
            $stmt = $conn->query("
              SELECT 
                i.InventoryID,
                p.ProductID,
                p.ProductName,
                p.PurchasePrice,
                p.SellingPrice,
                p.ImageURL,
                i.Quantity,
                i.DateReceived,
                i.ExpiryDate,
                c.CategoryName,
                p.CategoryID,
                CASE 
                  WHEN i.ExpiryDate IS NOT NULL AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY) THEN 1
                  ELSE 0
                END as IsExpiringSoon,
                CASE 
                  WHEN i.ExpiryDate IS NOT NULL THEN DATEDIFF(i.ExpiryDate, CURRENT_DATE)
                  ELSE NULL
                END as DaysUntilExpiry
              FROM Inventory i
              INNER JOIN Product p ON i.ProductID = p.ProductID
              INNER JOIN Category c ON p.CategoryID = c.CategoryID
              ORDER BY i.DateReceived DESC
            ");

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
              $stockClass = '';
              if ($row['Quantity'] <= 0) {
                $stockClass = 'out-of-stock';
              } elseif ($row['Quantity'] < 10) {
                $stockClass = 'low-stock';
              }
              
              // Add expiring soon class (takes precedence if item is also low stock)
              if ($row['IsExpiringSoon'] == 1 && $row['Quantity'] > 0) {
                $stockClass = 'expiring-soon';
              }
              
              // Prepare expiry badge if needed
              $expiryBadge = '';
              if ($row['DaysUntilExpiry'] !== null && $row['DaysUntilExpiry'] >= 0 && $row['DaysUntilExpiry'] <= 30) {
                $expiryBadge = '<span class="expiry-badge">Expires in ' . $row['DaysUntilExpiry'] . ' days</span>';
              }
          ?>
              <tr class="<?= $stockClass ?>">
                <td><?= htmlspecialchars($row['CategoryName']) ?></td>
                <td>
                  <div class="d-flex align-items-center">
                    <?php if ($row['ImageURL']): ?>
                      <img src="<?= htmlspecialchars($row['ImageURL']) ?>" alt="<?= htmlspecialchars($row['ProductName']) ?>" style="width: 40px; height: 40px; object-fit: cover; margin-right: 10px; border-radius: 4px;">
                    <?php endif; ?>
                    <div>
                      <?= htmlspecialchars($row['ProductName']) ?> <?= $expiryBadge ?>
                    </div>
                  </div>
                </td>
                <td><?= htmlspecialchars($row['Quantity']) ?></td>
                <td>₱<?= number_format($row['SellingPrice'], 2) ?></td>
                <td>₱<?= number_format($row['PurchasePrice'], 2) ?></td>
                <td><?= htmlspecialchars($row['DateReceived']) ?></td>
                <td><?= $row['ExpiryDate'] ? htmlspecialchars($row['ExpiryDate']) : '—' ?></td>
                <td class='actions'>
                  <?php if ($_SESSION['role'] == 1): ?>
                    <button class='btn btn-restock' onclick='openRestockModal(this)'
                      data-id='<?= $row['InventoryID'] ?>'
                      data-name='<?= htmlspecialchars($row['ProductName'], ENT_QUOTES) ?>'>
                      <i class="fas fa-sync-alt"></i>
                    </button>
                    <button class='btn btn-edit' onclick='openEditModal(this)'
                      data-id='<?= $row['InventoryID'] ?>'
                      data-name='<?= htmlspecialchars($row['ProductName'], ENT_QUOTES) ?>'
                      data-qty='<?= $row['Quantity'] ?>'
                      data-purchase='<?= $row['PurchasePrice'] ?>'
                      data-selling='<?= $row['SellingPrice'] ?>'
                      data-date='<?= $row['DateReceived'] ?>'
                      data-expiry='<?= $row['ExpiryDate'] ?>'
                      data-category='<?= $row['CategoryID'] ?>'
                      data-image='<?= $row['ImageURL'] ?>'>
                      <i class="fas fa-edit"></i>
                    </button>
                    <button class='btn btn-danger' onclick='openDeleteModal(<?= $row['InventoryID'] ?>)'>
                      <i class="fas fa-trash"></i>
                    </button>
                  <?php else: ?>
                    <span style="color: gray;">View Only</span>
                  <?php endif; ?>
                </td>
              </tr>
          <?php
            }
          } catch (PDOException $e) {
            echo "<tr><td colspan='8'>❌ Error loading inventory: " . $e->getMessage() . "</td></tr>";
          }
          ?>
          </tbody>
        </table>
      </div>

    </div>
  </main>
</div>

<!-- Add Modal -->
<div class="modal" id="addModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('addModal')">&times;</span>
    <h2>Add Inventory Item</h2>
    <form class="form-container" action="add_inventory.php" method="POST" enctype="multipart/form-data">
      <!-- Image Upload -->
      <div class="image-upload">
        <label>Product Image</label>
        <div class="image-preview" id="imagePreview">
          <div class="placeholder"><i class="fas fa-image"></i></div>
        </div>
        <label for="product_image" class="image-upload-btn">
          <i class="fas fa-upload"></i> Choose Image
        </label>
        <input type="file" id="product_image" name="product_image" accept="image/*" onchange="previewImage(this, 'imagePreview')">
      </div>
      
      <div class="form-group">
        <label for="product_name">Product Name</label>
        <input type="text" id="product_name" name="product_name" autocomplete="off" required>
        <div id="productSuggestions" class="suggestion-box"></div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="quantity">Quantity</label>
          <input type="number" id="quantity" name="quantity" min="1" required>
        </div>
        <div class="form-group">
          <label for="purchase_price">Purchase Price (₱)</label>
          <input type="number" step="0.01" id="purchase_price" name="purchase_price" min="0.01" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="selling_price">Selling Price (₱)</label>
          <input type="number" step="0.01" id="selling_price" name="selling_price" min="0.01" required>
        </div>
        <div class="form-group">
          <label for="category">Category</label>
          <select id="category" name="category_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['CategoryID'] ?>"><?= $cat['CategoryName'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="date_received">Date Received</label>
          <input type="date" id="date_received" name="date_received" max="<?= $today ?>" required>
        </div>
        <div class="form-group">
          <label for="expiry_date">Expiry Date</label>
          <input type="date" id="expiry_date" name="expiry_date" min="<?= $minExpiryDate ?>">
        </div>
      </div>

      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Item</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal" id="editModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('editModal')">&times;</span>
    <h2>Edit Inventory Item</h2>
    <form class="form-container" action="update_inventory.php" method="POST" enctype="multipart/form-data">
      <input type="hidden" id="edit_inventory_id" name="inventory_id">
      <input type="hidden" id="edit_product_id" name="product_id">
      
      <!-- Image Upload -->
      <div class="image-upload">
        <label>Product Image</label>
        <div class="image-preview" id="editImagePreview">
          <div class="placeholder"><i class="fas fa-image"></i></div>
        </div>
        <label for="edit_product_image" class="image-upload-btn">
          <i class="fas fa-upload"></i> Change Image
        </label>
        <input type="file" id="edit_product_image" name="product_image" accept="image/*" onchange="previewImage(this, 'editImagePreview')">
      </div>

      <div class="form-group">
        <label for="edit_product_name">Product Name</label>
        <input type="text" id="edit_product_name" name="product_name" required>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="edit_quantity">Quantity</label>
          <input type="number" id="edit_quantity" name="quantity" min="0" required>
        </div>
        <div class="form-group">
          <label for="edit_category_id">Category</label>
          <select id="edit_category_id" name="category_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['CategoryID'] ?>"><?= $cat['CategoryName'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="edit_purchase_price">Purchase Price (₱)</label>
          <input type="number" step="0.01" id="edit_purchase_price" name="purchase_price" min="0.01" required>
        </div>
        <div class="form-group">
          <label for="edit_selling_price">Selling Price (₱)</label>
          <input type="number" step="0.01" id="edit_selling_price" name="selling_price" min="0.01" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="edit_date_received">Date Received</label>
          <input type="date" id="edit_date_received" name="date_received" max="<?= $today ?>" required>
        </div>
        <div class="form-group">
          <label for="edit_expiry_date">Expiry Date</label>
          <input type="date" id="edit_expiry_date" name="expiry_date" min="<?= $minExpiryDate ?>">
        </div>
      </div>

      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Update Item</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete Modal -->
<div class="modal" id="deleteModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('deleteModal')">&times;</span>
    <h2>Confirm Deletion</h2>
    <form class="form-container" action="delete_inventory.php" method="POST">
      <p>Are you sure you want to delete this inventory item? This action cannot be undone.</p>
      <input type="hidden" id="inventory_id" name="inventory_id">
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete Permanently</button>
      </div>
    </form>
  </div>
</div>

<!-- Restock Modal -->
<div class="modal" id="restockModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('restockModal')">&times;</span>
    <h2>Restock Item</h2>
    <form class="form-container" action="restock_inventory.php" method="POST">
      <input type="hidden" id="restock_inventory_id" name="inventory_id">
      
      <div class="form-group">
        <label>Product</label>
        <p id="restock_product_name" style="font-weight: bold; margin: 5px 0 15px;"></p>
      </div>
      
      <div class="form-row">
        <div class="form-group">
          <label for="restock_quantity">Quantity to Add</label>
          <input type="number" id="restock_quantity" name="quantity" min="1" required>
        </div>
        <div class="form-group">
          <label for="restock_expiry_date">New Expiry Date</label>
          <input type="date" id="restock_expiry_date" name="expiry_date" min="<?= $minExpiryDate ?>">
        </div>
      </div>
      
      <div class="form-group">
        <label for="restock_date">Restock Date</label>
        <input type="date" id="restock_date" name="restock_date" max="<?= $today ?>" value="<?= $today ?>" required>
      </div>
      
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('restockModal')">Cancel</button>
        <button type="submit" class="btn btn-success">Confirm Restock</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const productInput = document.getElementById('product_name');
  const suggestionBox = document.getElementById('productSuggestions');

  // Set min date for expiry date inputs
  const expiryDateInput = document.getElementById('expiry_date');
  const today = new Date();
  const minDate = new Date(today);
  minDate.setDate(today.getDate() + 3);  // Set min date to 3 days from today
  
  // Format date to YYYY-MM-DD
  const minDateString = minDate.toISOString().split('T')[0];
  const todayString = today.toISOString().split('T')[0];
  
  // Set the min attribute for the expiry date input
  expiryDateInput.setAttribute('min', minDateString);
  
  // Set max date for date received
  const dateReceivedInput = document.getElementById('date_received');
  dateReceivedInput.setAttribute('max', todayString);
  dateReceivedInput.value = todayString;

  productInput.addEventListener('input', function () {
    const query = this.value.trim();
    if (query.length < 2) {
      suggestionBox.innerHTML = '';
      return;
    }

    fetch(`fetch_products.php?term=${encodeURIComponent(query)}`)
      .then(res => res.json())
      .then(data => {
        suggestionBox.innerHTML = '';
        data.forEach(product => {
          const div = document.createElement('div');
          div.classList.add('suggestion');
          div.textContent = product.ProductName;
          div.addEventListener('click', () => {
            productInput.value = product.ProductName;
            document.getElementById('purchase_price').value = product.PurchasePrice;
            document.getElementById('selling_price').value = product.SellingPrice;
            document.getElementById('category').value = product.CategoryID;
            suggestionBox.innerHTML = '';
          });
          suggestionBox.appendChild(div);
        });
      });
  });

  document.addEventListener('click', function (e) {
    if (!suggestionBox.contains(e.target) && e.target !== productInput) {
      suggestionBox.innerHTML = '';
    }
  });
  
  // Search functionality
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', filterProducts);
  
  // Sort functionality
  const sortSelect = document.getElementById('sortSelect');
  sortSelect.addEventListener('change', sortProducts);
});

// Preview image before upload
function previewImage(input, previewId) {
  const preview = document.getElementById(previewId);
  preview.innerHTML = '';
  
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    
    reader.onload = function(e) {
      const img = document.createElement('img');
      img.src = e.target.result;
      preview.appendChild(img);
    }
    
    reader.readAsDataURL(input.files[0]);
  } else {
    const placeholder = document.createElement('div');
    placeholder.className = 'placeholder';
    placeholder.innerHTML = '<i class="fas fa-image"></i>';
    preview.appendChild(placeholder);
  }
}

// Toggle between grid and table view
function toggleView(viewType) {
  const gridView = document.getElementById('gridView');
  const tableView = document.getElementById('tableView');
  const gridBtn = document.querySelector('.view-toggle-btn[data-view="grid"]');
  const tableBtn = document.querySelector('.view-toggle-btn[data-view="table"]');
  
  if (viewType === 'grid') {
    gridView.style.display = 'grid';
    tableView.style.display = 'none';
    gridBtn.classList.add('active');
    tableBtn.classList.remove('active');
  } else {
    gridView.style.display = 'none';
    tableView.style.display = 'block';
    gridBtn.classList.remove('active');
    tableBtn.classList.add('active');
  }
}

// Filter products based on search input
function filterProducts() {
  const searchValue = document.getElementById('searchInput').value.toLowerCase();
  const gridItems = document.querySelectorAll('.product-card');
  const tableRows = document.querySelectorAll('.table tbody tr');
  
  // Filter grid items
  gridItems.forEach(item => {
    const productName = item.getAttribute('data-name').toLowerCase();
    const category = item.getAttribute('data-category').toLowerCase();
    
    if (productName.includes(searchValue) || category.includes(searchValue)) {
      item.style.display = '';
    } else {
      item.style.display = 'none';
    }
  });
  
  // Filter table rows
  tableRows.forEach(row => {
    const productName = row.cells[1].textContent.toLowerCase();
    const category = row.cells[0].textContent.toLowerCase();
    
    if (productName.includes(searchValue) || category.includes(searchValue)) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });
}

// Filter inventory by type (all, expiring-soon, low-stock, out-of-stock)
function filterInventory(filterType) {
  const gridItems = document.querySelectorAll('.product-card');
  const tableRows = document.querySelectorAll('.table tbody tr');
  const filterButtons = document.querySelectorAll('.filter-btn');
  
  // Update active button
  filterButtons.forEach(btn => {
    if (btn.dataset.filter === filterType) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
  
  // Filter grid items
  gridItems.forEach(item => {
    if (filterType === 'all') {
      item.style.display = '';
    } else if (filterType === 'expiring-soon' && item.classList.contains('expiring-soon')) {
      item.style.display = '';
    } else if (filterType === 'low-stock' && item.classList.contains('low-stock')) {
      item.style.display = '';
    } else if (filterType === 'out-of-stock' && item.classList.contains('out-of-stock')) {
      item.style.display = '';
    } else {
      item.style.display = 'none';
    }
  });
  
  // Filter table rows
  tableRows.forEach(row => {
    if (filterType === 'all') {
      row.style.display = '';
    } else if (filterType === 'expiring-soon' && row.classList.contains('expiring-soon')) {
      row.style.display = '';
    } else if (filterType === 'low-stock' && row.classList.contains('low-stock')) {
      row.style.display = '';
    } else if (filterType === 'out-of-stock' && row.classList.contains('out-of-stock')) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });
}

// Sort products based on selected option
function sortProducts() {
  const sortValue = document.getElementById('sortSelect').value;
  
  if (!sortValue) return;
  
  // Sort grid items
  const productGrid = document.querySelector('.product-grid');
  const gridItems = Array.from(productGrid.querySelectorAll('.product-card'));
  
  gridItems.sort((a, b) => {
    let aValue, bValue;
    
    if (sortValue === 'name_asc' || sortValue === 'name_desc') {
      aValue = a.querySelector('.product-name').textContent.toLowerCase();
      bValue = b.querySelector('.product-name').textContent.toLowerCase();
    } else if (sortValue === 'price_asc' || sortValue === 'price_desc') {
      aValue = parseFloat(a.querySelector('.info-value:nth-child(4)').textContent.replace('₱', '').replace(',', ''));
      bValue = parseFloat(b.querySelector('.info-value:nth-child(4)').textContent.replace('₱', '').replace(',', ''));
    } else if (sortValue === 'quantity_asc' || sortValue === 'quantity_desc') {
      aValue = parseInt(a.querySelector('.info-value:nth-child(2)').textContent);
      bValue = parseInt(b.querySelector('.info-value:nth-child(2)').textContent);
    } else if (sortValue === 'expiry_asc') {
      const aExpiry = a.querySelector('.info-value:nth-child(10)');
      const bExpiry = b.querySelector('.info-value:nth-child(10)');
      
      aValue = aExpiry ? new Date(aExpiry.textContent) : new Date(9999, 11, 31);
      bValue = bExpiry ? new Date(bExpiry.textContent) : new Date(9999, 11, 31);
      
      return aValue - bValue;
    }
    
    if (sortValue.endsWith('_asc')) {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Re-append sorted grid items
  gridItems.forEach(item => productGrid.appendChild(item));
  
  // Sort table rows
  const tbody = document.querySelector('.table tbody');
  const rows = Array.from(tbody.querySelectorAll('tr'));
  
  rows.sort((a, b) => {
    let aValue, bValue;
    
    if (sortValue === 'name_asc' || sortValue === 'name_desc') {
      aValue = a.cells[1].textContent.toLowerCase();
      bValue = b.cells[1].textContent.toLowerCase();
    } else if (sortValue === 'price_asc' || sortValue === 'price_desc') {
      aValue = parseFloat(a.cells[3].textContent.replace('₱', '').replace(',', ''));
      bValue = parseFloat(b.cells[3].textContent.replace('₱', '').replace(',', ''));
    } else if (sortValue === 'quantity_asc' || sortValue === 'quantity_desc') {
      aValue = parseInt(a.cells[2].textContent);
      bValue = parseInt(b.cells[2].textContent);
    } else if (sortValue === 'expiry_asc') {
      const aText = a.cells[6].textContent;
      const bText = b.cells[6].textContent;
      
      aValue = aText !== '—' ? new Date(aText) : new Date(9999, 11, 31);
      bValue = bText !== '—' ? new Date(bText) : new Date(9999, 11, 31);
      
      return aValue - bValue;
    }
    
    if (sortValue.endsWith('_asc')) {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Re-append sorted rows
  rows.forEach(row => tbody.appendChild(row));
}

function openEditModal(button) {
  const modal = document.getElementById('editModal');
  modal.classList.add('show');

  document.getElementById('edit_inventory_id').value = button.dataset.id;
  document.getElementById('edit_product_name').value = button.dataset.name;
  document.getElementById('edit_quantity').value = button.dataset.qty;
  document.getElementById('edit_purchase_price').value = button.dataset.purchase;
  document.getElementById('edit_selling_price').value = button.dataset.selling;
  document.getElementById('edit_date_received').value = button.dataset.date;
  document.getElementById('edit_expiry_date').value = button.dataset.expiry || '';

  const select = document.getElementById('edit_category_id');
  Array.from(select.options).forEach(option => {
    option.selected = option.value === button.dataset.category;
  });
  
  // Set min date for expiry date
  const editExpiryDateInput = document.getElementById('edit_expiry_date');
  const today = new Date();
  const minDate = new Date(today);
  minDate.setDate(today.getDate() + 3);
  const minDateString = minDate.toISOString().split('T')[0];
  editExpiryDateInput.setAttribute('min', minDateString);
  
  // Preview existing image if available
  const imagePreview = document.getElementById('editImagePreview');
  imagePreview.innerHTML = '';
  
  if (button.dataset.image) {
    const img = document.createElement('img');
    img.src = button.dataset.image;
    imagePreview.appendChild(img);
  } else {
    const placeholder = document.createElement('div');
    placeholder.className = 'placeholder';
    placeholder.innerHTML = '<i class="fas fa-image"></i>';
    imagePreview.appendChild(placeholder);
  }
}

function openModal(id) {
  document.getElementById(id).classList.add('show');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('show');
}

function openRestockModal(button) {
  const modal = document.getElementById('restockModal');
  modal.classList.add('show');

  document.getElementById('restock_inventory_id').value = button.dataset.id;
  document.getElementById('restock_product_name').textContent = button.dataset.name;
  
  // Set default restock date to today
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('restock_date').value = today;
  document.getElementById('restock_date').setAttribute('max', today);
  
  // Set min date for expiry date
  const restockExpiryDateInput = document.getElementById('restock_expiry_date');
  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 3);
  const minDateString = minDate.toISOString().split('T')[0];
  restockExpiryDateInput.setAttribute('min', minDateString);
}

function openDeleteModal(inventoryId) {
  const modal = document.getElementById('deleteModal');
  modal.classList.add('show');
  document.getElementById('inventory_id').value = inventoryId;
}

document.addEventListener("DOMContentLoaded", function () {
    const params = new URLSearchParams(window.location.search);
    const toastType = params.get('toast');
    const message = params.get('msg');

    if (toastType && message) {
        Toastify({
            text: decodeURIComponent(message),
            duration: 3000,
            gravity: "bottom",
            position: "right",
            backgroundColor: toastType === "success" ? "#2ecc71" : "#e74c3c",
        }).showToast();

        // Remove toast params from URL
        if (window.history.replaceState) {
            const cleanUrl = window.location.href.split('?')[0];
            window.history.replaceState({}, document.title, cleanUrl);
        }
    }
});

// Show confirmation toast instead of alert
function showFlushConfirmation() {
    let confirmToast = Toastify({
        text: "",
        node: createConfirmationNode("Are you sure you want to move all expired items to expired inventory?"),
        duration: -1,
        gravity: "center",
        position: "center",
        backgroundColor: "#e74c3c",
        stopOnFocus: true,
        className: "toastify-center toastify-rounded",
        offset: {
            y: 10
        },
        onClick: function() {} // Prevent auto-close on click
    });
    
    confirmToast.showToast();
    
    // Add event listeners to the buttons
    document.getElementById('confirm-yes').addEventListener('click', function() {
        confirmToast.hideToast();
        flushExpiredItems();
    });
    
    document.getElementById('confirm-no').addEventListener('click', function() {
        confirmToast.hideToast();
        Toastify({
            text: "Operation cancelled",
            duration: 2000,
            gravity: "bottom",
            position: "right",
            backgroundColor: "#6c757d",
            stopOnFocus: true
        }).showToast();
    });
}

// Create confirmation node with buttons
function createConfirmationNode(message) {
    const container = document.createElement('div');
    container.className = 'toast-confirm';
    
    const messageSpan = document.createElement('span');
    messageSpan.textContent = message;
    
    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'toast-confirm-buttons';
    
    const yesButton = document.createElement('button');
    yesButton.id = 'confirm-yes';
    yesButton.className = 'toast-confirm-btn yes';
    yesButton.textContent = 'Yes';
    
    const noButton = document.createElement('button');
    noButton.id = 'confirm-no';
    noButton.className = 'toast-confirm-btn no';
    noButton.textContent = 'No';
    
    buttonsDiv.appendChild(yesButton);
    buttonsDiv.appendChild(noButton);
    
    container.appendChild(messageSpan);
    container.appendChild(buttonsDiv);
    
    return container;
}

function flushExpiredItems() {
    // Show processing notification
    const processingToast = Toastify({
        text: "Processing expired items...",
        duration: -1, // Stays until manually closed
        gravity: "bottom",
        position: "right",
        backgroundColor: "#17a2b8",
        stopOnFocus: true
    }).showToast();

    // Send request to flush expired items
    fetch('flush_expired_items.php', {
        method: 'POST',
        headers: { 
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({})
    })
    .then(async (response) => {
        // Close processing notification
        processingToast.hideToast();
        
        const text = await response.text();

        if (!response.ok) {
            throw new Error(text || `HTTP error! Status: ${response.status}`);
        }

        try {
            return JSON.parse(text);
        } catch (e) {
            throw new Error("Server returned invalid JSON: " + text);
        }
    })
    .then(data => {
        if (!data || typeof data.status === 'undefined') {
            throw new Error("Invalid server response structure");
        }

        // Show result notification
        Toastify({
            text: data.message || (data.status === "success" ? "Expired items processed successfully" : "Failed to process expired items"),
            duration: 5000,
            gravity: "bottom",
            position: "right",
            backgroundColor: data.status === "success" ? "#28a745" : "#dc3545",
            stopOnFocus: true,
            onClick: function() {
                this.hideToast();
            }
        }).showToast();

        // Refresh content
        if (typeof loadInventoryData === 'function') {
            loadInventoryData();
        } else {
            window.location.reload();
        }
    })
    .catch(error => {
        processingToast.hideToast();
        console.error("Flush error:", error);
        Toastify({
            text: "Error: " + (error.message || "Failed to process request"),
            duration: 5000,
            gravity: "bottom",
            position: "right",
            backgroundColor: "#dc3545",
            stopOnFocus: true,
            onClick: function() {
                this.hideToast();
            }
        }).showToast();
    });
}
</script>
</body>
</html>