<?php
// order_details.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], [1, 2, 3, 4])) { // Owner, Developer, Cashier, Staff
    header('Location: login.php');
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['toast'] = [
        'type' => 'error',
        'message' => 'Invalid order ID'
    ];
    header('Location: order_processing.php');
    exit;
}

$orderId = $_GET['id'];

// Get order details
// Replace the current query with this corrected version
$stmt = $conn->prepare("
    SELECT 
        o.*,
        CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
        c.Email AS CustomerEmail,
        c.Phone AS CustomerPhone,
        t.Status AS PaymentStatus,
        pm.MethodName AS PaymentMethod,
        t.TransactionID
    FROM Orders o
    JOIN Customers c ON o.CustomerID = c.CustomerID
    LEFT JOIN Transactions t ON o.OrderID = t.OrderID
    LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
    WHERE o.OrderID = ?
");
$stmt->execute([$orderId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    $_SESSION['toast'] = [
        'type' => 'error',
        'message' => 'Order not found'
    ];
    header('Location: order_processing.php');
    exit;
}

// Get order items
$stmt = $conn->prepare("
    SELECT 
        od.*,
        p.ProductName,
        p.SellingPrice
    FROM OrderDetails od
    JOIN Product p ON od.ProductID = p.ProductID
    WHERE od.OrderID = ?
");
$stmt->execute([$orderId]);
$orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Process order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
    $newStatus = $_POST['status'];
    $notes = $_POST['notes'] ?? '';
    
    // Validate status
    $validStatuses = ['pending', 'paid', 'preparing', 'ready_for_pickup', 'completed', 'cancelled'];
    if (!in_array($newStatus, $validStatuses)) {
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Invalid order status'
        ];
        header('Location: order_details.php?id=' . $orderId);
        exit;
    }
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Update order status
        $stmt = $conn->prepare("
            UPDATE Orders 
            SET OrderStatus = ?, UpdatedAt = NOW() 
            WHERE OrderID = ?
        ");
        $stmt->execute([$newStatus, $orderId]);
        
// Log the status change
$stmt = $conn->prepare("
    INSERT INTO audit_trail (
        affected_username, changed_by, action, timestamp
    ) VALUES (
        (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
        (SELECT Username FROM Users WHERE UserID = ?),
        ?, 
        NOW()
    )
");
$stmt->execute([
    $orderId,
    $_SESSION['user_id'],
    "Updated Order #$orderId status to " . ucfirst(str_replace('_', ' ', $newStatus)) . ($notes ? ": $notes" : '')
]);

// Get customer info
$stmt = $conn->prepare("
    SELECT o.CustomerID  : '')
");
        
        // Get customer info
        $stmt = $conn->prepare("
            SELECT o.CustomerID, c.UserID, c.Email, c.FirstName
            FROM Orders o
            JOIN Customers c ON o.CustomerID = c.CustomerID
            WHERE o.OrderID = ?
        ");
        $stmt->execute([$orderId]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Send notification based on new status
        if ($customer && $customer['UserID']) {
            $notificationMessage = '';
            $notificationType = 'order_status';
            $link = 'order_details.php?id=' . $orderId;
            
            switch ($newStatus) {
                case 'pending':
                    $notificationMessage = "Your Order #$orderId status has been changed to Pending.";
                    break;
                    
                case 'paid':
                    $notificationMessage = "Your Order #$orderId has been marked as Paid.";
                    break;
                    
                case 'preparing':
                    $notificationMessage = "Your Order #$orderId is now being prepared. We'll notify you when it's ready for pickup.";
                    break;
                    
                case 'ready_for_pickup':
                    // Get pickup code
                    $stmt = $conn->prepare("SELECT PickupCode FROM Orders WHERE OrderID = ?");
                    $stmt->execute([$orderId]);
                    $orderInfo = $stmt->fetch(PDO::FETCH_ASSOC);
                    $pickupCode = $orderInfo['PickupCode'];
                    
                    $notificationMessage = "Your Order #$orderId is now ready for pickup. Your pickup code is: $pickupCode";
                    break;
                    
                case 'completed':
                    $notificationMessage = "Your Order #$orderId has been completed. Thank you for your business!";
                    break;
                    
                case 'cancelled':
                    $notificationMessage = "Your Order #$orderId has been cancelled. " . ($notes ? "Reason: $notes" : "Please contact us for more information.");
                    break;
            }
            
            // Send in-app notification if user has an account
            if (!empty($notificationMessage)) {
                // Use the enhanced createNotificationWithLink function
                createNotificationWithLink(
                    $conn,
                    $customer['UserID'],
                    $notificationType,
                    $notificationMessage,
                    $link
                );
                
                // Also notify staff about the status change (owners and cashiers)
                $staffMessage = "Order #$orderId status changed to " . ucfirst(str_replace('_', ' ', $newStatus));
                if ($notes) {
                    $staffMessage .= " - Note: $notes";
                }
                
                // Notify owners (role 1) and cashiers (role 3)
                createNotificationForRoles($conn, [1, 3], 'order_status', $staffMessage, $_SESSION['user_id']);
            }
        }
        
        $conn->commit();
        
        // Set success message for Toastify
        $_SESSION['toast'] = [
            'type' => 'success',
            'message' => 'Order status updated successfully'
        ];
        
    } catch (Exception $e) {
        $conn->rollBack();
        
        // Set error message for Toastify
        $_SESSION['toast'] = [
            'type' => 'error',
            'message' => 'Error updating order status: ' . $e->getMessage()
        ];
    }
    
    header('Location: order_details.php?id=' . $orderId);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Details #<?= $orderId ?></title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .order-details-container {
      max-width: 1000px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .order-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .order-title {
      font-size: 1.5rem;
      font-weight: 600;
    }
    
    .order-status {
      padding: 5px 15px;
      border-radius: 20px;
      font-size: 0.9rem;
      font-weight: 500;
    }
    
    .status-pending {
      background-color: #f0f0f0;
      color: #666;
    }
    
    .status-paid {
      background-color: #e3f2fd;
      color: #1976d2;
    }
    
    .status-preparing {
      background-color: #fff8e1;
      color: #f57f17;
    }
    
    .status-ready_for_pickup {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-completed {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-cancelled {
      background-color: #ffebee;
      color: #c62828;
    }
    
    .order-sections {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .order-section {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
    }
    
    .section-title {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .info-row {
      display: flex;
      margin-bottom: 10px;
    }
    
    .info-label {
      width: 150px;
      color: #666;
      font-size: 0.9rem;
    }
    
    .info-value {
      flex: 1;
      font-weight: 500;
    }
    
    .pickup-code {
      background-color: #f5f5f5;
      padding: 10px;
      border-radius: 4px;
      text-align: center;
      font-size: 1.5rem;
      font-weight: 600;
      letter-spacing: 3px;
      margin: 15px 0;
    }
    
    .order-items {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 30px;
    }
    
    .items-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .items-table th {
      text-align: left;
      padding: 10px;
      border-bottom: 1px solid #eee;
      color: #666;
      font-weight: 600;
    }
    
    .items-table td {
      padding: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .items-table tr:last-child td {
      border-bottom: none;
    }
    
    .order-totals {
      margin-top: 20px;
      border-top: 1px solid #eee;
      padding-top: 15px;
    }
    
    .total-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 5px;
    }
    
    .total-row.grand-total {
      font-size: 1.2rem;
      font-weight: 600;
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid #eee;
    }
    
    .order-actions {
      display: flex;
      gap: 10px;
      margin-top: 20px;
    }
    
    .btn {
      padding: 10px 20px;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-decoration: none;
    }
    
    .btn i {
      margin-right: 8px;
    }
    
    .btn-primary {
      background-color: #4a934a;
      color: white;
    }
    
    .btn-primary:hover {
      background-color: #3a7a3a;
    }
    
    .btn-secondary {
      background-color: #f5f5f5;
      color: #333;
    }
    
    .btn-secondary:hover {
      background-color: #e0e0e0;
    }
    
    .btn-danger {
      background-color: #e74c3c;
      color: white;
    }
    
    .btn-danger:hover {
      background-color: #c0392b;
    }
    
    .btn-info {
      background-color: #3498db;
      color: white;
    }
    
    .btn-info:hover {
      background-color: #2980b9;
    }
    
    .btn-warning {
      background-color: #f39c12;
      color: white;
    }
    
    .btn-warning:hover {
      background-color: #d35400;
    }
    
    .btn-success {
      background-color: #2ecc71;
      color: white;
    }
    
    .btn-success:hover {
      background-color: #27ae60;
    }
    
    @media (max-width: 768px) {
      .order-sections {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="order-details-container">
      <div class="order-header">
        <div class="order-title">Order #<?= $orderId ?></div>
        <div class="order-status status-<?= $order['OrderStatus'] ?>">
          <?= ucfirst(str_replace('_', ' ', $order['OrderStatus'])) ?>
        </div>
      </div>
      
      <div class="order-sections">
        <div class="order-section">
          <div class="section-title">Customer Information</div>
          <div class="info-row">
            <div class="info-label">Name:</div>
            <div class="info-value"><?= htmlspecialchars($order['CustomerName']) ?></div>
          </div>
          <div class="info-row">
            <div class="info-label">Email:</div>
            <div class="info-value"><?= htmlspecialchars($order['CustomerEmail']) ?></div>
          </div>
          <div class="info-row">
            <div class="info-label">Phone:</div>
            <div class="info-value"><?= htmlspecialchars($order['CustomerPhone']) ?></div>
          </div>
        </div>
        
        <div class="order-section">
          <div class="section-title">Order Information</div>
          <div class="info-row">
            <div class="info-label">Order Date:</div>
            <div class="info-value"><?= date('M d, Y h:i A', strtotime($order['OrderDate'])) ?></div>
          </div>
          <div class="info-row">
            <div class="info-label">Pickup Date:</div>
            <div class="info-value"><?= date('M d, Y', strtotime($order['PickupDate'])) ?></div>
          </div>
          <div class="info-row">
            <div class="info-label">Pickup Time:</div>
            <div class="info-value"><?= date('h:i A', strtotime($order['PickupTime'])) ?></div>
          </div>
          <div class="info-row">
            <div class="info-label">Payment Status:</div>
            <div class="info-value"><?= $order['PaymentStatus'] ?? 'N/A' ?></div>
          </div>
          <div class="info-row">
            <div class="info-label">Payment Method:</div>
            <div class="info-value"><?= $order['PaymentMethod'] ?? 'N/A' ?></div>
          </div>
          <?php if ($order['PickupCode']): ?>
            <div class="info-row">
              <div class="info-label">Pickup Code:</div>
              <div class="info-value pickup-code"><?= $order['PickupCode'] ?></div>
            </div>
          <?php endif; ?>
        </div>
      </div>
      
      <div class="order-items">
        <div class="section-title">Order Items</div>
        <table class="items-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Quantity</th>
              <th>Unit Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $subtotal = 0;
            foreach ($orderItems as $item): 
              $itemTotal = $item['Quantity'] * $item['SellingPrice'];
              $subtotal += $itemTotal;
            ?>
              <tr>
                <td><?= htmlspecialchars($item['ProductName']) ?></td>
                <td><?= $item['Quantity'] ?></td>
                <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
                <td>₱<?= number_format($itemTotal, 2) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        
        <div class="order-totals">
          <div class="total-row">
            <div>Subtotal:</div>
            <div>₱<?= number_format($subtotal, 2) ?></div>
          </div>
   
          <div class="total-row grand-total">
            <div>Total:</div>
            <div>₱<?= number_format($order['TotalAmount'], 2) ?></div>
          </div>
        </div>
      </div>
      
      <div class="order-actions">
        <a href="orderingprocessing.php" class="btn btn-secondary">
          <i class="fas fa-arrow-left"></i> Back to Orders
        </a>
        
        <?php if ($order['OrderStatus'] === 'paid'): ?>
          <button class="btn btn-warning" onclick="updateOrderStatus('preparing')">
            <i class="fas fa-utensils"></i> Start Preparing
          </button>
        <?php elseif ($order['OrderStatus'] === 'preparing'): ?>
          <button class="btn btn-success" onclick="updateOrderStatus('ready_for_pickup')">
            <i class="fas fa-check"></i> Mark Ready for Pickup
          </button>
        <?php elseif ($order['OrderStatus'] === 'ready_for_pickup'): ?>
          <button class="btn btn-primary" onclick="updateOrderStatus('completed')">
            <i class="fas fa-check-double"></i> Complete Order
          </button>
        <?php endif; ?>
        
        <?php if ($order['OrderStatus'] !== 'completed' && $order['OrderStatus'] !== 'cancelled'): ?>
          <button class="btn btn-danger" onclick="confirmCancel()">
            <i class="fas fa-times"></i> Cancel Order
          </button>
        <?php endif; ?>
        
        <a href="print_order.php?id=<?= $orderId ?>" class="btn btn-info" target="_blank">
          <i class="fas fa-print"></i> Print Order
        </a>
      </div>
    </div>
  </main>
</div>

<!-- Status Update Modal -->
<div id="statusModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 class="modal-title">Update Order Status</h2>
      <button class="modal-close" onclick="closeModal()">&times;</button>
    </div>
    <form id="statusForm" method="post" action="">
      <input type="hidden" id="status" name="status">
      
      <div class="modal-body">
        <div class="form-group">
          <label for="notes">Additional Notes (Optional)</label>
          <textarea id="notes" name="notes" rows="3" class="form-control"></textarea>
        </div>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Update Status</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Check for toast messages
    <?php if (isset($_SESSION['toast'])): ?>
      Toastify({
        text: "<?= $_SESSION['toast']['message'] ?>",
        duration: 3000,
        gravity: "bottom",
        position: "right",
        backgroundColor: "<?= $_SESSION['toast']['type'] === 'success' ? '#4a934a' : '#e74c3c' ?>",
        stopOnFocus: true
      }).showToast();
      
      <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>
  });

  function updateOrderStatus(status) {
    document.getElementById('status').value = status;
    
    // Set modal title based on status
    let title = 'Update Order Status';
    switch (status) {
      case 'preparing':
        title = 'Start Preparing Order';
        break;
      case 'ready_for_pickup':
        title = 'Mark Order as Ready for Pickup';
        break;
      case 'completed':
        title = 'Complete Order';
        break;
      case 'cancelled':
        title = 'Cancel Order';
        break;
    }
    
    document.querySelector('.modal-title').textContent = title;
    document.getElementById('statusModal').classList.add('active');
  }
  
  function closeModal() {
    document.getElementById('statusModal').classList.remove('active');
  }
  
  // Close modal when clicking outside
  window.addEventListener('click', function(event) {
    const modal = document.getElementById('statusModal');
    if (event.target === modal) {
      closeModal();
    }
  });
  
  // Confirm before cancelling an order
  function confirmCancel() {
    if (confirm('Are you sure you want to cancel this order? This action cannot be undone.')) {
      updateOrderStatus('cancelled');
    }
  }
</script>
</body>
</html>
