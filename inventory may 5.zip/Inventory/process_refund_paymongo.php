<?php
// process_refund.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], [1, 2, 3])) { // Only Owner, Developer, Cashier can process refunds
    header('Location: login.php');
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid request method';
    header('Location: order_processing.php');
    exit;
}

// Get form data
$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$transactionId = isset($_POST['transaction_id']) ? intval($_POST['transaction_id']) : 0;
$paymentMethod = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
$reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
$refundItems = isset($_POST['refund_items']) ? $_POST['refund_items'] : [];

// Validate input
if ($orderId <= 0 || $transactionId <= 0 || $amount <= 0 || empty($reason)) {
    $_SESSION['error'] = 'Missing or invalid refund information';
    header('Location: order_details.php?id=' . $orderId);
    exit;
}

try {
    // Start transaction
    $conn->beginTransaction();
    
    // Get transaction details
    $stmt = $conn->prepare("
        SELECT t.*, o.TotalAmount, pm.MethodName 
        FROM Transactions t
        JOIN Orders o ON t.OrderID = o.OrderID
        JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
        WHERE t.TransactionID = ?
    ");
    $stmt->execute([$transactionId]);
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$transaction) {
        throw new Exception('Transaction not found');
    }
    
    // Check if amount is valid
    if ($amount > $transaction['Amount']) {
        throw new Exception('Refund amount cannot exceed the original transaction amount');
    }
    
    // Create refund record
    $stmt = $conn->prepare("
        INSERT INTO Refunds (
            TransactionID, 
            Amount, 
            Reason, 
            ProcessedBy, 
            Status
        ) VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $transactionId,
        $amount,
        $reason,
        $_SESSION['user_id'],
        'pending'
    ]);
    $refundId = $conn->lastInsertId();
    
    // Process refunded items if selected
    if (!empty($refundItems)) {
        foreach ($refundItems as $orderDetailId) {
            $quantityKey = 'refund_quantity_' . $orderDetailId;
            $refundQuantity = isset($_POST[$quantityKey]) ? intval($_POST[$quantityKey]) : 0;
            
            if ($refundQuantity <= 0) {
                continue;
            }
            
            // Get order detail information
            $stmt = $conn->prepare("
                SELECT od.*, p.ProductID 
                FROM OrderDetails od
                JOIN Product p ON od.ProductID = p.ProductID
                WHERE od.OrderDetailID = ?
            ");
            $stmt->execute([$orderDetailId]);
            $orderDetail = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$orderDetail) {
                continue;
            }
            
            // Validate refund quantity
            if ($refundQuantity > $orderDetail['Quantity']) {
                $refundQuantity = $orderDetail['Quantity'];
            }
            
            // Insert into RefundedItems
            $stmt = $conn->prepare("
                INSERT INTO RefundedItems (
                    OrderID, 
                    ProductID, 
                    QuantityRefunded, 
                    ItemCondition, 
                    ProcessedBy
                ) VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $orderId,
                $orderDetail['ProductID'],
                $refundQuantity,
                'PRISTINE', // Default condition, can be updated later
                $_SESSION['user_id']
            ]);
            
            // Optionally return items to inventory
            // This depends on your business logic - whether refunded items go back to inventory
            $stmt = $conn->prepare("
                INSERT INTO Inventory (
                    ProductID, 
                    Quantity, 
                    DateReceived
                ) VALUES (?, ?, CURRENT_DATE)
            ");
            $stmt->execute([
                $orderDetail['ProductID'],
                $refundQuantity
            ]);
            
            // Log inventory change
            $stmt = $conn->prepare("
                INSERT INTO InventoryLogs (
                    UserID, 
                    UsernameSnapshot, 
                    ProductNameSnapshot, 
                    Action, 
                    QuantityChanged, 
                    Remarks
                ) VALUES (
                    ?, 
                    (SELECT Username FROM Users WHERE UserID = ?), 
                    (SELECT ProductName FROM Product WHERE ProductID = ?), 
                    'REFUND_RETURN', 
                    ?, 
                    ?
                )
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $_SESSION['user_id'],
                $orderDetail['ProductID'],
                $refundQuantity,
                "Items returned to inventory from Order #$orderId refund"
            ]);
        }
    }
    
    // Process PayMongo refund if applicable
    if (in_array($transaction['MethodName'], ['GCash', 'Card', 'Maya', 'GrabPay'])) {
        // Check if there's a PayMongo transaction
        $stmt = $conn->prepare("
            SELECT * FROM PaymongoTransactions 
            WHERE TransactionID = ?
        ");
        $stmt->execute([$transactionId]);
        $paymongoTx = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($paymongoTx && !empty($paymongoTx['PaymentID'])) {
            // Load PayMongo API credentials
            $paymongoSecretKey = getenv('PAYMONGO_SECRET_KEY');
            
            if (empty($paymongoSecretKey)) {
                throw new Exception('PayMongo API credentials not configured');
            }
            
            // Prepare PayMongo API request
            $paymentId = $paymongoTx['PaymentID'];
            $refundData = [
                'data' => [
                    'attributes' => [
                        'amount' => intval($amount * 100), // Convert to cents
                        'reason' => 'requested_by_customer',
                        'notes' => $reason
                    ]
                ]
            ];
            
            // Initialize cURL session
            $ch = curl_init("https://api.paymongo.com/v1/payments/{$paymentId}/refunds");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($refundData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode($paymongoSecretKey . ':')
            ]);
            
            // Execute the request
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            // Process the response
            $responseData = json_decode($response, true);
            
            if ($httpCode >= 200 && $httpCode < 300 && isset($responseData['data']['id'])) {
                // Update refund record with PayMongo reference
                $stmt = $conn->prepare("
                    UPDATE Refunds 
                    SET Status = 'completed', RefundReference = ? 
                    WHERE RefundID = ?
                ");
                $stmt->execute([$responseData['data']['id'], $refundId]);
                
                // Update order status to refunded
                $stmt = $conn->prepare("
                    UPDATE Orders 
                    SET OrderStatus = 'refunded', UpdatedAt = NOW() 
                    WHERE OrderID = ?
                ");
                $stmt->execute([$orderId]);
                
                // Update transaction status
                $stmt = $conn->prepare("
                    UPDATE Transactions 
                    SET Status = 'refunded', UpdatedAt = NOW() 
                    WHERE TransactionID = ?
                ");
                $stmt->execute([$transactionId]);
                
                // Log the refund in audit trail
                $stmt = $conn->prepare("
                    INSERT INTO audit_trail (
                        affected_username, 
                        changed_by, 
                        action, 
                        timestamp
                    ) VALUES (
                        (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
                        (SELECT Username FROM Users WHERE UserID = ?),
                        ?, 
                        NOW()
                    )
                ");
                $stmt->execute([
                    $orderId,
                    $_SESSION['user_id'],
                    "Refunded ₱" . number_format($amount, 2) . " for Order #$orderId via PayMongo. Reason: $reason"
                ]);
                
                // Notify customer about the refund
                $stmt = $conn->prepare("
                    SELECT o.CustomerID, c.UserID, c.Email, c.FirstName
                    FROM Orders o
                    JOIN Customers c ON o.CustomerID = c.CustomerID
                    WHERE o.OrderID = ?
                ");
                $stmt->execute([$orderId]);
                $customer = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($customer && $customer['UserID']) {
                    $notificationMessage = "Your Order #$orderId has been refunded ₱" . number_format($amount, 2) . ". Reason: $reason";
                    createNotification(
                        $conn,
                        $customer['UserID'],
                        'refund',
                        $notificationMessage
                    );
                }
                
                $conn->commit();
                $_SESSION['success'] = 'Refund processed successfully via PayMongo';
            } else {
                // PayMongo API error
                $errorMessage = isset($responseData['errors'][0]['detail']) 
                    ? $responseData['errors'][0]['detail'] 
                    : 'Unknown error from PayMongo API';
                
                // Update refund record with failed status
                $stmt = $conn->prepare("
                    UPDATE Refunds 
                    SET Status = 'failed' 
                    WHERE RefundID = ?
                ");
                $stmt->execute([$refundId]);
                
                throw new Exception('PayMongo refund failed: ' . $errorMessage);
            }
        } else {
            throw new Exception('PayMongo payment information not found');
        }
    } else {
        // For non-PayMongo payments (Cash, Credit, etc.)
        // Update refund record
        $stmt = $conn->prepare("
            UPDATE Refunds 
            SET Status = 'completed' 
            WHERE RefundID = ?
        ");
        $stmt->execute([$refundId]);
        
        // Update order status to refunded
        $stmt = $conn->prepare("
            UPDATE Orders 
            SET OrderStatus = 'refunded', UpdatedAt = NOW() 
            WHERE OrderID = ?
        ");
        $stmt->execute([$orderId]);
        
        // Update transaction status
        $stmt = $conn->prepare("
            UPDATE Transactions 
            SET Status = 'refunded', UpdatedAt = NOW() 
            WHERE TransactionID = ?
        ");
        $stmt->execute([$transactionId]);
        
        // Log the refund in audit trail
        $stmt = $conn->prepare("
            INSERT INTO audit_trail (
                affected_username, 
                changed_by, 
                action, 
                timestamp
            ) VALUES (
                (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
                (SELECT Username FROM Users WHERE UserID = ?),
                ?, 
                NOW()
            )
        ");
        $stmt->execute([
            $orderId,
            $_SESSION['user_id'],
            "Refunded ₱" . number_format($amount, 2) . " for Order #$orderId manually. Reason: $reason"
        ]);
        
        // Notify customer about the refund
        $stmt = $conn->prepare("
            SELECT o.CustomerID, c.UserID, c.Email, c.FirstName
            FROM Orders o
            JOIN Customers c ON o.CustomerID = c.CustomerID
            WHERE o.OrderID = ?
        ");
        $stmt->execute([$orderId]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($customer && $customer['UserID']) {
            $notificationMessage = "Your Order #$orderId has been refunded ₱" . number_format($amount, 2) . ". Reason: $reason";
            createNotification(
                $conn,
                $customer['UserID'],
                'refund',
                $notificationMessage
            );
        }
        
        $conn->commit();
        $_SESSION['success'] = 'Refund processed successfully';
    }
    
    header('Location: order_details.php?id=' . $orderId);
    exit;
    
} catch (Exception $e) {
    $conn->rollBack();
    $_SESSION['error'] = 'Error processing refund: ' . $e->getMessage();
    header('Location: order_details.php?id=' . $orderId);
    exit;
}