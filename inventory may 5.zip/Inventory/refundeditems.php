<?php
session_start();
require('config/database.php');

// Check if user is logged in and has appropriate permissions
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3)) {
    header('Location: index.php');
    exit;
}

// Apply filters if provided
$whereClause = "1=1"; // Always true condition to start with
$params = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = $_GET['search'];
    $whereClause .= " AND (p.ProductName LIKE ? OR r.ItemCondition LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (isset($_GET['start_date']) && !empty($_GET['start_date'])) {
    $startDate = $_GET['start_date'];
    $whereClause .= " AND r.RefundedAt >= ?";
    $params[] = $startDate;
}

if (isset($_GET['end_date']) && !empty($_GET['end_date'])) {
    $endDate = $_GET['end_date'];
    $whereClause .= " AND r.RefundedAt <= ?";
    $params[] = $endDate;
}

// Fetching the refunded items from the database along with the user who processed it
$query = "SELECT r.RefundID, o.OrderID, p.ProductName, r.QuantityRefunded, r.ItemCondition, r.RefundedAt, 
            u.Username as ProcessedBy, p.SellingPrice * r.QuantityRefunded as ProductRefundAmount
          FROM RefundedItems r
          JOIN Orders o ON r.OrderID = o.OrderID
          JOIN Product p ON r.ProductID = p.ProductID
          JOIN Users u ON r.ProcessedBy = u.UserID
          WHERE $whereClause
          ORDER BY r.RefundedAt DESC";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$refundedItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total refunded amount
$totalRefundQuery = "SELECT SUM(p.SellingPrice * r.QuantityRefunded) as TotalRefundAmount 
                     FROM RefundedItems r
                     JOIN Product p ON r.ProductID = p.ProductID
                     WHERE $whereClause";
$totalRefundStmt = $conn->prepare($totalRefundQuery);
$totalRefundStmt->execute($params);
$totalRefundAmount = $totalRefundStmt->fetch(PDO::FETCH_ASSOC)['TotalRefundAmount'] ?? 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refunded Items - Adriana's Marketing</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
</head>
<style>
.header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.damaged-items-container {
    margin-top: 10px;  /* Ensure the link is directly underneath */
}

.damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    display: block;
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}
</style>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="container">
                <div class="header-container">
                    <h1>Refunded Items Management</h1>
                </div>
                <a href="transactions.php" class="damaged-items-link">Transactions<<</a>

                <!-- Display Total Refunded Amount -->
                <div class="total-refund-container" style="background-color: red; color: white; padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem;">
                    <h3>Total Refunded Amount: ₱<?= number_format($totalRefundAmount, 2) ?></h3>
                </div>

                <!-- Search and Filter Form -->
                <div class="search-sort-container">
                    <form method="GET">
                        <div class="search-bar">
                            <input type="text" name="search" placeholder="Search by product or condition..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                           
                        </div>
                        <div class="date-filters">
                            <label>From: <input type="date" name="start_date" class="date-input" value="<?= $_GET['start_date'] ?? '' ?>"></label>
                            <label>To: <input type="date" name="end_date" class="date-input" value="<?= $_GET['end_date'] ?? '' ?>"></label>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <?php if (!empty($_GET)): ?>
                            <a href="refundeditems.php" class="btn btn-secondary">Clear Filters</a>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Refunded Items Table -->
                <div class="table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th>Refund ID</th>
                <th>Order ID</th>
                <th>Product Name</th>
                <th>Quantity Refunded</th>
                <th>Item Condition</th>
                <th>Refunded At</th>
                <th>Processed By</th>
                <th>Refund Amount</th> <!-- New column for the refund amount -->
            </tr>
        </thead>
        <tbody>
            <?php if (empty($refundedItems)): ?>
                <tr>
                    <td colspan="8" style="text-align: center; padding: 2rem;">No refunded items found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($refundedItems as $item): ?>
                    <tr>
                        <td><?= $item['RefundID'] ?></td>
                        <td><?= $item['OrderID'] ?></td>
                        <td><?= htmlspecialchars($item['ProductName']) ?></td>
                        <td><?= $item['QuantityRefunded'] ?></td>
                        <td><?= htmlspecialchars($item['ItemCondition']) ?></td>
                        <td><?= date('M d, Y', strtotime($item['RefundedAt'])) ?></td>
                        <td><?= htmlspecialchars($item['ProcessedBy']) ?></td>
                        <td>₱<?= number_format($item['ProductRefundAmount'], 2) ?></td> <!-- Display the refund amount -->
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
            </div>
        </main>
    </div>

    <script>
        // Show toast messages
        function showToast(type, message) {
            Toastify({
                text: message,
                duration: 5000,
                close: true,
                gravity: "bottom", 
                position: "right", 
                backgroundColor: type === 'success' ? "#4a934a" : type === 'error' ? "#dc3545" : "#4a93a9",
                stopOnFocus: true
            }).showToast();
        }

        // Check for success/error messages in URL
        const urlParams = new URLSearchParams(window.location.search);
        const successMessage = urlParams.get('msg_success');
        const errorMessage = urlParams.get('msg_error');
        
        if (successMessage) {
            showToast('success', decodeURIComponent(successMessage));
        }
        
        if (errorMessage) {
            showToast('error', decodeURIComponent(errorMessage));
        }
    </script>
</body>
</html>