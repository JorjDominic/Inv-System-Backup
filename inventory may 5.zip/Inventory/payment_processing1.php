<?php
// payment_process.php
session_start();
require_once 'config/database.php';
require_once 'config/paymongo.php';
require_once 'notification.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
error_log('Payment process started');

// Initialize response
$response = [
    'success' => false,
    'message' => '',
    'redirect_url' => null
];

// Validate request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

// Get order data from session
if (!isset($_SESSION['order_data'])) {
    $response['message'] = 'No order data found';
    echo json_encode($response);
    exit;
}

$orderData = $_SESSION['order_data'];
$input = json_decode(file_get_contents('php://input'), true);
$paymentMethod = $input['payment_method'] ?? '';

if (empty($paymentMethod)) {
    $response['message'] = 'Please select a payment method';
    echo json_encode($response);
    exit;
}

try {
    // Start transaction
    $conn->beginTransaction();

    // Get or create customer
    $customerId = null;
    $userId = $_SESSION['user_id'] ?? null;
    
    if ($userId) {
        $stmt = $conn->prepare("SELECT CustomerID FROM Customers WHERE UserID = ?");
        $stmt->execute([$userId]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        $customerId = $customer['CustomerID'] ?? null;
    }

    if (!$customerId) {
        $nameParts = explode(' ', $orderData['customer_name'], 2);
        $stmt = $conn->prepare("
            INSERT INTO Customers (
                UserID, FirstName, LastName, Email, Phone
            ) VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $userId,
            $nameParts[0],
            $nameParts[1] ?? '',
            $orderData['email'],
            $orderData['contact_number']
        ]);
        $customerId = $conn->lastInsertId();
    }

    // Create order
    $stmt = $conn->prepare("
        INSERT INTO Orders (
            CustomerID, UserID, OrderStatus, 
            PickupDate, PickupCode, PickupNotes, TotalAmount
        ) VALUES (?, ?, 'pending', ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $customerId,
        $userId,
        $orderData['pickup_date'],
        $orderData['pickup_code'],
        $orderData['pickup_notes'] ?? '',
        $orderData['total_amount']
    ]);
    
    $orderId = $conn->lastInsertId();
    $_SESSION['current_order_id'] = $orderId;

    // Create order items
    $stmt = $conn->prepare("
        INSERT INTO OrderDetails (
            OrderID, ProductID, Quantity, Price
        ) VALUES (?, ?, ?, ?)
    ");
    
    foreach ($orderData['items'] as $item) {
        $stmt->execute([$orderId, $item['id'], $item['quantity'], $item['price']]);
        
        // Update inventory
        $updateStmt = $conn->prepare("
            UPDATE Inventory 
            SET Quantity = Quantity - ? 
            WHERE ProductID = ? AND Quantity >= ?
        ");
        $updateStmt->execute([$item['quantity'], $item['id'], $item['quantity']]);
    }

    // Create transaction record
    $paymentMethodId = null;
    $stmt = $conn->prepare("SELECT PaymentMethodID FROM PaymentMethods WHERE MethodName = ?");
    
    switch ($paymentMethod) {
        case 'card': $methodName = 'Card'; break;
        case 'gcash': $methodName = 'GCash'; break;
        case 'grab_pay': $methodName = 'GrabPay'; break;
        case 'paymaya': $methodName = 'Maya'; break;
        default: $methodName = 'Other';
    }
    
    $stmt->execute([$methodName]);
    $paymentMethodRow = $stmt->fetch(PDO::FETCH_ASSOC);
    $paymentMethodId = $paymentMethodRow['PaymentMethodID'] ?? null;

    $stmt = $conn->prepare("
        INSERT INTO Transactions (
            OrderID, Amount, TransactionType, PaymentMethodID, Status
        ) VALUES (?, ?, 'online', ?, 'pending')
    ");
    
    $stmt->execute([$orderId, $orderData['total_amount'], $paymentMethodId]);
    $transactionId = $conn->lastInsertId();
    $_SESSION['current_transaction_id'] = $transactionId;

    // Process payment based on method
    $amount = intval($orderData['total_amount'] * 100);
    $description = "Order #$orderId - " . date('Y-m-d H:i:s');

    if ($paymentMethod === 'card') {
        $paymentIntentData = [
            'data' => [
                'attributes' => [
                    'amount' => $amount,
                    'payment_method_allowed' => ['card'],
                    'payment_method_options' => [
                        'card' => ['request_three_d_secure' => 'any']
                    ],
                    'currency' => 'PHP',
                    'description' => $description,
                    'statement_descriptor' => substr('Order #' . $orderId, 0, 20)
                ]
            ]
        ];
        
        $paymentIntent = paymongo_request('payment_intents', 'POST', $paymentIntentData);
        
        if (isset($paymentIntent['errors'])) {
            throw new Exception('PayMongo API Error: ' . json_encode($paymentIntent['errors']));
        }

        $paymentIntentId = $paymentIntent['data']['id'];
        
        // Store Paymongo transaction
        $stmt = $conn->prepare("
            INSERT INTO PaymongoTransactions (
                TransactionID, PaymentIntentID, ClientKey, PaymentMethod,
                CustomerID, CustomerName, CustomerEmail, CustomerPhone,
                Description
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $transactionId,
            $paymentIntentId,
            $paymentIntent['data']['attributes']['client_key'],
            $paymentMethod,
            $customerId,
            $orderData['customer_name'],
            $orderData['email'],
            $orderData['contact_number'],
            $description
        ]);

        $response = [
            'success' => true,
            'client_key' => $paymentIntent['data']['attributes']['client_key'],
            'payment_intent_id' => $paymentIntentId,
            'message' => 'Payment intent created',
            'payment_type' => 'card'
        ];
    } else {
        // E-wallet payment
        $sourceData = [
            'data' => [
                'attributes' => [
                    'amount' => $amount,
                    'currency' => 'PHP',
'redirect' => [
    'success' => 'http://' . $_SERVER['HTTP_HOST'] . '/php/Inventory/payment_success.php',
    'failed' => 'http://' . $_SERVER['HTTP_HOST'] . '/php/Inventory/payment_failed.php'
],
                    'type' => $paymentMethod,
                    'billing' => [
                        'name' => $orderData['customer_name'],
                        'email' => $orderData['email'],
                        'phone' => $orderData['contact_number']
                    ]
                ]
            ]
        ];
        
        $source = paymongo_request('sources', 'POST', $sourceData);
        
        if (isset($source['errors'])) {
            throw new Exception('PayMongo API Error: ' . json_encode($source['errors']));
        }

        $sourceId = $source['data']['id'];
        
        // Store Paymongo transaction
        $stmt = $conn->prepare("
            INSERT INTO PaymongoTransactions (
                TransactionID, PaymentSourceID, PaymentMethod,
                CustomerID, CustomerName, CustomerEmail, CustomerPhone,
                Description
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $transactionId,
            $sourceId,
            $paymentMethod,
            $customerId,
            $orderData['customer_name'],
            $orderData['email'],
            $orderData['contact_number'],
            $description
        ]);

        $response = [
            'success' => true,
            'redirect_url' => $source['data']['attributes']['redirect']['checkout_url'],
            'message' => 'Payment source created',
            'payment_type' => 'ewallet'
        ];
    }

    $conn->commit();
    
} catch (Exception $e) {
    $conn->rollBack();
    $response['message'] = 'Error processing payment: ' . $e->getMessage();
    error_log('Payment Error: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
}

header('Content-Type: application/json');
echo json_encode($response);