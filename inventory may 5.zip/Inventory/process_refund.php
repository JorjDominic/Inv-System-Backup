<?php
session_start();
require 'config/database.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: transactions.php?toast=error&msg=' . urlencode("❌ Invalid request method"));
    exit;
}

// Auth check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3)) {
    header('Location: transactions.php?toast=error&msg=' . urlencode("❌ Unauthorized access"));
    exit;
}

// Validate inputs
if (!isset($_POST['order_id'], $_POST['product_id'], $_POST['refund_qty'], $_POST['condition'])) {
    header('Location: transactions.php?toast=error&msg=' . urlencode("❌ Missing fields"));
    exit;
}

// Get data
$orderId = intval($_POST['order_id']);
$productId = intval($_POST['product_id']);
$refundQty = intval($_POST['refund_qty']);
$condition = strtoupper(trim($_POST['condition']));
$reason = trim($_POST['refund_reason'] ?? 'Refund - damaged item');
$userId = $_SESSION['user_id'];

// Ensure username is in session
if (!isset($_SESSION['username'])) {
    // Fetch username from database if it's not set
    $stmt = $conn->prepare("SELECT Username FROM Users WHERE UserID = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $_SESSION['username'] = $user ? $user['Username'] : 'Unknown';
}

$username = $_SESSION['username'];

try {
    $conn->beginTransaction();

    if ($refundQty <= 0) throw new Exception("Refund quantity must be greater than 0");
    if (!in_array($condition, ['PRISTINE', 'DAMAGED'])) throw new Exception("Invalid item condition");

    // Fetch order qty
    $stmt = $conn->prepare("SELECT Quantity FROM OrderDetails WHERE OrderID = ? AND ProductID = ?");
    $stmt->execute([$orderId, $productId]);
    $orderItem = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$orderItem) throw new Exception("Product not found in order");

    $orderedQty = $orderItem['Quantity'];

    // Check if already refunded
    $stmt = $conn->prepare("SELECT COALESCE(SUM(QuantityRefunded), 0) FROM RefundedItems WHERE OrderID = ? AND ProductID = ?");
    $stmt->execute([$orderId, $productId]);
    $alreadyRefunded = $stmt->fetchColumn();

    if ($alreadyRefunded + $refundQty > $orderedQty) {
        throw new Exception("Cannot refund more than ordered quantity");
    }

    // Insert refund
    $stmt = $conn->prepare("INSERT INTO RefundedItems (OrderID, ProductID, QuantityRefunded, ItemCondition, ProcessedBy, RefundedAt)
                            VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$orderId, $productId, $refundQty, $condition, $userId]);

    // Get product name
    $stmt = $conn->prepare("SELECT ProductName FROM Product WHERE ProductID = ?");
    $stmt->execute([$productId]);
    $productName = $stmt->fetchColumn();

    if (!$productName) throw new Exception("Product name not found");

    // Fetch expiry date, if available
    $expiryStmt = $conn->prepare("SELECT ExpiryDate FROM Inventory WHERE ProductID = ? AND ExpiryDate IS NOT NULL ORDER BY ExpiryDate DESC LIMIT 1");
    $expiryStmt->execute([$productId]);
    $expiryDate = $expiryStmt->fetchColumn();

    // If no expiry date is found, we can either skip it or set a default (e.g., current date)
    if (!$expiryDate) {
        $expiryDate = date('Y-m-d'); // Set current date as fallback
    }

    if ($condition === 'PRISTINE') {
        // Insert restock (for pristine condition)
        $stmt = $conn->prepare("INSERT INTO Inventory (ProductID, Quantity, DateReceived, ExpiryDate)
                                VALUES (?, ?, NOW(), ?)");
        $stmt->execute([$productId, $refundQty, $expiryDate]);
        $inventoryId = $conn->lastInsertId();

        // Log restock action
        $remarks = "Refunded and restocked: $productName";
        $logStmt = $conn->prepare("INSERT INTO InventoryLogs (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks)
                                   VALUES (?, ?, ?, ?, 'restock_refund', ?, ?)");
        $logStmt->execute([$userId, $username, $productName, $inventoryId, $refundQty, $remarks]);

    } else {
        // Log damaged item action
        $remarks = "Refunded item marked as DAMAGED: $productName";

        $conn->prepare("INSERT INTO InventoryLogs (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks)
                        VALUES (?, ?, ?, NULL, 'refund_damaged', ?, ?)")
             ->execute([$userId, $username, $productName, $refundQty, $remarks]);

        $conn->prepare("INSERT INTO DamagedItems (ProductID, Quantity, Reason, ReportedBy)
                        VALUES (?, ?, ?, ?)")
             ->execute([$productId, $refundQty, $reason, $userId]);
    }

    $conn->commit();

    // ✅ Redirect with success
    header('Location: transactions.php?toast=success&msg=' . urlencode("✅ Refunded $refundQty $productName"));
    exit;

} catch (Exception $e) {
    $conn->rollBack();
    header('Location: transactions.php?toast=error&msg=' . urlencode("❌ " . $e->getMessage()));
    exit;
}
?>
