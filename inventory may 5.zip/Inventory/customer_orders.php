<?php
// customer_orders.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Check if user is logged in and has customer role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 5) { // Assuming 5 is the customer role ID
    header('Location: login.php?toast=error&msg=' . urlencode("Please login to view your orders"));
    exit;
}

$userId = $_SESSION['user_id'];

// Get customer ID for the logged-in user
$stmt = $conn->prepare("SELECT CustomerID FROM Customers WHERE UserID = ?");
$stmt->execute([$userId]);
$customer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$customer) {
    // If no customer record exists, redirect to profile completion page
    header('Location: complete_profile.php?toast=error&msg=' . urlencode("Please complete your profile first"));
    exit;
}

$customerId = $customer['CustomerID'];

// Get status filter if provided
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';
$validStatuses = ['pending', 'paid', 'preparing', 'ready_for_pickup', 'completed', 'cancelled', 'all'];

if (!in_array($statusFilter, $validStatuses)) {
    $statusFilter = 'all';
}

// Build query based on filter
$sql = "
    SELECT 
        o.OrderID, 
        o.OrderDate, 
        o.OrderStatus,
        o.PickupDate,
        o.PickupTime,
        o.PickupCode,
        o.TotalAmount,
        COUNT(od.OrderDetailID) AS ItemCount,
        t.Status AS PaymentStatus,
        t.TransactionID,
        pl.ReferenceNumber
    FROM Orders o
    LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
    LEFT JOIN Transactions t ON o.OrderID = t.OrderID
    LEFT JOIN PaymentLinks pl ON o.OrderID = pl.OrderID
    WHERE o.CustomerID = :customerId
";

if ($statusFilter !== 'all') {
    $sql .= " AND o.OrderStatus = :status";
}

$sql .= "
    GROUP BY o.OrderID, o.OrderDate, o.OrderStatus, o.PickupDate, o.PickupTime, 
             o.PickupCode, o.TotalAmount, PaymentStatus, t.TransactionID, pl.ReferenceNumber
    ORDER BY o.OrderDate DESC
";

$stmt = $conn->prepare($sql);
$stmt->bindParam(':customerId', $customerId, PDO::PARAM_INT);

if ($statusFilter !== 'all') {
    $stmt->bindParam(':status', $statusFilter);
}

$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get customer name
$stmt = $conn->prepare("SELECT CONCAT(FirstName, ' ', LastName) AS CustomerName FROM Customers WHERE CustomerID = ?");
$stmt->execute([$customerId]);
$customerName = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - Adriana's Marketing</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .orders-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .page-title {
            font-size: 1.8rem;
            font-weight: 600;
            color: #333;
        }
        
        .filter-tabs {
            display: flex;
            overflow-x: auto;
            gap: 10px;
            margin-bottom: 20px;
            padding-bottom: 10px;
        }
        
        .filter-tab {
            padding: 8px 16px;
            background-color: #f5f5f5;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            white-space: nowrap;
            transition: background-color 0.2s;
            text-decoration: none;
            color: #333;
        }
        
        .filter-tab.active {
            background-color: #4a934a;
            color: white;
        }
        
        .filter-tab:hover:not(.active) {
            background-color: #e0e0e0;
        }
        
        .orders-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }
        
        .order-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: transform 0.2s;
        }
        
        .order-card:hover {
            transform: translateY(-5px);
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .order-id {
            font-size: 1.2rem;
            font-weight: 600;
        }
        
        .order-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #f0f0f0;
            color: #666;
        }
        
        .status-paid {
            background-color: #e3f2fd;
            color: #1976d2;
        }
        
        .status-preparing {
            background-color: #fff8e1;
            color: #f57f17;
        }
        
        .status-ready_for_pickup {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .status-completed {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .status-cancelled {
            background-color: #ffebee;
            color: #c62828;
        }
        
        .order-info {
            margin-bottom: 15px;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 8px;
        }
        
        .info-label {
            width: 120px;
            color: #666;
            font-size: 0.9rem;
        }
        
        .info-value {
            flex: 1;
            font-weight: 500;
        }
        
        .pickup-code {
            background-color: #f5f5f5;
            padding: 8px;
            border-radius: 4px;
            text-align: center;
            font-size: 1.2rem;
            font-weight: 600;
            letter-spacing: 2px;
            margin: 10px 0;
        }
        
        .order-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        
        .btn {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s;
            text-align: center;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn i {
            margin-right: 5px;
        }
        
        .btn-primary {
            background-color: #4a934a;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #3a7a3a;
        }
        
        .btn-secondary {
            background-color: #f5f5f5;
            color: #333;
        }
        
        .btn-secondary:hover {
            background-color: #e0e0e0;
        }
        
        .btn-info {
            background-color: #3498db;
            color: white;
        }
        
        .btn-info:hover {
            background-color: #2980b9;
        }
        
        .btn-warning {
            background-color: #f39c12;
            color: white;
        }
        
        .btn-warning:hover {
            background-color: #d35400;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 0;
            grid-column: 1 / -1;
        }
        
        .empty-state i {
            font-size: 3rem;
            color: #ccc;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
            color: #666;
        }
        
        .empty-state p {
            color: #888;
            max-width: 400px;
            margin: 0 auto;
        }
        
        .reference-number {
            font-family: monospace;
            background-color: #f5f5f5;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .orders-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-tabs {
                padding-bottom: 15px;
            }
        }
    </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
    <main class="content">
        <div class="orders-container">
            <div class="page-header">
                <h1 class="page-title">My Orders</h1>
            </div>
            
            <div class="filter-tabs">
                <a href="?status=all" class="filter-tab <?= $statusFilter === 'all' ? 'active' : '' ?>">
                    All Orders
                </a>
                <a href="?status=pending" class="filter-tab <?= $statusFilter === 'pending' ? 'active' : '' ?>">
                    Pending
                </a>
                <a href="?status=paid" class="filter-tab <?= $statusFilter === 'paid' ? 'active' : '' ?>">
                    Paid
                </a>
                <a href="?status=preparing" class="filter-tab <?= $statusFilter === 'preparing' ? 'active' : '' ?>">
                    Preparing
                </a>
                <a href="?status=ready_for_pickup" class="filter-tab <?= $statusFilter === 'ready_for_pickup' ? 'active' : '' ?>">
                    Ready for Pickup
                </a>
                <a href="?status=completed" class="filter-tab <?= $statusFilter === 'completed' ? 'active' : '' ?>">
                    Completed
                </a>
                <a href="?status=cancelled" class="filter-tab <?= $statusFilter === 'cancelled' ? 'active' : '' ?>">
                    Cancelled
                </a>
            </div>
            
            <?php if (empty($orders)): ?>
                <div class="empty-state">
                    <i class="fas fa-shopping-bag"></i>
                    <h3>No orders found</h3>
                    <p>You don't have any <?= $statusFilter !== 'all' ? $statusFilter : '' ?> orders yet.</p>
                    <p><a href="shop.php" class="btn btn-primary" style="margin-top: 20px; display: inline-block;">Start Shopping</a></p>
                </div>
            <?php else: ?>
                <div class="orders-grid">
                    <?php foreach ($orders as $order): ?>
                        <div class="order-card">
                            <div class="order-header">
                                <div class="order-id">Order #<?= $order['OrderID'] ?></div>
                                <div class="order-status status-<?= $order['OrderStatus'] ?>">
                                    <?= ucfirst(str_replace('_', ' ', $order['OrderStatus'])) ?>
                                </div>
                            </div>
                            
                            <div class="order-info">
                                <div class="info-row">
                                    <div class="info-label">Order Date:</div>
                                    <div class="info-value"><?= date('M d, Y h:i A', strtotime($order['OrderDate'])) ?></div>
                                </div>
                                <div class="info-row">
                                    <div class="info-label">Pickup Date:</div>
                                    <div class="info-value"><?= date('M d, Y', strtotime($order['PickupDate'])) ?></div>
                                </div>
                                <div class="info-row">
                                    <div class="info-label">Pickup Time:</div>
                                    <div class="info-value"><?= date('h:i A', strtotime($order['PickupTime'])) ?></div>
                                </div>
                                <div class="info-row">
                                    <div class="info-label">Items:</div>
                                    <div class="info-value"><?= $order['ItemCount'] ?> items</div>
                                </div>
                                <div class="info-row">
                                    <div class="info-label">Total:</div>
                                    <div class="info-value">₱<?= number_format($order['TotalAmount'], 2) ?></div>
                                </div>
                                <?php if ($order['PaymentStatus']): ?>
                                    <div class="info-row">
                                        <div class="info-label">Payment:</div>
                                        <div class="info-value"><?= ucfirst($order['PaymentStatus']) ?></div>
                                    </div>
                                <?php endif; ?>
                                <?php if ($order['ReferenceNumber']): ?>
                                    <div class="info-row">
                                        <div class="info-label">Reference:</div>
                                        <div class="info-value">
                                            <span class="reference-number"><?= $order['ReferenceNumber'] ?></span>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($order['OrderStatus'] === 'ready_for_pickup' && $order['PickupCode']): ?>
                                <div class="pickup-code"><?= $order['PickupCode'] ?></div>
                            <?php endif; ?>
                            
                            <div class="order-actions">
                                <a href="customer_order_details.php?id=<?= $order['OrderID'] ?>" class="btn btn-primary">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                                
                                <?php if ($order['OrderStatus'] === 'pending' && (!isset($order['PaymentStatus']) || $order['PaymentStatus'] === 'pending')): ?>
                                    <a href="payment.php?order_id=<?= $order['OrderID'] ?>" class="btn btn-info">
                                        <i class="fas fa-credit-card"></i> Pay Now
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($order['OrderStatus'] === 'completed'): ?>
                                    <a href="reorder.php?order_id=<?= $order['OrderID'] ?>" class="btn btn-secondary">
                                        <i class="fas fa-redo"></i> Reorder
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Check for toast messages from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const toastType = urlParams.get('toast');
        const toastMsg = urlParams.get('msg');
        
        if (toastType && toastMsg) {
            Toastify({
                text: decodeURIComponent(toastMsg),
                duration: 3000,
                gravity: "bottom",
                position: "right",
                backgroundColor: toastType === 'success' ? '#4a934a' : '#e74c3c',
                stopOnFocus: true
            }).showToast();
            
            // Remove toast parameters from URL
            const url = new URL(window.location);
            url.searchParams.delete('toast');
            url.searchParams.delete('msg');
            window.history.replaceState({}, '', url);
        }
    });
</script>
</body>
</html>
