<?php
session_start();
require('config/database.php');
require_once 'notification.php'; // Include notification system

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// No login required for cart
// But we can track if user is logged in for personalized features
$isLoggedIn = isset($_SESSION['user_id']);
$isCustomer = $isLoggedIn && $_SESSION['role'] == 3; // Assuming role 3 is customer

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Calculate cart totals
$cartItems = [];
$subtotal = 0;
$itemCount = 0;

if (!empty($_SESSION['cart'])) {
    // Get all product IDs in the cart
    $productIds = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));
    
    // Fetch product details for all items in cart
    $stmt = $conn->prepare("
        SELECT 
            p.ProductID,
            p.ProductName,
            p.SellingPrice,
            p.ImageURL,
            SUM(i.Quantity) as AvailableQuantity
        FROM Product p
        LEFT JOIN Inventory i ON p.ProductID = i.ProductID
        WHERE p.ProductID IN ($placeholders)
        GROUP BY p.ProductID, p.ProductName, p.SellingPrice, p.ImageURL
    ");
    $stmt->execute($productIds);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Build cart items with product details
    foreach ($products as $product) {
        $productId = $product['ProductID'];
        $cartQuantity = $_SESSION['cart'][$productId]['quantity'];
        $itemTotal = $product['SellingPrice'] * $cartQuantity;
        
        $cartItems[] = [
            'id' => $productId,
            'name' => $product['ProductName'],
            'price' => $product['SellingPrice'],
            'quantity' => $cartQuantity,
            'total' => $itemTotal,
            'image' => $product['ImageURL'],
            'availableQuantity' => $product['AvailableQuantity']
        ];
        
        $subtotal += $itemTotal;
        $itemCount += $cartQuantity;
    }
}

// Calculate tax and total
$taxRate = 0.12; // 12% tax
$tax = $subtotal * $taxRate;
$total = $subtotal + $tax;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Shopping Cart</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    /* General Styles */
    :root {
      --primary-color: #4a934a;
      --danger-color: #e74c3c;
      --warning-color: #f39c12;
      --info-color: #3498db;
      --light-gray: #f8f9fa;
      --border-color: #dee2e6;
      --text-color: #333;
      --text-muted: #6c757d;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: var(--text-color);
    }
    
    /* Cart Styles */
    .cart-container {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 30px;
    }
    
    .cart-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 15px;
      border-bottom: 1px solid var(--border-color);
    }
    
    .cart-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--text-color);
      border-bottom: none;
    }
    
    .continue-shopping {
      display: flex;
      align-items: center;
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 500;
      transition: color 0.2s;
    }
    
    .continue-shopping i {
      margin-right: 8px;
    }
    
    .continue-shopping:hover {
      color: #3a7a3a;
    }
    
    .cart-empty {
      text-align: center;
      padding: 40px 20px;
    }
    
    .cart-empty i {
      font-size: 4rem;
      color: var(--text-muted);
      margin-bottom: 20px;
    }
    
    .cart-empty h3 {
      font-size: 1.5rem;
      margin-bottom: 15px;
    }
    
    .cart-empty p {
      color: var(--text-muted);
      margin-bottom: 25px;
    }
    
    .cart-empty .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 4px;
      padding: 10px 20px;
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    
    .cart-empty .btn:hover {
      background-color: #3a7a3a;
    }
    
    /* Cart Items */
    .cart-items {
      margin-bottom: 30px;
    }
    
    .cart-item {
      display: flex;
      align-items: center;
      padding: 15px 0;
      border-bottom: 1px solid var(--border-color);
    }
    
    .cart-item:last-child {
      border-bottom: none;
    }
    
    .item-image {
      width: 80px;
      height: 80px;
      border-radius: 4px;
      overflow: hidden;
      margin-right: 15px;
      background-color: var(--light-gray);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .item-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .item-image .no-image {
      color: #ccc;
      font-size: 2rem;
    }
    
    .item-details {
      flex: 1;
    }
    
    .item-name {
      font-weight: 600;
      font-size: 1.1rem;
      margin-bottom: 5px;
    }
    
    .item-price {
      color: var(--text-muted);
      font-size: 0.9rem;
    }
    
    .item-quantity {
      display: flex;
      align-items: center;
      margin: 0 20px;
    }
    
    .quantity-controls {
      display: flex;
      align-items: center;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      overflow: hidden;
    }
    
    .quantity-controls button {
      background-color: #f8f9fa;
      border: none;
      width: 32px;
      height: 32px;
      font-size: 1rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .quantity-controls button:hover {
      background-color: #e9ecef;
    }
    
    .quantity-controls input {
      width: 40px;
      height: 32px;
      border: none;
      border-left: 1px solid var(--border-color);
      border-right: 1px solid var(--border-color);
      text-align: center;
      font-size: 0.9rem;
    }
    
    .quantity-controls input:focus {
      outline: none;
    }
    
    .item-total {
      font-weight: 600;
      min-width: 100px;
      text-align: right;
    }
    
    .item-remove {
      margin-left: 15px;
    }
    
    .remove-btn {
      background: none;
      border: none;
      color: var(--danger-color);
      cursor: pointer;
      font-size: 1.2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border-radius: 4px;
      transition: background-color 0.2s;
    }
    
    .remove-btn:hover {
      background-color: #fff5f5;
    }
    
    /* Cart Summary */
    .cart-summary {
      background-color: #f8f9fa;
      border-radius: 8px;
      padding: 20px;
    }
    
    .summary-header {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid var(--border-color);
    }
    
    .summary-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    
    .summary-label {
      color: var(--text-muted);
    }
    
    .summary-value {
      font-weight: 500;
    }
    
    .summary-total {
      font-size: 1.2rem;
      font-weight: 600;
      margin-top: 15px;
      padding-top: 15px;
      border-top: 1px solid var(--border-color);
    }
    
    .checkout-btn {
      display: block;
      width: 100%;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 4px;
      padding: 12px;
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      margin-top: 20px;
      transition: background-color 0.2s;
    }
    
    .checkout-btn:hover {
      background-color: #3a7a3a;
    }
    
    .checkout-btn:disabled {
      background-color: #cccccc;
      cursor: not-allowed;
    }
    
    /* Cart Actions */
    .cart-actions {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid var(--border-color);
    }
    
    .clear-cart-btn {
      display: flex;
      align-items: center;
      gap: 8px;
      background: none;
      border: 1px solid var(--danger-color);
      color: var(--danger-color);
      border-radius: 4px;
      padding: 8px 16px;
      font-size: 0.9rem;
      cursor: pointer;
      transition: background-color 0.2s, color 0.2s;
    }
    
    .clear-cart-btn:hover {
      background-color: var(--danger-color);
      color: white;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
      .cart-item {
        flex-wrap: wrap;
      }
      
      .item-details {
        width: calc(100% - 95px);
      }
      
      .item-quantity {
        margin: 10px 0;
        order: 3;
      }
      
      .item-total {
        margin-left: auto;
        order: 2;
      }
      
      .item-remove {
        order: 4;
      }
      
      .cart-actions {
        flex-direction: column;
        gap: 15px;
      }
      
      .clear-cart-btn {
        width: 100%;
        justify-content: center;
      }
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>Shopping Cart</h1>
        <div class="link-container">
          <a href="catalog.php" class="inventory-link">&lt;&lt; Back to Catalog</a>
        </div>
      </div>
      
      <div class="cart-container">
        <div class="cart-header">
          <h2>Your Cart (<?= $itemCount ?> items)</h2>
          <a href="catalog.php" class="continue-shopping">
            <i class="fas fa-arrow-left"></i> Continue Shopping
          </a>
        </div>
        
        <?php if (empty($cartItems)): ?>
          <div class="cart-empty">
            <i class="fas fa-shopping-cart"></i>
            <h3>Your cart is empty</h3>
            <p>Looks like you haven't added any products to your cart yet.</p>
            <a href="catalog.php" class="btn">
              <i class="fas fa-shopping-basket"></i> Start Shopping
            </a>
          </div>
        <?php else: ?>
          <div class="cart-items">
            <?php foreach ($cartItems as $item): ?>
              <div class="cart-item" data-id="<?= $item['id'] ?>">
                <div class="item-image">
                  <?php if ($item['image']): ?>
                    <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                  <?php else: ?>
                    <div class="no-image"><i class="fas fa-image"></i></div>
                  <?php endif; ?>
                </div>
                <div class="item-details">
                  <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
                  <div class="item-price">₱<?= number_format($item['price'], 2) ?> each</div>
                </div>
                <div class="item-quantity">
                  <div class="quantity-controls">
                    <button type="button" onclick="updateCartItemQuantity(<?= $item['id'] ?>, 'decrease')">-</button>
                    <input type="number" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['availableQuantity'] ?>" 
                           onchange="updateCartItemQuantity(<?= $item['id'] ?>, 'set', this.value)">
                    <button type="button" onclick="updateCartItemQuantity(<?= $item['id'] ?>, 'increase', null, <?= $item['availableQuantity'] ?>)">+</button>
                  </div>
                </div>
                <div class="item-total">₱<?= number_format($item['total'], 2) ?></div>
                <div class="item-remove">
                  <button type="button" class="remove-btn" onclick="removeCartItem(<?= $item['id'] ?>)">
                    <i class="fas fa-trash-alt"></i>
                  </button>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
          
          <div class="cart-actions">
            <button type="button" class="clear-cart-btn" onclick="clearCart()">
              <i class="fas fa-trash"></i> Clear Cart
            </button>
          </div>
        <?php endif; ?>
      </div>
      
      <?php if (!empty($cartItems)): ?>
        <div class="cart-container">
          <div class="cart-summary">
            <div class="summary-header">Order Summary</div>
            <div class="summary-row">
              <div class="summary-label">Subtotal (<?= $itemCount ?> items)</div>
              <div class="summary-value">₱<?= number_format($subtotal, 2) ?></div>
            </div>
            <div class="summary-row">
              <div class="summary-label">Tax (12%)</div>
              <div class="summary-value">₱<?= number_format($tax, 2) ?></div>
            </div>
            <div class="summary-row summary-total">
              <div class="summary-label">Total</div>
              <div class="summary-value">₱<?= number_format($total, 2) ?></div>
            </div>
            <button type="button" class="checkout-btn" onclick="window.location.href='checkout.php'">
              Proceed to Checkout
            </button>
          </div>
        </div>
      <?php endif; ?>
      
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
  // Update cart item quantity
// Update cart item quantity
function updateCartItemQuantity(productId, action, value = null, max = null) {
    let newQuantity;
    
    if (action === 'decrease') {
        const input = document.querySelector(`.cart-item[data-id="${productId}"] input`);
        const currentValue = parseInt(input.value);
        newQuantity = currentValue > 1 ? currentValue - 1 : 1;
    } else if (action === 'increase') {
        const input = document.querySelector(`.cart-item[data-id="${productId}"] input`);
        const currentValue = parseInt(input.value);
        newQuantity = max !== null ? Math.min(currentValue + 1, max) : currentValue + 1;
    } else if (action === 'set') {
        newQuantity = parseInt(value);
        if (isNaN(newQuantity) || newQuantity < 1) {
            newQuantity = 1;
        } else if (max !== null && newQuantity > max) {
            newQuantity = max;
        }
    }
    
    // Show loading indicator
    Toastify({
        text: "Updating cart...",
        duration: 2000,
        gravity: "bottom",
        position: "right",
        backgroundColor: "#3498db"
    }).showToast();
    
    // Send AJAX request to update cart
    fetch('update_cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `product_id=${productId}&quantity=${newQuantity}&action=update`
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Reload the page to update cart
            window.location.reload();
        } else {
            // Show error toast
            Toastify({
                text: data.message || "Error updating cart",
                duration: 3000,
                gravity: "bottom",
                position: "right",
                backgroundColor: "#e74c3c",
                stopOnFocus: true
            }).showToast();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Toastify({
            text: "Error updating cart. Please try again.",
            duration: 3000,
            gravity: "bottom",
            position: "right",
            backgroundColor: "#e74c3c",
            stopOnFocus: true
        }).showToast();
    });
}

// Remove item from cart
function removeCartItem(productId) {
    if (!confirm('Are you sure you want to remove this item from your cart?')) {
        return;
    }
    
    // Show loading indicator
    Toastify({
        text: "Removing item...",
        duration: 2000,
        gravity: "bottom",
        position: "right",
        backgroundColor: "#3498db"
    }).showToast();
    
    // Send AJAX request to remove item
    fetch('update_cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `product_id=${productId}&action=remove`
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Reload the page to update cart
            window.location.reload();
        } else {
            // Show error toast
            Toastify({
                text: data.message || "Error removing item",
                duration: 3000,
                gravity: "bottom",
                position: "right",
                backgroundColor: "#e74c3c",
                stopOnFocus: true
            }).showToast();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Toastify({
            text: "Error removing item. Please try again.",
            duration: 3000,
            gravity: "bottom",
            position: "right",
            backgroundColor: "#e74c3c",
            stopOnFocus: true
        }).showToast();
    });
}

// Clear cart
function clearCart() {
    if (!confirm('Are you sure you want to clear your cart?')) {
        return;
    }
    
    // Show loading indicator
    Toastify({
        text: "Clearing cart...",
        duration: 2000,
        gravity: "bottom",
        position: "right",
        backgroundColor: "#3498db"
    }).showToast();
    
    // Send AJAX request to clear cart
    fetch('update_cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'action=clear'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Show success toast
            Toastify({
                text: "Cart cleared successfully",
                duration: 3000,
                gravity: "bottom",
                position: "right",
                backgroundColor: "#4a934a"
            }).showToast();
            
            // Reload the page to update cart
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            // Show error toast
            Toastify({
                text: data.message || "Error clearing cart",
                duration: 3000,
                gravity: "bottom",
                position: "right",
                backgroundColor: "#e74c3c",
                stopOnFocus: true
            }).showToast();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Toastify({
            text: "Error clearing cart. Please try again.",
            duration: 3000,
            gravity: "bottom",
            position: "right",
            backgroundColor: "#e74c3c",
            stopOnFocus: true
        }).showToast();
    });
}
</script>
</body>
</html>