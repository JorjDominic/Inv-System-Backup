<?php
// Access session
if (!isset($_SESSION)) {
    session_start();
}

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    require_once('config/database.php');
    require_once('notification.php');
    
    $userID = $_SESSION['user_id'];
    
    // Get user information
    $stmt = $conn->prepare("SELECT FirstName, LastName, RoleID FROM Users WHERE UserID = :userID");
    $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get role name (optional, only if needed)
    $stmt = $conn->prepare("SELECT RoleName FROM Roles WHERE RoleID = :roleID");
    $stmt->bindParam(':roleID', $user['RoleID'], PDO::PARAM_INT);
    $stmt->execute();
    $role = $stmt->fetch(PDO::FETCH_ASSOC);
    $roleName = $role ? $role['RoleName'] : 'User';  // Default role if not found
    
    // Get unread notifications
    $unreadNotifications = getUnreadNotifications($conn, $userID, 5); // Fetch the latest 5 unread notifications
    $unreadCount = countUnreadNotifications($conn, $userID); // Count how many notifications are unread
} else {
    // Default values if not logged in
    $user = ['FirstName' => 'Guest', 'LastName' => ''];
    $roleName = 'Guest';
    $unreadNotifications = [];
    $unreadCount = 0;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="css/navbar.css">
    <script>
        window.onload = function () {
            // Sidebar toggle functionality
            const toggleButton = document.getElementById('toggle-btn');
            const sidebar = document.getElementById('sidebar');

            if (toggleButton && sidebar) {
                toggleButton.addEventListener('click', function () {
                    sidebar.classList.toggle('close');
                    toggleButton.classList.toggle('rotate');
                
                    // Adjust navbar position when sidebar is toggled
                    const navbar = document.getElementById('navbar');
                    if (sidebar.classList.contains('close')) {
                        navbar.classList.add('sidebar-collapsed');
                    } else {
                        navbar.classList.remove('sidebar-collapsed');
                    }

                    Array.from(sidebar.getElementsByClassName('show')).forEach(ul => {
                        ul.classList.remove('show');
                        ul.previousElementSibling.classList.remove('rotate');
                    });
                });
            }

            window.toggleSubMenu = function (button) {
                const submenu = button.nextElementSibling;
                submenu.classList.toggle('show');
                button.classList.toggle('rotate');

                if (sidebar && sidebar.classList.contains('close')) {
                    sidebar.classList.toggle('close');
                    if (toggleButton) {
                        toggleButton.classList.toggle('rotate');
                    }
                }
            };
        
            // Logout modal functionality
            window.showLogoutModal = function(e) {
                e.preventDefault();
                document.getElementById('logoutModal').style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }

            window.hideLogoutModal = function() {
                document.getElementById('logoutModal').style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        
            const logoutModal = document.getElementById('logoutModal');
            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === this) {
                        hideLogoutModal();
                    }
                });
            }

            // Notification dropdown functionality
            const notificationIcon = document.getElementById('notification-icon');
            const notificationDropdown = document.getElementById('notification-dropdown');
        
            if (notificationIcon && notificationDropdown) {
                notificationIcon.addEventListener('click', function() {
                    notificationDropdown.classList.toggle('show');
                });

                // Close notification dropdown when clicking outside
                document.addEventListener('click', function(e) {
                    if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
                        notificationDropdown.classList.remove('show');
                    }
                });
            }

            // Profile dropdown functionality
            const profilePic = document.getElementById('profile-pic');
            const profileDropdown = document.getElementById('profile-dropdown-menu');
        
            if (profilePic && profileDropdown) {
                profilePic.addEventListener('click', function() {
                    profileDropdown.classList.toggle('show');
                });

                // Close profile dropdown when clicking outside
                document.addEventListener('click', function(e) {
                    if (!profilePic.contains(e.target) && !profileDropdown.contains(e.target)) {
                    profileDropdown.classList.remove('show');
                    }
                });
            }
        
            // Mark notification as read
            const markReadLinks = document.querySelectorAll('.mark-notification-read');
            markReadLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const notificationID = this.getAttribute('data-id');
                    markNotificationAsRead(notificationID, this);
                });
            });
        
            // Mark all notifications as read
            const markAllReadLink = document.querySelector('.mark-all-read');
            if (markAllReadLink) {
                markAllReadLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    markAllNotificationsAsRead();
                });
            }
        
            function markNotificationAsRead(notificationID, link) {
                fetch('mark_notification_read.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'notification_id=' + notificationID
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove the notification item
                        const notificationItem = link.closest('.notification-item');
                        notificationItem.classList.add('read');
                    
                        // Update the notification badge
                        const badge = document.querySelector('.notification-badge');
                        if (badge) {
                            const currentCount = parseInt(badge.textContent || '0');
                            if (currentCount > 1) {
                                badge.textContent = currentCount - 1;
                            } else {
                                badge.style.display = 'none';
                            }
                        }
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        
            function markAllNotificationsAsRead() {
                fetch('mark_notification_read.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'mark_all=true'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Mark all notifications as read
                        document.querySelectorAll('.notification-item').forEach(item => {
                            item.classList.add('read');
                        });
                    
                        // Hide the notification badge
                        const badge = document.querySelector('.notification-badge');
                        if (badge) {
                            badge.style.display = 'none';
                        }
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        };
    </script>
    <style>
        /* Additional styles for notifications */
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #e53e3e;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .notification-item {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: flex-start;
            transition: background-color 0.2s;
        }
        
        .notification-item:hover {
            background-color: #f7fafc;
        }
        
        .notification-item.read {
            opacity: 0.7;
        }
        
        .notification-icon-wrapper {
            margin-right: 12px;
            display: flex;
            align-items: center;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-content p {
            margin: 0 0 5px 0;
            color: #2d3748;
            font-size: 14px;
        }
        
        .notification-time {
            font-size: 12px;
            color: #718096;
        }
        
        .mark-notification-read {
            color: #4299e1;
            font-size: 12px;
            text-decoration: none;
            margin-left: 10px;
        }
        
        .view-all {
            display: block;
            text-align: center;
            padding: 10px;
            color: #4299e1;
            text-decoration: none;
            font-weight: 500;
        }
        
        /* Profile picture styles */
        .profile-pic {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #4a5568;
            cursor: pointer;
            overflow: hidden;
        }
        
        .profile-pic img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        /* Fix for empty notification list */
        .empty-notifications {
            padding: 20px;
            text-align: center;
            color: #718096;
        }
    </style>
</head>
<body>
    <!-- Logout Modal -->
    <div id="logoutModal" class="logout-modal">
        <div class="logout-modal-content">
            <h2>Confirm Logout</h2>
            <p>Are you sure you want to log out?</p>
            <div class="logout-modal-actions">
                <button onclick="hideLogoutModal()" class="logout-btn-cancel">Cancel</button>
                <a href="logout.php" class="logout-btn-confirm">Logout</a>
            </div>
        </div>
    </div>

    <!-- Navbar -->
    <div id="navbar" class="navbar">
        <div class="brand">
            <div class="logo-placeholder"> <img src="logo.jpg" alt="Logo"></div>
            <div class="company-name">Adriana's Marketing</div>
        </div>
        <div class="nav-items">
            <div class="notification-wrapper">
                <div id="notification-icon" class="notification-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#718096">
                        <path d="M160-200v-80h80v-280q0-83 50-147.5T420-792v-28q0-25 17.5-42.5T480-880q25 0 42.5 17.5T540-820v28q80 20 130 84.5T720-560v280h80v80H160Zm320-300Zm0 420q-33 0-56.5-23.5T400-160h160q0 33-23.5 56.5T480-80ZM320-280h320v-280q0-66-47-113t-113-47q-66 0-113 47t-47 113v280Z"/>
                    </svg>
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-badge"><?= $unreadCount > 9 ? '9+' : $unreadCount ?></span>
                    <?php endif; ?>
                </div>
                <div id="notification-dropdown" class="dropdown-menu notification-dropdown">
                    <div class="dropdown-header">
                        <h3>Notifications</h3>
                        <?php if ($unreadCount > 0): ?>
                            <a href="#" class="mark-all-read">Mark all as read</a>
                        <?php endif; ?>
                    </div>
                    <div class="dropdown-divider"></div>
                    <?php if (empty($unreadNotifications)): ?>
                        <div class="empty-notifications">
                            <p>No new notifications</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($unreadNotifications as $notification): ?>
                            <div class="notification-item">
                                <div class="notification-icon-wrapper">
                                    <?= getNotificationIcon($notification['NotificationType']) ?>
                                </div>
                                <div class="notification-content">
                                    <p><?= htmlspecialchars($notification['Message']) ?></p>
                                    <span class="notification-time"><?= formatNotificationTime($notification['CreatedAt']) ?></span>
                                    <a href="#" class="mark-notification-read" data-id="<?= $notification['NotificationID'] ?>">Mark as read</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <div class="dropdown-divider"></div>
                    <a href="all_notification.php" class="view-all">View all notifications</a>
                </div>
            </div>
            <div class="profile-wrapper">
                <div id="profile-pic" class="profile-pic">
                    <?php
                    // Display user initials if no profile picture
                    if (isset($user['FirstName']) && isset($user['LastName'])) {
                        $initials = strtoupper(substr($user['FirstName'], 0, 1) . substr($user['LastName'], 0, 1));
                        echo $initials;
                    } else {
                        echo 'U';
                    }
                    ?>
                </div>
                <div id="profile-dropdown-menu" class="dropdown-menu profile-dropdown">
                    <div class="dropdown-header profile-header">
                        <div class="profile-info">
                            <h3><?= htmlspecialchars($user['FirstName'] . ' ' . $user['LastName']) ?></h3>
                            <p><?= htmlspecialchars($roleName) ?></p>
                        </div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <a href="profilepage.php" class="dropdown-item">
                        <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#718096">
                            <path d="M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z"/>
                        </svg>
                        <span>My Profile</span>
                    </a>

                    <div class="dropdown-divider"></div>
                    <a href="#" onclick="showLogoutModal(event)" class="dropdown-item">
                        <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#718096">
                            <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/>
                        </svg>
                        <span>Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
