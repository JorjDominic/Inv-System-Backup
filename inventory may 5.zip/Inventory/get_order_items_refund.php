<?php
// get_order_items.php
session_start();
require_once 'config/database.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], [1, 2, 3, 4])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Check if order ID is provided
if (!isset($_GET['order_id']) || !is_numeric($_GET['order_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid order ID']);
    exit;
}

$orderId = intval($_GET['order_id']);

try {
    // Get order items
    $stmt = $conn->prepare("
        SELECT 
            od.OrderDetailID,
            od.ProductID,
            od.Quantity,
            od.Price,
            p.ProductName
        FROM OrderDetails od
        JOIN Product p ON od.ProductID = p.ProductID
        WHERE od.OrderID = ?
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json');
    echo json_encode(['items' => $items]);
    
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Error fetching order items: ' . $e->getMessage()]);
}