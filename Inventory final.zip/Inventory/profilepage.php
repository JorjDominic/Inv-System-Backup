<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM Users WHERE UserID = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['FirstName']);
    $last_name = trim($_POST['LastName']);
    $email = trim($_POST['Email']);
    $current_password = trim($_POST['current_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    $errors = [];
    $success = [];
    
    // Update basic info
    if ($first_name != $user['FirstName'] || $last_name != $user['LastName'] || $email != $user['Email']) {
        $stmt = $conn->prepare("UPDATE Users SET FirstName = ?, LastName = ?, Email = ? WHERE UserID = ?");
        $stmt->execute([$first_name, $last_name, $email, $user_id]);
        $success[] = "Profile information updated successfully.";
    }
    
    // Password change
    if (!empty($current_password) || !empty($new_password) || !empty($confirm_password)) {
        if (empty($current_password)) {
            $errors[] = "Current password is required to change password.";
        } elseif (!password_verify($current_password, $user['Password'])) {
            $errors[] = "Current password is incorrect.";
        } elseif ($new_password != $confirm_password) {
            $errors[] = "New passwords do not match.";
        } elseif (strlen($new_password) < 8) {
            $errors[] = "Password must be at least 8 characters long.";
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE Users SET Password = ? WHERE UserID = ?");
            $stmt->execute([$hashed_password, $user_id]);
            $success[] = "Password updated successfully.";
        }
    }
    
    // Store messages in session
    if (!empty($errors)) {
        $_SESSION['error_messages'] = $errors;
    }
    if (!empty($success)) {
        $_SESSION['success_messages'] = $success;
    }
    
    // Refresh user data
    header("Location: profile.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Profile - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .profile-container {
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            color: white;
            padding: 20px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            box-shadow: var(--shadow-md);
        }
        
        .profile-header h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 600;
            color: white;
        }
        
        .profile-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 30px;
            margin-bottom: 20px;
        }
        
        .profile-card h2 {
            margin-top: 0;
            color: var(--text-dark);
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 25px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--medium-gray);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--medium-gray);
            border-radius: var(--border-radius-sm);
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: var(--border-radius-sm);
            font-size: 0.95rem;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .profile-container {
                padding: 15px;
            }
            
            .profile-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="profile-container">
                <!-- Profile Header -->
                <div class="profile-header">
                    <h1>Edit Profile</h1>
                </div>
                
                <!-- Display Messages -->
                <?php if (isset($_SESSION['error_messages'])): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($_SESSION['error_messages'] as $error): ?>
                            <p><?= htmlspecialchars($error) ?></p>
                        <?php endforeach; ?>
                        <?php unset($_SESSION['error_messages']); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['success_messages'])): ?>
                    <div class="alert alert-success">
                        <?php foreach ($_SESSION['success_messages'] as $message): ?>
                            <p><?= htmlspecialchars($message) ?></p>
                        <?php endforeach; ?>
                        <?php unset($_SESSION['success_messages']); ?>
                    </div>
                <?php endif; ?>
                
                <!-- Profile Form -->
                <div class="profile-card">
                    <h2>Profile Information</h2>
                    <form method="POST" action="profile.php">
                        <div class="form-group">
                            <label for="FirstName">First Name</label>
                            <input type="text" class="form-control" id="FirstName" name="FirstName" 
                                   value="<?= htmlspecialchars($user['FirstName']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="LastName">Last Name</label>
                            <input type="text" class="form-control" id="LastName" name="LastName" 
                                   value="<?= htmlspecialchars($user['LastName']) ?>" required>
                        </div>
                        
                        <h2 style="margin-top: 30px;">Change Password</h2>
                        <p>Leave blank to keep current password</p>
                        
                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password">
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                        
                        <button type="submit" class="btn-primary">Update Profile</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</body>
</html>