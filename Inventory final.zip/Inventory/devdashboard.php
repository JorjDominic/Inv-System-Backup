<?php

session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 2) {  // Only for Developer role (role 2)
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Developer Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            box-sizing: border-box;
        }

        html {
            line-height: 1.5rem;
        }

        /* Main Container */
        .container {
            padding: 1rem;
        }

        /* Grid Layout for Dashboard */
        .dashboard-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* Create 2 equal columns */
            grid-gap: 1rem; /* Space between columns */
        }

        /* Dashboard Cards */
        .dashboard-card {
            background-color: #f4f4f4; /* Light gray background for cards */
            border-radius: 8px; /* Rounded corners */
            padding: 1rem;
            margin: 1rem 0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        .dashboard-card h3 {
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
            color: #333;
        }

        .dashboard-card p {
            color: #666;
            font-size: 1rem;
        }

        /* Styling for different notification types */
        .project-updates {
            border-left: 5px solid #3498db; /* Blue for updates */
        }

        .development-tasks {
            border-left: 5px solid #f39c12; /* Yellow for tasks */
        }

        .bug-reports {
            border-left: 5px solid #e74c3c; /* Red for bug reports */
        }

        /* Placeholder Card (Fourth container) */
        .placeholder {
            border-left: 5px solid #e0e0e0; /* Light gray for placeholder */
            color: #999;
        }
    </style>
</head>
<body>

<?php include 'sidebar.php'; ?> 

<main>
    <div class="container">
        <h2>Welcome, Developer <?= htmlspecialchars($_SESSION['user_name']) ?></h2>
        <div class="date"><?= date('l, F j, Y') ?></div>
    </div>

    <div class="dashboard-container">
        <!-- Project Updates -->
        <div class="dashboard-card project-updates">
            <h3>Project Updates</h3>
            <p>Check the latest updates on ongoing projects and milestones.</p>
        </div>

        <!-- Development Tasks -->
        <div class="dashboard-card development-tasks">
            <h3>Assigned Tasks</h3>
            <p>See the tasks assigned to you and their status.</p>
        </div>

        <!-- Bug Reports -->
        <div class="dashboard-card bug-reports">
            <h3>Bug Reports</h3>
            <p>View the reported bugs and their current status.</p>
        </div>

        <!-- Placeholder for future content -->
        <div class="dashboard-card placeholder">
            <h3>Placeholder</h3>
            <p>This is a placeholder for additional content or notifications.</p>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</main>

</body>
</html>
