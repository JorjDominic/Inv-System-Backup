<?php
// Restrict to CLI access
if (php_sapi_name() !== 'cli' && isset($_SERVER['REMOTE_ADDR'])) {
    header('HTTP/1.0 403 Forbidden');
    exit('This script can only be run from the command line or via cron job.');
}

require_once('config/database.php');

// Get current date
$currentDate = date('Y-m-d');
$systemUserId = 1; // ID of system user for automated actions

try {
    $conn->beginTransaction();
    
    // Find items that have expired (including product price info)
    $findExpiredQuery = "
        SELECT 
            i.InventoryID,
            i.ProductID,
            p.ProductName,
            i.Quantity,
            i.ExpiryDate,
            p.PurchasePrice
        FROM Inventory i
        JOIN Product p ON i.ProductID = p.ProductID
        WHERE 
            i.ExpiryDate IS NOT NULL 
            AND i.ExpiryDate <= :currentDate
            AND i.Quantity > 0
    ";
    
    $findExpiredStmt = $conn->prepare($findExpiredQuery);
    $findExpiredStmt->bindParam(':currentDate', $currentDate);
    $findExpiredStmt->execute();
    
    $expiredItems = $findExpiredStmt->fetchAll(PDO::FETCH_ASSOC);
    $processedCount = 0;
    
    foreach ($expiredItems as $item) {
        // Insert into ExpiredItems table with more details
        $insertQuery = "
            INSERT INTO ExpiredItems (
                InventoryID,
                ProductID, 
                Quantity, 
                ExpiryDate, 
                DateExpired, 
                ReportedBy,
                PurchasePrice,
                Remarks
            ) VALUES (
                :inventoryId,
                :productId,
                :quantity,
                :expiryDate,
                NOW(),
                :reportedBy,
                :purchasePrice,
                'Automatically detected as expired'
            )
        ";
        
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bindParam(':inventoryId', $item['InventoryID']);
        $insertStmt->bindParam(':productId', $item['ProductID']);
        $insertStmt->bindParam(':quantity', $item['Quantity']);
        $insertStmt->bindParam(':expiryDate', $item['ExpiryDate']);
        $insertStmt->bindParam(':reportedBy', $systemUserId);
        $insertStmt->bindParam(':purchasePrice', $item['PurchasePrice']);
        $insertStmt->execute();
        
        // Update inventory to set quantity to 0 and mark as expired
        $updateQuery = "
            UPDATE Inventory
            SET 
                Quantity = 0,
                Status = 'EXPIRED'
            WHERE InventoryID = :inventoryId
        ";
        
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bindParam(':inventoryId', $item['InventoryID']);
        $updateStmt->execute();
        
        // Detailed inventory log
        $logQuery = "
            INSERT INTO InventoryLogs (
                InventoryID,
                ProductID,
                UserID,
                Action,
                Quantity,
                OldQuantity,
                NewQuantity,
                Remarks,
                LogDate
            ) VALUES (
                :inventoryId,
                :productId,
                :userId,
                'EXPIRED',
                :quantity,
                :quantity,
                0,
                'Item automatically marked as expired. Original expiry: ' || :expiryDate,
                NOW()
            )
        ";
        
        $logStmt = $conn->prepare($logQuery);
        $logStmt->bindParam(':inventoryId', $item['InventoryID']);
        $logStmt->bindParam(':productId', $item['ProductID']);
        $logStmt->bindParam(':userId', $systemUserId);
        $logStmt->bindParam(':quantity', $item['Quantity']);
        $logStmt->bindParam(':expiryDate', $item['ExpiryDate']);
        $logStmt->execute();
        
        $processedCount++;
    }
    
    $conn->commit();
    echo "Expired items check completed. $processedCount items processed.\n";
    
} catch (PDOException $e) {
    $conn->rollBack();
    echo "Error processing expired items: " . $e->getMessage() . "\n";
    exit(1); // Non-zero exit code for cron job failure
}