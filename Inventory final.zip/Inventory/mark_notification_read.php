<?php
session_start();
require('config/database.php');
require('notifications.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

$userID = $_SESSION['user_id'];

// Check if notification ID is provided
if (isset($_POST['notification_id'])) {
    $notificationID = $_POST['notification_id'];
    $success = markNotificationAsRead($conn, $notificationID, $userID);
    
    header('Content-Type: application/json');
    echo json_encode(['success' => $success]);
    exit;
} 
// Check if mark all as read is requested
elseif (isset($_POST['mark_all'])) {
    $success = markAllNotificationsAsRead($conn, $userID);
    
    header('Content-Type: application/json');
    echo json_encode(['success' => $success]);
    exit;
} else {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

// Function to mark a specific notification as read
function markNotificationAsRead($conn, $notificationID, $userID) {
    try {
        $stmt = $conn->prepare("UPDATE Notifications SET IsRead = 1 WHERE NotificationID = ? AND UserID = ?");
        $stmt->execute([$notificationID, $userID]);
        
        if ($stmt->rowCount() > 0) {
            return true;  // Successfully marked as read
        } else {
            return false;  // No row was updated, maybe the notification does not exist
        }
    } catch (PDOException $e) {
        error_log('Error marking notification as read: ' . $e->getMessage());
        return false;  // Error occurred
    }
}

// Function to mark all notifications as read for a user
function markAllNotificationsAsRead($conn, $userID) {
    try {
        $stmt = $conn->prepare("UPDATE Notifications SET IsRead = 1 WHERE UserID = ?");
        $stmt->execute([$userID]);
        
        if ($stmt->rowCount() > 0) {
            return true;  // Successfully marked all as read
        } else {
            return false;  // No rows updated, maybe no notifications
        }
    } catch (PDOException $e) {
        error_log('Error marking all notifications as read: ' . $e->getMessage());
        return false;  // Error occurred
    }
}
?>
