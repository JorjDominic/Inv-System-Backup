<?php
session_start();
require('config/database.php');
require('notification.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$userID = $_SESSION['user_id'];
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Get all notifications for the user
$notifications = getAllNotifications($conn, $userID, $limit, $offset);

// Count total notifications for pagination
$stmt = $conn->prepare("SELECT COUNT(*) FROM Notifications WHERE UserID = :userID");
$stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
$stmt->execute();
$totalNotifications = $stmt->fetchColumn();
$totalPages = ceil($totalNotifications / $limit);

// Get user information
$stmt = $conn->prepare("SELECT FirstName, LastName, RoleID FROM Users WHERE UserID = :userID");
$stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get role name
$stmt = $conn->prepare("SELECT RoleName FROM Roles WHERE RoleID = :roleID");
$stmt->bindParam(':roleID', $user['Role'], PDO::PARAM_INT);
$stmt->execute();
$role = $stmt->fetch(PDO::FETCH_ASSOC);
$roleName = $role ? $role['RoleName'] : 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Notifications - Adriana's Marketing</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/navbar.css">
    <style>
        .notifications-container {
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .notifications-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .notifications-header h1 {
            margin: 0;
            font-size: 1.8rem;
            color: var(--text-dark);
        }
        
        .mark-all-read-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
        }
        
        .notification-list {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .notification-item {
            display: flex;
            padding: 16px;
            border-bottom: 1px solid #eee;
            transition: background-color 0.2s;
        }
        
        .notification-item:last-child {
            border-bottom: none;
        }
        
        .notification-item.unread {
            background-color: #f0f9ff;
        }
        
        .notification-icon-wrapper {
            margin-right: 16px;
            display: flex;
            align-items: flex-start;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-content p {
            margin: 0 0 5px 0;
            color: var(--text-dark);
        }
        
        .notification-time {
            font-size: 0.8rem;
            color: var(--text-medium);
        }
        
        .notification-actions {
            display: flex;
            align-items: center;
        }
        
        .mark-read-btn {
            background: none;
            border: none;
            color: var(--primary-color);
            cursor: pointer;
            font-size: 0.9rem;
            padding: 5px;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        
        .pagination a, .pagination span {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 4px;
            border-radius: 4px;
            text-decoration: none;
            color: var(--text-dark);
        }
        
        .pagination a {
            background-color: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .pagination a:hover {
            background-color: #f5f5f5;
        }
        
        .pagination .active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .pagination .disabled {
            color: #ccc;
            cursor: not-allowed;
        }
        
        .no-notifications {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-medium);
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>
    
    <div class="main-content-wrapper">
        <main class="content">
            <div class="notifications-container">
                <div class="notifications-header">
                    <h1>All Notifications</h1>
                    <?php if (!empty($notifications)): ?>
                        <button class="mark-all-read-btn" id="markAllReadBtn">Mark all as read</button>
                    <?php endif; ?>
                </div>
                
                <div class="notification-list">
                    <?php if (empty($notifications)): ?>
                        <div class="no-notifications">
                            <p>You have no notifications</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($notifications as $notification): ?>
                            <div class="notification-item <?= $notification['IsRead'] ? '' : 'unread' ?>" data-id="<?= $notification['NotificationID'] ?>">
                                <div class="notification-icon-wrapper">
                                    <?= getNotificationIcon($notification['NotificationType']) ?>
                                </div>
                                <div class="notification-content">
                                    <p><?= htmlspecialchars($notification['Message']) ?></p>
                                    <span class="notification-time"><?= formatNotificationTime($notification['CreatedAt']) ?></span>
                                </div>
                                <?php if (!$notification['IsRead']): ?>
                                    <div class="notification-actions">
                                        <button class="mark-read-btn" data-id="<?= $notification['NotificationID'] ?>">Mark as read</button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?>">Previous</a>
                        <?php else: ?>
                            <span class="disabled">Previous</span>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="active"><?= $i ?></span>
                            <?php else: ?>
                                <a href="?page=<?= $i ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <a href="?page=<?= $page + 1 ?>">Next</a>
                        <?php else: ?>
                            <span class="disabled">Next</span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Mark single notification as read
            const markReadButtons = document.querySelectorAll('.mark-read-btn');
            markReadButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const notificationID = this.getAttribute('data-id');
                    markNotificationAsRead(notificationID, this);
                });
            });
            
            // Mark all notifications as read
            const markAllReadBtn = document.getElementById('markAllReadBtn');
            if (markAllReadBtn) {
                markAllReadBtn.addEventListener('click', function() {
                    markAllNotificationsAsRead();
                });
            }
            
            function markNotificationAsRead(notificationID, button) {
                fetch('mark_notification_read.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'notification_id=' + notificationID
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove unread class and the button
                        const notificationItem = button.closest('.notification-item');
                        notificationItem.classList.remove('unread');
                        button.parentElement.remove();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
            
            function markAllNotificationsAsRead() {
                fetch('mark_notification_read.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'mark_all=true'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove all unread classes and buttons
                        document.querySelectorAll('.notification-item.unread').forEach(item => {
                            item.classList.remove('unread');
                        });
                        document.querySelectorAll('.notification-actions').forEach(actions => {
                            actions.remove();
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        });
    </script>
</body>
</html>
