<?php
session_start();
require 'config/database.php';
require 'notification.php'; // Add this line

header('Content-Type: application/json');

try {
    if (!isset($_SESSION['user_id'])) {
        throw new Exception("Permission denied. Please login.");
    }

    $currentDate = date('Y-m-d');
    $conn->beginTransaction();

    // 1. Count and validate expired items
    $countStmt = $conn->prepare("
        SELECT COUNT(*) 
        FROM Inventory i
        JOIN Product p ON i.ProductID = p.ProductID
        WHERE i.ExpiryDate IS NOT NULL 
        AND i.ExpiryDate < ? 
        AND i.Quantity > 0
    ");
    $countStmt->execute([$currentDate]);
    $count = $countStmt->fetchColumn();

    if ($count > 0) {
        // Get details of expired items for notifications
        $expiredItemsStmt = $conn->prepare("
            SELECT p.ProductName, i.Quantity, i.ExpiryDate
            FROM Inventory i
            JOIN Product p ON i.ProductID = p.ProductID
            WHERE i.ExpiryDate IS NOT NULL 
            AND i.ExpiryDate < ? 
            AND i.Quantity > 0
        ");
        $expiredItemsStmt->execute([$currentDate]);
        $expiredItems = $expiredItemsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 2. Move expired items to ExpiredItems table
        $moveStmt = $conn->prepare("
            INSERT INTO ExpiredItems (
                InventoryID,
                ProductID,
                Quantity,
                ExpiryDate,
                ReportedBy,
                PurchasePrice,
                Remarks
            )
            SELECT 
                i.InventoryID,
                i.ProductID, 
                i.Quantity, 
                i.ExpiryDate, 
                ?, 
                p.PurchasePrice,
                'Automatically processed by system'
            FROM Inventory i
            JOIN Product p ON i.ProductID = p.ProductID
            WHERE i.ExpiryDate IS NOT NULL 
            AND i.ExpiryDate < ? 
            AND i.Quantity > 0
        ");
        $moveStmt->execute([$_SESSION['user_id'], $currentDate]);

        // 3. Remove expired items from Inventory
        $deleteStmt = $conn->prepare("
            DELETE FROM Inventory 
            WHERE ExpiryDate IS NOT NULL 
            AND ExpiryDate < ? 
            AND i.Quantity > 0
        ");
        $deleteStmt->execute([$currentDate]);
        
        // 4. Create notifications for admins and inventory managers
        $notifyStmt = $conn->prepare("SELECT UserID FROM Users WHERE RoleID IN (1, 2)"); // Admins and inventory managers
        $notifyStmt->execute();
        $notifyUsers = $notifyStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Create a summary notification
        $notificationMessage = "$count expired items have been removed from inventory";
        foreach ($notifyUsers as $user) {
            createNotification($conn, $user['UserID'], 'inventory_update', $notificationMessage);
        }
        
        // Create detailed notifications for each expired item
        foreach ($expiredItems as $item) {
            $itemMessage = "{$item['Quantity']} units of {$item['ProductName']} expired on " . date('M d, Y', strtotime($item['ExpiryDate']));
            foreach ($notifyUsers as $user) {
                createNotification($conn, $user['UserID'], 'inventory_update', $itemMessage);
            }
        }
    }

    $conn->commit();

    // Return success response
    echo json_encode([
        'status' => 'success',
        'count' => $count,
        'message' => $count ? "Processed $count expired items" : "No expired items found"
    ]);

} catch (PDOException $e) {
    $conn->rollBack();
    error_log("Database error processing expired items: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database operation failed',
        'debug' => $e->getMessage() // Remove in production
    ]);
} catch (Exception $e) {
    $conn->rollBack();
    error_log("Error processing expired items: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
