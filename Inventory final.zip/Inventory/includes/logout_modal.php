<?php
// Access session
if (!isset($_SESSION)) {
    session_start();
}
?>
<div id="logoutModal" class="logout-modal">
    <div class="logout-modal-content">
        <h2>Confirm Logout</h2>
        <p>Are you sure you want to log out?</p>
        <div class="logout-modal-actions">
            <button onclick="hideLogoutModal()" class="logout-btn-cancel">Cancel</button>
            <a href="logout.php" class="logout-btn-confirm">Logout</a>
        </div>
    </div>
</div>