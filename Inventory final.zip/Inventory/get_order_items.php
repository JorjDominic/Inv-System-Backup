<?php
session_start();
require('config/database.php');

$orderId = $_GET['order_id'] ?? null;

if (!$orderId || !is_numeric($orderId)) {
    die("<div class='error-message'>❌ Invalid order ID.</div>");
}

try {
    // Fetch order items
    $stmt = $conn->prepare("
    SELECT 
        p.ProductID,
        p.ProductName,
        ANY_VALUE(od.Price) AS Price,
        ANY_VALUE(od.Quantity) AS Quantity,
        (ANY_VALUE(od.Price) * ANY_VALUE(od.Quantity)) AS Subtotal,
        COALESCE(SUM(ri.QuantityRefunded), 0) AS RefundedQty
    FROM OrderDetails od
    JOIN Product p ON od.ProductID = p.ProductID
    LEFT JOIN RefundedItems ri ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
    WHERE od.OrderID = ?
    GROUP BY p.ProductID, p.ProductName
    ORDER BY p.ProductName
");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$items) {
        echo "<div class='error-message'>No items found for this order.</div>";
        exit;
    }

    echo '<table class="item-table" style="width: 100%;">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Refunded</th>
                    <th>Subtotal</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>';

    foreach ($items as $item) {
        $available = $item['Quantity'] - $item['RefundedQty'];
        $disabled = $available <= 0 ? 'disabled' : '';

        echo "<tr>
            <td>" . htmlspecialchars($item['ProductName']) . "</td>
            <td>₱" . number_format($item['Price'], 2) . "</td>
            <td>" . intval($item['Quantity']) . "</td>
            <td>" . intval($item['RefundedQty']) . "</td>
            <td>₱" . number_format($item['Subtotal'], 2) . "</td>
            <td>
                <button class='btn btn-sm btn-danger' 
                    onclick=\"openItemRefundModal(" . htmlspecialchars($orderId) . ", " . $item['ProductID'] . ", " . $item['Quantity'] . ", " . $item['RefundedQty'] . ", '" . htmlspecialchars($item['ProductName'], ENT_QUOTES) . "')\"
                    $disabled>
                    Refund
                </button>
            </td>
        </tr>";
    }

    echo '</tbody></table>';

} catch (PDOException $e) {
    echo '<div class="error-message">Error loading items: ' . htmlspecialchars($e->getMessage()) . '</div>';
}
?>
