<?php
session_start();
require_once 'config/database.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName    = $_POST['product_name'];
    $categoryID     = $_POST['category_id'];
    $quantity       = $_POST['quantity'];
    $purchasePrice  = $_POST['purchase_price'];
    $sellingPrice   = $_POST['selling_price'];
    $dateReceived   = $_POST['date_received'];
    $expiryDate     = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

    try {
        $conn->beginTransaction();

        // ✅ Step 1: Check if product already exists (by name and category)
        $checkStmt = $conn->prepare("SELECT ProductID FROM Product WHERE ProductName = ? AND CategoryID = ?");
        $checkStmt->execute([$productName, $categoryID]);
        $product = $checkStmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            // ✅ Reuse existing ProductID
            $productID = $product['ProductID'];
        } else {
            // ❌ Product doesn't exist yet, insert it
            $productStmt = $conn->prepare("INSERT INTO Product (ProductName, CategoryID, PurchasePrice, SellingPrice)
                                           VALUES (?, ?, ?, ?)");
            $productStmt->execute([$productName, $categoryID, $purchasePrice, $sellingPrice]);
            $productID = $conn->lastInsertId();
        }

        // ✅ Step 2: Insert stock into Inventory table
        $inventoryStmt = $conn->prepare("INSERT INTO Inventory (ProductID, Quantity, DateReceived, ExpiryDate)
                                         VALUES (?, ?, ?, ?)");
        $inventoryStmt->execute([$productID, $quantity, $dateReceived, $expiryDate]);

        $conn->commit();

        $_SESSION['success'] = "✅ Stock successfully added!";
        header("Location: inventory.php");
        exit;

    } catch (PDOException $e) {
        $conn->rollBack();
        echo "❌ Error: " . $e->getMessage();
        exit;
    }
}
?>
