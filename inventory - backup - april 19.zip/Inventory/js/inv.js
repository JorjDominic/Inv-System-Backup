document.addEventListener('DOMContentLoaded', function () {
  // General modal open/close
  window.openModal = function (id) {
    const modal = document.getElementById(id);
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';

    if (id === 'cartSummaryModal') {
      displayCartItems();
    }
  };

  window.closeModal = function (id) {
    const modal = document.getElementById(id);
    modal.classList.remove('show');
    document.body.style.overflow = 'auto';
  };

  // Close modals by clicking outside
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function (e) {
      if (e.target === this) closeModal(this.id);
    });
  });

  // 🔍 Live Search
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      const searchTerm = this.value.toLowerCase();
      document.querySelectorAll('.table tbody tr').forEach(row => {
        const productName = row.cells[1].textContent.toLowerCase(); // Changed to cells[1] for product name
        row.style.display = productName.includes(searchTerm) ? '' : 'none';
      });
    });
  }

  window.openDeleteModal = function (inventoryId) {
    const modal = document.getElementById('deleteModal');
    if (modal) {
      const input = modal.querySelector('input[name="inventory_id"]');
      input.value = inventoryId;
      openModal('deleteModal'); // ✅ This line triggers showing the modal
    }
  };
  
  // ⬇ Sorting

  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', function () {
      const value = this.value;
      const tbody = document.querySelector('.table tbody');
      const rows = Array.from(tbody.querySelectorAll('tr'));
      const getPrice = (cell) => parseFloat(cell.textContent.replace(/[₱,]/g, ''));

      rows.sort((a, b) => {
        const getText = (cell) => cell.textContent.trim();
        const getPrice = (cell) => parseFloat(cell.textContent.replace(/[^\d.]/g, '')) || 0;
        const getQuantity = (cell) => parseInt(cell.textContent) || 0;
      
        switch (value) {
          case 'name_asc':
            return getText(a.cells[1]).localeCompare(getText(b.cells[1]));
          case 'name_desc':
            return getText(b.cells[1]).localeCompare(getText(a.cells[1]));
          case 'quantity_asc':
            return getQuantity(a.cells[2]) - getQuantity(b.cells[2]);
          case 'quantity_desc':
            return getQuantity(b.cells[2]) - getQuantity(a.cells[2]);
          case 'price_asc':
            return getPrice(a.cells[3]) - getPrice(b.cells[3]); // Selling Price column
          case 'price_desc':
            return getPrice(b.cells[3]) - getPrice(a.cells[3]);
          default:
            return 0;
        }
      });

      rows.forEach(row => tbody.appendChild(row));
    });
  }

  // Order buttons
  document.querySelectorAll('.btn-order').forEach(button => {
    button.addEventListener('click', function () {
      const productName = button.getAttribute('data-name');
      const price = parseFloat(button.getAttribute('data-price'));
      openCartModal(productName, price);
    });
  });

  // Quantity input listener
  const qtyInput = document.getElementById('quantity');
  if (qtyInput) {
    qtyInput.addEventListener('input', updateTotalPrice);
  }

  // Cart form submission handler
  const cartForm = document.getElementById('cartForm');
  if (cartForm) {
    cartForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const productName = document.getElementById('modalProductName').textContent;
      const price = parseFloat(document.getElementById('modalProductPrice').textContent);
      const quantity = parseInt(document.getElementById('quantity').value);
      
      if (quantity > 0) {
        addToCart(productName, price, quantity);
        closeModal('cartModal');
      }
    });
  }

  // Discount input listener
  const discountInput = document.getElementById('discount');
  if (discountInput) {
    discountInput.addEventListener('input', updateCartTotal);
  }
});

// 🛒 Cart functionality
let cart = [];

function openCartModal(productName, price) {
  document.getElementById('modalProductName').textContent = productName;
  document.getElementById('modalProductPrice').textContent = price.toFixed(2);
  document.getElementById('quantity').value = 1;
  updateTotalPrice();
  openModal('cartModal');
}

function updateTotalPrice() {
  const quantity = parseInt(document.getElementById('quantity').value) || 0;
  const price = parseFloat(document.getElementById('modalProductPrice').textContent) || 0;
  const total = (quantity * price).toFixed(2);
  document.getElementById('modalTotalPrice').textContent = total;
}

function addToCart(name, price, quantity) {
  const index = cart.findIndex(item => item.name === name && item.price === price);
  
  if (index >= 0) {
    cart[index].quantity += quantity;
  } else {
    cart.push({ name, price, quantity });
  }

  updateCartCount();
  displayCartItems();
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  document.getElementById('cartCount').textContent = count;
}

function updateCartTotal() {
  const discount = parseFloat(document.getElementById('discount').value) || 0;
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal - discount;
  document.getElementById('cartTotal').textContent = total > 0 ? total.toFixed(2) : '0.00';
}

function displayCartItems() {
  const container = document.getElementById('cartItemsContainer');
  container.innerHTML = '';

  if (cart.length === 0) {
    container.innerHTML = '<p class="empty-cart-message">Your cart is empty</p>';
    document.getElementById('cartTotal').textContent = '0.00';
    return;
  }

  let total = 0;

  cart.forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const itemElement = document.createElement('div');
    itemElement.className = 'cart-item';
    itemElement.innerHTML = `
      <div class="cart-item-details">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-quantity">
          <button class="qty-btn" onclick="changeQuantity(${index}, -1)">−</button>
          <span>${item.quantity}</span>
          <button class="qty-btn" onclick="changeQuantity(${index}, 1)">+</button>
        </div>
      </div>
      <div class="cart-item-price">₱${itemTotal.toFixed(2)}</div>
    `;
    container.appendChild(itemElement);
  });

  document.getElementById('cartTotal').textContent = total.toFixed(2);
}

function changeQuantity(index, delta) {
  cart[index].quantity += delta;
  if (cart[index].quantity <= 0) {
    cart.splice(index, 1);
  }

  updateCartCount();
  displayCartItems();
  updateCartTotal();
}

function checkout() {
  if (cart.length === 0) {
    alert('Your cart is empty!');
    return;
  }

  const paymentMethod = document.getElementById('paymentMethod').value;
  const discount = parseFloat(document.getElementById('discount').value) || 0;

  fetch('process_order.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      cart: cart,
      payment_method: paymentMethod,
      discount: discount
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      alert('Order placed successfully!');
      cart = [];
      updateCartCount();
      displayCartItems();
      closeModal('cartSummaryModal');
    } else {
      alert('❌ Error: ' + data.error);
    }
  })
  .catch(err => {
    console.error('Checkout failed:', err);
    alert('Something went wrong during checkout.');
  });
}