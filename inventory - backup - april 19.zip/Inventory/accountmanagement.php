<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

$stmt = $conn->prepare("SELECT * FROM Users");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/accmanagement.css">
    <title>Account Management</title>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-wrapper">
<main class="content">
<div class="container">
    <h1>Account Management</h1>
    <div class="search-sort-bar">
    <div class="search-bar">
        <input type="text" id="searchInput" placeholder="Search by username, action, or role...">
    </div>
    <div class="sort-bar">
        <select id="roleFilter">
            <option value="">All Roles</option>
            <option value="Owner">Owner</option>
            <option value="Developer">Developer</option>
            <option value="Cashier">Cashier</option>
            <option value="Staff">Staff</option>
        </select>
    </div>
</div>
    <table class="table">
        <thead>
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Role</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['Username']) ?></td>
                    <td><?= htmlspecialchars($user['Email']) ?></td>
                    <td><?= htmlspecialchars($user['FirstName']) ?></td>
                    <td><?= htmlspecialchars($user['LastName']) ?></td>
                    <td><?= $user['RoleID'] == 1 ? 'Owner' : ($user['RoleID'] == 2 ? 'Developer' : ($user['RoleID'] == 3 ? 'Cashier' : 'Staff')) ?></td>
                    <td><?= htmlspecialchars($user['createdAt']) ?></td>
                    <td><?= htmlspecialchars($user['updatedAt']) ?></td>
                    <td>
                        <button class="btn btn-edit" onclick="openEditModal(<?= $user['UserID'] ?>, '<?= htmlspecialchars($user['Username']) ?>', '<?= htmlspecialchars($user['Email']) ?>', <?= $user['RoleID'] ?>, '<?= htmlspecialchars($user['FirstName']) ?>', '<?= htmlspecialchars($user['LastName']) ?>')">Edit</button>
                        <?php if ($user['RoleID'] != 1): ?>
    <a href="delete_user.php?id=<?= $user['UserID'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
<?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>Edit User</h2>
        <form action="edit_user.php" method="POST">
            <input type="hidden" id="editUserId" name="user_id">

            <label for="editUsername">Username:</label>
            <input type="text" id="editUsername" name="username" readonly><br>

            <label for="editEmail">Email:</label>
            <input type="email" id="editEmail" name="email" required><br>

            <label for="editFirstName">First Name:</label>
            <input type="text" id="editFirstName" name="firstname" required><br>

            <label for="editLastName">Last Name:</label>
            <input type="text" id="editLastName" name="lastname" required><br>

            <label for="editRole">Role:</label>
            <?php if ($user['RoleID'] == 1): ?>
                <input type="hidden" id="editRole" name="role" value="1">
                <input type="text" value="Owner (Locked - Super Admin)" readonly>
            <?php else: ?>
                <select id="editRole" name="role" required>
                    <option value="1">Owner</option>
                    <option value="2">Developer</option>
                    <option value="3">Cashier</option>
                    <option value="4">Staff</option>
                </select>
            <?php endif; ?>


            <button type="submit">Save Changes</button>
        </form>
    </div>
</div>

<script>
function openEditModal(id, username, email, role, firstName, lastName) {
    document.getElementById("editUserId").value = id;
    document.getElementById("editUsername").value = username;
    document.getElementById("editEmail").value = email;
    document.getElementById("editFirstName").value = firstName;
    document.getElementById("editLastName").value = lastName;

    const roleDropdown = document.getElementById("editRole");

    if (role == 1) {
        roleDropdown.innerHTML = '<option value="1" selected>Owner (Locked - Super Admin)</option>';
        roleDropdown.disabled = true;
    } else {
        roleDropdown.innerHTML = `
            <option value="1">Owner</option>
            <option value="2">Developer</option>
            <option value="3">Cashier</option>
            <option value="4">Staff</option>
        `;
        roleDropdown.value = role;
        roleDropdown.disabled = false;
    }

    document.getElementById("editModal").style.display = "block";
}

function outsideModalClick(e) {
    const modal = document.getElementById("editModal");
    const content = document.querySelector(".modal-content");

    if (!content.contains(e.target)) {
        closeModal();
    }
}
function closeModal() {
    document.getElementById("editModal").style.display = "none";
}


document.getElementById("searchInput").addEventListener("keyup", filterAuditTrail);
document.getElementById("roleFilter").addEventListener("change", filterAuditTrail);

function filterAuditTrail() {
    const searchValue = document.getElementById("searchInput").value.toLowerCase();
    const selectedRole = document.getElementById("roleFilter").value;
    const rows = document.querySelectorAll(".table tbody tr");

    rows.forEach(row => {
        const rowText = row.innerText.toLowerCase();
        const roleCell = row.querySelector("td:nth-child(5)").innerText.trim(); // Role column

        const matchesSearch = rowText.includes(searchValue);
        const matchesRole = !selectedRole || roleCell === selectedRole;

        row.style.display = matchesSearch && matchesRole ? "" : "none";
    });
}
</script>

<?php include 'footer.php'; ?>
</main>
</div>
</body>
</html>
