<?php
session_start();
require('config/database.php');

// ✅ Permission check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2 && $_SESSION['role'] != 4)) {
    header('Location: index.php');
    exit;
}

// ✅ Validate input
if (!isset($_POST['inventory_id']) || !isset($_POST['quantity'])) {
    die("Invalid request.");
}

$inventoryId = intval($_POST['inventory_id']);
$quantity = intval($_POST['quantity']);
$expiryDate = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

try {
    // ✅ Update inventory
    $stmt = $conn->prepare("
        UPDATE Inventory 
        SET Quantity = Quantity + :quantity,
            ExpiryDate = COALESCE(:expiry_date, ExpiryDate)
        WHERE InventoryID = :inventory_id
    ");
    $stmt->execute([
        ':quantity' => $quantity,
        ':expiry_date' => $expiryDate,
        ':inventory_id' => $inventoryId
    ]);

    // ✅ Get product name for logging
    $productStmt = $conn->prepare("
        SELECT p.ProductName 
        FROM Inventory i 
        JOIN Product p ON i.ProductID = p.ProductID 
        WHERE i.InventoryID = ?
    ");
    $productStmt->execute([$inventoryId]);
    $product = $productStmt->fetch();


    header("Location: inventory.php?success=restocked");
    exit;

} catch (PDOException $e) {
    die("Error restocking item: " . $e->getMessage());
}
