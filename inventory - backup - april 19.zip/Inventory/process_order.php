<?php
session_start();
require('config/database.php');

// Read raw JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($_SESSION['user_id']) || empty($input['cart']) || empty($input['payment_method'])) {
    http_response_code(400);
    echo json_encode(["success" => false, "error" => "Invalid session or missing input."]);
    exit;
}

$userId = $_SESSION['user_id'];
$cart = $input['cart'];
$methodName = $input['payment_method'];
$orderDate = date('Y-m-d');
$orderDiscount = isset($input['discount']) ? floatval($input['discount']) : 0;

try {
    // Get PaymentMethodID
    $stmt = $conn->prepare("SELECT PaymentMethodID FROM PaymentMethods WHERE MethodName = ?");
    $stmt->execute([$methodName]);
    $method = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$method) {
        http_response_code(400);
        echo json_encode(["success" => false, "error" => "Invalid payment method."]);
        exit;
    }

    $paymentMethodID = $method['PaymentMethodID'];

    $conn->beginTransaction();

    // Insert into Orders
    $stmt = $conn->prepare("INSERT INTO Orders (UserID, OrderDate, PaymentMethodID) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $orderDate, $paymentMethodID]);
    $orderId = $conn->lastInsertId();

    $subtotal = 0;

    // Insert into OrderDetails (no discount)
    foreach ($cart as $item) {
        $stmt = $conn->prepare("SELECT ProductID FROM Product WHERE ProductName = ? AND SellingPrice = ?");
        $stmt->execute([$item['name'], $item['price']]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            throw new Exception("Product not found: " . $item['name']);
        }

        $itemSubtotal = $item['price'] * $item['quantity'];
        $subtotal += $itemSubtotal;

        $stmt = $conn->prepare("
            INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Price)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $orderId,
            $product['ProductID'],
            $item['quantity'],
            $item['price']
        ]);

        // Deduct inventory using FIFO
        $productId = $product['ProductID'];
        $quantityNeeded = $item['quantity'];

        $stmt = $conn->prepare("
            SELECT InventoryID, Quantity 
            FROM Inventory 
            WHERE ProductID = ? AND Quantity > 0 
            ORDER BY ExpiryDate ASC
        ");
        $stmt->execute([$productId]);
        $inventoryBatches = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($inventoryBatches as $batch) {
            if ($quantityNeeded <= 0) break;

            $deductQty = min($quantityNeeded, $batch['Quantity']);
            $stmt = $conn->prepare("UPDATE Inventory SET Quantity = Quantity - ? WHERE InventoryID = ?");
            $stmt->execute([$deductQty, $batch['InventoryID']]);

            $quantityNeeded -= $deductQty;
        }

        if ($quantityNeeded > 0) {
            throw new Exception("Insufficient stock for product: " . $item['name']);
        }
    }

    // Apply order-level discount and insert into Receipts
    $finalTotal = max(0, $subtotal - $orderDiscount);

    $stmt = $conn->prepare("
        INSERT INTO Receipts (OrderID, TotalAmount, Discount, PaymentMethodID, DateIssued)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $orderId,
        $finalTotal,
        $orderDiscount,
        $paymentMethodID,
        $orderDate
    ]);

    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "✅ Order placed successfully.",
        "order_id" => $orderId,
        "subtotal" => $subtotal,
        "order_discount" => $orderDiscount,
        "total" => $finalTotal
    ]);

} catch (Exception $e) {
    $conn->rollBack();
    http_response_code(500);
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
}
?>
