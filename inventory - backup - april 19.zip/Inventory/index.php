
<!DOCTYPE html>
<html>
<head>
    <title>Login & Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        function showForm(formId) {
            const loginForm = document.getElementById("loginForm");
            const registerForm = document.getElementById("registerForm");
            const loginMsg = document.getElementById("loginMessage");
            const registerMsg = document.getElementById("registerMessage");

            loginForm.style.display = "none";
                registerForm.style.display = "none";
                verifyForm.style.display = "none";

            if (formId === "loginForm") {
                loginForm.style.display = "block";
                loginMsg.style.display = "block";
                registerMsg.style.display = "none";
            } else if (formId === "registerForm") {
                registerForm.style.display = "block";
                loginMsg.style.display = "none";
                registerMsg.style.display = "block";
            } else if (formId === "verifyForm") {
                verifyForm.style.display = "block"; // ✅ Correct behavior
                loginMsg.style.display = "none";
                registerMsg.style.display = "none";
            }
        }

        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = document.getElementById(iconId);
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.add('show');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('show');
            }
        }
 
        // AJAX function to submit form
        function submitForm(username, email, firstname, lastname, password) {
            $.ajax({
                url: 'register.php', // PHP script to process the form
                type: 'POST',
                data: {
                    username: username,
                    email: email,
                    firstname: firstname,
                    lastname: lastname,
                    password: password
                },
                success: function(response) {
                    // If registration is successful, display success message
                    alert(response);
                    window.location.href = "index.php"; // Redirect to index (or another page)
                },
                error: function(xhr, status, error) {
                    // If there's an error, display error message
                    alert('Error: ' + error);
                }
            });
        }

        function proceedToVerification() {
            const username = $('#username').val();
            const firstname = $('#firstname').val();
            const lastname = $('#lastname').val();
            const password = $('#regpassword').val();

            // ✅ Validate username length
            const usernameRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;

                if (!usernameRegex.test(username)) {
                    alert("Username must be at least 8 characters long and contain at least one letter and one number.");
                    return false;
                }

            // ✅ Validate first and last name
            const nameRegex = /^[a-zA-Z]+$/;
            if (!nameRegex.test(firstname) || !nameRegex.test(lastname)) {
                alert("First Name and Last Name should only contain letters.");
                return false;
            }
            
                // ✅ Validate password security
                const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
                if (!passwordRegex.test(password)) {
                    alert("Password must be at least 8 characters long and include:\n- 1 uppercase letter\n- 1 lowercase letter\n- 1 number");
                    return false;
                }
            // ✅ Check if username exists
            $.post('check_username.php', { username }, function (res) {
                if (res.trim() === 'OK') {
                    // If username is valid, store to session and move on
                    sessionStorage.setItem('username', username);
                    sessionStorage.setItem('firstname', firstname);
                    sessionStorage.setItem('lastname', lastname);
                    sessionStorage.setItem('password', password);

                    showForm('verifyForm'); // ✅ Show verification form only if username is valid
                } else {
                    alert(res); // Show message like "Username already taken"
                }
            });

            return false; // Prevent default form submission
}

function sendVerificationCode() {
    const email = $('#email').val();
    if (!email) return alert("Please enter your email.");

    // Check if email already exists
    $.post('check_email.php', { email }, function (res) {
        if (res.trim() === "OK") {
            // Proceed to send code
            $.post('send_verification_code.php', { email }, function (response) {
                alert(response);
                sessionStorage.setItem('email', email);
            });
        } else {
            alert(res); // Show "❌ Email already in use"
        }
    });
}

function verifyAndRegister() {
    const code = $('#code').val();
    const email = sessionStorage.getItem('email');

    const data = {
        code,
        email,
        username: sessionStorage.getItem('username'),
        firstname: sessionStorage.getItem('firstname'),
        lastname: sessionStorage.getItem('lastname'),
        password: sessionStorage.getItem('password')
    };

    $.post('verify_and_register.php', data, function (res) {
        alert(res);
        if (res.includes("success")) {
            sessionStorage.clear();
            window.location.href = 'index.php';
        }
    });
}
$(document).ready(function() {
    // Password strength indicator
    $('#regpassword').on('input', function() {
        const password = $(this).val();
        updatePasswordStrength(password);
    });
});

function updatePasswordStrength(password) {
    // Check each requirement
    const hasMinLength = password.length >= 8;
    const hasLowercase = /[a-z]/.test(password);
    const hasUppercase = /[A-Z]/.test(password);
    const hasNumber = /\d/.test(password);
    
    // Update UI for each requirement
    updateRequirement('#length', hasMinLength);
    updateRequirement('#lowercase', hasLowercase);
    updateRequirement('#uppercase', hasUppercase);
    updateRequirement('#number', hasNumber);
}

function updateRequirement(selector, isValid) {
    const $element = $(selector);
    $element.toggleClass('valid', isValid);
    $element.toggleClass('invalid', !isValid);
    
    // Update the bullet point
    $element.find('span').remove();
    const icon = isValid ? '✓' : '✗';
    $element.prepend(`<span>${icon}</span>`);
}

    </script>
</head>
<body>
    

    <div class = "logindiv">
    <div class="login">
        <form id="loginForm" method="POST" action="login.php">
            <img src="logo.jpg" class="logo" alt="Adriana's Marketing Logo" class="logo">
            <h3>Login</h3>
            <input type="text" name="username" placeholder="Username" required><br>
             <div class="password-wrapper">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                    <span id="loginToggle" class="password-toggle" onclick="togglePassword('password', 'loginToggle')"></span>
                </div>
            <p style="text-align: right;" class = "forgor">
                <a href="forgotpassword.php">Forgot Password?</a>
            </p>

            <p id="loginMessage">
                Don't have an account? <a href="#" onclick="showForm('registerForm')">Register here</a>
            </p>

            <button type="submit">Login</button>
        </form>
    </div>

    <!-- Register Form -->
    <div class="register">
    <form id="registerForm" style="display: none;" onsubmit="proceedToVerification(); return false;">
        <h3>Register</h3>
        <input type="text" id="username" placeholder="Username" required><br>
        <input type="text" id="firstname" placeholder="First Name" required><br>
        <input type="text" id="lastname" placeholder="Last Name" required><br>
        
        <div class="password-wrapper">
            <input type="password" id="regpassword" placeholder="Password" required>
            <span id="registerToggle" class="password-toggle" onclick="togglePassword('regpassword', 'registerToggle')"></span>
        </div>
                <div id="passwordStrength" class="strength-message">Password must include:
                <ul>
                    <li id="length" class="invalid">At least 8 characters</li>
                    <li id="lowercase" class="invalid">A lowercase letter</li>
                    <li id="uppercase" class="invalid">An uppercase letter</li>
                    <li id="number" class="invalid">A number</li>
                </ul>
        </div>
        <p id="registerMessage">
            Already have an account? <a href="#" onclick="showForm('loginForm')">Go back to login</a>
        </p>

        <button type="submit">Proceed</button>
    </form>
</div>

    <!-- 📧 Email Verification Form -->
    <div class="verify">
        <form id="verifyForm" method="POST" style="display:none;" onsubmit="verifyAndRegister(); return false;">
            <h3>Email Verification</h3>
            <input type="email" id="email" placeholder="Enter Email" required><br>
            <button type="button" onclick="sendVerificationCode()">Send Code</button><br><br>
            <input type="text" id="code" placeholder="Enter verification code" required><br>
            <p id="registerMessage">
           <a href="#" onclick="showForm('registerForm')">Go back </a>
            </p>
            <button type="submit">Verify & Register</button>
        </form>
    </div>


</div>

</body>
</html>


