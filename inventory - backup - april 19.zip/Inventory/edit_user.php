<?php
session_start();
require('config/database.php');

if ($_SESSION['role'] != 1 && $_SESSION['role'] != 2) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = $_POST['user_id'];
    $username = htmlspecialchars(trim($_POST['username']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $role = $_POST['role'];

    // Update the user
    $stmt = $conn->prepare("UPDATE Users SET Username = ?, Email = ?, RoleID = ?, updatedAt = NOW() WHERE UserID = ?");
    $stmt->execute([$username, $email, $role, $userId]);

    // Log to audit trail
    $change_time = date('Y-m-d H:i:s');
    $changed_by = $_SESSION['user_name']; // assuming this is set at login

    $log_query = "INSERT INTO audit_trail (affected_username, changed_by, action, timestamp) 
                  VALUES (:affected_username, :changed_by, 'Account Updated', :timestamp)";
    $log_stmt = $conn->prepare($log_query);
    $log_stmt->bindParam(':affected_username', $username);
    $log_stmt->bindParam(':changed_by', $changed_by);
    $log_stmt->bindParam(':timestamp', $change_time);
    $log_stmt->execute();

    echo '<script>alert("User Edited!"); window.location.href="accountmanagement.php";</script>';
}
?>

