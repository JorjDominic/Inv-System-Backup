<?php
session_start();
require('config/database.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['error' => 'No expense ID provided']);
    exit;
}

$expense_id = $_GET['id'];

try {
    // Prepare and execute query
    $stmt = $conn->prepare("
        SELECT 
            ExpenseID as expense_id, 
            Description as description, 
            Category as category, 
            Amount as amount, 
            Date as date
        FROM Expenses 
        WHERE ExpenseID = ?
    ");
    
    $stmt->execute([$expense_id]);
    $expense = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$expense) {
        echo json_encode(['error' => 'Expense not found']);
        exit;
    }
    
    // Return expense data as JSON
    echo json_encode($expense);
    
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
