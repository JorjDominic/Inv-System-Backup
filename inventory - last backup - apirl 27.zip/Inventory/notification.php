<?php
// Notifications management functions

/**
 * Create a new notification
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID to send notification to
 * @param string $type Notification type
 * @param string $message Notification message
 * @return bool Success status
 */
function createNotification($conn, $userID, $type, $message) {
    try {
        $stmt = $conn->prepare("INSERT INTO Notifications (UserID, NotificationType, Message) 
                               VALUES (:userID, :type, :message)");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->bindParam(':type', $type, PDO::PARAM_STR);
        $stmt->bindParam(':message', $message, PDO::PARAM_STR);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error creating notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Get unread notifications for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @param int $limit Maximum number of notifications to return
 * @return array Notifications
 */
function getUnreadNotifications($conn, $userID, $limit = 5) {
    try {
        $stmt = $conn->prepare("SELECT * FROM Notifications 
                               WHERE UserID = :userID AND IsRead = 0 
                               ORDER BY CreatedAt DESC LIMIT :limit");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting unread notifications: " . $e->getMessage());
        return [];
    }
}

/**
 * Get all notifications for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @param int $limit Maximum number of notifications to return
 * @param int $offset Offset for pagination
 * @return array Notifications
 */
function getAllNotifications($conn, $userID, $limit = 20, $offset = 0) {
    try {
        $stmt = $conn->prepare("SELECT * FROM Notifications 
                               WHERE UserID = :userID 
                               ORDER BY CreatedAt DESC LIMIT :limit OFFSET :offset");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting all notifications: " . $e->getMessage());
        return [];
    }
}

/**
 * Mark a notification as read
 * 
 * @param PDO $conn Database connection
 * @param int $notificationID Notification ID
 * @param int $userID User ID (for security)
 * @return bool Success status
 */
function markNotificationAsRead($conn, $notificationID, $userID) {
    try {
        $stmt = $conn->prepare("UPDATE Notifications 
                               SET IsRead = 1 
                               WHERE NotificationID = :notificationID AND UserID = :userID");
        $stmt->bindParam(':notificationID', $notificationID, PDO::PARAM_INT);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error marking notification as read: " . $e->getMessage());
        return false;
    }
}

/**
 * Mark all notifications as read for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @return bool Success status
 */
function markAllNotificationsAsRead($conn, $userID) {
    try {
        $stmt = $conn->prepare("UPDATE Notifications 
                               SET IsRead = 1 
                               WHERE UserID = :userID AND IsRead = 0");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error marking all notifications as read: " . $e->getMessage());
        return false;
    }
}

/**
 * Count unread notifications for a user
 * 
 * @param PDO $conn Database connection
 * @param int $userID User ID
 * @return int Number of unread notifications
 */
function countUnreadNotifications($conn, $userID) {
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM Notifications 
                               WHERE UserID = :userID AND IsRead = 0");
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        error_log("Error counting unread notifications: " . $e->getMessage());
        return 0;
    }
}

/**
 * Get notification icon based on type
 * 
 * @param string $type Notification type
 * @return string SVG icon HTML
 */
function getNotificationIcon($type) {
    switch ($type) {
        case 'inventory_update':
            $color = "#9fce88"; // Green
            $path = "<path d=\"M440-183v-274L296-312l-56-56 240-240 240 240-56 56-144-145v274h-80ZM240-720v-80h480v80H240Z\"/>";
            break;
        case 'order_status':
            $color = "#63b3ed"; // Blue
            $path = "<path d=\"M280-280h280v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80ZM160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v480q0 33-23.5 56.5T800-160H160Z\"/>";
            break;
        case 'low_stock':
            $color = "#f56565"; // Red
            $path = "<path d=\"M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z\"/>";
            break;
        case 'report_ready':
            $color = "#d69e2e"; // Yellow
            $path = "<path d=\"M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm80-80h400v-80H280v80Zm0-160h400v-80H280v80Zm0-160h400v-80H280v80Zm-80 400v-560 560Z\"/>";
            break;
        default:
            $color = "#718096"; // Gray
            $path = "<path d=\"M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z\"/>";
    }
    
    return "<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"20px\" viewBox=\"0 -960 960 960\" width=\"20px\" fill=\"$color\">$path</svg>";
}

/**
 * Format notification time to human-readable format
 * 
 * @param string $timestamp MySQL timestamp
 * @return string Human-readable time
 */
function formatNotificationTime($timestamp) {
    $notificationTime = strtotime($timestamp);
    $currentTime = time();
    $timeDiff = $currentTime - $notificationTime;
    
    if ($timeDiff < 60) {
        return "Just now";
    } elseif ($timeDiff < 3600) {
        $minutes = floor($timeDiff / 60);
        return $minutes . " minute" . ($minutes > 1 ? "s" : "") . " ago";
    } elseif ($timeDiff < 86400) {
        $hours = floor($timeDiff / 3600);
        return $hours . " hour" . ($hours > 1 ? "s" : "") . " ago";
    } elseif ($timeDiff < 604800) {
        $days = floor($timeDiff / 86400);
        return $days . " day" . ($days > 1 ? "s" : "") . " ago";
    } else {
        return date("M j, Y", $notificationTime);
    }
}
