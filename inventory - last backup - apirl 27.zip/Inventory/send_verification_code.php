<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
session_start();

// Sanitize email input
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "❌ Invalid email address.";
    exit;
}

// Generate a 6-digit verification code
$code = rand(100000, 999999);

// Store code and email in session for later verification
$_SESSION['verification_code'] = $code;
$_SESSION['verification_email'] = $email;

// Setup PHPMailer
$mail = new PHPMailer(true);

try {
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';            // Your SMTP server
    $mail->SMTPAuth   = true;
    $mail->Username   = 'b6664253@gmail.com';       // 🔁 Replace with your Gmail
    $mail->Password   = 'wbbkxuoxrvguckjj';         // 🔁 Replace with app password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Sender and Recipient
    $mail->setFrom('b6664253@gmail.com', 'Adriana\'s Marketing');
    $mail->addAddress($email); // Send to user

    // Email Content
    $mail->isHTML(true);
    $mail->Subject = 'Your Email Verification Code';
    $mail->Body    = "
        <p>Hi there,</p>
        <p>Your verification code is:</p>
        <h2 style='color: #4a934a;'>$code</h2>
        <p>Please enter this code on the website to complete your registration.</p>
        <p>Thanks,<br>Adriana's Marketing Team</p>
    ";

    $mail->send();
    echo "✅ Verification code sent to <strong>$email</strong>";
} catch (Exception $e) {
    echo "❌ Email sending failed: {$mail->ErrorInfo}";
}
?>
