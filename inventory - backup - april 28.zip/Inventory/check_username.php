<?php
require 'config/database.php';

$username = trim($_POST['username'] ?? '');

if (!$username) {
    echo '❌ No username received.';
    exit;
}

$stmt = $conn->prepare("SELECT UserID FROM Users WHERE Username = ?");
$stmt->execute([$username]);

if ($stmt->rowCount() > 0) {
    echo '❌ Username already taken.';
} else {
    echo 'OK';
}
?>
