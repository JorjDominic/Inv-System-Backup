<script>
document.querySelectorAll('.transaction-row').forEach(row => {
  row.addEventListener('click', function () {
    const orderId = this.dataset.orderId;
    const detailsRow = this.nextElementSibling;
    const detailsContainer = detailsRow.querySelector('.item-details-content');

    // Toggle visibility
    if (detailsRow.style.display === 'none') {
      detailsRow.style.display = 'table-row';

      // Fetch items only if not already loaded
      if (!detailsContainer.dataset.loaded) {
        fetch(`get_order_items.php?order_id=${orderId}`)
          .then(res => res.text())
          .then(html => {
            detailsContainer.innerHTML = html;
            detailsContainer.dataset.loaded = true;
          })
          .catch(err => {
            detailsContainer.innerHTML = "❌ Failed to load items.";
          });
      }
    } else {
      detailsRow.style.display = 'none';
    }
  });
});
</script>