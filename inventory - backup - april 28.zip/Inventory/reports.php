<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
  header('Location: index.php');
  exit;
}
session_regenerate_id(true);

// Define report types
$reportTypes = [
    'sales' => 'Sales Report',
    'inventory' => 'Inventory Report',
    'expenses' => 'Expenses Report',
    'low_stock' => 'Low Stock Report',

];

// Get current date
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

// Default date range (current month)
$startDate = $firstDayOfMonth;
$endDate = $currentDate;

// Process form submission for report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportType = $_POST['report_type'] ?? 'sales';
    $startDate = $_POST['start_date'] ?? $firstDayOfMonth;
    $endDate = $_POST['end_date'] ?? $currentDate;
    
    // If export to PDF is requested
    if (isset($_POST['action']) && $_POST['action'] === 'export_pdf') {
        // Redirect to PDF generator with parameters
        header("Location: generate_pdf.php?report_type=$reportType&start_date=$startDate&end_date=$endDate");
        exit;
    }
}

// Function to get report data based on type and date range
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            // Sales report query
            $query = "SELECT r.ReceiptID, r.TotalAmount, r.DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Receipts r
                      JOIN Orders o ON r.OrderID = o.OrderID
                      JOIN OrderDetails od ON o.OrderID = od.OrderID
                      JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                      JOIN Users u ON r.UserID = u.UserID
                      WHERE r.DateIssued BETWEEN ? AND ?
                      GROUP BY r.ReceiptID
                      ORDER BY r.DateIssued DESC";
            break;
            
        case 'inventory':
            // Inventory report query
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        case 'expenses':
            // Expenses report query
            $query = "SELECT e.ExpenseID, e.Description, e.Category, e.Amount, e.Date, 
                      CONCAT(u.FirstName, ' ', u.LastName) as RecordedBy
                      FROM Expenses e
                      JOIN Users u ON e.UserID = u.UserID
                      WHERE e.Date BETWEEN ? AND ?
                      ORDER BY e.Date DESC";
            break;
            
        case 'profit':
            // Profit & Loss report query
            $query = "SELECT 
                      (SELECT SUM(TotalAmount) FROM Receipts WHERE DateIssued BETWEEN ? AND ?) as GrossRevenue,
                      (SELECT SUM(Amount) FROM Expenses WHERE Date BETWEEN ? AND ?) as TotalExpenses,
                      (SELECT SUM(od.Price * ri.QuantityRefunded) 
                       FROM RefundedItems ri
                       JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                       WHERE ri.RefundedAt BETWEEN ? AND ?) as TotalRefunds,
                      (SELECT SUM(d.Quantity * p.PurchasePrice)
                       FROM DamagedItems d
                       JOIN Product p ON d.ProductID = p.ProductID
                       WHERE d.ReportedAt BETWEEN ? AND ?) as DamagedCost,
                      (SELECT SUM(LossValue)
                       FROM ExpiredItems
                       WHERE DateExpired BETWEEN ? AND ?) as ExpiredCost";
            break;
            
        case 'expired':
            // Expired items report query
            $query = "SELECT e.ExpiredID, p.ProductName, e.Quantity, e.ExpiryDate, 
                      e.DateExpired, CONCAT(u.FirstName, ' ', u.LastName) as ReportedBy, 
                      e.LossValue, c.CategoryName
                      FROM ExpiredItems e
                      JOIN Product p ON e.ProductID = p.ProductID
                      JOIN Users u ON e.ReportedBy = u.UserID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      WHERE e.DateExpired BETWEEN ? AND ?
                      ORDER BY e.DateExpired DESC";
            break;
            
        case 'damaged':
            // Damaged items report query
            $query = "SELECT d.DamageID, p.ProductName, d.Quantity, d.Reason, 
                      d.ReportedAt, CONCAT(u.FirstName, ' ', u.LastName) as ReportedBy, 
                      (d.Quantity * p.PurchasePrice) as LossAmount, c.CategoryName
                      FROM DamagedItems d
                      JOIN Product p ON d.ProductID = p.ProductID
                      JOIN Users u ON d.ReportedBy = u.UserID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      WHERE d.ReportedAt BETWEEN ? AND ?
                      ORDER BY d.ReportedAt DESC";
            break;
            
        case 'low_stock':
            // Low stock report query
            $lowStockThreshold = 10; // Define what "low stock" means
            $query = "SELECT p.ProductID, p.ProductName, SUM(i.Quantity) as TotalQuantity, 
                      c.CategoryName, p.PurchasePrice, p.SellingPrice
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      HAVING TotalQuantity <= ?
                      ORDER BY TotalQuantity ASC";
            break;
            
        case 'refunds':
            // Refunds report query
            $query = "SELECT ri.RefundID, p.ProductName, ri.QuantityRefunded, 
                      ri.ItemCondition, ri.RefundedAt, 
                      CONCAT(u.FirstName, ' ', u.LastName) as ProcessedBy,
                      (od.Price * ri.QuantityRefunded) as RefundAmount
                      FROM RefundedItems ri
                      JOIN Product p ON ri.ProductID = p.ProductID
                      JOIN Users u ON ri.ProcessedBy = u.UserID
                      JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                      WHERE ri.RefundedAt BETWEEN ? AND ?
                      ORDER BY ri.RefundedAt DESC";
            break;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        // Bind parameters based on report type
        switch ($reportType) {
            case 'inventory':
                $stmt->execute();
                break;
                
            case 'low_stock':
                $stmt->execute([10]); // Low stock threshold
                break;
                
            case 'profit':
                $stmt->execute([$startDate, $endDate, $startDate, $endDate, $startDate, $endDate, $startDate, $endDate, $startDate, $endDate]);
                break;
                
            default:
                $stmt->execute([$startDate, $endDate]);
                break;
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary data for certain report types
        if ($reportType === 'sales') {
            $totalSales = array_sum(array_column($data, 'TotalAmount'));
            $data['summary'] = [
                'totalSales' => $totalSales,
                'transactionCount' => count($data)
            ];
        } elseif ($reportType === 'expenses') {
            $totalExpenses = array_sum(array_column($data, 'Amount'));
            $data['summary'] = [
                'totalExpenses' => $totalExpenses
            ];
        } elseif ($reportType === 'inventory') {
            $totalValue = array_sum(array_column($data, 'TotalValue'));
            $totalItems = array_sum(array_column($data, 'TotalQuantity'));
            $data['summary'] = [
                'totalValue' => $totalValue,
                'totalItems' => $totalItems
            ];
        }
        
    } catch (PDOException $e) {
        // Handle error
        echo "Error: " . $e->getMessage();
    }
    
    return $data;
}

// Get report data if a report type is selected
$reportData = [];
$selectedReportType = $_POST['report_type'] ?? 'sales';

// Check if form was submitted (either for generating report or exporting PDF)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportData = getReportData($conn, $selectedReportType, $startDate, $endDate);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reports - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .reports-container {
            padding: 20px;
        }
        
        .report-form {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-sm);
            font-family: 'Poppins', sans-serif;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        
        .report-results {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            overflow-x: auto;
        }
        
        .report-title {
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--text-dark);
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .report-table th, .report-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .report-table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .report-table tr:last-child td {
            border-bottom: none;
        }
        
        .report-summary {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .summary-label {
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .summary-value {
            font-weight: 600;
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: var(--text-medium);
            font-style: italic;
        }
        
        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
            }
            
            .btn-group {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="reports-container">
                <h1 class="report-title">Generate Reports</h1>
                
                <div class="report-form">
                    <!-- IMPORTANT: Changed form to submit to reports.php instead of generate_pdf.php -->
                    <form method="POST" action="">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="report_type">Report Type</label>
                                <select name="report_type" id="report_type" class="form-control">
                                    <?php foreach ($reportTypes as $value => $label): ?>
                                        <option value="<?= $value ?>" <?= ($selectedReportType === $value) ? 'selected' : '' ?>>
                                            <?= $label ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" 
                                       value="<?= $startDate ?>" max="<?= $currentDate ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" 
                                       value="<?= $endDate ?>" max="<?= $currentDate ?>">
                            </div>
                        </div>
                        <div class="btn-group">
                            <button type="submit" name="action" value="generate_report" class="btn btn-primary">Generate Report</button>
                            <button type="submit" name="action" value="export_pdf" class="btn btn-success">Export to PDF</button>
                        </div>
                    </form>
                </div>
                
                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($reportData)): ?>
                    <div class="report-results">
                        <h2 class="report-title"><?= $reportTypes[$selectedReportType] ?></h2>
                        <p>Period: <?= date('F d, Y', strtotime($startDate)) ?> to <?= date('F d, Y', strtotime($endDate)) ?></p>
                        
                        <?php if ($selectedReportType === 'sales'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Receipt ID</th>
                                            <th>Date</th>
                                            <th>Items</th>
                                            <th>Payment Method</th>
                                            <th>Cashier</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalAmount = 0;
                                        foreach ($reportData as $key => $sale): 
                                            if ($key !== 'summary'):
                                                $totalAmount += $sale['TotalAmount'];
                                        ?>
                                            <tr>
                                                <td><?= $sale['ReceiptID'] ?></td>
                                                <td><?= date('M d, Y', strtotime($sale['DateIssued'])) ?></td>
                                                <td><?= $sale['ItemCount'] ?></td>
                                                <td><?= $sale['PaymentMethod'] ?></td>
                                                <td><?= $sale['Cashier'] ?></td>
                                                <td>₱<?= number_format($sale['TotalAmount'], 2) ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Sales:</span>
                                    <span class="summary-value">₱<?= number_format($totalAmount, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Transaction Count:</span>
                                    <span class="summary-value"><?= count($reportData) - 1 ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'inventory'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Quantity</th>
                                            <th>Purchase Price</th>
                                            <th>Selling Price</th>
                                            <th>Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalValue = 0;
                                        $totalItems = 0;
                                        foreach ($reportData as $key => $item): 
                                            if ($key !== 'summary'):
                                                $totalValue += $item['TotalValue'];
                                                $totalItems += $item['TotalQuantity'];
                                        ?>
                                            <tr>
                                                <td><?= $item['ProductID'] ?></td>
                                                <td><?= $item['ProductName'] ?></td>
                                                <td><?= $item['CategoryName'] ?></td>
                                                <td><?= $item['TotalQuantity'] ?></td>
                                                <td>₱<?= number_format($item['PurchasePrice'], 2) ?></td>
                                                <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
                                                <td>₱<?= number_format($item['TotalValue'], 2) ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Inventory Value:</span>
                                    <span class="summary-value">₱<?= number_format($totalValue, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Items:</span>
                                    <span class="summary-value"><?= $totalItems ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'expenses'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Description</th>
                                            <th>Category</th>
                                            <th>Date</th>
                                            <th>Recorded By</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalExpenses = 0;
                                        foreach ($reportData as $key => $expense): 
                                            if ($key !== 'summary'):
                                                $totalExpenses += $expense['Amount'];
                                        ?>
                                            <tr>
                                                <td><?= $expense['ExpenseID'] ?></td>
                                                <td><?= $expense['Description'] ?></td>
                                                <td><?= $expense['Category'] ?></td>
                                                <td><?= date('M d, Y', strtotime($expense['Date'])) ?></td>
                                                <td><?= $expense['RecordedBy'] ?></td>
                                                <td>₱<?= number_format($expense['Amount'], 2) ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Expenses:</span>
                                    <span class="summary-value">₱<?= number_format($totalExpenses, 2) ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'profit'): ?>
                            <?php 
                                $profitData = $reportData[0] ?? [];
                                $grossRevenue = $profitData['GrossRevenue'] ?? 0;
                                $totalExpenses = $profitData['TotalExpenses'] ?? 0;
                                $totalRefunds = $profitData['TotalRefunds'] ?? 0;
                                $damagedCost = $profitData['DamagedCost'] ?? 0;
                                $expiredCost = $profitData['ExpiredCost'] ?? 0;
                                
                                $netRevenue = $grossRevenue - $totalRefunds;
                                $totalLosses = $damagedCost + $expiredCost;
                                $netProfit = $netRevenue - $totalExpenses - $totalLosses;
                            ?>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Gross Revenue:</span>
                                    <span class="summary-value">₱<?= number_format($grossRevenue, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Refunds:</span>
                                    <span class="summary-value">₱<?= number_format($totalRefunds, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Net Revenue:</span>
                                    <span class="summary-value">₱<?= number_format($netRevenue, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Regular Expenses:</span>
                                    <span class="summary-value">₱<?= number_format($totalExpenses, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Damaged Inventory Cost:</span>
                                    <span class="summary-value">₱<?= number_format($damagedCost, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Expired Inventory Cost:</span>
                                    <span class="summary-value">₱<?= number_format($expiredCost, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Losses:</span>
                                    <span class="summary-value">₱<?= number_format($totalLosses, 2) ?></span>
                                </div>
                                <div class="summary-item" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
                                    <span class="summary-label" style="font-size: 1.1rem;">Net Profit:</span>
                                    <span class="summary-value" style="font-size: 1.1rem; color: <?= $netProfit >= 0 ? '#28a745' : '#dc3545' ?>;">
                                        ₱<?= number_format($netProfit, 2) ?>
                                    </span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'expired'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Quantity</th>
                                            <th>Expiry Date</th>
                                            <th>Reported By</th>
                                            <th>Loss Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalLoss = 0;
                                        $totalItems = 0;
                                        foreach ($reportData as $item): 
                                            $totalLoss += $item['LossValue'];
                                            $totalItems += $item['Quantity'];
                                        ?>
                                            <tr>
                                                <td><?= $item['ExpiredID'] ?></td>
                                                <td><?= $item['ProductName'] ?></td>
                                                <td><?= $item['CategoryName'] ?></td>
                                                <td><?= $item['Quantity'] ?></td>
                                                <td><?= date('M d, Y', strtotime($item['ExpiryDate'])) ?></td>
                                                <td><?= $item['ReportedBy'] ?></td>
                                                <td>₱<?= number_format($item['LossValue'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Loss Value:</span>
                                    <span class="summary-value">₱<?= number_format($totalLoss, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Expired Items:</span>
                                    <span class="summary-value"><?= $totalItems ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'damaged'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Quantity</th>
                                            <th>Reason</th>
                                            <th>Reported By</th>
                                            <th>Loss Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalLoss = 0;
                                        $totalItems = 0;
                                        foreach ($reportData as $item): 
                                            $totalLoss += $item['LossAmount'];
                                            $totalItems += $item['Quantity'];
                                        ?>
                                            <tr>
                                                <td><?= $item['DamageID'] ?></td>
                                                <td><?= $item['ProductName'] ?></td>
                                                <td><?= $item['CategoryName'] ?></td>
                                                <td><?= $item['Quantity'] ?></td>
                                                <td><?= $item['Reason'] ?></td>
                                                <td><?= $item['ReportedBy'] ?></td>
                                                <td>₱<?= number_format($item['LossAmount'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Loss Amount:</span>
                                    <span class="summary-value">₱<?= number_format($totalLoss, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Damaged Items:</span>
                                    <span class="summary-value"><?= $totalItems ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'low_stock'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Current Stock</th>
                                            <th>Purchase Price</th>
                                            <th>Selling Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalItems = 0;
                                        foreach ($reportData as $item): 
                                            $totalItems += $item['TotalQuantity'];
                                        ?>
                                            <tr>
                                                <td><?= $item['ProductID'] ?></td>
                                                <td><?= $item['ProductName'] ?></td>
                                                <td><?= $item['CategoryName'] ?></td>
                                                <td><?= $item['TotalQuantity'] ?></td>
                                                <td>₱<?= number_format($item['PurchasePrice'], 2) ?></td>
                                                <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Low Stock Items:</span>
                                    <span class="summary-value"><?= count($reportData) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Quantity:</span>
                                    <span class="summary-value"><?= $totalItems ?></span>
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'refunds'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Refund ID</th>
                                            <th>Product Name</th>
                                            <th>Quantity</th>
                                            <th>Condition</th>
                                            <th>Refund Date</th>
                                            <th>Processed By</th>
                                            <th>Refund Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalRefund = 0;
                                        $totalItems = 0;
                                        foreach ($reportData as $item): 
                                            $totalRefund += $item['RefundAmount'];
                                            $totalItems += $item['QuantityRefunded'];
                                        ?>
                                            <tr>
                                                <td><?= $item['RefundID'] ?></td>
                                                <td><?= $item['ProductName'] ?></td>
                                                <td><?= $item['QuantityRefunded'] ?></td>
                                                <td><?= $item['ItemCondition'] ?></td>
                                                <td><?= date('M d, Y', strtotime($item['RefundedAt'])) ?></td>
                                                <td><?= $item['ProcessedBy'] ?></td>
                                                <td>₱<?= number_format($item['RefundAmount'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Refund Amount:</span>
                                    <span class="summary-value">₱<?= number_format($totalRefund, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Refunded Items:</span>
                                    <span class="summary-value"><?= $totalItems ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="report-results">
                        <div class="no-data">No data available for the selected criteria.</div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
