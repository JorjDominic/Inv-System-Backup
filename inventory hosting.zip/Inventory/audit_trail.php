<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

// Initialize filters
$search = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$action = $_GET['action'] ?? '';
$user = $_GET['user'] ?? '';

// Initialize conditions and parameters
$conditions = [];
$params = [];

if (!empty($search)) {
    $conditions[] = "(ProductNameSnapshot LIKE ? OR UsernameSnapshot LIKE ? OR Remarks LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($startDate)) {
    $conditions[] = "Timestamp >= ?";
    $params[] = $startDate . ' 00:00:00';  // Set start of the day
}

if (!empty($endDate)) {
    $conditions[] = "Timestamp <= ?";
    $params[] = $endDate . ' 23:59:59';  // Set end of the day
}

if (!empty($action)) {
    $conditions[] = "Action = ?";
    $params[] = $action;
}

if (!empty($user)) {
    $conditions[] = "UsernameSnapshot = ?";
    $params[] = $user;
}

// Build the WHERE clause
$whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

// Fetch total record count for pagination
$countQuery = "SELECT COUNT(*) as total FROM audit_trail a $whereClause";
$countStmt = $conn->prepare($countQuery);
$countStmt->execute($params);
$totalLogs = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];

// Pagination
$logsPerPage = 20;
$totalPages = ceil($totalLogs / $logsPerPage);
$page = isset($_GET['page']) ? max(1, min($totalPages, intval($_GET['page']))) : 1;
$offset = ($page - 1) * $logsPerPage;  // Offset for the current page

// Get logs with pagination
$query = "
    SELECT a.*, u.RoleID, r.RoleName
    FROM audit_trail a
    LEFT JOIN Users u ON LOWER(a.changed_by) = LOWER(u.Username)
    LEFT JOIN Roles r ON u.RoleID = r.RoleID
    $whereClause
    ORDER BY a.Timestamp DESC
    LIMIT $logsPerPage OFFSET $offset
";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$audit_trail = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="css/accmanagement.css">
    <title>Audit Trail</title>
</head>
<style>
.pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 20px;
}

.pagination a, .pagination span {
    padding: 8px 12px;
    border: 1px solid #ddd;
    color: #333;
    text-decoration: none;
    border-radius: 4px;
}

.pagination a:hover {
    background-color: #f5f5f5;
}

.pagination .active {
    background-color: #4a934a;
    color: white;
    border-color: #4a934a;
}

.pagination .disabled {
    color: #aaa;
    cursor: not-allowed;
}
sort-bar {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    align-items: center;
    margin-bottom: 20px;
    padding: 10px 0;
    background-color: #f5f5f5;
    border-radius: 8px;
}

.sort-bar select,
.sort-bar input[type="date"],
.sort-bar input[type="text"] {
    padding: 0.8rem 1rem;
    font-size: 1rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    width: 100%;
    max-width: 250px; /* Limits width of each input */
    background-color: #fff;
}

.sort-bar label {
    font-size: 1rem;
    color: #333;
    margin-right: 5px;
}

/* Filter Button */
.sort-bar button {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    font-size: 1rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.sort-bar button:hover {
    background-color: #45a049;
}

/* Clear Filters Button */
.clear-filters {
    background-color: #6c757d;
    color: white;
    font-size: 1rem;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.clear-filters:hover {
    background-color: #5a6268;
}

/* Responsive Design */
@media (max-width: 768px) {
    .sort-bar {
        flex-direction: column;
    }

    .sort-bar select,
    .sort-bar input[type="date"],
    .sort-bar input[type="text"] {
        max-width: 100%;
    }

    .sort-bar button {
        width: 100%;
        margin-top: 10px;
    }
}
</style>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-wrapper">
<main class="content">
    <div class="audit-container">
        <h2>Audit Trail</h2>

        <div class="search-sort-bar">
        <div class="search-bar">
                <input type="text" id="searchInput" name="search" placeholder="Search by username, action, or role..." value="<?= htmlspecialchars($search) ?>">
            
            </div>
            <div class="sort-bar">
                <select id="roleFilter" style="padding: 0.65rem 1rem;">
                    <option value="">All Roles</option>
                    <option value="Owner">Owner</option>
                    <option value="Developer">Developer</option>
                    <option value="Cashier">Cashier</option>
                    <option value="Staff">Staff</option>
                </select>
            </div>
        </div>

        <form method="GET">
            <!-- Search Input -->


            <!-- Date Range Filters -->
            <div class="sort-bar">
                <label for="start_date">From:</label>
                <input type="date" id="start_date" name="start_date" value="<?= htmlspecialchars($startDate) ?>">

                <label for="end_date">To:</label>
                <input type="date" id="end_date" name="end_date" value="<?= htmlspecialchars($endDate) ?>">
            </div>

            <!-- Filter Apply Button -->
            <div class="sort-bar">
                <button type="submit" class="btn">Filter</button>
            </div>
        </form>

        <table class="table">
            <thead>
                <tr>
                    <th>Account Affected</th>
                    <th>Changed By</th>
                    <th>Role</th>
                    <th>Action</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($audit_trail as $entry): ?>
                <tr>
                    <td><?= htmlspecialchars($entry['affected_username']) ?></td>
                    <td><?= htmlspecialchars($entry['changed_by']) ?></td>
                    <td>
                        <?php
                        if (isset($entry['RoleName']) && !empty($entry['RoleName'])) {
                            echo htmlspecialchars($entry['RoleName']);
                        } else {
                            $role = match ($entry['RoleID'] ?? null) {
                                1 => 'Owner',
                                2 => 'Developer',
                                3 => 'Cashier',
                                4 => 'Staff',
                                null => 'User not found',
                                default => 'Unknown (ID: ' . ($entry['RoleID'] ?? 'null') . ')'
                            };
                            echo $role;
                        }
                        ?>
                    </td>
                    <td><?= htmlspecialchars($entry['action']) ?></td>
                    <td class="timestamp"><?= htmlspecialchars($entry['timestamp']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=1">First</a>
            <a href="?page=<?= $page - 1 ?>">Previous</a>
        <?php else: ?>
            <span class="disabled">First</span>
            <span class="disabled">Previous</span>
        <?php endif; ?>

        <!-- Page Numbers -->
        <?php
        $startPage = max(1, $page - 2);
        $endPage = min($totalPages, $page + 2);
        for ($i = $startPage; $i <= $endPage; $i++): ?>
            <?php if ($i == $page): ?>
                <span class="active"><?= $i ?></span>
            <?php else: ?>
                <a href="?page=<?= $i ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1 ?>">Next</a>
            <a href="?page=<?= $totalPages ?>">Last</a>
        <?php else: ?>
            <span class="disabled">Next</span>
            <span class="disabled">Last</span>
        <?php endif; ?>
    </div>

    <div style="margin-top: 20px; text-align: center; color: #777;">
        Showing <?= count($audit_trail) ?> of <?= $totalLogs ?> logs
    </div>
</main>
</div>
<script>
document.getElementById("searchInput").addEventListener("keyup", filterAuditTrail);
document.getElementById("roleFilter").addEventListener("change", filterAuditTrail);

function filterAuditTrail() {
    const searchValue = document.getElementById("searchInput").value.toLowerCase();
    const selectedRole = document.getElementById("roleFilter").value;
    const rows = document.querySelectorAll(".table tbody tr");

    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        const role = row.children[2].innerText.trim(); // 3rd column is Role
        const matchesSearch = text.includes(searchValue);
        const matchesRole = !selectedRole || role === selectedRole;
        row.style.display = matchesSearch && matchesRole ? "" : "none";
    });
}
document.getElementById("searchInput").addEventListener("keyup", filterAuditTrail);
document.getElementById("roleFilter").addEventListener("change", filterAuditTrail);

function filterAuditTrail() {
    const searchValue = document.getElementById("searchInput").value.toLowerCase();
    const selectedRole = document.getElementById("roleFilter").value;
    const rows = document.querySelectorAll(".table tbody tr");

    rows.forEach(row => {
        const text = row.innerText.toLowerCase();
        const role = row.children[2].innerText.trim(); // 3rd column is Role
        const matchesSearch = text.includes(searchValue);
        const matchesRole = !selectedRole || role === selectedRole;
        row.style.display = matchesSearch && matchesRole ? "" : "none";
    });
}
</script>
</body>
</html>
