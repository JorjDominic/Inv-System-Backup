<?php
session_start();
require('config/database.php');
require('notification.php');

// Only allow admin/staff access
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3)) {
  header('Location: index.php');
  exit;
}

// Fetch FIFO-stacked inventory items
$query = "
SELECT 
  p.ProductName,
  p.CategoryID,
  c.CategoryName,
  p.SellingPrice,
  SUM(i.Quantity) AS TotalQuantity,
  MIN(i.ExpiryDate) AS NearestExpiry
FROM Inventory i
JOIN Product p ON i.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
WHERE i.ExpiryDate >= CURRENT_DATE OR i.ExpiryDate IS NULL  -- Include items with no expiry date
GROUP BY p.ProductName, p.CategoryID, p.SellingPrice
HAVING TotalQuantity > 0
ORDER BY NearestExpiry ASC
";


$stmt = $conn->query($query);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get top selling products (last 30 days)
$topSellingQuery = "
SELECT 
  p.ProductName,
  p.SellingPrice,
  SUM(od.Quantity) as TotalSold,
  c.CategoryName
FROM OrderDetails od
JOIN Product p ON od.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
JOIN Orders o ON od.OrderID = o.OrderID
WHERE o.OrderDate >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
GROUP BY p.ProductID
ORDER BY TotalSold DESC
LIMIT 5
";
$topSellingStmt = $conn->query($topSellingQuery);
$topSellingItems = $topSellingStmt->fetchAll(PDO::FETCH_ASSOC);

// Get low stock items
$lowStockQuery = "
SELECT 
  p.ProductName,
  p.SellingPrice,
  SUM(i.Quantity) as TotalQuantity,
  c.CategoryName
FROM Inventory i
JOIN Product p ON i.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
GROUP BY p.ProductID
HAVING TotalQuantity < 10 AND TotalQuantity > 0
ORDER BY TotalQuantity ASC
LIMIT 5
";
$lowStockStmt = $conn->query($lowStockQuery);
$lowStockItems = $lowStockStmt->fetchAll(PDO::FETCH_ASSOC);

// Check if we should send low stock notifications (limit to once per day per item)
if (count($lowStockItems) > 0) {
    // Get admin users
    $adminStmt = $conn->prepare("SELECT UserID FROM Users WHERE RoleID = 1");
    $adminStmt->execute();
    $adminUsers = $adminStmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($lowStockItems as $item) {
        // Check if notification was already sent today for this item
        $checkStmt = $conn->prepare("
            SELECT COUNT(*) FROM Notifications 
            WHERE NotificationType = 'low_stock' 
            AND Message LIKE ? 
            AND DATE(CreatedAt) = CURDATE()
        ");
        $checkStmt->execute(['%' . $item['ProductName'] . '%']);
        $notificationExists = $checkStmt->fetchColumn() > 0;
        
        if (!$notificationExists) {
            $lowStockMessage = "Low stock alert: {$item['ProductName']} has only {$item['TotalQuantity']} units remaining";
            
            // Notify all admins about low stock
            foreach ($adminUsers as $admin) {
                createNotification($conn, $admin['UserID'], 'low_stock', $lowStockMessage);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Inventory - FIFO View</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
  <style>
    .dashboard-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .dashboard-card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      padding: 20px;
      position: relative;
      overflow: hidden;
    }
    
    .dashboard-card h3 {
      margin-top: 0;
      color: #333;
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
    }
    
    .dashboard-card.top-selling {
      border-left: 4px solid #27ae60;
    }
    
    .dashboard-card.low-stock {
      border-left: 4px solid #f39c12;
    }
    
    .item-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .item-list li {
      padding: 10px 0;
      border-bottom: 1px solid #f0f0f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .item-list li:last-child {
      border-bottom: none;
    }
    
    .item-name {
      font-weight: 500;
      color: #333;
    }
    
    .item-detail {
      color: #777;
      font-size: 0.9rem;
    }
    
    .badge {
      display: inline-block;
      padding: 3px 8px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
    }
    
    .badge-success {
      background-color: #d4edda;
      color: #155724;
    }
    
    .badge-warning {
      background-color: #fff3cd;
      color: #856404;
    }
    
    .quick-add-btn {
      background-color: #4a934a;
      color: white;
      border: none;
      padding: 5px 10px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.8rem;
      transition: background-color 0.3s;
    }
    
    .quick-add-btn:hover {
      background-color: #3a7a3a;
    }
  </style>
</head>
<script src="js/inv.js" defer></script>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <h1>Order Inventory</h1>
      
      <!-- Dashboard Cards -->
      <div class="dashboard-cards">
        <!-- Top Selling Items Card -->
        <div class="dashboard-card top-selling">
          <h3>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
              <polyline points="17 6 23 6 23 12"></polyline>
            </svg>
            &nbsp;Top Selling Items (30 Days)
          </h3>
          <?php if (count($topSellingItems) > 0): ?>
            <ul class="item-list">
              <?php foreach ($topSellingItems as $item): ?>
                <li>
                  <div>
                    <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                    <div class="item-detail"><?= htmlspecialchars($item['CategoryName']) ?> • ₱<?= number_format($item['SellingPrice'], 2) ?></div>
                  </div>
                  <div>
                    <span class="badge badge-success"><?= $item['TotalSold'] ?> sold</span>
                    <button class="quick-add-btn" 
                      data-name="<?= htmlspecialchars($item['ProductName']) ?>"
                      data-price="<?= $item['SellingPrice'] ?>"
                      onclick="quickAddToCart(this)">
                      + Add
                    </button>
                  </div>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php else: ?>
            <p>No sales data available for the last 30 days.</p>
          <?php endif; ?>
        </div>
        
        <!-- Low Stock Items Card -->
        <div class="dashboard-card low-stock">
          <h3>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f39c12" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34"></path>
              <path d="M3 7l9 6 9-6"></path>
              <line x1="13" y1="17" x2="19" y2="11"></line>
              <polyline points="19 17 19 11 13 11"></polyline>
            </svg>
            &nbsp;Low Stock Items
          </h3>
          <?php if (count($lowStockItems) > 0): ?>
            <ul class="item-list">
              <?php foreach ($lowStockItems as $item): ?>
                <li>
                  <div>
                    <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                    <div class="item-detail"><?= htmlspecialchars($item['CategoryName']) ?> • ₱<?= number_format($item['SellingPrice'], 2) ?></div>
                  </div>
                  <div>
                    <span class="badge badge-warning"><?= $item['TotalQuantity'] ?> left</span>
                    <button class="quick-add-btn" 
                      data-name="<?= htmlspecialchars($item['ProductName']) ?>"
                      data-price="<?= $item['SellingPrice'] ?>"
                      onclick="quickAddToCart(this)">
                      + Add
                    </button>
                  </div>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php else: ?>
            <p>No low stock items at the moment.</p>
          <?php endif; ?>
        </div>
      </div>

      <div class="search-sort-container">
        <div class="search-bar">
          <input type="text" id="searchInput" placeholder="Search products...">
        </div>
        <div class="sort-options">
          <select id="sortSelect">
            <option value="">Sort By</option>
            <option value="name_asc">Name (A-Z)</option>
            <option value="name_desc">Name (Z-A)</option>
            <option value="price_asc">Price (Low-High)</option>
            <option value="price_desc">Price (High-Low)</option>
            <option value="quantity_asc">Quantity (Low-High)</option>
            <option value="quantity_desc">Quantity (High-Low)</option>
          </select>
        </div>
      </div>
      
      <table class="table">
        <thead>
          <tr>
            <th>Category</th>
            <th>Product Name</th>
            <th>Selling Price</th>
            <th>Total Quantity</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="productTableBody">
          <?php foreach ($items as $item): ?>
            <tr class="<?= $item['TotalQuantity'] < 10 ? 'low-stock' : '' ?>">
              <td><?= htmlspecialchars($item['CategoryName']) ?></td>
              <td><?= htmlspecialchars($item['ProductName']) ?></td>
              <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
              <td><?= $item['TotalQuantity'] ?></td>
              <td> <button class="btn-order" 
                data-name="<?= htmlspecialchars($item['ProductName']) ?>"
                data-price="<?= $item['SellingPrice'] ?>">
                Add to Cart
                </button>
            </td>
              
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="modal" id="cartModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('cartModal')">&times;</span>
    <h2>Add to Cart</h2>
    <form id="cartForm" class="form-container">
      <input type="hidden" id="productId" name="product_id">
      <input type="hidden" id="productName" name="product_name">
      <input type="hidden" id="productPrice" name="product_price">
      
      <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" min="1" value="1" required>
      </div>
      
      <div class="form-group">
        <label>Product: <span id="modalProductName"></span></label>
      </div>
      
      <div class="form-group">
        <label>Price: ₱<span id="modalProductPrice"></span></label>
      </div>
      
      <div class="form-group">
        <label>Total: ₱<span id="modalTotalPrice">0.00</span></label>
      </div>
      
      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('cartModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Add to Cart</button>
      </div>
    </form>
  </div>
</div>

<!-- Cart Summary Modal -->
<div class="modal" id="cartSummaryModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('cartSummaryModal')">&times;</span>
    <h2>Your Cart</h2>
    
    <div class="cart-content">
      <!-- Customer Details (Optional) -->
      <div class="form-group">
        <h4>Customer Info (Optional)</h4>
        <div class="form-row">
          <div class="form-group">

          </div>
          <div class="form-group">

          </div>
        </div>
        <div class="form-group">
  
        </div>
      </div>

      <!-- Cart Items -->
      <div class="cart-items-section">
        <div id="cartItemsContainer" class="cart-items-container">
          <!-- Cart items will be dynamically inserted here -->
        </div>
      </div>
      
      <!-- Order Summary -->
      <div class="order-summary">
        <div class="form-group">
          <label for="discount">Discount (₱)</label>
          <input type="number" id="discount" min="0" value="0" step="0.01" oninput="updateCartTotal()">
        </div>
        
        <div class="form-group">
          <label for="paymentMethod">Payment Method</label>
          <select id="paymentMethod" class="form-control">
            <option value="Cash">Cash</option>
            <option value="GCash">GCash</option>
            <option value="Credit">Credit</option>
            <option value="Other">Other</option>
          </select>
        </div>
        
        <div class="summary-row total">
          <span>Total:</span>
          <span id="cartTotal">₱0.00</span>
        </div>
      </div>
    </div>
    
    <!-- Action Buttons -->
    <div class="cart-actions">
      <button type="button" class="btn btn-secondary" onclick="closeModal('cartSummaryModal')">
        Continue Shopping
      </button>
      <button type="button" class="btn btn-primary" onclick="checkout()">
        Checkout
      </button>
    </div>
  </div>
</div>
<!-- Cart Button (Add to header) -->
<div class="cart-button-container">
  <button class="btn btn-primary" onclick="openModal('cartSummaryModal')">
    <span class="icon"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e3e3e3"><path d="M280-80q-33 0-56.5-23.5T200-160q0-33 23.5-56.5T280-240q33 0 56.5 23.5T360-160q0 33-23.5 56.5T280-80Zm400 0q-33 0-56.5-23.5T600-160q0-33 23.5-56.5T680-240q33 0 56.5 23.5T760-160q0 33-23.5 56.5T680-80ZM246-720l96 200h280l110-200H246Zm-38-80h590q23 0 35 20.5t1 41.5L692-482q-11 20-29.5 31T622-440H324l-44 80h480v80H280q-45 0-68-39.5t-2-78.5l54-98-144-304H40v-80h130l38 80Zm134 280h280-280Z"/></svg></span> 
    <span id="cartCount">0</span>
  </button>
</div>
  </main>
</div>
<script src="js/inv.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const toastType = urlParams.get("toast");
    const message = urlParams.get("msg");

    if (toastType && message) {
        let bgColor;

        switch (toastType) {
            case "success":
                bgColor = "#2ecc71"; // Green
                break;
            case "error":
                bgColor = "#e74c3c"; // Red
                break;
            case "info":
                bgColor = "#3498db"; // Blue
                break;
            case "warning":
                bgColor = "#f39c12"; // Yellow/Orange
                break;
            default:
                bgColor = "#34495e"; // Default gray
        }

        Toastify({
            text: decodeURIComponent(message),
            duration: 3000,
            gravity: "bottom",
            position: "right",
            backgroundColor: bgColor,
            close: true
        }).showToast();

        // Clean the URL after showing the toast
        if (window.history.replaceState) {
            const cleanUrl = window.location.href.split('?')[0];
            window.history.replaceState({}, document.title, cleanUrl);
        }
    }
    
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', filterProducts);
    
    // Sort functionality
    const sortSelect = document.getElementById('sortSelect');
    sortSelect.addEventListener('change', sortProducts);
    
    // Quick add to cart function
    window.quickAddToCart = function(button) {
        const productName = button.dataset.name;
        const productPrice = button.dataset.price;
        
        // Set modal values
        document.getElementById('productName').value = productName;
        document.getElementById('productPrice').value = productPrice;
        document.getElementById('modalProductName').textContent = productName;
        document.getElementById('modalProductPrice').textContent = parseFloat(productPrice).toFixed(2);
        document.getElementById('modalTotalPrice').textContent = parseFloat(productPrice).toFixed(2);
        
        // Open modal
        openModal('cartModal');
    };
    
    // Initialize existing buttons
    document.querySelectorAll('.btn-order').forEach(button => {
        button.addEventListener('click', function() {
            quickAddToCart(this);
        });
    });
});

// Filter products based on search input
function filterProducts() {
    const searchValue = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.getElementById('productTableBody').getElementsByTagName('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const productName = rows[i].getElementsByTagName('td')[1].textContent.toLowerCase();
        const category = rows[i].getElementsByTagName('td')[0].textContent.toLowerCase();
        
        if (productName.includes(searchValue) || category.includes(searchValue)) {
            rows[i].style.display = '';
        } else {
            rows[i].style.display = 'none';
        }
    }
}

// Sort products based on selected option
function sortProducts() {
    const sortValue = document.getElementById('sortSelect').value;
    const tbody = document.getElementById('productTableBody');
    const rows = Array.from(tbody.getElementsByTagName('tr'));
    
    if (!sortValue) return;
    
    rows.sort((a, b) => {
        let aValue, bValue;
        
        if (sortValue === 'name_asc' || sortValue === 'name_desc') {
            aValue = a.getElementsByTagName('td')[1].textContent.toLowerCase();
            bValue = b.getElementsByTagName('td')[1].textContent.toLowerCase();
        } else if (sortValue === 'price_asc' || sortValue === 'price_desc') {
            aValue = parseFloat(a.getElementsByTagName('td')[2].textContent.replace('₱', '').replace(',', ''));
            bValue = parseFloat(b.getElementsByTagName('td')[2].textContent.replace('₱', '').replace(',', ''));
        } else if (sortValue === 'quantity_asc' || sortValue === 'quantity_desc') {
            aValue = parseInt(a.getElementsByTagName('td')[3].textContent);
            bValue = parseInt(b.getElementsByTagName('td')[3].textContent);
        }
        
        if (sortValue.endsWith('_asc')) {
            return aValue > bValue ? 1 : -1;
        } else {
            return aValue < bValue ? 1 : -1;
        }
    });
    
    // Re-append sorted rows
    rows.forEach(row => tbody.appendChild(row));
}
</script>
</body>
</html>
