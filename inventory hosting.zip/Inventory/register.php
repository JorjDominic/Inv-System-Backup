<?php
require 'config/database.php';

// Set JSON header
header('Content-Type: application/json');

// For debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = [
    'success' => false,
    'message' => '',
    'errors' => []
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and get input values
    $username   = htmlspecialchars(trim($_POST['username'] ?? ''));
    $firstname  = htmlspecialchars(trim($_POST['firstname'] ?? ''));
    $lastname   = htmlspecialchars(trim($_POST['lastname'] ?? ''));
    $email      = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password   = $_POST['password'] ?? '';

    // Validate inputs
    if (empty($username)) {
        $response['errors']['username'] = 'Username is required';
    } elseif (!preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/', $username)) {
        $response['errors']['username'] = 'Must be 8+ chars with letters and numbers';
    }

    if (empty($firstname)) {
        $response['errors']['firstname'] = 'First name is required';
    } elseif (!preg_match('/^[a-zA-Z]+$/', $firstname)) {
        $response['errors']['firstname'] = 'Only letters allowed';
    }

    if (empty($lastname)) {
        $response['errors']['lastname'] = 'Last name is required';
    } elseif (!preg_match('/^[a-zA-Z]+$/', $lastname)) {
        $response['errors']['lastname'] = 'Only letters allowed';
    }

    if (empty($email)) {
        $response['errors']['email'] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['errors']['email'] = 'Invalid email format';
    }

    if (empty($password)) {
        $response['errors']['password'] = 'Password is required';
    } elseif (strlen($password) < 8 || 
             !preg_match('/[A-Z]/', $password) || 
             !preg_match('/[a-z]/', $password) || 
             !preg_match('/[0-9]/', $password)) {
        $response['errors']['password'] = 'Must be 8+ chars with uppercase, lowercase, and number';
    }

    // Check if username/email exists only if no validation errors
    if (empty($response['errors'])) {
        try {
            // Check if username exists
            $stmt = $conn->prepare("SELECT UserID FROM Users WHERE Username = ?");
            $stmt->execute([$username]);
            if ($stmt->rowCount() > 0) {
                $response['errors']['username'] = 'Username already taken';
            }

            // Check if email exists - separate check to allow separate error handling
            $stmt = $conn->prepare("SELECT UserID FROM Users WHERE Email = ?");
            $stmt->execute([$email]);
            if ($stmt->rowCount() > 0) {
                $response['errors']['email'] = 'Email already in use';
            }
        } catch (PDOException $e) {
            $response['message'] = 'Database error checking credentials';
        }
    }

    // If no errors, proceed with registration
    if (empty($response['errors'])) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $roleId = 5; // Customer role

        try {
            $conn->beginTransaction();

            // Insert user
            $stmt = $conn->prepare("INSERT INTO Users (Username, Email, Password, FirstName, LastName, RoleID)
                                    VALUES (?, ?, ?, ?, ?, ?)");
            $result = $stmt->execute([$username, $email, $hashedPassword, $firstname, $lastname, $roleId]);

            if (!$result) {
                throw new PDOException("Insert failed: " . implode(", ", $stmt->errorInfo()));
            }

            // Log to audit trail
            $change_time = date('Y-m-d H:i:s');
            $log_query = "INSERT INTO audit_trail (affected_username, changed_by, action, timestamp) 
                          VALUES (:affected, :changer, 'Account Registered', :timestamp)";
            $log_stmt = $conn->prepare($log_query);
            $log_stmt->bindParam(':affected', $username);
            $log_stmt->bindParam(':changer', $username);
            $log_stmt->bindParam(':timestamp', $change_time);
            $log_stmt->execute();

            $conn->commit();

            $response['success'] = true;
            $response['message'] = 'Registration successful! Please login.';
        } catch (PDOException $e) {
            $conn->rollBack();
            $response['message'] = 'Registration failed: ' . $e->getMessage();
        }
    } else {
        $response['message'] = 'Please correct the errors below';
    }
} else {
    $response['message'] = 'Invalid request method';
}

echo json_encode($response);
?>
