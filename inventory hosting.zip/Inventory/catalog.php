<?php
session_start();
require('config/database.php');
require_once 'notification.php'; // Include notification system

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// No login required for catalog browsing
// But we can track if user is logged in for personalized features
$isLoggedIn = isset($_SESSION['user_id']);
$isCustomer = $isLoggedIn && $_SESSION['role'] == 3; // Assuming role 3 is customer

ini_set('display_errors', 1);
error_reporting(E_ALL);

$categoryStmt = $conn->query("SELECT CategoryID, CategoryName FROM Category ORDER BY CategoryName");
$categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);

// Get current date for expiry calculations
$today = date('Y-m-d');

// Get total products count
$totalProductsQuery = "SELECT COUNT(DISTINCT p.ProductID) as count FROM Product p";
$totalProductsStmt = $conn->query($totalProductsQuery);
$totalProducts = $totalProductsStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get available products count (products with quantity > 0)
$availableProductsQuery = "SELECT COUNT(DISTINCT p.ProductID) as count FROM Product p 
                          JOIN Inventory i ON p.ProductID = i.ProductID 
                          WHERE i.Quantity > 0";
$availableProductsStmt = $conn->query($availableProductsQuery);
$availableProducts = $availableProductsStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get category count
$categoryCountQuery = "SELECT COUNT(*) as count FROM Category";
$categoryCountStmt = $conn->query($categoryCountQuery);
$categoryCount = $categoryCountStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get featured products count (for demo purposes, we'll count low stock items)
$featuredProductsQuery = "SELECT COUNT(DISTINCT p.ProductID) as count FROM Product p 
                         JOIN Inventory i ON p.ProductID = i.ProductID 
                         WHERE i.Quantity > 0 AND i.Quantity < 10";
$featuredProductsStmt = $conn->query($featuredProductsQuery);
$featuredProducts = $featuredProductsStmt->fetch(PDO::FETCH_ASSOC)['count'];

// Calculate cart count
$cartCount = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product Catalog</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    /* General Styles */
    :root {
      --primary-color: #4a934a;
      --danger-color: #e74c3c;
      --warning-color: #f39c12;
      --info-color: #3498db;
      --expiring-color: #17a2b8;
      --light-gray: #f8f9fa;
      --border-color: #dee2e6;
      --text-color: #333;
      --text-muted: #6c757d;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: var(--text-color);
    }
    
    /* Dashboard Cards */
    .inventory-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .stat-card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      padding: 20px;
      text-align: center;
      transition: transform 0.3s ease;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
    }
    
    .stat-card h3 {
      font-size: 2rem;
      margin: 0;
      color: var(--primary-color);
    }
    
    .stat-card p {
      color: var(--text-muted);
      margin: 10px 0 0;
    }
    
    .stat-card.warning h3 {
      color: var(--warning-color);
    }
    
    .stat-card.danger h3 {
      color: var(--danger-color);
    }
    
    .stat-card.info h3 {
      color: var(--info-color);
    }
    
    .stat-card.expiring h3 {
      color: var(--expiring-color);
    }
    
    /* Header and Controls */
    .header-container {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      margin-bottom: 20px;
    }
    
    .link-container {
      margin-top: 10px;
      display: flex;
      gap: 15px;
    }
    
    .inventory-link {
      font-size: 1rem;
      color: var(--info-color);
      font-weight: 600;
      text-decoration: none;
    }
    
    .inventory-link:hover {
      text-decoration: underline;
    }
    
    .search-sort-container {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      margin-bottom: 20px;
      align-items: center;
      justify-content: space-between;
      width: 100%;
    }
    
    .search-bar {
      flex: 1;
      min-width: 250px;
    }
    
    .search-bar input {
      width: 100%;
      padding: 10px 15px;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      font-size: 1rem;
    }
    
    .sort-options select {
      padding: 10px 15px;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      font-size: 1rem;
      min-width: 180px;
    }
    
    /* Filter Buttons */
    .filter-options {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 20px;
    }

    .filter-btn {
      padding: 8px 15px;
      border: none;
      border-radius: 20px;
      background-color: #f0f0f0;
      color: var(--text-color);
      cursor: pointer;
      transition: all 0.2s;
      font-size: 0.9rem;
      white-space: nowrap;
    }

    .filter-btn:hover {
      background-color: #e0e0e0;
    }

    .filter-btn.active {
      background-color: var(--primary-color);
      color: white;
      font-weight: bold;
    }
    
    /* View Toggle */
    .view-toggle {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 20px;
    }
    
    .view-toggle-btn {
      padding: 8px 15px;
      background-color: white;
      border: 1px solid var(--border-color);
      cursor: pointer;
    }
    
    .view-toggle-btn:first-child {
      border-radius: 4px 0 0 4px;
    }
    
    .view-toggle-btn:last-child {
      border-radius: 0 4px 4px 0;
    }
    
    .view-toggle-btn.active {
      background-color: var(--primary-color);
      color: white;
      border-color: var(--primary-color);
    }
    
    /* Product Grid */
    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .product-card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      display: flex;
      flex-direction: column;
    }
    
    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .product-card.out-of-stock {
      border-left: 4px solid var(--danger-color);
      background-color: #fff5f5;
    }
    
    .product-card.low-stock {
      border-left: 4px solid var(--warning-color);
      background-color: #fff9f0;
    }
    
    .product-image {
      height: 180px;
      background-color: #f8f9fa;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      position: relative;
    }
    
    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    .product-image .no-image {
      color: #ccc;
      font-size: 3rem;
    }
    
    .product-status {
      position: absolute;
      top: 10px;
      right: 10px;
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 0.8rem;
      font-weight: bold;
      color: white;
    }
    
    .status-out {
      background-color: var(--danger-color);
    }
    
    .status-low {
      background-color: var(--warning-color);
    }
    
    .product-details {
      padding: 15px;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }
    
    .product-category {
      font-size: 0.8rem;
      color: var(--text-muted);
      margin-bottom: 5px;
      text-transform: uppercase;
    }
    
    .product-name {
      font-size: 1.1rem;
      font-weight: bold;
      margin-bottom: 10px;
      line-height: 1.3;
    }
    
    .product-info {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
      font-size: 0.9rem;
    }
    
    .info-label {
      color: var(--text-muted);
    }
    
    .info-value {
      font-weight: 500;
      text-align: right;
    }
    
    .product-actions {
      padding: 15px;
      background-color: #f8f9fa;
      display: flex;
      gap: 8px;
      justify-content: space-between;
    }
    
    .action-btn {
      padding: 8px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.9rem;
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 1;
      transition: background-color 0.2s;
    }
    
    .action-btn i {
      margin-right: 5px;
    }
    
    .btn-view {
      background-color: #e3f2fd;
      color: #0d6efd;
    }
    
    .btn-view:hover {
      background-color: #cce5ff;
    }
    
    .btn-add-cart {
      background-color: var(--primary-color);
      color: white;
    }
    
    .btn-add-cart:hover {
      background-color: #3a7a3a;
    }
    
    .btn-add-cart:disabled {
      background-color: #cccccc;
      cursor: not-allowed;
    }
    
    /* Table View */
    .table-container {
      overflow-x: auto;
      margin-bottom: 30px;
      display: none;
    }
    
    .table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .table th, .table td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid var(--border-color);
    }
    
    .table th {
      background-color: #f8f9fa;
      font-weight: 600;
    }
    
    .table tr:hover {
      background-color: #f8f9fa;
    }
    
    .table tr.out-of-stock {
      background-color: #fff5f5;
    }
    
    .table tr.low-stock {
      background-color: #fff9f0;
    }
    
    .table .actions {
      display: flex;
      gap: 5px;
    }
    
    .table .btn {
      padding: 5px 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.8rem;
    }
    
    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 50px 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    .empty-state i {
      font-size: 3rem;
      color: #ccc;
      margin-bottom: 20px;
    }
    
    .empty-state h3 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }
    
    .empty-state p {
      color: var(--text-muted);
    }
    
    /* Product Detail Modal */
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      overflow-y: auto;
    }
    
    .modal.show {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .modal-content {
      background-color: white;
      border-radius: 8px;
      max-width: 800px;
      width: 90%;
      margin: 40px auto;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
      position: relative;
      animation: fadeIn 0.3s ease-out;
    }
    
    .modal-header {
      padding: 20px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--primary-color);
      border-bottom: none;
    }
    
    .close {
      font-size: 1.5rem;
      color: var(--text-muted);
      cursor: pointer;
      transition: color 0.2s;
    }
    
    .close:hover {
      color: var(--danger-color);
    }
    
    .modal-body {
      padding: 20px;
    }
    
    .product-detail-content {
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
    }
    
    .product-gallery {
      flex: 1;
      min-width: 300px;
    }
    
    .product-main-image {
      height: 300px;
      background-color: #f8f9fa;
      border-radius: 8px;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .product-main-image img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
    
    .product-info-container {
      flex: 1;
      min-width: 300px;
    }
    
    .product-title {
      font-size: 1.8rem;
      margin-bottom: 10px;
      color: var(--text-color);
    }
    
    .product-price {
      font-size: 1.5rem;
      font-weight: bold;
      color: var(--primary-color);
      margin-bottom: 15px;
    }
    
    .product-availability {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 0.9rem;
      font-weight: 500;
      margin-bottom: 20px;
    }
    
    .product-availability.in-stock {
      background-color: #d4edda;
      color: #155724;
    }
    
    .product-availability.low-stock {
      background-color: #fff3cd;
      color: #856404;
    }
    
    .product-availability.out-of-stock {
      background-color: #f8d7da;
      color: #721c24;
    }
    
    .product-description {
      margin-bottom: 20px;
      line-height: 1.6;
      color: var(--text-color);
    }
    
    .product-meta {
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid var(--border-color);
    }
    
    .meta-item {
      display: flex;
      margin-bottom: 10px;
    }
    
    .meta-label {
      width: 120px;
      color: var(--text-muted);
    }
    
    .meta-value {
      font-weight: 500;
    }
    
    /* Quantity Input */
    .quantity-input {
      display: flex;
      align-items: center;
      margin: 20px 0;
    }
    
    .quantity-input label {
      margin-right: 10px;
      font-weight: 500;
    }
    
    .quantity-input .quantity-controls {
      display: flex;
      align-items: center;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      overflow: hidden;
    }
    
    .quantity-input button {
      background-color: #f8f9fa;
      border: none;
      width: 36px;
      height: 36px;
      font-size: 1.2rem;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .quantity-input button:hover {
      background-color: #e9ecef;
    }
    
    .quantity-input input {
      width: 50px;
      height: 36px;
      border: none;
      border-left: 1px solid var(--border-color);
      border-right: 1px solid var(--border-color);
      text-align: center;
      font-size: 1rem;
    }
    
    .quantity-input input:focus {
      outline: none;
    }
    
    /* Add to Cart Button */
    .add-to-cart-btn {
      display: inline-block;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 4px;
      padding: 10px 20px;
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    
    .add-to-cart-btn:hover {
      background-color: #3a7a3a;
    }
    
    .add-to-cart-btn:disabled {
      background-color: #cccccc;
      cursor: not-allowed;
    }
    
    .add-to-cart-btn i {
      margin-right: 8px;
    }
    
    /* Floating Cart Button */
    .cart-button-container {
      position: fixed;
      bottom: 30px;
      right: 30px;
      z-index: 999;
    }
    
    .cart-button {
      display: flex;
      align-items: center;
      gap: 10px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 50px;
      padding: 12px 20px;
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
      transition: transform 0.2s, background-color 0.2s;
    }
    
    .cart-button:hover {
      background-color: #3a7a3a;
      transform: translateY(-3px);
    }
    
    .cart-count {
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: white;
      color: var(--primary-color);
      border-radius: 50%;
      width: 24px;
      height: 24px;
      font-size: 0.8rem;
      font-weight: bold;
    }
    
    /* Animations */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
      40% { transform: translateY(-10px); }
      60% { transform: translateY(-5px); }
    }
    
    .bounce {
      animation: bounce 0.8s ease;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
      .search-sort-container {
        flex-direction: column;
        align-items: stretch;
      }
      
      .search-bar, .sort-options {
        width: 100%;
      }
      
      .product-detail-content {
        flex-direction: column;
      }
      
      .modal-content {
        width: 95%;
        margin: 20px auto;
      }
      
      .cart-button-container {
        bottom: 20px;
        right: 20px;
      }
      
      .cart-button {
        padding: 10px 16px;
      }
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>Order Products</h1>
        <div class="link-container">
          
          <a href="cart.php" class="inventory-link">View Cart (<?= $cartCount ?>)</a>
        </div>
      </div>
  
      <!-- Stats Dashboard -->
      <div class="inventory-stats">
        <div class="stat-card">
          <h3><?= $totalProducts ?></h3>
          <p>Total Products</p>
        </div>
        
        <div class="stat-card info">
          <h3><?= $categoryCount ?></h3>
          <p>Categories</p>
        </div>
        
        <div class="stat-card warning">
          <h3><?= $availableProducts ?></h3>
          <p>Available Products</p>
        </div>
        
       
      </div>

      <div class="search-sort-container">
        <div class="search-bar">
          <input type="text" id="searchInput" placeholder="Search products...">
        </div>
        
        <div class="sort-options">
          <select id="sortSelect">
            <option value="">Sort By</option>
            <option value="name_asc">Name (A-Z)</option>
            <option value="name_desc">Name (Z-A)</option>
            <option value="price_asc">Price (Low-High)</option>
            <option value="price_desc">Price (High-Low)</option>
          </select>
        </div>

        <div class="sort-options">
          <select id="availabilityFilter">
            <option value="all">All Products</option>
            <option value="in-stock">In Stock</option>
            <option value="low-stock">Low Stock</option>
          </select>
        </div>
      </div>
      
      <!-- Filter buttons for categories -->
      <div class="filter-options">
        <button class="filter-btn active" data-category="all">All Categories</button>
        <?php foreach ($categories as $category): ?>
          <button class="filter-btn" data-category="<?= $category['CategoryID'] ?>"><?= htmlspecialchars($category['CategoryName']) ?></button>
        <?php endforeach; ?>
      </div>
      
      <!-- View Toggle -->
      <div class="view-toggle">
        <button class="view-toggle-btn active" data-view="grid">
          <i class="fas fa-th"></i> Grid
        </button>
        <button class="view-toggle-btn" data-view="table">
          <i class="fas fa-list"></i> Table
        </button>
      </div>

      <!-- Product Grid View -->
      <div id="gridView" class="product-grid">
        <?php
        try {
          $stmt = $conn->query("
            SELECT 
              p.ProductID,
              p.ProductName,
              p.SellingPrice,
              p.ImageURL,
              c.CategoryName,
              c.CategoryID,
              SUM(i.Quantity) as TotalQuantity
            FROM Product p
            INNER JOIN Category c ON p.CategoryID = c.CategoryID
            LEFT JOIN Inventory i ON p.ProductID = i.ProductID
            GROUP BY p.ProductID, p.ProductName, p.SellingPrice, p.ImageURL, c.CategoryName, c.CategoryID
            ORDER BY p.ProductName ASC
          ");

          $hasProducts = false;
          
          while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $hasProducts = true;
            $stockClass = '';
            $statusBadge = '';
            $availabilityClass = 'in-stock';
            $availabilityText = 'In Stock';
            $isOutOfStock = $row['TotalQuantity'] <= 0;
            
            if ($isOutOfStock) {
              $stockClass = 'out-of-stock';
              $statusBadge = '<div class="product-status status-out">Out of Stock</div>';
              $availabilityClass = 'out-of-stock';
              $availabilityText = 'Out of Stock';
            } elseif ($row['TotalQuantity'] < 10) {
              $stockClass = 'low-stock';
              $statusBadge = '<div class="product-status status-low">Low Stock: ' . $row['TotalQuantity'] . '</div>';
              $availabilityClass = 'low-stock';
              $availabilityText = 'Low Stock - Only ' . $row['TotalQuantity'] . ' left';
            }
        ?>
            <div class="product-card <?= $stockClass ?>" 
                 data-id="<?= $row['ProductID'] ?>"
                 data-category="<?= $row['CategoryID'] ?>"
                 data-name="<?= htmlspecialchars($row['ProductName']) ?>"
                 data-price="<?= $row['SellingPrice'] ?>"
                 data-availability="<?= $row['TotalQuantity'] > 0 ? ($row['TotalQuantity'] < 10 ? 'low-stock' : 'in-stock') : 'out-of-stock' ?>"
                 data-category-name="<?= htmlspecialchars($row['CategoryName']) ?>"
                 data-quantity="<?= $row['TotalQuantity'] ?>"
                 data-image="<?= htmlspecialchars($row['ImageURL'] ?? '') ?>">
              <div class="product-image">
                <?php if ($row['ImageURL']): ?>
                  <img src="<?= htmlspecialchars($row['ImageURL']) ?>" alt="<?= htmlspecialchars($row['ProductName']) ?>">
                <?php else: ?>
                  <div class="no-image"><i class="fas fa-image"></i></div>
                <?php endif; ?>
                <?= $statusBadge ?>
              </div>
              <div class="product-details">
                <div class="product-category"><?= htmlspecialchars($row['CategoryName']) ?></div>
                <h3 class="product-name"><?= htmlspecialchars($row['ProductName']) ?></h3>
                <div class="product-info">
                  <div class="info-label">Price:</div>
                  <div class="info-value">₱<?= number_format($row['SellingPrice'], 2) ?></div>
                  
                  <div class="info-label">Availability:</div>
                  <div class="info-value <?= $availabilityClass ?>"><?= $availabilityText ?></div>
                </div>
              </div>
              <div class="product-actions">
                <button class="action-btn btn-view" onclick="showProductDetails(<?= $row['ProductID'] ?>)">
                  <i class="fas fa-eye"></i> View
                </button>
                <button class="action-btn btn-add-cart" onclick="addToCart(<?= $row['ProductID'] ?>)" <?= $isOutOfStock ? 'disabled' : '' ?>>
                  <i class="fas fa-cart-plus"></i> Add to Cart
                </button>
              </div>
            </div>
        <?php
          }
          
          if (!$hasProducts) {
            echo '<div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>No products found</h3>
                    <p>We\'re currently updating our inventory. Please check back soon!</p>
                  </div>';
          }
        } catch (PDOException $e) {
          echo '<div class="empty-state">
                  <i class="fas fa-exclamation-triangle"></i>
                  <h3>Error loading products</h3>
                  <p>We\'re experiencing technical difficulties. Please try again later.</p>
                </div>';
        }
        ?>
      </div>

      <!-- Table View -->
      <div id="tableView" class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Category</th>
              <th>Price</th>
              <th>Availability</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php
          try {
            $stmt = $conn->query("
              SELECT 
                p.ProductID,
                p.ProductName,
                p.SellingPrice,
                p.ImageURL,
                c.CategoryName,
                c.CategoryID,
                SUM(i.Quantity) as TotalQuantity
              FROM Product p
              INNER JOIN Category c ON p.CategoryID = c.CategoryID
              LEFT JOIN Inventory i ON p.ProductID = i.ProductID
              GROUP BY p.ProductID, p.ProductName, p.SellingPrice, p.ImageURL, c.CategoryName, c.CategoryID
              ORDER BY p.ProductName ASC
            ");
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
              $rowClass = '';
              $availabilityText = 'In Stock';
              $availabilityClass = 'in-stock';
              $isOutOfStock = $row['TotalQuantity'] <= 0;
              
              if ($isOutOfStock) {
                $rowClass = 'out-of-stock';
                $availabilityText = 'Out of Stock';
                $availabilityClass = 'out-of-stock';
              } elseif ($row['TotalQuantity'] < 10) {
                $rowClass = 'low-stock';
                $availabilityText = 'Low Stock - Only ' . $row['TotalQuantity'] . ' left';
                $availabilityClass = 'low-stock';
              }
          ?>
              <tr class="<?= $rowClass ?>" 
                  data-id="<?= $row['ProductID'] ?>"
                  data-category="<?= $row['CategoryID'] ?>"
                  data-name="<?= htmlspecialchars($row['ProductName']) ?>"
                  data-price="<?= $row['SellingPrice'] ?>"
                  data-availability="<?= $row['TotalQuantity'] > 0 ? ($row['TotalQuantity'] < 10 ? 'low-stock' : 'in-stock') : 'out-of-stock' ?>"
                  data-category-name="<?= htmlspecialchars($row['CategoryName']) ?>"
                  data-quantity="<?= $row['TotalQuantity'] ?>"
                  data-image="<?= htmlspecialchars($row['ImageURL'] ?? '') ?>">
                <td>
                  <div class="d-flex align-items-center">
                    <?php if ($row['ImageURL']): ?>
                      <img src="<?= htmlspecialchars($row['ImageURL']) ?>" alt="<?= htmlspecialchars($row['ProductName']) ?>" style="width: 40px; height: 40px; object-fit: cover; margin-right: 10px; border-radius: 4px;">
                    <?php endif; ?>
                    <div>
                      <?= htmlspecialchars($row['ProductName']) ?>
                    </div>
                  </div>
                </td>
                <td><?= htmlspecialchars($row['CategoryName']) ?></td>
                <td>₱<?= number_format($row['SellingPrice'], 2) ?></td>
                <td class="<?= $availabilityClass ?>"><?= $availabilityText ?></td>
                <td class="actions">
                  <button class="btn btn-primary" onclick="showProductDetails(<?= $row['ProductID'] ?>)">
                    <i class="fas fa-eye"></i> View
                  </button>
                  <button class="btn btn-success" onclick="addToCart(<?= $row['ProductID'] ?>)" <?= $isOutOfStock ? 'disabled' : '' ?>>
                    <i class="fas fa-cart-plus"></i> Add
                  </button>
                </td>
              </tr>
          <?php
            }
          } catch (PDOException $e) {
            echo "<tr><td colspan='5'>❌ Error loading products: " . $e->getMessage() . "</td></tr>";
          }
          ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<!-- Floating Cart Button -->
<div class="cart-button-container">
  <a href="cart.php" class="cart-button">
    <i class="fas fa-shopping-cart"></i>
    <span>View Cart</span>
    <div class="cart-count" id="cartCountBadge"><?= $cartCount ?></div>
  </a>
</div>

<!-- Product Detail Modal -->
<div class="modal" id="productModal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 id="modalProductName">Product Details</h2>
      <span class="close" onclick="closeModal()">&times;</span>
    </div>
    <div class="modal-body" id="modalBody">
      <!-- Content will be loaded dynamically -->
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', filterProducts);
    
    // Sort functionality
    const sortSelect = document.getElementById('sortSelect');
    sortSelect.addEventListener('change', filterProducts);
    
    // Availability filter
    const availabilityFilter = document.getElementById('availabilityFilter');
    availabilityFilter.addEventListener('change', filterProducts);
    
    // Category filter
    const categoryButtons = document.querySelectorAll('.filter-btn');
    categoryButtons.forEach(button => {
      button.addEventListener('click', function() {
        // Remove active class from all buttons
        categoryButtons.forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked button
        this.classList.add('active');
        
        filterProducts();
      });
    });
    
    // View toggle
    const viewButtons = document.querySelectorAll('.view-toggle-btn');
    viewButtons.forEach(button => {
      button.addEventListener('click', function() {
        const viewType = this.getAttribute('data-view');
        toggleView(viewType);
      });
    });
    
    // Check for URL parameters to handle direct links
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('product');
    const categoryId = urlParams.get('category');
    
    if (productId) {
      // Show product details if product ID is in URL
      showProductDetails(productId);
    } else if (categoryId) {
      // Filter by category if category ID is in URL
      const categoryButton = document.querySelector(`.filter-btn[data-category="${categoryId}"]`);
      if (categoryButton) {
        categoryButtons.forEach(btn => btn.classList.remove('active'));
        categoryButton.classList.add('active');
        filterProducts();
      }
    }
  });

  // Filter products based on search, sort, category, and availability
  function filterProducts() {
    const searchValue = document.getElementById('searchInput').value.toLowerCase();
    const sortValue = document.getElementById('sortSelect').value;
    const availabilityValue = document.getElementById('availabilityFilter').value;
    const activeCategory = document.querySelector('.filter-btn.active').getAttribute('data-category');
    
    // Filter grid view
    const gridItems = document.querySelectorAll('.product-card');
    gridItems.forEach(item => {
      const productName = item.getAttribute('data-name').toLowerCase();
      const productCategory = item.getAttribute('data-category');
      const productAvailability = item.getAttribute('data-availability');
      
      // Check if product matches all filters
      const matchesSearch = productName.includes(searchValue);
      const matchesCategory = activeCategory === 'all' || productCategory === activeCategory;
      const matchesAvailability = availabilityValue === 'all' || 
                                 (availabilityValue === 'in-stock' && (productAvailability === 'in-stock' || productAvailability === 'low-stock')) ||
                                 (availabilityValue === 'low-stock' && productAvailability === 'low-stock');
      
      if (matchesSearch && matchesCategory && matchesAvailability) {
        item.style.display = '';
      } else {
        item.style.display = 'none';
      }
    });
    
    // Filter table view
    const tableRows = document.querySelectorAll('.table tbody tr');
    tableRows.forEach(row => {
      if (!row.hasAttribute('data-id')) return; // Skip non-product rows
      
      const productName = row.getAttribute('data-name').toLowerCase();
      const productCategory = row.getAttribute('data-category');
      const productAvailability = row.getAttribute('data-availability');
      
      // Check if product matches all filters
      const matchesSearch = productName.includes(searchValue);
      const matchesCategory = activeCategory === 'all' || productCategory === activeCategory;
      const matchesAvailability = availabilityValue === 'all' || 
                                 (availabilityValue === 'in-stock' && (productAvailability === 'in-stock' || productAvailability === 'low-stock')) ||
                                 (availabilityValue === 'low-stock' && productAvailability === 'low-stock');
      
      if (matchesSearch && matchesCategory && matchesAvailability) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
    
    // Sort products if sort option is selected
    if (sortValue) {
      sortProducts(sortValue);
    }
    
    // Check if any products are visible
    checkEmptyState();
    
    // Update URL with category parameter
    if (activeCategory !== 'all') {
      const url = new URL(window.location);
      url.searchParams.set('category', activeCategory);
      window.history.replaceState({}, '', url);
    } else {
      const url = new URL(window.location);
      url.searchParams.delete('category');
      window.history.replaceState({}, '', url);
    }
  }

  // Sort products based on selected option
  function sortProducts(sortValue) {
    // Sort grid items
    const productGrid = document.getElementById('gridView');
    const gridItems = Array.from(productGrid.querySelectorAll('.product-card:not([style*="display: none"])'));
    
    gridItems.sort((a, b) => {
      const aName = a.getAttribute('data-name');
      const bName = b.getAttribute('data-name');
      const aPrice = parseFloat(a.getAttribute('data-price'));
      const bPrice = parseFloat(b.getAttribute('data-price'));
      
      if (sortValue === 'name_asc') {
        return aName.localeCompare(bName);
      } else if (sortValue === 'name_desc') {
        return bName.localeCompare(aName);
      } else if (sortValue === 'price_asc') {
        return aPrice - bPrice;
      } else if (sortValue === 'price_desc') {
        return bPrice - aPrice;
      }
      return 0;
    });
    
    // Re-append sorted grid items
    gridItems.forEach(item => productGrid.appendChild(item));
    
    // Sort table rows
    const tableBody = document.querySelector('.table tbody');
    const tableRows = Array.from(tableBody.querySelectorAll('tr:not([style*="display: none"])'));
    
    tableRows.sort((a, b) => {
      if (!a.hasAttribute('data-id') || !b.hasAttribute('data-id')) return 0;
      
      const aName = a.getAttribute('data-name');
      const bName = b.getAttribute('data-name');
      const aPrice = parseFloat(a.getAttribute('data-price'));
      const bPrice = parseFloat(b.getAttribute('data-price'));
      
      if (sortValue === 'name_asc') {
        return aName.localeCompare(bName);
      } else if (sortValue === 'name_desc') {
        return bName.localeCompare(aName);
      } else if (sortValue === 'price_asc') {
        return aPrice - bPrice;
      } else if (sortValue === 'price_desc') {
        return bPrice - aPrice;
      }
      return 0;
    });
    
    // Re-append sorted table rows
    tableRows.forEach(row => tableBody.appendChild(row));
  }

  // Toggle between grid and table view
  function toggleView(viewType) {
    const gridView = document.getElementById('gridView');
    const tableView = document.getElementById('tableView');
    const gridBtn = document.querySelector('.view-toggle-btn[data-view="grid"]');
    const tableBtn = document.querySelector('.view-toggle-btn[data-view="table"]');
    
    if (viewType === 'grid') {
      gridView.style.display = 'grid';
      tableView.style.display = 'none';
      gridBtn.classList.add('active');
      tableBtn.classList.remove('active');
    } else {
      gridView.style.display = 'none';
      tableView.style.display = 'block';
      gridBtn.classList.remove('active');
      tableBtn.classList.add('active');
    }
    
    checkEmptyState();
  }

  // Check if any products are visible and show empty state if needed
  function checkEmptyState() {
    const gridView = document.getElementById('gridView');
    const tableView = document.getElementById('tableView');
    const gridItems = gridView.querySelectorAll('.product-card:not([style*="display: none"])');
    const tableRows = tableView.querySelectorAll('tr[data-id]:not([style*="display: none"])');
    
    // Check grid view
    if (gridView.style.display !== 'none' && gridItems.length === 0) {
      let emptyState = gridView.querySelector('.empty-state');
      if (!emptyState) {
        emptyState = document.createElement('div');
        emptyState.className = 'empty-state';
        emptyState.innerHTML = `
          <i class="fas fa-search"></i>
          <h3>No products found</h3>
          <p>Try adjusting your search or filter criteria</p>
        `;
        gridView.appendChild(emptyState);
      } else {
        emptyState.style.display = 'block';
      }
    } else {
      const emptyState = gridView.querySelector('.empty-state');
      if (emptyState) {
        emptyState.style.display = 'none';
      }
    }
    
    // Check table view
    if (tableView.style.display !== 'none' && tableRows.length === 0) {
      const tableBody = tableView.querySelector('tbody');
      let emptyRow = tableBody.querySelector('.empty-row');
      if (!emptyRow) {
        emptyRow = document.createElement('tr');
        emptyRow.className = 'empty-row';
        emptyRow.innerHTML = `
          <td colspan="5" style="text-align: center; padding: 30px;">
            <i class="fas fa-search" style="font-size: 2rem; color: #ccc; margin-bottom: 10px;"></i>
            <h3>No products found</h3>
            <p>Try adjusting your search or filter criteria</p>
          </td>
        `;
        tableBody.appendChild(emptyRow);
      } else {
        emptyRow.style.display = '';
      }
    } else {
      const emptyRow = tableView.querySelector('.empty-row');
      if (emptyRow) {
        emptyRow.style.display = 'none';
      }
    }
  }

  // Show product details modal
  function showProductDetails(productId) {
    // Find the product data
    const productCard = document.querySelector(`.product-card[data-id="${productId}"]`);
    const tableRow = document.querySelector(`.table tbody tr[data-id="${productId}"]`);
    
    let productData;
    if (productCard) {
      productData = {
        id: productCard.getAttribute('data-id'),
        name: productCard.getAttribute('data-name'),
        price: productCard.getAttribute('data-price'),
        category: productCard.getAttribute('data-category-name'),
        availability: productCard.getAttribute('data-availability'),
        quantity: productCard.getAttribute('data-quantity'),
        image: productCard.getAttribute('data-image') || null
      };
    } else if (tableRow) {
      productData = {
        id: tableRow.getAttribute('data-id'),
        name: tableRow.getAttribute('data-name'),
        price: tableRow.getAttribute('data-price'),
        category: tableRow.getAttribute('data-category-name'),
        availability: tableRow.getAttribute('data-availability'),
        quantity: tableRow.getAttribute('data-quantity'),
        image: tableRow.getAttribute('data-image') || null
      };
    } else {
      console.error('Product not found');
      return;
    }
    
    // Set modal title
    document.getElementById('modalProductName').textContent = productData.name;
    
    // Build modal content
    let availabilityText = 'In Stock';
    let availabilityClass = 'in-stock';
    let isOutOfStock = productData.availability === 'out-of-stock';
    
    if (isOutOfStock) {
      availabilityText = 'Out of Stock';
      availabilityClass = 'out-of-stock';
    } else if (productData.availability === 'low-stock') {
      availabilityText = 'Low Stock - Only ' + productData.quantity + ' left';
      availabilityClass = 'low-stock';
    }
    
    const modalContent = `
      <div class="product-detail-content">
        <div class="product-gallery">
          <div class="product-main-image">
            ${productData.image ? 
              `<img src="${productData.image}" alt="${productData.name}">` : 
              `<div class="no-image"><i class="fas fa-image"></i></div>`
            }
          </div>
        </div>
        <div class="product-info-container">
          <div class="product-category">${productData.category}</div>
          <h1 class="product-title">${productData.name}</h1>
          <div class="product-price">₱${parseFloat(productData.price).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
          <div class="product-availability ${availabilityClass}">${availabilityText}</div>
          
          <div class="product-description">
            <p>This premium quality product is designed to meet your needs. Experience the best in quality and performance.</p>
            <p>Our products are carefully selected to ensure you get the best value for your money.</p>
          </div>
          
          ${!isOutOfStock ? `
          <div class="quantity-input">
            <label>Quantity:</label>
            <div class="quantity-controls">
              <button type="button" onclick="decrementQuantity('modalQuantity')">-</button>
              <input type="number" id="modalQuantity" min="1" max="${productData.quantity}" value="1">
              <button type="button" onclick="incrementQuantity('modalQuantity', ${productData.quantity})">+</button>
            </div>
          </div>
          
          <button class="add-to-cart-btn" onclick="addToCartFromModal(${productData.id})">
            <i class="fas fa-cart-plus"></i> Add to Cart
          </button>
          ` : ''}
          
          <div class="product-meta">
            <div class="meta-item">
              <div class="meta-label">SKU:</div>
              <div class="meta-value">PROD-${productData.id}</div>
            </div>
            <div class="meta-item">
              <div class="meta-label">Category:</div>
              <div class="meta-value">${productData.category}</div>
            </div>
            <div class="meta-item">
              <div class="meta-label">Availability:</div>
              <div class="meta-value ${availabilityClass}">${availabilityText}</div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.getElementById('modalBody').innerHTML = modalContent;
    
    // Show modal
    document.getElementById('productModal').classList.add('show');
    
    // Update URL with product parameter
    const url = new URL(window.location);
    url.searchParams.set('product', productId);
    window.history.replaceState({}, '', url);
  }

  // Close modal
  function closeModal() {
    document.getElementById('productModal').classList.remove('show');
    
    // Remove product parameter from URL
    const url = new URL(window.location);
    url.searchParams.delete('product');
    window.history.replaceState({}, '', url);
  }

  // Close modal when clicking outside
  window.addEventListener('click', function(event) {
    const modal = document.getElementById('productModal');
    if (event.target === modal) {
      closeModal();
    }
  });
  
  // Quantity controls
  function decrementQuantity(inputId) {
    const input = document.getElementById(inputId);
    const currentValue = parseInt(input.value);
    if (currentValue > 1) {
      input.value = currentValue - 1;
    }
  }
  
  function incrementQuantity(inputId, max) {
    const input = document.getElementById(inputId);
    const currentValue = parseInt(input.value);
    if (currentValue < max) {
      input.value = currentValue + 1;
    }
  }
  
  // Add to cart from product card
  function addToCart(productId) {
    addToCartWithQuantity(productId, 1);
  }
  
  // Add to cart from modal
  function addToCartFromModal(productId) {
    const quantityInput = document.getElementById('modalQuantity');
    const quantity = parseInt(quantityInput.value);
    addToCartWithQuantity(productId, quantity);
  }
  
  // Add to cart with specified quantity
// Add to cart with specified quantity
function addToCartWithQuantity(productId, quantity) {
    // Find product data
    const productCard = document.querySelector(`.product-card[data-id="${productId}"]`);
    const tableRow = document.querySelector(`.table tbody tr[data-id="${productId}"]`);
    
    let productData;
    if (productCard) {
        productData = {
            id: productCard.getAttribute('data-id'),
            name: productCard.getAttribute('data-name'),
            price: productCard.getAttribute('data-price'),
            image: productCard.getAttribute('data-image') || null
        };
    } else if (tableRow) {
        productData = {
            id: tableRow.getAttribute('data-id'),
            name: tableRow.getAttribute('data-name'),
            price: tableRow.getAttribute('data-price'),
            image: tableRow.getAttribute('data-image') || null
        };
    } else {
        console.error('Product not found');
        return;
    }
    
    // Create form data
    const formData = new FormData();
    formData.append('product_id', productId);
    formData.append('quantity', quantity);
    
    // Show loading indicator
    Toastify({
        text: "Adding to cart...",
        duration: 2000,
        gravity: "bottom",
        position: "right",
        backgroundColor: "#3498db"
    }).showToast();
    
    // Send AJAX request to add to cart
    fetch('add_to_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Update cart count
            const cartCountBadge = document.getElementById('cartCountBadge');
            if (cartCountBadge) {
                cartCountBadge.textContent = data.cartCount;
            }
            
            // Add bounce animation to cart button
            const cartButton = document.querySelector('.cart-button');
            if (cartButton) {
                cartButton.classList.remove('bounce');
                void cartButton.offsetWidth; // Trigger reflow
                cartButton.classList.add('bounce');
            }
            
            // Show success toast
            Toastify({
                text: `Added ${quantity} ${quantity > 1 ? 'items' : 'item'} to cart`,
                duration: 3000,
                gravity: "bottom",
                position: "right",
                backgroundColor: "#4a934a",
                stopOnFocus: true,
                onClick: function() {
                    window.location.href = 'cart.php';
                }
            }).showToast();
            
            // Close modal if open
            if (typeof closeModal === 'function') {
                closeModal();
            }
        } else {
            // Show error toast
            Toastify({
                text: data.message || "Error adding to cart",
                duration: 3000,
                gravity: "bottom",
                position: "right",
                backgroundColor: "#e74c3c",
                stopOnFocus: true
            }).showToast();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Toastify({
            text: "Error adding to cart. Please try again.",
            duration: 3000,
            gravity: "bottom",
            position: "right",
            backgroundColor: "#e74c3c",
            stopOnFocus: true
        }).showToast();
    });
}
</script>
</body>
</html>
