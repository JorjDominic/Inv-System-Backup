<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login & Register - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <style>
        /* Styles for disabled verification */
        .verification-disabled {
            position: relative;
            background-color: #f8f8f8 !important;
            cursor: not-allowed;
        }
        
        .verification-disabled::after {
            content: "VERIFICATION DISABLED";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 14px;
            font-weight: bold;
            color: #e74c3c;
            pointer-events: none;
            text-align: center;
            width: 100%;
        }
        
        .verification-disabled input {
            opacity: 0.5;
        }
        
        /* Diagonal strikethrough line */
        .verification-disabled::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to right top, transparent 45%, #e74c3c 48%, #e74c3c 52%, transparent 55%);
            pointer-events: none;
        }
        
        /* Custom toast styling */
        .info-toast {
            z-index: 9999 !important;
            pointer-events: none !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="screen" id="screen">
            <!-- Background Shapes -->
            <div class="screen__background">
                <span class="screen__background__shape screen__background__shape4"></span>
                <span class="screen__background__shape screen__background__shape3"></span>
                <span class="screen__background__shape screen__background__shape2"></span>
                <span class="screen__background__shape screen__background__shape1"></span>
            </div>
            
            <!-- Login Form -->
            <div class="screen__content">
                <form id="loginForm" class="login" method="POST" action="login.php">
                    <img src="logo.jpg" class="logo" alt="Adriana's Marketing Logo">
                    <h2>Login</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user"></i>
                        <input type="text" name="username" class="login__input" placeholder="Username" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-lock"></i>
                        <input type="password" id="password" name="password" class="login__input" placeholder="Password" required>
                        <span id="loginToggle" class="password-toggle" onclick="togglePassword('password', 'loginToggle')"></span>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Log In Now</span>
                        <i class="button__icon fas fa-chevron-right"></i>
                    </button>
                    
                    <p class="forgot-password">
                        <a href="javascript:void(0);" onclick="showForgotPasswordNotification(); return false;">Forgot Password?</a>
                    </p>
                    
                    <p id="loginMessage" class="switch-form">
                        Don't have an account? <a href="javascript:void(0);" onclick="switchForm('register'); return false;">Register here</a>
                    </p>
                </form>
                
                <!-- Register Form -->
                <form id="registerForm" class="login" style="display: none;" method="POST" action="register.php">
                    <h2>Register</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user"></i>
                        <input type="text" name="username" id="username" class="login__input" placeholder="Username" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user-edit"></i>
                        <input type="text" name="firstname" id="firstname" class="login__input" placeholder="First Name" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-user-edit"></i>
                        <input type="text" name="lastname" id="lastname" class="login__input" placeholder="Last Name" required>
                    </div>

                    <div class="login__field">
                        <i class="login__icon fas fa-envelope"></i>
                        <input type="email" name="email" id="regemail" class="login__input" placeholder="Email" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-lock"></i>
                        <input type="password" name="password" id="regpassword" class="login__input" placeholder="Password" required>
                        <span id="registerToggle" class="password-toggle" onclick="togglePassword('regpassword', 'registerToggle')"></span>
                    </div>
                    
                    <div id="passwordStrength" class="strength-message">
                        <ul>
                            <li id="length" class="invalid"><span>✗</span> At least 8 characters</li>
                            <li id="lowercase" class="invalid"><span>✗</span> A lowercase letter</li>
                            <li id="uppercase" class="invalid"><span>✗</span> An uppercase letter</li>
                            <li id="number" class="invalid"><span>✗</span> A number</li>
                        </ul>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Register</span>
                        <i class="button__icon fas fa-chevron-right"></i>
                    </button>
                    
                    <p id="registerMessage" class="switch-form">
                        Already have an account? <a href="javascript:void(0);" onclick="switchForm('login'); return false;">Go back to login</a>
                    </p>

                </form>
                
                <!-- Verification Form (kept for reference but not used) -->
                <form id="verifyForm" class="login" style="display: none;" onsubmit="verifyAndRegister(); return false;">
                    <h2>Email Verification</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-envelope"></i>
                        <input type="email" id="email" class="login__input" placeholder="Enter Email" required>
                    </div>
                    
                    <button type="button" class="verification-btn" onclick="sendVerificationCode()">
                        <span class="button__text">Send Code</span>
                        <i class="button__icon fas fa-paper-plane"></i>
                    </button>
                    
                    <div class="login__field verification-disabled">
                        <i class="login__icon fas fa-key"></i>
                        <input type="text" id="code" class="login__input" placeholder="Verification disabled" disabled>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Verify & Register</span>
                        <i class="button__icon fas fa-chevron-right"></i>
                    </button>
                    
                    <p class="switch-form">
                        <a href="javascript:void(0);" onclick="switchForm('register'); return false;">Go back</a>
                    </p>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Variable to track if notification has been shown
        let verificationNotificationShown = false;
        
        // Switch between forms
        function switchForm(formType) {
            const loginForm = document.getElementById("loginForm");
            const registerForm = document.getElementById("registerForm");
            const verifyForm = document.getElementById("verifyForm");
            const screen = document.getElementById("screen");
            
            // Hide all forms first
            loginForm.style.display = "none";
            registerForm.style.display = "none";
            verifyForm.style.display = "none";
            
            // Show the requested form
            if (formType === "login") {
                loginForm.style.display = "block";
                screen.classList.remove("register-mode");
                screen.classList.remove("verify-mode");
            } else if (formType === "register") {
                registerForm.style.display = "block";
                screen.classList.add("register-mode");
                screen.classList.remove("verify-mode");
                
                // Show notification that email verification is disabled (only once)
                if (!verificationNotificationShown) {
                    // Use a longer delay to ensure the form is fully displayed
                    setTimeout(function() {
                        try {
                            Toastify({
                                text: "Email Verification is disabled",
                                duration: 5000,
                                gravity: "top",
                                position: "center",
                                backgroundColor: "#f39c12",
                                className: "info-toast",
                                stopOnFocus: true,
                                escapeMarkup: false,
                                close: false,
                                onClick: function(e) {
                                    // Prevent any default behavior
                                    e.preventDefault();
                                    e.stopPropagation();
                                    return false;
                                }
                            }).showToast();
                            verificationNotificationShown = true;
                        } catch (error) {
                            console.error("Error showing toast:", error);
                        }
                    }, 300);
                }
            } else if (formType === "verify") {
                verifyForm.style.display = "block";
                screen.classList.remove("register-mode");
                screen.classList.add("verify-mode");
            }
        }
        
        // Toggle password visibility
        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = document.getElementById(iconId);
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.add('show');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('show');
            }
        }
        
        // Password strength indicator
        document.addEventListener('DOMContentLoaded', function() {
            if (document.getElementById('regpassword')) {
                document.getElementById('regpassword').addEventListener('input', function() {
                    const password = this.value;
                    updatePasswordStrength(password);
                });
            }
            
            // Handle register form submission
            const registerForm = document.getElementById('registerForm');
            if (registerForm) {
                registerForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const username = document.getElementById('username').value;
                    const firstname = document.getElementById('firstname').value;
                    const lastname = document.getElementById('lastname').value;
                    const password = document.getElementById('regpassword').value;
                    const email = document.getElementById('regemail').value;
                    
                    // Validate username
                    const usernameRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
                    if (!usernameRegex.test(username)) {
                        Toastify({
                            text: "Username must be at least 8 characters long and contain at least one letter and one number.",
                            duration: 3000,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#e74c3c"
                        }).showToast();
                        return false;
                    }
                    
                    // Validate names
                    const nameRegex = /^[a-zA-Z]+$/;
                    if (!nameRegex.test(firstname) || !nameRegex.test(lastname)) {
                        Toastify({
                            text: "First Name and Last Name should only contain letters.",
                            duration: 3000,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#e74c3c"
                        }).showToast();
                        return false;
                    }
                    
                    // Validate password
                    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
                    if (!passwordRegex.test(password)) {
                        Toastify({
                            text: "Password must be at least 8 characters long and include:\n- 1 uppercase letter\n- 1 lowercase letter\n- 1 number",
                            duration: 3000,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#e74c3c"
                        }).showToast();
                        return false;
                    }
                    
                    // Validate email
                    if (!email || !isValidEmail(email)) {
                        Toastify({
                            text: "Please enter a valid email address.",
                            duration: 3000,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#e74c3c"
                        }).showToast();
                        return false;
                    }
                    
                    // Show loading state
                    const submitBtn = registerForm.querySelector('.login__submit');
                    const originalText = submitBtn.querySelector('.button__text').textContent;
                    submitBtn.querySelector('.button__text').textContent = 'Registering...';
                    submitBtn.disabled = true;
                    
                    // Submit the form via AJAX to prevent page reload
                    const formData = new FormData(registerForm);
                    
                    fetch('register.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Toastify({
                                text: data.message || "Registration successful!",
                                duration: 3000,
                                gravity: "top",
                                position: "center",
                                backgroundColor: "#2ecc71"
                            }).showToast();
                            
                            // Optionally switch to login form after successful registration
                            setTimeout(() => {
                                switchForm('login');
                            }, 3000);
                        } else {
                            // Check for specific errors and display them separately
                            if (data.errors) {
                                // Username error
                                if (data.errors.username) {
                                    Toastify({
                                        text: "Username error: " + data.errors.username,
                                        duration: 4000,
                                        gravity: "top",
                                        position: "center",
                                        backgroundColor: "#e74c3c"
                                    }).showToast();
                                }
                                
                                // Email error
                                if (data.errors.email) {
                                    setTimeout(() => {
                                        Toastify({
                                            text: "Email error: " + data.errors.email + "\nEmail verification is disabled",
                                            duration: 4000,
                                            gravity: "top",
                                            position: "center",
                                            backgroundColor: "#e74c3c"
                                        }).showToast();
                                    }, data.errors.username ? 1500 : 0); // Delay if username error is also shown
                                }
                                
                                // Other errors
                                if (!data.errors.username && !data.errors.email && data.message) {
                                    Toastify({
                                        text: data.message,
                                        duration: 3000,
                                        gravity: "top",
                                        position: "center",
                                        backgroundColor: "#e74c3c"
                                    }).showToast();
                                }
                            } else if (data.message) {
                                Toastify({
                                    text: data.message || "Registration failed. Please try again.",
                                    duration: 3000,
                                    gravity: "top",
                                    position: "center",
                                    backgroundColor: "#e74c3c"
                                }).showToast();
                            }
                            
                            // Reset the form button
                            submitBtn.querySelector('.button__text').textContent = originalText;
                            submitBtn.disabled = false;
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Toastify({
                            text: "An error occurred. Please try again.",
                            duration: 3000,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#e74c3c"
                        }).showToast();
                        
                        // Reset the form button
                        submitBtn.querySelector('.button__text').textContent = originalText;
                        submitBtn.disabled = false;
                    });
                });
            }
        });

        function updatePasswordStrength(password) {
            // Check each requirement
            const hasMinLength = password.length >= 8;
            const hasLowercase = /[a-z]/.test(password);
            const hasUppercase = /[A-Z]/.test(password);
            const hasNumber = /\d/.test(password);
            
            // Update UI for each requirement
            updateRequirement('length', hasMinLength);
            updateRequirement('lowercase', hasLowercase);
            updateRequirement('uppercase', hasUppercase);
            updateRequirement('number', hasNumber);
        }

        function updateRequirement(id, isValid) {
            const element = document.getElementById(id);
            if (!element) return;
            
            if (isValid) {
                element.classList.remove('invalid');
                element.classList.add('valid');
                element.querySelector('span').textContent = '✓';
            } else {
                element.classList.remove('valid');
                element.classList.add('invalid');
                element.querySelector('span').textContent = '✗';
            }
        }
        
        // Helper function to validate email
        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
        
        // Handle URL parameters for toast messages
        document.addEventListener("DOMContentLoaded", function () {
            const params = new URLSearchParams(window.location.search);
            const loginStatus = params.get("login");
            const toast = params.get("toast");
            const msg = params.get("msg");

            if (loginStatus === "success") {
                Toastify({
                    text: "Login successful!",
                    duration: 3000,
                    gravity: "top",
                    position: "center",
                    backgroundColor: "#2ecc71",
                    callback: function () {
                        // Clear the login param after toast disappears
                        clearUrlParams(['login']);
                    }
                }).showToast();
            } else if (loginStatus === "failed") {
                const errorMsg = params.get("error") || "Invalid username or password!";
                Toastify({
                    text: errorMsg,
                    duration: 3000,
                    gravity: "bottom",
                    position: "center",
                    backgroundColor: "#e74c3c",
                    callback: function () {
                        // Clear the login param after toast disappears
                        clearUrlParams(['login', 'error']);
                    }
                }).showToast();
                
                // If it's an email verification error, show additional notification
                if (errorMsg.includes("email") || errorMsg.includes("Email")) {
                    setTimeout(() => {
                        Toastify({
                            text: "Email verification is disabled",
                            duration: 3000,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#f39c12"
                        }).showToast();
                    }, 1500);
                }
            }
            
            // Handle toast messages from redirects
            if (toast && msg) {
                const bgColor = toast === "success" ? "#2ecc71" : "#e74c3c";
                Toastify({
                    text: decodeURIComponent(msg),
                    duration: 3000,
                    gravity: "top",
                    position: "center",
                    backgroundColor: bgColor,
                    callback: function () {
                        clearUrlParams(['toast', 'msg']);
                    }
                }).showToast();
            }

            function clearUrlParams(paramsToRemove) {
                if (window.history.replaceState) {
                    const url = new URL(window.location);
                    paramsToRemove.forEach(param => url.searchParams.delete(param));
                    window.history.replaceState({}, document.title, url.toString());
                }
            }
        });

        // Show notification for forgot password
        function showForgotPasswordNotification() {
            Toastify({
                text: "Email verification is disabled. Password reset functionality is not available.",
                duration: 4000,
                gravity: "top",
                position: "center",
                backgroundColor: "#f39c12",
                className: "info-toast",
                stopOnFocus: true
            }).showToast();
        }
    </script>
</body>
</html>
