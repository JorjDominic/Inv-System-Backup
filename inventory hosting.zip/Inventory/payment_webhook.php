<?php
// payment_webhook.php
require_once 'config/database.php';
require_once 'config/paymongo.php';
require_once 'notification.php';

// Get the JSON payload
$payload = file_get_contents('php://input');
$event = json_decode($payload, true);

// Log the webhook for debugging
error_log('PayMongo Webhook Received: ' . $payload);

// Verify the event
if (!$event || !isset($event['data']) || !isset($event['data']['attributes'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid payload']);
    exit;
}

try {
    // Extract data from the event
    $data = $event['data'];
    $attributes = $data['attributes'];
    $eventType = $event['type'] ?? '';
    
    error_log('PayMongo Event Type: ' . $eventType);
    
    // Store webhook in database for audit purposes
    $stmt = $conn->prepare("
        INSERT INTO PaymentWebhooks (
            EventType, PayloadData, Status
        ) VALUES (?, ?, 'received')
    ");
    $stmt->execute([$eventType, $payload]);
    $webhookId = $conn->lastInsertId();
    
    // Handle different event types
    if ($eventType === 'link.payment.paid' || $eventType === 'link.payment.failed') {
        // This is a payment link event
        $linkId = $attributes['link']['id'] ?? null;
        $isPaid = $eventType === 'link.payment.paid';
        
        if (!$linkId) {
            throw new Exception("Missing link ID in webhook payload");
        }
        
        error_log('Processing payment link event for link ID: ' . $linkId);
        
        // Find the order associated with this payment link
        $stmt = $conn->prepare("
            SELECT o.OrderID, o.CustomerID, o.TotalAmount 
            FROM PaymentLinks pl
            JOIN Orders o ON pl.OrderID = o.OrderID
            WHERE pl.LinkID = ?
        ");
        $stmt->execute([$linkId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            // Try to find by reference number as fallback
            $refNumber = $attributes['reference_number'] ?? null;
            if ($refNumber) {
                $stmt = $conn->prepare("
                    SELECT o.OrderID, o.CustomerID, o.TotalAmount 
                    FROM PaymentLinks pl
                    JOIN Orders o ON pl.OrderID = o.OrderID
                    WHERE pl.ReferenceNumber = ?
                ");
                $stmt->execute([$refNumber]);
                $order = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            if (!$order) {
                throw new Exception("Order not found for link ID: $linkId");
            }
        }
        
        error_log('Found order ID: ' . $order['OrderID']);
        
        // Update payment link status
        $stmt = $conn->prepare("
            UPDATE PaymentLinks 
            SET Status = ? 
            WHERE LinkID = ?
        ");
        $stmt->execute([$isPaid ? 'paid' : 'failed', $linkId]);
        
        // Find the transaction for this order
        $stmt = $conn->prepare("
            SELECT t.TransactionID, t.PaymentMethodID
            FROM Transactions t
            WHERE t.OrderID = ?
        ");
        $stmt->execute([$order['OrderID']]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($transaction) {
            // Update transaction status
            $stmt = $conn->prepare("
                UPDATE Transactions 
                SET Status = ? 
                WHERE TransactionID = ?
            ");
            $stmt->execute([$isPaid ? 'paid' : 'failed', $transaction['TransactionID']]);
            
            // Update payment method if available in the webhook data
            if ($isPaid && isset($attributes['payment_method_used'])) {
                updatePaymentMethod($conn, $transaction['TransactionID'], $attributes['payment_method_used']);
            }
        }
        
        // Update order status
        $stmt = $conn->prepare("
            UPDATE Orders 
            SET OrderStatus = ? 
            WHERE OrderID = ?
        ");
        $stmt->execute([$isPaid ? 'paid' : 'cancelled', $order['OrderID']]);
        
        // If payment was successful, send notification
        if ($isPaid) {
            // Get customer details
            $stmt = $conn->prepare("
                SELECT c.FirstName, c.LastName, c.Email, c.Phone
                FROM Customers c
                WHERE c.CustomerID = ?
            ");
            $stmt->execute([$order['CustomerID']]);
            $customer = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($customer && function_exists('send_notification')) {
                // Send payment confirmation notification
                $message = "Your payment for Order #{$order['OrderID']} has been received. Thank you for your purchase!";
                
                error_log('Payment notification sent to: ' . $customer['Email']);
            }
        }
    }
    
    // Update webhook status to processed
    $stmt = $conn->prepare("
        UPDATE PaymentWebhooks 
        SET Status = 'processed' 
        WHERE WebhookID = ?
    ");
    $stmt->execute([$webhookId]);
    
    // Log successful processing
    error_log('Webhook processed successfully');
    
    // Return success response
    http_response_code(200);
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    // Update webhook status to failed
    if (isset($webhookId)) {
        try {
            $stmt = $conn->prepare("
                UPDATE PaymentWebhooks 
                SET Status = 'failed', ErrorMessage = ? 
                WHERE WebhookID = ?
            ");
            $stmt->execute([$e->getMessage(), $webhookId]);
        } catch (Exception $updateError) {
            error_log('Failed to update webhook status: ' . $updateError->getMessage());
        }
    }
    
    error_log('Webhook Error: ' . $e->getMessage());
    error_log('Stack trace: ' . $e->getTraceAsString());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

/**
 * Update the payment method for a transaction based on the actual method used
 */
function updatePaymentMethod($conn, $transactionId, $paymentMethodUsed) {
    // Map PayMongo payment method to our payment method names
    $methodMap = [
        'card' => 'Card',
        'gcash' => 'GCash',
        'grab_pay' => 'GrabPay',
        'paymaya' => 'Maya',
        'dob' => 'Online Banking',
        'billease' => 'BillEase',
        'dob_ubp' => 'UnionBank',
        'dob_bpi' => 'BPI',
        // Add more mappings as needed
    ];
    
    $methodName = isset($methodMap[$paymentMethodUsed]) ? $methodMap[$paymentMethodUsed] : $paymentMethodUsed;
    
    // Find the payment method ID
    $stmt = $conn->prepare("
        SELECT PaymentMethodID 
        FROM PaymentMethods 
        WHERE MethodName = ?
    ");
    $stmt->execute([$methodName]);
    $method = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // If method doesn't exist, create it
    if (!$method) {
        // Try case-insensitive match
        $stmt = $conn->prepare("
            SELECT PaymentMethodID 
            FROM PaymentMethods 
            WHERE LOWER(MethodName) = LOWER(?)
        ");
        $stmt->execute([$methodName]);
        $method = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // If still not found, create it
        if (!$method) {
            $stmt = $conn->prepare("
                INSERT INTO PaymentMethods (
                    MethodName, Description, RequiresVerification
                ) VALUES (?, ?, TRUE)
            ");
            $stmt->execute([$methodName, "Payment method via PayMongo"]);
            $methodId = $conn->lastInsertId();
        } else {
            $methodId = $method['PaymentMethodID'];
        }
    } else {
        $methodId = $method['PaymentMethodID'];
    }
    
    // Update the transaction with the correct payment method
    $stmt = $conn->prepare("
        UPDATE Transactions 
        SET PaymentMethodID = ? 
        WHERE TransactionID = ?
    ");
    $stmt->execute([$methodId, $transactionId]);
    
    // Update the PaymongoTransactions table
    $stmt = $conn->prepare("
        UPDATE PaymongoTransactions 
        SET PaymentMethod = ? 
        WHERE TransactionID = ?
    ");
    $stmt->execute([$paymentMethodUsed, $transactionId]);
    
    error_log("Updated payment method for transaction $transactionId to $methodName (ID: $methodId)");
    
    return true;
}
?>
