<?php
session_start();
require('config/database.php');

// Security headers
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

// Get current date and time periods
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

// Default date range (current month)
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : $firstDayOfMonth;
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : $currentDate;

// Function to get report data based on type and date range - using the same function from reports.php
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            // Sales report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status IN ('paid', 'cancelled', 'refunded') 
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
            
        case 'refunds':
            // Refunds report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'refunded' 
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;

        case 'cancellations':
            // Cancellations report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'cancelled' 
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
        case 'inventory':
            // Inventory report query
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        default:
            $data = [];
            return $data;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        // Bind parameters based on report type
        switch ($reportType) {
            case 'inventory':
                $stmt->execute();
                break;
                
            default:
                $stmt->execute([$startDate, $endDate]);
                break;
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary data for certain report types
        if ($reportType === 'sales') {
            $totalSales = 0;
            foreach ($data as $sale) {
                if (isset($sale['TotalAmount'])) {
                    $totalSales += $sale['TotalAmount'];
                }
            }
            $data['summary'] = [
                'totalSales' => $totalSales,
                'transactionCount' => count($data)
            ];
        } elseif ($reportType === 'refunds') {
            $totalRefunds = 0;
            foreach ($data as $refund) {
                if (isset($refund['TotalAmount'])) {
                    $totalRefunds += $refund['TotalAmount'];
                }
            }
            $data['summary'] = [
                'totalRefunds' => $totalRefunds,
                'refundCount' => count($data)
            ];
        } elseif ($reportType === 'cancellations') {
            $totalCancellations = 0;
            foreach ($data as $cancellation) {
                if (isset($cancellation['TotalAmount'])) {
                    $totalCancellations += $cancellation['TotalAmount'];
                }
            }
            $data['summary'] = [
                'totalCancellations' => $totalCancellations,
                'cancellationCount' => count($data)
            ];
        } elseif ($reportType === 'inventory') {
            $totalValue = 0;
            $totalItems = 0;
            foreach ($data as $item) {
                if (isset($item['TotalValue'])) {
                    $totalValue += $item['TotalValue'];
                }
                if (isset($item['TotalQuantity'])) {
                    $totalItems += $item['TotalQuantity'];
                }
            }
            $data['summary'] = [
                'totalValue' => $totalValue,
                'totalItems' => $totalItems
            ];
        }
        
    } catch (PDOException $e) {
        // Handle error
        echo "Error: " . $e->getMessage();
    }
    
    return $data;
}

// Get inventory data by category
function getInventoryByCategory($conn) {
    $query = "SELECT 
                c.CategoryName, 
                SUM(i.Quantity) as TotalQuantity,
                SUM(i.Quantity * p.PurchasePrice) as TotalValue
              FROM Product p
              JOIN Inventory i ON p.ProductID = i.ProductID
              JOIN Category c ON p.CategoryID = c.CategoryID
              GROUP BY c.CategoryID
              ORDER BY c.CategoryName";
    
    try {
        $stmt = $conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return [];
    }
}

// Get low stock items
function getLowStockItems($conn, $threshold = 10) {
    $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
              SUM(i.Quantity) as TotalQuantity, 
              p.PurchasePrice, p.SellingPrice,
              (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
              FROM Product p
              JOIN Inventory i ON p.ProductID = i.ProductID
              JOIN Category c ON p.CategoryID = c.CategoryID
              GROUP BY p.ProductID
              HAVING TotalQuantity <= ?
              ORDER BY TotalQuantity ASC";
    
    try {
        $stmt = $conn->prepare($query);
        $stmt->execute([$threshold]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return [];
    }
}

// Fetch data for the selected period
$salesData = getReportData($conn, 'sales', $startDate, $endDate);
$refundsData = getReportData($conn, 'refunds', $startDate, $endDate);
$cancellationsData = getReportData($conn, 'cancellations', $startDate, $endDate);
$inventoryData = getReportData($conn, 'inventory', $startDate, $endDate);
$inventoryByCategory = getInventoryByCategory($conn);
$lowStockItems = getLowStockItems($conn);

// Calculate summary totals
$totalSales = isset($salesData['summary']['totalSales']) ? $salesData['summary']['totalSales'] : 0;
$salesCount = isset($salesData['summary']['transactionCount']) ? $salesData['summary']['transactionCount'] : 0;
$totalRefunds = isset($refundsData['summary']['totalRefunds']) ? $refundsData['summary']['totalRefunds'] : 0;
$refundsCount = isset($refundsData['summary']['refundCount']) ? $refundsData['summary']['refundCount'] : 0;
$totalCancellations = isset($cancellationsData['summary']['totalCancellations']) ? $cancellationsData['summary']['totalCancellations'] : 0;
$cancellationsCount = isset($cancellationsData['summary']['cancellationCount']) ? $cancellationsData['summary']['cancellationCount'] : 0;

// Prepare data for transaction types bar chart
$transactionTypes = ['Sales', 'Refunds', 'Cancellations'];
$transactionAmounts = [$totalSales, $totalRefunds, $totalCancellations];
$transactionCounts = [$salesCount, $refundsCount, $cancellationsCount];

// Process inventory data for chart
$inventoryLabels = [];
$inventoryData = [];

foreach ($inventoryByCategory as $category) {
    $inventoryLabels[] = $category['CategoryName'];
    $inventoryData[] = $category['TotalValue'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Business Analytics - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #4a934a;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --border-radius: 8px;
            --border-radius-sm: 4px;
            --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 8px rgba(0, 0, 0, 0.1);
            --text-dark: #333;
            --text-medium: #666;
            --text-light: #999;
        }
        
        .analytics-container {
            padding: 20px;
        }
        
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .filter-form {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-sm);
            font-family: 'Poppins', sans-serif;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .dashboard-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        
        .card-header {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .card-title {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .card-body {
            flex: 1;
        }
        
        .chart-container {
            width: 100%;
            height: 300px;
        }
        
        .full-width {
            grid-column: 1 / -1;
        }
        
        .half-width {
            grid-column: span 2;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th, .data-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .data-table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .data-table tr:last-child td {
            border-bottom: none;
        }
        
        .low-stock {
            color: var(--danger-color);
        }
        
        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .half-width {
                grid-column: span 1;
            }
            
            .form-row {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="analytics-container">
                <div class="page-header">
                    <h1>Business Analytics</h1>
                    <a href="reports.php" class="btn btn-secondary">Back to Reports</a>
                </div>
                
                <div class="filter-form">
                    <form method="GET" action="">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" 
                                       value="<?= $startDate ?>" max="<?= $currentDate ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" 
                                       value="<?= $endDate ?>" max="<?= $currentDate ?>">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Analytics</button>
                    </form>
                </div>
                
                <!-- Transaction Types Bar Chart -->
                <div class="dashboard-grid">
                    <div class="dashboard-card full-width">
                        <div class="card-header">
                            <h3 class="card-title">Transaction Summary</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="transactionTypesChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Inventory by Category Chart -->
                <div class="dashboard-grid">
                    <div class="dashboard-card full-width">
                        <div class="card-header">
                            <h3 class="card-title">Inventory by Category</h3>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="inventoryCategoryChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Low Stock Items -->
                <div class="dashboard-grid">
                    <div class="dashboard-card full-width">
                        <div class="card-header">
                            <h3 class="card-title">Low Stock Items</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Current Stock</th>
                                            <th>Purchase Price</th>
                                            <th>Selling Price</th>
                                            <th>Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($lowStockItems as $item): ?>
                                            <tr>
                                                <td><?= $item['ProductID'] ?></td>
                                                <td><?= htmlspecialchars($item['ProductName']) ?></td>
                                                <td><?= htmlspecialchars($item['CategoryName']) ?></td>
                                                <td class="low-stock"><?= $item['TotalQuantity'] ?></td>
                                                <td>₱<?= number_format($item['PurchasePrice'], 2) ?></td>
                                                <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
                                                <td>₱<?= number_format($item['TotalValue'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($lowStockItems)): ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No low stock items found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        // Initialize charts when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            // Transaction Types Bar Chart
            const transactionTypesCtx = document.getElementById('transactionTypesChart').getContext('2d');
            const transactionTypesChart = new Chart(transactionTypesCtx, {
                type: 'bar',
                data: {
                    labels: <?= json_encode($transactionTypes) ?>,
                    datasets: [
                        {
                            label: 'Amount (₱)',
                            data: <?= json_encode($transactionAmounts) ?>,
                            backgroundColor: [
                                'rgba(74, 147, 74, 0.7)',
                                'rgba(220, 53, 69, 0.7)',
                                'rgba(255, 193, 7, 0.7)'
                            ],
                            borderColor: [
                                'rgba(74, 147, 74, 1)',
                                'rgba(220, 53, 69, 1)',
                                'rgba(255, 193, 7, 1)'
                            ],
                            borderWidth: 1,
                            yAxisID: 'y'
                        },
                        {
                            label: 'Count',
                            data: <?= json_encode($transactionCounts) ?>,
                            backgroundColor: [
                                'rgba(74, 147, 74, 0.3)',
                                'rgba(220, 53, 69, 0.3)',
                                'rgba(255, 193, 7, 0.3)'
                            ],
                            borderColor: [
                                'rgba(74, 147, 74, 1)',
                                'rgba(220, 53, 69, 1)',
                                'rgba(255, 193, 7, 1)'
                            ],
                            borderWidth: 1,
                            yAxisID: 'y1'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: 'Amount (₱)'
                            },
                            ticks: {
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                }
                            }
                        },
                        y1: {
                            type: 'linear',
                            display: true,
                            position: 'right',
                            title: {
                                display: true,
                                text: 'Count'
                            },
                            grid: {
                                drawOnChartArea: false
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.dataset.label || '';
                                    const value = context.raw || 0;
                                    if (label === 'Amount (₱)') {
                                        return label + ': ₱' + value.toLocaleString();
                                    } else {
                                        return label + ': ' + value;
                                    }
                                }
                            }
                        }
                    }
                }
            });
            
            // Inventory Category Chart
            const inventoryCategoryCtx = document.getElementById('inventoryCategoryChart').getContext('2d');
            const inventoryCategoryChart = new Chart(inventoryCategoryCtx, {
                type: 'pie',
                data: {
                    labels: <?= json_encode($inventoryLabels) ?>,
                    datasets: [{
                        data: <?= json_encode($inventoryData) ?>,
                        backgroundColor: [
                            'rgba(74, 147, 74, 0.7)',
                            'rgba(54, 162, 235, 0.7)',
                            'rgba(255, 206, 86, 0.7)',
                            'rgba(75, 192, 192, 0.7)',
                            'rgba(153, 102, 255, 0.7)',
                            'rgba(255, 159, 64, 0.7)',
                            'rgba(201, 203, 207, 0.7)',
                            'rgba(255, 99, 132, 0.7)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: ₱${value.toLocaleString()} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>