<?php
session_start();
require('config/database.php');

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}

// Include TCPDF library
require_once('includes/tcpdf/tcpdf/tcpdf.php');

// Get parameters from URL
$reportType = $_GET['report_type'] ?? 'sales';
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Define report types
$reportTypes = [
    'sales' => 'Sales Report',
    'refunds' => 'Refunds Report',
    'cancellations' => 'Cancellations Report',
    'inventory' => 'Inventory Report'
];

// Create new PDF document
class MYPDF extends TCPDF {
    // Page header
    public function Header() {
        // Logo
        $image_file = 'images/logo.png';
        if (file_exists($image_file)) {
            $this->Image($image_file, 10, 10, 30, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        }
        
        // Set font
        $this->SetFont('helvetica', 'B', 16);
        // Title
        $this->Cell(0, 15, 'Adriana\'s Marketing', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        $this->Ln(10);
        
        // Report title and date range
        $this->SetFont('helvetica', 'B', 12);
        $this->Cell(0, 10, $this->reportTitle, 0, 1, 'C');
        $this->SetFont('helvetica', '', 10);
        $this->Cell(0, 5, 'Period: ' . $this->dateRange, 0, 1, 'C');
        
        // Line break
        $this->Ln(5);
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
        // Generation timestamp
        $this->Cell(0, 10, 'Generated on: ' . date('m/d/Y H:i'), 0, false, 'R');
    }
}

// Create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set custom properties
$pdf->reportTitle = $reportTypes[$reportType];
$pdf->dateRange = date('F d, Y', strtotime($startDate)) . ' to ' . date('F d, Y', strtotime($endDate));

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Adriana\'s Marketing');
$pdf->SetTitle($reportTypes[$reportType]);
$pdf->SetSubject($reportTypes[$reportType]);
$pdf->SetKeywords('Report, PDF, Inventory, Sales, Refunds, Cancellations');

// Set margins
$pdf->SetMargins(15, 40, 15);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(15);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, 25);

// Add a page
$pdf->AddPage();

// Function to get report data
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      t.TransactionType, COUNT(od.OrderDetailID) as ItemCount, 
                      pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'paid' 
                      AND t.CreatedAt >= ? AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
            
        case 'refunds':
            $query = "SELECT ri.RefundID, p.ProductName, ri.QuantityRefunded, 
                      ri.ItemCondition, ri.RefundedAt, 
                      CONCAT(u.FirstName, ' ', u.LastName) as ProcessedBy,
                      (od.Price * ri.QuantityRefunded) as RefundAmount,
                      t.TransactionID as ReceiptID
                      FROM RefundedItems ri
                      JOIN Product p ON ri.ProductID = p.ProductID
                      JOIN Users u ON ri.ProcessedBy = u.UserID
                      JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                      JOIN Orders o ON ri.OrderID = o.OrderID
                      JOIN Transactions t ON o.OrderID = t.OrderID
                      WHERE ri.RefundedAt BETWEEN ? AND ?
                      ORDER BY ri.RefundedAt DESC";
            break;

        case 'cancellations':
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      t.TransactionType, COUNT(od.OrderDetailID) as ItemCount,
                      pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier, r.Reason as CancellationReason
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      LEFT JOIN Refunds r ON t.TransactionID = r.TransactionID
                      WHERE t.Status = 'cancelled' 
                      AND t.CreatedAt >= ? AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;

        case 'inventory':
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        default:
            return $data;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        if ($reportType === 'inventory') {
            $stmt->execute();
        } else {
            $stmt->execute([$startDate, $endDate]);
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary data
        $summary = [];
        switch ($reportType) {
            case 'sales':
                $summary['totalAmount'] = array_sum(array_column($data, 'TotalAmount'));
                $summary['count'] = count($data);
                break;
                
            case 'refunds':
                $summary['totalAmount'] = array_sum(array_column($data, 'RefundAmount'));
                $summary['count'] = count($data);
                break;
                
            case 'cancellations':
                $summary['totalAmount'] = array_sum(array_column($data, 'TotalAmount'));
                $summary['count'] = count($data);
                break;
                
            case 'inventory':
                $summary['totalValue'] = array_sum(array_column($data, 'TotalValue'));
                $summary['totalItems'] = array_sum(array_column($data, 'TotalQuantity'));
                break;
        }
        
        $data['summary'] = $summary;
        
    } catch (PDOException $e) {
        error_log("Error generating report: " . $e->getMessage());
    }
    
    return $data;
}

// Get report data
$reportData = getReportData($conn, $reportType, $startDate, $endDate);

// Generate report content
$pdf->SetFont('helvetica', '', 9);

switch ($reportType) {
    case 'sales':
        // Sales Report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(20, 7, 'Trans ID', 1, 0, 'C');
        $pdf->Cell(25, 7, 'Date', 1, 0, 'C');
        $pdf->Cell(15, 7, 'Items', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Payment', 1, 0, 'C');
        $pdf->Cell(50, 7, 'Cashier', 1, 0, 'C');
        $pdf->Cell(25, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        foreach ($reportData as $key => $sale) {
            if ($key !== 'summary') {
                $pdf->Cell(20, 6, $sale['TransactionID'], 1);
                $pdf->Cell(25, 6, date('m/d/Y', strtotime($sale['DateIssued'])), 1);
                $pdf->Cell(15, 6, $sale['ItemCount'], 1, 0, 'C');
                $pdf->Cell(30, 6, $sale['PaymentMethod'], 1);
                $pdf->Cell(50, 6, $sale['Cashier'], 1);
                $pdf->Cell(25, 6, '₱' . number_format($sale['TotalAmount'], 2), 1, 1, 'R');
            }
        }
        
        // Summary
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(140, 7, 'Total Sales:', 1, 0, 'R');
        $pdf->Cell(25, 7, '₱' . number_format($reportData['summary']['totalAmount'], 2), 1, 1, 'R');
        $pdf->Cell(140, 7, 'Transactions:', 1, 0, 'R');
        $pdf->Cell(25, 7, $reportData['summary']['count'], 1, 1, 'R');
        break;
        
    case 'refunds':
        // Refunds Report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Receipt', 1, 0, 'C');
        $pdf->Cell(50, 7, 'Product', 1, 0, 'C');
        $pdf->Cell(15, 7, 'Qty', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Condition', 1, 0, 'C');
        $pdf->Cell(40, 7, 'Processed By', 1, 0, 'C');
        $pdf->Cell(25, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        foreach ($reportData as $key => $refund) {
            if ($key !== 'summary') {
                $pdf->Cell(15, 6, $refund['RefundID'], 1);
                $pdf->Cell(20, 6, $refund['ReceiptID'], 1);
                $pdf->Cell(50, 6, $refund['ProductName'], 1);
                $pdf->Cell(15, 6, $refund['QuantityRefunded'], 1, 0, 'C');
                $pdf->Cell(20, 6, $refund['ItemCondition'], 1);
                $pdf->Cell(40, 6, $refund['ProcessedBy'], 1);
                $pdf->Cell(25, 6, '₱' . number_format($refund['RefundAmount'], 2), 1, 1, 'R');
            }
        }
        
        // Summary
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(160, 7, 'Total Refunds:', 1, 0, 'R');
        $pdf->Cell(25, 7, '₱' . number_format($reportData['summary']['totalAmount'], 2), 1, 1, 'R');
        $pdf->Cell(160, 7, 'Refund Count:', 1, 0, 'R');
        $pdf->Cell(25, 7, $reportData['summary']['count'], 1, 1, 'R');
        break;
        
    case 'cancellations':
        // Cancellations Report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(20, 7, 'Trans ID', 1, 0, 'C');
        $pdf->Cell(25, 7, 'Date', 1, 0, 'C');
        $pdf->Cell(15, 7, 'Items', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Payment', 1, 0, 'C');
        $pdf->Cell(50, 7, 'Cashier', 1, 0, 'C');
        $pdf->Cell(25, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        foreach ($reportData as $key => $cancellation) {
            if ($key !== 'summary') {
                $pdf->Cell(20, 6, $cancellation['TransactionID'], 1);
                $pdf->Cell(25, 6, date('m/d/Y', strtotime($cancellation['DateIssued'])), 1);
                $pdf->Cell(15, 6, $cancellation['ItemCount'], 1, 0, 'C');
                $pdf->Cell(30, 6, $cancellation['PaymentMethod'], 1);
                $pdf->Cell(50, 6, $cancellation['Cashier'], 1);
                $pdf->Cell(25, 6, '₱' . number_format($cancellation['TotalAmount'], 2), 1, 1, 'R');
            }
        }
        
        // Summary
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(140, 7, 'Total Cancelled:', 1, 0, 'R');
        $pdf->Cell(25, 7, '₱' . number_format($reportData['summary']['totalAmount'], 2), 1, 1, 'R');
        $pdf->Cell(140, 7, 'Cancellations:', 1, 0, 'R');
        $pdf->Cell(25, 7, $reportData['summary']['count'], 1, 1, 'R');
        break;
        
    case 'inventory':
        // Inventory Report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Product', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Category', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Qty', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Cost', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Value', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        foreach ($reportData as $key => $item) {
            if ($key !== 'summary') {
                $pdf->Cell(15, 6, $item['ProductID'], 1);
                $pdf->Cell(60, 6, $item['ProductName'], 1);
                $pdf->Cell(30, 6, $item['CategoryName'], 1);
                $pdf->Cell(20, 6, $item['TotalQuantity'], 1, 0, 'C');
                $pdf->Cell(30, 6, '₱' . number_format($item['PurchasePrice'], 2), 1, 0, 'R');
                $pdf->Cell(30, 6, '₱' . number_format($item['TotalValue'], 2), 1, 1, 'R');
            }
        }
        
        // Summary
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(125, 7, 'Total Inventory Value:', 1, 0, 'R');
        $pdf->Cell(30, 7, '₱' . number_format($reportData['summary']['totalValue'], 2), 1, 1, 'R');
        $pdf->Cell(125, 7, 'Total Items:', 1, 0, 'R');
        $pdf->Cell(30, 7, $reportData['summary']['totalItems'], 1, 1, 'R');
        break;
}

// Output the PDF
$pdf->Output($reportTypes[$reportType] . '_' . date('Y-m-d') . '.pdf', 'D');
?>