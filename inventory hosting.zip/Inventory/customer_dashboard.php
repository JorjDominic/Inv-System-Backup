<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is a customer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 5) {
  header('Location: index.php');
  exit;
}
session_regenerate_id(true);

// Get current date and time
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');

// Get customer ID from user ID
$customerQuery = "SELECT CustomerID, FirstName, LastName, Email, Phone, Address, City, ZipCode 
                FROM Customers 
                WHERE UserID = ?";
$customerStmt = $conn->prepare($customerQuery);
$customerStmt->execute([$_SESSION['user_id']]);
$customerData = $customerStmt->fetch(PDO::FETCH_ASSOC);
$customerID = $customerData['CustomerID'] ?? null;
$userQuery = "SELECT UserID, Username, FirstName, LastName, Email, RoleID 
              FROM Users 
              WHERE UserID = ? AND RoleID = 5";
$userStmt = $conn->prepare($userQuery);
$userStmt->execute([$_SESSION['user_id']]);
$userData = $userStmt->fetch(PDO::FETCH_ASSOC);

$userID = $userData['UserID'];
// Fetch recent orders (last 30 days)
$recentOrdersQuery = "SELECT o.OrderID, o.OrderDate, o.OrderStatus, o.TotalAmount, 
                    o.PickupDate, o.PickupTime, o.PickupCode,
                    COUNT(od.OrderDetailID) as ItemCount
                    FROM Orders o
                    LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                    WHERE o.CustomerID = ? 
                    AND o.OrderDate >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
                    GROUP BY o.OrderID
                    ORDER BY o.OrderDate DESC
                    LIMIT 5";
$recentOrdersStmt = $conn->prepare($recentOrdersQuery);
$recentOrdersStmt->execute([$customerID]);
$recentOrders = $recentOrdersStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch order status counts
$orderStatusQuery = "SELECT OrderStatus, COUNT(*) as StatusCount
                  FROM Orders
                  WHERE CustomerID = ?
                  GROUP BY OrderStatus";
$orderStatusStmt = $conn->prepare($orderStatusQuery);
$orderStatusStmt->execute([$customerID]);
$orderStatusCounts = $orderStatusStmt->fetchAll(PDO::FETCH_ASSOC);

// Format order status counts into an associative array
$statusCounts = [
    'pending' => 0,
    'paid' => 0,
    'preparing' => 0,
    'ready_for_pickup' => 0,
    'completed' => 0,
    'cancelled' => 0,
    'refunded' => 0
];

foreach ($orderStatusCounts as $status) {
    $statusCounts[$status['OrderStatus']] = $status['StatusCount'];
}

// Fetch pending pickups (paid or ready for pickup)
$pendingPickupsQuery = "SELECT o.OrderID, o.OrderDate, o.OrderStatus, o.TotalAmount, 
                      o.PickupDate, o.PickupTime, o.PickupCode
                      FROM Orders o
                      WHERE o.CustomerID = ? 
                      AND o.OrderStatus IN ('paid', 'ready_for_pickup')
                      ORDER BY o.PickupDate ASC, o.PickupTime ASC
                      LIMIT 5";
$pendingPickupsStmt = $conn->prepare($pendingPickupsQuery);
$pendingPickupsStmt->execute([$customerID]);
$pendingPickups = $pendingPickupsStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch recently purchased products
$recentProductsQuery = "SELECT p.ProductName, od.Quantity, od.Price, o.OrderDate
                      FROM OrderDetails od
                      JOIN Orders o ON od.OrderID = o.OrderID
                      JOIN Product p ON od.ProductID = p.ProductID
                      WHERE o.CustomerID = ?
                      AND o.OrderStatus IN ('paid', 'preparing', 'ready_for_pickup', 'completed')
                      ORDER BY o.OrderDate DESC
                      LIMIT 5";
$recentProductsStmt = $conn->prepare($recentProductsQuery);
$recentProductsStmt->execute([$customerID]);
$recentProducts = $recentProductsStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch refund history
$refundsQuery = "SELECT ri.RefundID, p.ProductName, ri.QuantityRefunded, 
                ri.ItemCondition, ri.RefundedAt, o.OrderID
                FROM RefundedItems ri
                JOIN Orders o ON ri.OrderID = o.OrderID
                JOIN Product p ON ri.ProductID = p.ProductID
                WHERE o.CustomerID = ?
                ORDER BY ri.RefundedAt DESC
                LIMIT 5";
$refundsStmt = $conn->prepare($refundsQuery);
$refundsStmt->execute([$customerID]);
$refunds = $refundsStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total spent
$totalSpentQuery = "SELECT SUM(t.Amount) as TotalSpent
                 FROM Transactions t
                 JOIN Orders o ON t.OrderID = o.OrderID
                 WHERE o.CustomerID = ?
                 AND t.Status = 'paid'";
$totalSpentStmt = $conn->prepare($totalSpentQuery);
$totalSpentStmt->execute([$customerID]);
$totalSpent = $totalSpentStmt->fetch(PDO::FETCH_ASSOC)['TotalSpent'] ?? 0;

// Calculate total orders
$totalOrdersQuery = "SELECT COUNT(*) as TotalOrders
                  FROM Orders
                  WHERE CustomerID = ?";
$totalOrdersStmt = $conn->prepare($totalOrdersQuery);
$totalOrdersStmt->execute([$customerID]);
$totalOrders = $totalOrdersStmt->fetch(PDO::FETCH_ASSOC)['TotalOrders'] ?? 0;

// Get frequently purchased products
$frequentProductsQuery = "SELECT p.ProductName, SUM(od.Quantity) as TotalQuantity, 
                        COUNT(DISTINCT o.OrderID) as OrderCount
                        FROM OrderDetails od
                        JOIN Orders o ON od.OrderID = o.OrderID
                        JOIN Product p ON od.ProductID = p.ProductID
                        WHERE o.CustomerID = ?
                        AND o.OrderStatus IN ('paid', 'preparing', 'ready_for_pickup', 'completed')
                        GROUP BY p.ProductID
                        ORDER BY TotalQuantity DESC
                        LIMIT 5";
$frequentProductsStmt = $conn->prepare($frequentProductsQuery);
$frequentProductsStmt->execute([$customerID]);
$frequentProducts = $frequentProductsStmt->fetchAll(PDO::FETCH_ASSOC);

// Get payment methods used
$paymentMethodsQuery = "SELECT pm.MethodName, COUNT(t.TransactionID) as UseCount
                     FROM Transactions t
                     JOIN Orders o ON t.OrderID = o.OrderID
                     JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                     WHERE o.CustomerID = ?
                     AND t.Status = 'paid'
                     GROUP BY pm.PaymentMethodID
                     ORDER BY UseCount DESC";
$paymentMethodsStmt = $conn->prepare($paymentMethodsQuery);
$paymentMethodsStmt->execute([$customerID]);
$paymentMethods = $paymentMethodsStmt->fetchAll(PDO::FETCH_ASSOC);

// Get notifications
$notificationsQuery = "SELECT NotificationID, NotificationType, Message, CreatedAt, IsRead
                    FROM Notifications
                    WHERE UserID = ?
                    ORDER BY CreatedAt DESC
                    LIMIT 5";
$notificationsStmt = $conn->prepare($notificationsQuery);
$notificationsStmt->execute([$_SESSION['user_id']]);
$notifications = $notificationsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Customer Dashboard - Adriana's Marketing</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
      /* Dashboard Styles */
      .dashboard-container {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
          padding: 20px;
      }
      
      .dashboard-card {
          background-color: white;
          border-radius: var(--border-radius);
          box-shadow: var(--shadow-sm);
          padding: 20px;
          position: relative;
          overflow: hidden;
      }
      
      .dashboard-card h3 {
          margin-top: 0;
          color: var(--text-dark);
          font-size: 1.2rem;
          font-weight: 600;
          margin-bottom: 15px;
          display: flex;
          align-items: center;
      }
      
      .dashboard-card h3 svg {
          margin-right: 10px;
          width: 24px;
          height: 24px;
      }
      
      .dashboard-card.orders {
          border-left: 4px solid #3498db;
      }
      
      .dashboard-card.pickups {
          border-left: 4px solid #f39c12;
      }
      
      .dashboard-card.products {
          border-left: 4px solid #2ecc71;
      }
      
      .dashboard-card.refunds {
          border-left: 4px solid #e74c3c;
      }
      
      .dashboard-card.profile {
          border-left: 4px solid #9b59b6;
      }
      
      .dashboard-card.notifications {
          border-left: 4px solid #e67e22;
      }
      
      .dashboard-card.payment {
          border-left: 4px solid #1abc9c;
      }
      
      .welcome-header {
          background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
          color: white;
          padding: 30px;
          border-radius: var(--border-radius);
          margin-bottom: 20px;
          box-shadow: var(--shadow-md);
      }
      
      .welcome-header h1 {
          margin: 0;
          font-size: 1.8rem;
          font-weight: 600;
          color: white;
      }
      
      .welcome-header p {
          margin: 10px 0 0;
          opacity: 0.9;
          font-size: 1rem;
      }
      
      .stat-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 15px;
          margin-top: 20px;
      }
      
      .stat-card {
          background-color: rgba(255, 255, 255, 0.1);
          padding: 15px;
          border-radius: var(--border-radius-sm);
          text-align: center;
      }
      
      .stat-card h3 {
          margin: 0;
          font-size: 1.8rem;
          font-weight: 700;
          color: white;
      }
      
      .stat-card p {
          margin: 5px 0 0;
          font-size: 0.9rem;
          opacity: 0.8;
      }
      
      .item-list {
          list-style: none;
          padding: 0;
          margin: 0;
      }
      
      .item-list li {
          padding: 10px 0;
          border-bottom: 1px solid #f0f0f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
      }
      
      .item-list li:last-child {
          border-bottom: none;
      }
      
      .item-name {
          font-weight: 500;
          color: var(--text-dark);
      }
      
      .item-detail {
          color: var(--text-medium);
          font-size: 0.9rem;
      }
      
      .badge {
          display: inline-block;
          padding: 3px 8px;
          border-radius: 12px;
          font-size: 0.75rem;
          font-weight: 500;
      }
      
      .badge-warning {
          background-color: #f39c12;
          color: #fff;
      }
      
      .badge-success {
          background-color: #d4edda;
          color: #155724;
      }
      
      .badge-info {
          background-color: #d1ecf1;
          color: #0c5460;
      }
      
      .badge-danger {
          background-color: #f8d7da;
          color: #721c24;
      }
      
      .badge-primary {
          background-color: #cce5ff;
          color: #004085;
      }
      
      .badge-orange {
          background-color: #ffe5d0;
          color: #d35400;
      }
      
      .badge-purple {
          background-color: #e8daef;
          color: #8e44ad;
      }
      
      .badge-pending {
          background-color: #fff3cd;
          color: #856404;
      }
      
      .badge-paid {
          background-color: #d1ecf1;
          color: #0c5460;
      }
      
      .badge-preparing {
          background-color: #d6d8d9;
          color: #383d41;
      }
      
      .badge-ready {
          background-color: #d4edda;
          color: #155724;
      }
      
      .badge-completed {
          background-color: #c3e6cb;
          color: #155724;
      }
      
      .badge-cancelled {
          background-color: #f8d7da;
          color: #721c24;
      }
      
      .badge-refunded {
          background-color: #f5c6cb;
          color: #721c24;
      }
      
      .view-all {
          display: block;
          text-align: center;
          margin-top: 15px;
          color: var(--primary-color);
          text-decoration: none;
          font-size: 0.9rem;
          font-weight: 500;
      }
      
      .view-all:hover {
          text-decoration: underline;
      }
      
      .date-display {
          font-size: 1rem;
          color: rgba(255, 255, 255, 0.8);
          margin-top: 5px;
      }
      
      .empty-state {
          text-align: center;
          padding: 20px 0;
          color: var(--text-light);
          font-style: italic;
      }
      
      .status-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
          gap: 10px;
          margin-top: 15px;
      }
      
      .status-item {
          text-align: center;
          padding: 10px;
          border-radius: var(--border-radius-sm);
          background-color: #f8f9fa;
      }
      
      .status-count {
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text-dark);
          margin-bottom: 5px;
      }
      
      .status-label {
          font-size: 0.8rem;
          color: var(--text-medium);
      }
      
      .profile-info {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 15px;
      }
      
      .profile-field {
          margin-bottom: 15px;
      }
      
      .profile-label {
          font-size: 0.8rem;
          color: var(--text-medium);
          margin-bottom: 5px;
      }
      
      .profile-value {
          font-size: 1rem;
          color: var(--text-dark);
          font-weight: 500;
      }
      
      .notification-unread {
          background-color: #f8f9fa;
      }
      
      .notification-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background-color: var(--primary-color);
          display: inline-block;
          margin-right: 5px;
      }
      
      .btn-primary {
          background-color: var(--primary-color);
          color: white;
          border: none;
          padding: 8px 16px;
          border-radius: var(--border-radius-sm);
          cursor: pointer;
          font-weight: 500;
          text-decoration: none;
          display: inline-block;
          font-size: 0.9rem;
      }
      
      .btn-primary:hover {
          background-color: var(--primary-dark);
      }
      
      @media (max-width: 768px) {
          .dashboard-container {
              grid-template-columns: 1fr;
          }
          
          .welcome-header {
              padding: 20px;
          }
          
          .welcome-header h1 {
              font-size: 1.5rem;
          }
          
          .stat-grid {
              grid-template-columns: repeat(2, 1fr);
          }
          
          .profile-info {
              grid-template-columns: 1fr;
          }
      }
  </style>
</head>
<body>
  <?php include 'sidebar.php'; ?>
  <?php include 'navbar.php'; ?>

  <div class="main-content-wrapper">
      <main class="content">
          <!-- Welcome Header with Stats -->
          <div class="welcome-header">
          <h1>Welcome, <?= htmlspecialchars($userData['FirstName'] . ' ' . $userData['LastName']) ?></h1>
              <p class="date-display"><?= date('l, F j, Y') ?></p>
              
              <div class="stat-grid">
                  <div class="stat-card">
                      <h3><?= $totalOrders ?></h3>
                      <p>Total Orders</p>
                  </div>
                  <div class="stat-card">
                      <h3>₱<?= number_format($totalSpent, 2) ?></h3>
                      <p>Total Spent</p>
                  </div>
                  <div class="stat-card">
                      <h3><?= $statusCounts['pending'] + $statusCounts['paid'] + $statusCounts['preparing'] + $statusCounts['ready_for_pickup'] ?></h3>
                      <p>Active Orders</p>
                  </div>
              </div>
          </div>
          
          <div class="dashboard-container">
              <!-- Recent Orders Card -->
              <div class="dashboard-card orders">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <circle cx="9" cy="21" r="1"></circle>
                          <circle cx="20" cy="21" r="1"></circle>
                          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                      </svg>
                      Recent Orders
                  </h3>
                  <?php if (count($recentOrders) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentOrders as $order): ?>
                              <li>
                                  <div>
                                      <span class="item-name">Order #<?= $order['OrderID'] ?></span>
                                      <div class="item-detail">
                                          <?= date('M d, Y', strtotime($order['OrderDate'])) ?> • 
                                          <?= $order['ItemCount'] ?> items
                                      </div>
                                  </div>
                                  <div>
                                      <span class="badge badge-<?= strtolower($order['OrderStatus']) ?>">
                                          <?= ucfirst($order['OrderStatus']) ?>
                                      </span>
                                      <div class="item-detail text-right">₱<?= number_format($order['TotalAmount'], 2) ?></div>
                                  </div>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="customer_orders.php" class="view-all">View Order History</a>
                  <?php else: ?>
                      <div class="empty-state">You haven't placed any orders yet.</div>
                      <a href="shop.php" class="btn-primary" style="display: block; text-align: center; margin-top: 15px;">Start Shopping</a>
                  <?php endif; ?>
              </div>
              
              <!-- Order Status Card -->
              <div class="dashboard-card orders">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline>
                          <path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path>
                      </svg>
                      Order Status
                  </h3>
                  <div class="status-grid">
                      <div class="status-item">
                          <div class="status-count"><?= $statusCounts['pending'] ?></div>
                          <div class="status-label">Pending</div>
                      </div>
                      <div class="status-item">
                          <div class="status-count"><?= $statusCounts['paid'] ?></div>
                          <div class="status-label">Paid</div>
                      </div>
                      <div class="status-item">
                          <div class="status-count"><?= $statusCounts['preparing'] ?></div>
                          <div class="status-label">Preparing</div>
                      </div>
                      <div class="status-item">
                          <div class="status-count"><?= $statusCounts['ready_for_pickup'] ?></div>
                          <div class="status-label">Ready</div>
                      </div>
                      <div class="status-item">
                          <div class="status-count"><?= $statusCounts['completed'] ?></div>
                          <div class="status-label">Completed</div>
                      </div>
                      <div class="status-item">
                          <div class="status-count"><?= $statusCounts['cancelled'] + $statusCounts['refunded'] ?></div>
                          <div class="status-label">Cancelled/Refunded</div>
                      </div>
                  </div>
                  <a href="customer_orders.php" class="view-all">View All Orders</a>
              </div>
              
              <!-- Pending Pickups Card -->
              <div class="dashboard-card pickups">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f39c12" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                          <line x1="16" y1="2" x2="16" y2="6"></line>
                          <line x1="8" y1="2" x2="8" y2="6"></line>
                          <line x1="3" y1="10" x2="21" y2="10"></line>
                      </svg>
                      Pending Pickups
                  </h3>
                  <?php if (count($pendingPickups) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($pendingPickups as $pickup): ?>
                              <li>
                                  <div>
                                      <span class="item-name">Order #<?= $pickup['OrderID'] ?></span>
                                      <div class="item-detail">
                                          <?php if ($pickup['PickupDate']): ?>
                                              Pickup: <?= date('M d, Y', strtotime($pickup['PickupDate'])) ?>
                                              <?= $pickup['PickupTime'] ? ' at ' . date('g:i A', strtotime($pickup['PickupTime'])) : '' ?>
                                          <?php else: ?>
                                              No pickup date set
                                          <?php endif; ?>
                                      </div>
                                  </div>
                                  <div>
                                      <span class="badge badge-<?= strtolower($pickup['OrderStatus']) ?>">
                                          <?= ucfirst($pickup['OrderStatus']) ?>
                                      </span>
                                      <?php if ($pickup['PickupCode']): ?>
                                          <div class="item-detail text-right">Code: <?= $pickup['PickupCode'] ?></div>
                                      <?php endif; ?>
                                  </div>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="customer_orders.php?status=pickup" class="view-all">View All Pickups</a>
                  <?php else: ?>
                      <div class="empty-state">No pending pickups at the moment.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Recently Purchased Products Card -->
              <div class="dashboard-card products">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2ecc71" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                          <line x1="3" y1="6" x2="21" y2="6"></line>
                          <path d="M16 10a4 4 0 0 1-8 0"></path>
                      </svg>
                      Recently Purchased
                  </h3>
                  <?php if (count($recentProducts) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentProducts as $product): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($product['ProductName']) ?></span>
                                      <div class="item-detail">
                                          <?= date('M d, Y', strtotime($product['OrderDate'])) ?> • 
                                          <?= $product['Quantity'] ?> units
                                      </div>
                                  </div>
                                  <span class="badge badge-success">₱<?= number_format($product['Price'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="customer_orders.php" class="view-all">View Purchase History</a>
                  <?php else: ?>
                      <div class="empty-state">You haven't purchased any products yet.</div>
                      <a href="catalog.php" class="btn-primary" style="display: block; text-align: center; margin-top: 15px;">Browse Products</a>
                  <?php endif; ?>
              </div>
              
              <!-- Frequently Purchased Products Card -->
              <div class="dashboard-card products">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2ecc71" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                          <polyline points="17 6 23 6 23 12"></polyline>
                      </svg>
                      Frequently Purchased
                  </h3>
                  <?php if (count($frequentProducts) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($frequentProducts as $product): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($product['ProductName']) ?></span>
                                      <div class="item-detail">
                                          Purchased <?= $product['OrderCount'] ?> times
                                      </div>
                                  </div>
                                  <span class="badge badge-primary"><?= $product['TotalQuantity'] ?> units</span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="catalog.php" class="view-all">Shop Again</a>  
                      </ul>
                
                  <?php else: ?>
                      <div class="empty-state">No purchase history available.</div>
                      <a href="catalog.php" class="btn-primary" style="display: block; text-align: center; margin-top: 15px;">Start Shopping</a>
                  <?php endif; ?>
              </div>
              
              <!-- Refund History Card -->
              <div class="dashboard-card refunds">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e74c3c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <polyline points="1 4 1 10 7 10"></polyline>
                          <polyline points="23 20 23 14 17 14"></polyline>
                          <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"></path>
                      </svg>
                      Refund History
                  </h3>
                  <?php if (count($refunds) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($refunds as $refund): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($refund['ProductName']) ?></span>
                                      <div class="item-detail">
                                          Order #<?= $refund['OrderID'] ?> • 
                                          <?= date('M d, Y', strtotime($refund['RefundedAt'])) ?>
                                      </div>
                                  </div>
                                  <div>
                                      <span class="badge badge-<?= strtolower($refund['ItemCondition']) === 'pristine' ? 'info' : 'danger' ?>">
                                          <?= $refund['ItemCondition'] ?>
                                      </span>
                                      <div class="item-detail text-right"><?= $refund['QuantityRefunded'] ?> units</div>
                                  </div>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="customer_orders.php" class="view-all">View All Refunds</a>
                  <?php else: ?>
                      <div class="empty-state">No refund history available.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Payment Methods Card -->
              <div class="dashboard-card payment">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1abc9c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                          <line x1="1" y1="10" x2="23" y2="10"></line>
                      </svg>
                      Payment Methods
                  </h3>
                  <?php if (count($paymentMethods) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($paymentMethods as $method): ?>
                              <li>
                                  <span class="item-name"><?= htmlspecialchars($method['MethodName']) ?></span>
                                  <span class="badge badge-primary">Used <?= $method['UseCount'] ?> times</span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                  <?php else: ?>
                      <div class="empty-state">No payment methods used yet.</div>
                  <?php endif; ?>
                  <a href="customer_orders.php" class="view-all">Manage Payment Methods</a>
              </div>
              
              <!-- Notifications Card -->
              <div class="dashboard-card notifications">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e67e22" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                          <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                      </svg>
                      Notifications
                  </h3>
                  <?php if (count($notifications) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($notifications as $notification): ?>
                              <li class="<?= $notification['IsRead'] ? '' : 'notification-unread' ?>">
                                  <div>
                                      <?php if (!$notification['IsRead']): ?>
                                          <span class="notification-dot"></span>
                                      <?php endif; ?>
                                      <span class="item-name"><?= htmlspecialchars($notification['NotificationType']) ?></span>
                                      <div class="item-detail">
                                          <?= htmlspecialchars($notification['Message']) ?>
                                      </div>
                                  </div>
                                  <div class="item-detail">
                                      <?= date('M d, g:i A', strtotime($notification['CreatedAt'])) ?>
                                  </div>
                              </li>
                          <?php endforeach; ?>
                      </ul>

                      <div class="empty-state">No notifications at the moment.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Profile Card -->
             
          </div>
      </main>
  </div>

  <script>
      // Add any JavaScript functionality here
      document.addEventListener('DOMContentLoaded', function() {
          // Example: Auto-refresh the dashboard every 5 minutes
          // setTimeout(function() { location.reload(); }, 300000);
      });
  </script>
</body>
</html>
