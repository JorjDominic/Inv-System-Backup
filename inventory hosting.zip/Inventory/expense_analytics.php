<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
  header('Location: index.php');
  exit;
}
session_regenerate_id(true);

// Get current date and time
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

// Default date range (current month)
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : $firstDayOfMonth;
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : $currentDate;

// Calculate regular expenses for selected period
$regularExpensesQuery = "SELECT SUM(Amount) as RegularExpenses 
                      FROM Expenses 
                      WHERE Date BETWEEN ? AND ?";
$regularExpensesStmt = $conn->prepare($regularExpensesQuery);
$regularExpensesStmt->execute([$startDate, $endDate]);
$regularExpenses = $regularExpensesStmt->fetch(PDO::FETCH_ASSOC)['RegularExpenses'] ?? 0;

// Calculate damaged items cost for selected period
$damagedItemsQuery = "SELECT SUM(d.Quantity * p.PurchasePrice) as DamagedCost
                  FROM DamagedItems d
                  JOIN Product p ON d.ProductID = p.ProductID
                  WHERE d.ReportedAt BETWEEN ? AND ?";
$damagedItemsStmt = $conn->prepare($damagedItemsQuery);
$damagedItemsStmt->execute([$startDate, $endDate]);
$damagedItemsCost = $damagedItemsStmt->fetch(PDO::FETCH_ASSOC)['DamagedCost'] ?? 0;

// Calculate expired items cost for selected period - FIXED to match owner dashboard
$expiredItemsQuery = "SELECT SUM(LossValue) as ExpiredCost
                   FROM ExpiredItems
                   WHERE ExpiryDate BETWEEN ? AND CURRENT_DATE";
$expiredItemsStmt = $conn->prepare($expiredItemsQuery);
$expiredItemsStmt->execute([$firstDayOfMonth]);
$expiredItemsCost = $expiredItemsStmt->fetch(PDO::FETCH_ASSOC)['ExpiredCost'] ?? 0;

// Add debugging output to verify the expired items cost
echo "<!-- DEBUG: Expired Items Cost: " . $expiredItemsCost . " -->";

// Calculate damaged refunds cost
$damagedRefundsQuery = "SELECT 
                      SUM(CASE WHEN ri.ItemCondition = 'DAMAGED' THEN od.Price * ri.QuantityRefunded ELSE 0 END) as DamagedRefunds
                      FROM RefundedItems ri
                      JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                      JOIN Orders o ON ri.OrderID = o.OrderID
                      WHERE (ri.RefundedAt BETWEEN ? AND ? OR o.OrderDate BETWEEN ? AND ?)";
$damagedRefundsStmt = $conn->prepare($damagedRefundsQuery);
$damagedRefundsStmt->execute([$startDate, $endDate, $startDate, $endDate]);
$damagedRefunds = $damagedRefundsStmt->fetch(PDO::FETCH_ASSOC)['DamagedRefunds'] ?? 0;

// Calculate total expenses (regular expenses + damaged items cost + expired items cost + damaged refunds)
$totalExpenses = $regularExpenses + $damagedItemsCost + $expiredItemsCost + $damagedRefunds;

// Get expense breakdown by category
$expenseCategoriesQuery = "SELECT Category, SUM(Amount) as TotalAmount
                        FROM Expenses
                        WHERE Date BETWEEN ? AND ?
                        GROUP BY Category
                        ORDER BY TotalAmount DESC";
$expenseCategoriesStmt = $conn->prepare($expenseCategoriesQuery);
$expenseCategoriesStmt->execute([$startDate, $endDate]);
$expenseCategories = $expenseCategoriesStmt->fetchAll(PDO::FETCH_ASSOC);

// Get monthly expense trend for the past 12 months
$monthlyExpensesQuery = "SELECT 
                      DATE_FORMAT(Date, '%Y-%m') as Month,
                      SUM(Amount) as MonthlyExpense
                      FROM Expenses
                      WHERE Date >= DATE_SUB(?, INTERVAL 12 MONTH)
                      GROUP BY DATE_FORMAT(Date, '%Y-%m')
                      ORDER BY Month";
$monthlyExpensesStmt = $conn->prepare($monthlyExpensesQuery);
$monthlyExpensesStmt->execute([$endDate]);
$monthlyExpenses = $monthlyExpensesStmt->fetchAll(PDO::FETCH_ASSOC);

// Format monthly expenses data for chart
$monthLabels = [];
$expenseData = [];
foreach ($monthlyExpenses as $month) {
    $monthLabels[] = date('M Y', strtotime($month['Month'] . '-01'));
    $expenseData[] = $month['MonthlyExpense'];
}

// Get expense data by user
$expensesByUserQuery = "SELECT u.Username, SUM(e.Amount) as TotalAmount
                     FROM Expenses e
                     JOIN Users u ON e.UserID = u.UserID
                     WHERE e.Date BETWEEN ? AND ?
                     GROUP BY e.UserID
                     ORDER BY TotalAmount DESC";
$expensesByUserStmt = $conn->prepare($expensesByUserQuery);
$expensesByUserStmt->execute([$startDate, $endDate]);
$expensesByUser = $expensesByUserStmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent expenses
$recentExpensesQuery = "SELECT e.ExpenseID, e.Description, e.Category, e.Amount, e.Date, u.Username
                     FROM Expenses e
                     JOIN Users u ON e.UserID = u.UserID
                     WHERE e.Date BETWEEN ? AND ?
                     ORDER BY e.Date DESC
                     LIMIT 10";
$recentExpensesStmt = $conn->prepare($recentExpensesQuery);
$recentExpensesStmt->execute([$startDate, $endDate]);
$recentExpenses = $recentExpensesStmt->fetchAll(PDO::FETCH_ASSOC);

// Get damaged items details
$damagedItemsDetailsQuery = "SELECT d.DamageID, p.ProductName, d.Quantity, d.Reason, 
                          d.ReportedAt, u.Username as ReportedBy, 
                          (d.Quantity * p.PurchasePrice) as LossAmount
                          FROM DamagedItems d
                          JOIN Product p ON d.ProductID = p.ProductID
                          JOIN Users u ON d.ReportedBy = u.UserID
                          WHERE d.ReportedAt BETWEEN ? AND ?
                          ORDER BY d.ReportedAt DESC
                          LIMIT 10";
$damagedItemsDetailsStmt = $conn->prepare($damagedItemsDetailsQuery);
$damagedItemsDetailsStmt->execute([$startDate, $endDate]);
$damagedItemsDetails = $damagedItemsDetailsStmt->fetchAll(PDO::FETCH_ASSOC);

// Get expired items details
$expiredItemsDetailsQuery = "SELECT e.ExpiredID, p.ProductName, e.Quantity, e.ExpiryDate, 
                          e.DateExpired, u.Username as ReportedBy, e.LossValue
                          FROM ExpiredItems e
                          JOIN Product p ON e.ProductID = p.ProductID
                          JOIN Users u ON e.ReportedBy = u.UserID
                          WHERE e.DateExpired BETWEEN ? AND ?
                          ORDER BY e.DateExpired DESC
                          LIMIT 10";
$expiredItemsDetailsStmt = $conn->prepare($expiredItemsDetailsQuery);
$expiredItemsDetailsStmt->execute([$startDate, $endDate]);
$expiredItemsDetails = $expiredItemsDetailsStmt->fetchAll(PDO::FETCH_ASSOC);

// Get damaged refunds details
$damagedRefundsDetailsQuery = "SELECT ri.RefundID, p.ProductName, ri.QuantityRefunded, 
                            ri.RefundedAt, u.Username as ProcessedBy,
                            (od.Price * ri.QuantityRefunded) as RefundAmount
                            FROM RefundedItems ri
                            JOIN Product p ON ri.ProductID = p.ProductID
                            JOIN Users u ON ri.ProcessedBy = u.UserID
                            JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                            WHERE ri.ItemCondition = 'DAMAGED' AND ri.RefundedAt BETWEEN ? AND ?
                            ORDER BY ri.RefundedAt DESC
                            LIMIT 10";
$damagedRefundsDetailsStmt = $conn->prepare($damagedRefundsDetailsQuery);
$damagedRefundsDetailsStmt->execute([$startDate, $endDate]);
$damagedRefundsDetails = $damagedRefundsDetailsStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate gross revenue for selected period (for expense ratio)
$grossRevenueQuery = "SELECT SUM(TotalAmount) as GrossRevenue 
                   FROM Receipts 
                   WHERE DateIssued BETWEEN ? AND ?";
$grossRevenueStmt = $conn->prepare($grossRevenueQuery);
$grossRevenueStmt->execute([$startDate, $endDate]);
$grossRevenue = $grossRevenueStmt->fetch(PDO::FETCH_ASSOC)['GrossRevenue'] ?? 0;

// Calculate expense to revenue ratio
$expenseRatio = $grossRevenue > 0 ? ($totalExpenses / $grossRevenue) * 100 : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Expense Analytics - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .analytics-container {
            padding: 20px;
        }
        
        .date-filter {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-sm);
            font-family: 'Poppins', sans-serif;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .dashboard-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-card h3 {
            margin-top: 0;
            color: var(--text-dark);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .metric-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .metric-card {
            background-color: #f8f9fa;
            border-radius: var(--border-radius-sm);
            padding: 15px;
            text-align: center;
        }
        
        .metric-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .metric-label {
            font-size: 0.9rem;
            color: var(--text-medium);
        }
        
        .negative {
            color: #dc3545;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            margin-top: 15px;
        }
        
        .chart-container.half-height {
            height: 200px;
        }
        
        .summary-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .summary-table th, .summary-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .summary-table th {
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .summary-table tr:last-child td {
            border-bottom: none;
        }
        
        .card-footer {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            text-align: right;
            font-size: 0.9rem;
        }
        
        .card-footer a {
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .card-footer a:hover {
            text-decoration: underline;
        }
        
        .tab-container {
            margin-bottom: 20px;
        }
        
        .tabs {
            display: flex;
            overflow-x: auto;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            font-weight: 500;
            white-space: nowrap;
        }
        
        .tab.active {
            border-bottom-color: var(--primary-color);
            color: var(--primary-color);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .expense-breakdown {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 15px;
        }
        
        .expense-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .expense-label {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .expense-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }
        
        .expense-dot-regular {
            background-color: #3498db;
        }
        
        .expense-dot-damaged {
            background-color: #e67e22;
        }
        
        .expense-dot-expired {
            background-color: #c0392b;
        }
        
        .expense-dot-refunds {
            background-color: #9b59b6;
        }
        
        @media (max-width: 768px) {
            .filter-form {
                flex-direction: column;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .metric-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        .damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    display: block;
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="analytics-container">
                <h1>Expense Analytics</h1>
                <?php if ($role == 1): ?>
                <a href="expenses.php" class="damaged-items-link">View Expense<<</a>
                <?php endif; ?>
                <!-- Date Filter -->
                <div class="date-filter">
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" id="start_date" name="start_date" class="form-control" 
                                   value="<?= $startDate ?>" max="<?= $currentDate ?>">
                        </div>
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" id="end_date" name="end_date" class="form-control" 
                                   value="<?= $endDate ?>" max="<?= $currentDate ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Apply Filter</button>
                    </form>
                </div>
                
                <!-- Tabs Navigation -->
                <div class="tab-container">
                    <div class="tabs">
                        <div class="tab active" onclick="openTab('overview')">Expense Overview</div>
                        
                    </div>
                    
                    <!-- Expense Overview Tab -->
                    <div id="overview" class="tab-content active">
                        <div class="dashboard-grid">
                            <!-- Key Expense Metrics -->
                            <div class="dashboard-card">
                                <h3>Expense Summary</h3>
                                <div class="metric-grid">
                                    <div class="metric-card">
                                        <div class="metric-value negative">₱<?= number_format($regularExpenses, 2) ?></div>
                                        <div class="metric-label">Regular Expenses</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value negative">₱<?= number_format($damagedItemsCost, 2) ?></div>
                                        <div class="metric-label">Damaged Inventory</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value negative">₱<?= number_format($expiredItemsCost, 2) ?></div>
                                        <div class="metric-label">Expired Inventory</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value negative">₱<?= number_format($damagedRefunds, 2) ?></div>
                                        <div class="metric-label">Damaged Refunds</div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="expenses.php?start_date=<?= $startDate ?>&end_date=<?= $endDate ?>">View Detailed Expenses</a>
                                </div>
                            </div>
                            
                            <!-- Expense Breakdown -->
                            <div class="dashboard-card">
                                <h3>Expense Breakdown</h3>
                                <div class="chart-container">
                                    <canvas id="expenseBreakdownChart"></canvas>
                                </div>
                                <div class="expense-breakdown">
                                    <div class="expense-item">
                                        <div class="expense-label">
                                            <div class="expense-dot expense-dot-regular"></div>
                                            <span>Regular Expenses</span>
                                        </div>
                                        <span>₱<?= number_format($regularExpenses, 2) ?></span>
                                    </div>
                                    <div class="expense-item">
                                        <div class="expense-label">
                                            <div class="expense-dot expense-dot-damaged"></div>
                                            <span>Damaged Items</span>
                                        </div>
                                        <span>₱<?= number_format($damagedItemsCost, 2) ?></span>
                                    </div>
                                    <div class="expense-item">
                                        <div class="expense-label">
                                            <div class="expense-dot expense-dot-expired"></div>
                                            <span>Expired Items</span>
                                        </div>
                                        <span>₱<?= number_format($expiredItemsCost, 2) ?></span>
                                    </div>
                                    <div class="expense-item">
                                        <div class="expense-label">
                                            <div class="expense-dot expense-dot-refunds"></div>
                                            <span>Damaged Refunds</span>
                                        </div>
                                        <span>₱<?= number_format($damagedRefunds, 2) ?></span>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Expense to Revenue Ratio -->
                            <div class="dashboard-card">
                                <h3>Expense to Revenue Ratio</h3>
                                <div class="chart-container">
                                    <canvas id="expenseRatioChart"></canvas>
                                </div>
                                <div class="card-footer">
                                    <p>Current Expense Ratio: <?= number_format($expenseRatio, 2) ?>% of Revenue</p>
                                </div>
                            </div>
                            
                            <!-- Recent Expenses -->
                            <div class="dashboard-card">
                                <h3>Recent Expenses</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th>Category</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recentExpenses as $expense): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($expense['Description']) ?></td>
                                                <td><?= htmlspecialchars($expense['Category']) ?></td>
                                                <td><?= date('M d, Y', strtotime($expense['Date'])) ?></td>
                                                <td>₱<?= number_format($expense['Amount'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <div class="card-footer">
                                    <a href="expenses.php?start_date=<?= $startDate ?>&end_date=<?= $endDate ?>">View All Expenses</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Expense Categories Tab -->
                    <div id="categories" class="tab-content">
                        <div class="dashboard-grid">
                            <!-- Expense Categories Chart -->
                            <div class="dashboard-card">
                                <h3>Expense by Category</h3>
                                <div class="chart-container">
                                    <canvas id="expenseCategoriesChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Expense Categories Table -->
                            <div class="dashboard-card">
                                <h3>Expense Categories</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Amount</th>
                                            <th>% of Regular Expenses</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($expenseCategories as $category): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($category['Category']) ?></td>
                                                <td>₱<?= number_format($category['TotalAmount'], 2) ?></td>
                                                <td><?= number_format($category['TotalAmount'] / $regularExpenses * 100, 2) ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Expense by User -->
                            <div class="dashboard-card">
                                <h3>Expense by User</h3>
                                <div class="chart-container">
                                    <canvas id="expenseByUserChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Expense by User Table -->
                            <div class="dashboard-card">
                                <h3>Expense by User</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Amount</th>
                                            <th>% of Regular Expenses</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($expensesByUser as $user): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($user['Username']) ?></td>
                                                <td>₱<?= number_format($user['TotalAmount'], 2) ?></td>
                                                <td><?= number_format($user['TotalAmount'] / $regularExpenses * 100, 2) ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Expense Trends Tab -->
                    <div id="trends" class="tab-content">
                        <div class="dashboard-grid">
                            <!-- Monthly Expense Trend -->
                            <div class="dashboard-card">
                                <h3>Monthly Expense Trend</h3>
                                <div class="chart-container">
                                    <canvas id="monthlyExpenseChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Expense vs Revenue Trend -->
                            <div class="dashboard-card">
                                <h3>Expense vs Revenue</h3>
                                <div class="chart-container">
                                    <canvas id="expenseVsRevenueChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Expense Type Trend -->
                            <div class="dashboard-card">
                                <h3>Expense Type Trend</h3>
                                <div class="chart-container">
                                    <canvas id="expenseTypeChart"></canvas>
                                </div>
                                <div class="card-footer">
                                    <p>Shows the trend of different expense types over time</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Expense Details Tab -->
                    <div id="details" class="tab-content">
                        <div class="dashboard-grid">
                            <!-- Damaged Items Details -->
                            <div class="dashboard-card">
                                <h3>Damaged Items Details</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Reason</th>
                                            <th>Reported By</th>
                                            <th>Loss Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($damagedItemsDetails as $item): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($item['ProductName']) ?></td>
                                                <td><?= $item['Quantity'] ?></td>
                                                <td><?= htmlspecialchars($item['Reason']) ?></td>
                                                <td><?= htmlspecialchars($item['ReportedBy']) ?></td>
                                                <td>₱<?= number_format($item['LossAmount'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <div class="card-footer">
                                    <a href="damaged_inventory.php">View All Damaged Items</a>
                                </div>
                            </div>
                            
                            <!-- Expired Items Details -->
                            <div class="dashboard-card">
                                <h3>Expired Items Details</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Expiry Date</th>
                                            <th>Reported By</th>
                                            <th>Loss Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($expiredItemsDetails as $item): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($item['ProductName']) ?></td>
                                                <td><?= $item['Quantity'] ?></td>
                                                <td><?= date('M d, Y', strtotime($item['ExpiryDate'])) ?></td>
                                                <td><?= htmlspecialchars($item['ReportedBy']) ?></td>
                                                <td>₱<?= number_format($item['LossValue'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <div class="card-footer">
                                    <a href="expired_items.php">View All Expired Items</a>
                                </div>
                            </div>
                            
                            <!-- Damaged Refunds Details -->
                            <div class="dashboard-card">
                                <h3>Damaged Refunds Details</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Quantity</th>
                                            <th>Refund Date</th>
                                            <th>Processed By</th>
                                            <th>Refund Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($damagedRefundsDetails as $item): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($item['ProductName']) ?></td>
                                                <td><?= $item['QuantityRefunded'] ?></td>
                                                <td><?= date('M d, Y', strtotime($item['RefundedAt'])) ?></td>
                                                <td><?= htmlspecialchars($item['ProcessedBy']) ?></td>
                                                <td>₱<?= number_format($item['RefundAmount'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <div class="card-footer">
                                    <a href="refunds.php">View All Refunds</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Function to open tab
        function openTab(tabName) {
            // Hide all tab contents
            const tabContents = document.querySelectorAll('.tab-content');
            tabContents.forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active class from all tabs
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show the selected tab content
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to the clicked tab
            event.currentTarget.classList.add('active');
        }
        
        // Chart.js Configuration
        Chart.defaults.font.family = "'Poppins', sans-serif";
        Chart.defaults.color = '#666';
        
        // Expense Breakdown Chart
        const expenseBreakdownCtx = document.getElementById('expenseBreakdownChart').getContext('2d');
        new Chart(expenseBreakdownCtx, {
            type: 'pie',
            data: {
                labels: ['Regular Expenses', 'Damaged Inventory', 'Expired Inventory', 'Damaged Refunds'],
                datasets: [{
                    data: [
                        <?= $regularExpenses ?>, 
                        <?= $damagedItemsCost ?>, 
                        <?= $expiredItemsCost ?>, 
                        <?= $damagedRefunds ?>
                    ],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 159, 64, 0.7)',
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(153, 102, 255, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                                const percentage = (context.raw / <?= $totalExpenses ?> * 100).toFixed(1);
                                return `${context.label}: ₱${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Expense Ratio Chart
        const expenseRatioCtx = document.getElementById('expenseRatioChart').getContext('2d');
        new Chart(expenseRatioCtx, {
            type: 'bar',
            data: {
                labels: ['Revenue', 'Expenses'],
                datasets: [{
                    label: 'Amount',
                    data: [<?= $grossRevenue ?>, <?= $totalExpenses ?>],
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(255, 99, 132, 0.7)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₱' + context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Expense Categories Chart
        const expenseCategoriesCtx = document.getElementById('expenseCategoriesChart').getContext('2d');
        new Chart(expenseCategoriesCtx, {
            type: 'pie',
            data: {
                labels: <?= json_encode(array_column($expenseCategories, 'Category')) ?>,
                datasets: [{
                    data: <?= json_encode(array_column($expenseCategories, 'TotalAmount')) ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 206, 86, 0.7)',
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(153, 102, 255, 0.7)',
                        'rgba(255, 159, 64, 0.7)',
                        'rgba(201, 203, 207, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                                const percentage = (context.raw / <?= $regularExpenses ?> * 100).toFixed(1);
                                return `${context.label}: ₱${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Expense by User Chart
        const expenseByUserCtx = document.getElementById('expenseByUserChart').getContext('2d');
        new Chart(expenseByUserCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_column($expensesByUser, 'Username')) ?>,
                datasets: [{
                    label: 'Amount',
                    data: <?= json_encode(array_column($expensesByUser, 'TotalAmount')) ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.7)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₱' + context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Monthly Expense Chart
        const monthlyExpenseCtx = document.getElementById('monthlyExpenseChart').getContext('2d');
        new Chart(monthlyExpenseCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode($monthLabels) ?>,
                datasets: [{
                    label: 'Monthly Expenses',
                    data: <?= json_encode($expenseData) ?>,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 2,
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₱' + context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Placeholder charts for demonstration
        // Expense vs Revenue Chart
        const expenseVsRevenueCtx = document.getElementById('expenseVsRevenueChart').getContext('2d');
        new Chart(expenseVsRevenueCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [
                    {
                        label: 'Revenue',
                        data: [50000, 55000, 60000, 58000, 62000, 65000],
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2,
                        tension: 0.1
                    },
                    {
                        label: 'Expenses',
                        data: [30000, 32000, 35000, 33000, 36000, 38000],
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 2,
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Expense Type Chart
        const expenseTypeCtx = document.getElementById('expenseTypeChart').getContext('2d');
        new Chart(expenseTypeCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [
                    {
                        label: 'Regular Expenses',
                        data: [20000, 22000, 23000, 21000, 24000, 25000],
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderWidth: 2,
                        tension: 0.1
                    },
                    {
                        label: 'Damaged Inventory',
                        data: [5000, 4500, 6000, 5500, 5800, 6200],
                        borderColor: 'rgba(255, 159, 64, 1)',
                        backgroundColor: 'rgba(255, 159, 64, 0.2)',
                        borderWidth: 2,
                        tension: 0.1
                    },
                    {
                        label: 'Expired Inventory',
                        data: [3000, 3500, 4000, 4200, 4500, 4800],
                        borderColor: 'rgba(255, 99, 132, 1)',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderWidth: 2,
                        tension: 0.1
                    },
                    {
                        label: 'Damaged Refunds',
                        data: [2000, 2000, 2000, 2300, 1700, 2000],
                        borderColor: 'rgba(153, 102, 255, 1)',
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderWidth: 2,
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
