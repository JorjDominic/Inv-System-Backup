<?php
session_start();
require('config/database.php');

// Uncomment for debugging
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

// Define report types
$reportTypes = [
    'sales' => 'Sales Report',
    'refunds' => 'Refunds Report',
    'cancellations' => 'Cancellations Report',
    'inventory' => 'Inventory Report'
];

// Get current date
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

// Default date range (current month)
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : $firstDayOfMonth;
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : $currentDate;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportType = $_POST['report_type'] ?? 'sales';
    $startDate = $_POST['start_date'] ?? $firstDayOfMonth;
    $endDate = $_POST['end_date'] ?? $currentDate;
    
    if (isset($_POST['action']) && $_POST['action'] === 'export_pdf') {
        header("Location: generate_pdf.php?report_type=$reportType&start_date=$startDate&end_date=$endDate");
        exit;
    }
}

// Function to get report data
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      t.TransactionType, COUNT(od.OrderDetailID) as ItemCount, 
                      pm.MethodName as PaymentMethodName,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'paid' 
                      AND t.CreatedAt >= ? AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
            
        case 'refunds':
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      t.TransactionType, COUNT(od.OrderDetailID) as ItemCount,
                      pm.MethodName as PaymentMethodName,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'refunded' 
                      AND t.CreatedAt >= ? AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;

        case 'cancellations':
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
       t.TransactionType, COUNT(od.OrderDetailID) as ItemCount,
       pm.MethodName as PaymentMethodName,
       CONCAT(u.FirstName, ' ', u.LastName) as Cashier,
       MAX(r.Reason) as CancellationReason
FROM Transactions t
LEFT JOIN Orders o ON t.OrderID = o.OrderID
LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
LEFT JOIN Users u ON o.UserID = u.UserID
LEFT JOIN Refunds r ON t.TransactionID = r.TransactionID
WHERE t.Status = 'cancelled' 
AND t.CreatedAt >= ? AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
GROUP BY t.TransactionID
ORDER BY t.CreatedAt DESC
";
            break;

        case 'inventory':
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        default:
            return $data;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        if ($reportType === 'inventory') {
            $stmt->execute();
        } else {
            $stmt->execute([$startDate, $endDate]);
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary data
        $summary = [];
        switch ($reportType) {
            case 'sales':
                $summary['totalAmount'] = array_sum(array_column($data, 'TotalAmount'));
                $summary['count'] = count($data);
                break;
                
            case 'refunds':
                $summary['totalAmount'] = array_sum(array_column($data, 'TotalAmount'));
                $summary['count'] = count($data);
                break;
                
            case 'cancellations':
                $summary['totalAmount'] = array_sum(array_column($data, 'TotalAmount'));
                $summary['count'] = count($data);
                break;
                
            case 'inventory':
                $summary['totalValue'] = array_sum(array_column($data, 'TotalValue'));
                $summary['totalItems'] = array_sum(array_column($data, 'TotalQuantity'));
                break;
        }
        
        $data['summary'] = $summary;
        
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    
    return $data;
}

// Get report data
$reportData = [];
$selectedReportType = $_POST['report_type'] ?? 'sales';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportData = getReportData($conn, $selectedReportType, $startDate, $endDate);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reports - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .reports-container { padding: 20px; }
        .report-form {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        .form-row { display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 15px; }
        .form-group { flex: 1; min-width: 200px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; color: var(--text-dark); }
        .form-control { width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: var(--border-radius-sm); }
        .btn-group { display: flex; gap: 10px; }
        .btn { padding: 8px 16px; border: none; border-radius: var(--border-radius-sm); cursor: pointer; font-weight: 500; }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-success { background-color: #28a745; color: white; }
        .report-results { background-color: white; border-radius: var(--border-radius); box-shadow: var(--shadow-sm); padding: 20px; overflow-x: auto; }
        .report-title { margin-top: 0; margin-bottom: 20px; color: var(--text-dark); font-size: 1.5rem; font-weight: 600; }
        .report-table { width: 100%; border-collapse: collapse; }
        .report-table th, .report-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
        .report-table th { background-color: #f8f9fa; font-weight: 600; color: var(--text-dark); }
        .report-summary { margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee; }
        .summary-item { display: flex; justify-content: space-between; margin-bottom: 10px; }
        .summary-label { font-weight: 500; color: var(--text-dark); }
        .summary-value { font-weight: 600; }
        .no-data { text-align: center; padding: 30px; color: var(--text-medium); font-style: italic; }
        .badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 12px; font-weight: 500; }
        .badge-primary { background-color: #cce5ff; color: #004085; }
        .badge-success { background-color: #d4edda; color: #155724; }
        .badge-danger { background-color: #f8d7da; color: #721c24; }
        
        @media (max-width: 768px) {
            .form-row, .btn-group { flex-direction: column; }
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="reports-container">
                <h1 class="report-title">Generate Reports</h1>
                <a href="business_analytics.php">Go to Business Analytics</a>
                
                <div class="report-form">
                    <form method="POST" action="">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="report_type">Report Type</label>
                                <select name="report_type" id="report_type" class="form-control">
                                    <?php foreach ($reportTypes as $value => $label): ?>
                                        <option value="<?= $value ?>" <?= ($selectedReportType === $value) ? 'selected' : '' ?>>
                                            <?= $label ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" 
                                       value="<?= $startDate ?>" max="<?= $currentDate ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" 
                                       value="<?= $endDate ?>" max="<?= $currentDate ?>">
                            </div>
                        </div>
                        <div class="btn-group">
                            <button type="submit" name="action" value="generate_report" class="btn btn-primary">Generate Report</button>
                            <button type="submit" name="action" value="export_pdf" class="btn btn-success">Export to PDF</button>
                        </div>
                    </form>
                </div>
                
                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($reportData)): ?>
                    <div class="report-results">
                        <h2 class="report-title"><?= $reportTypes[$selectedReportType] ?></h2>
                        <p>Period: <?= date('F d, Y', strtotime($startDate)) ?> to <?= date('F d, Y', strtotime($endDate)) ?></p>
                        
                        <?php if ($selectedReportType === 'sales'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Date</th>
                                            <th>Items</th>
                                            <th>Payment Type</th>
                                            <th>Amount</th>
                                            <th>Processed By</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($reportData as $key => $sale): ?>
                                            <?php if ($key !== 'summary' && isset($sale['TransactionID'])): ?>
                                                <tr>
                                                    <td>#<?= $sale['TransactionID'] ?></td>
                                                    <td><?= date('M d, Y h:i A', strtotime($sale['DateIssued'])) ?></td>
                                                    <td><?= $sale['ItemCount'] ?></td>
                                                    <td>
                                                        <?php if ($sale['TransactionType'] === 'online'): ?>
                                                            <span class="badge badge-primary">Online</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-success">Walk-in (<?= $sale['PaymentMethodName'] ?? 'Cash' ?>)</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>₱<?= number_format($sale['TotalAmount'], 2) ?></td>
                                                    <td><?= htmlspecialchars($sale['Cashier']) ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Sales:</span>
                                    <span class="summary-value">₱<?= number_format($reportData['summary']['totalAmount'], 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Number of Transactions:</span>
                                    <span class="summary-value"><?= $reportData['summary']['count'] ?></span>
                                </div>
                            </div>

                        <?php elseif ($selectedReportType === 'refunds'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Date Refunded</th>
                                            <th>Items</th>
                                            <th>Payment Type</th>
                                            <th>Amount</th>
                                            <th>Processed By</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($reportData as $key => $refund): ?>
                                            <?php if ($key !== 'summary' && isset($refund['TransactionID'])): ?>
                                                <tr>
                                                    <td>#<?= $refund['TransactionID'] ?></td>
                                                    <td><?= date('M d, Y h:i A', strtotime($refund['DateIssued'])) ?></td>
                                                    <td><?= $refund['ItemCount'] ?></td>
                                                    <td>
                                                        <?php if ($refund['TransactionType'] === 'online'): ?>
                                                            <span class="badge badge-primary">Online</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-success">Walk-in (<?= $refund['PaymentMethodName'] ?? 'Cash' ?>)</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>₱<?= number_format($refund['TotalAmount'], 2) ?></td>
                                                    <td><?= htmlspecialchars($refund['Cashier']) ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Refund Amount:</span>
                                    <span class="summary-value">₱<?= number_format($reportData['summary']['totalAmount'], 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Number of Refunds:</span>
                                    <span class="summary-value"><?= $reportData['summary']['count'] ?></span>
                                </div>
                            </div>

                        <?php elseif ($selectedReportType === 'cancellations'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Date Cancelled</th>
                                            <th>Payment Type</th>
                                            <th>Amount</th>
                                            <th>Processed By</th>
                                            <th>Reason</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($reportData as $key => $cancellation): ?>
                                            <?php if ($key !== 'summary' && isset($cancellation['TransactionID'])): ?>
                                                <tr>
                                                    <td>#<?= $cancellation['TransactionID'] ?></td>
                                                    <td><?= date('M d, Y h:i A', strtotime($cancellation['DateIssued'])) ?></td>
                                                    <td>
                                                        <?php if ($cancellation['TransactionType'] === 'online'): ?>
                                                            <span class="badge badge-primary">Online</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-success">Walk-in (<?= $cancellation['PaymentMethodName'] ?? 'Cash' ?>)</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>₱<?= number_format($cancellation['TotalAmount'], 2) ?></td>
                                                    <td><?= htmlspecialchars($cancellation['Cashier']) ?></td>
                                                    <td><?= isset($cancellation['CancellationReason']) ? htmlspecialchars($cancellation['CancellationReason']) : 'N/A' ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Cancellation Amount:</span>
                                    <span class="summary-value">₱<?= number_format($reportData['summary']['totalAmount'], 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Number of Cancellations:</span>
                                    <span class="summary-value"><?= $reportData['summary']['count'] ?></span>
                                </div>
                            </div>

                        <?php elseif ($selectedReportType === 'inventory'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Quantity</th>
                                            <th>Purchase Price</th>
                                            <th>Selling Price</th>
                                            <th>Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($reportData as $key => $item): ?>
                                            <?php if ($key !== 'summary' && isset($item['ProductID'])): ?>
                                                <tr>
                                                    <td><?= $item['ProductID'] ?></td>
                                                    <td><?= htmlspecialchars($item['ProductName']) ?></td>
                                                    <td><?= htmlspecialchars($item['CategoryName']) ?></td>
                                                    <td><?= $item['TotalQuantity'] ?></td>
                                                    <td>₱<?= number_format($item['PurchasePrice'], 2) ?></td>
                                                    <td>₱<?= number_format($item['SellingPrice'], 2) ?></td>
                                                    <td>₱<?= number_format($item['TotalValue'], 2) ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Inventory Value:</span>
                                    <span class="summary-value">₱<?= number_format($reportData['summary']['totalValue'], 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Items:</span>
                                    <span class="summary-value"><?= $reportData['summary']['totalItems'] ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="report-results">
                        <div class="no-data">No data available for the selected criteria.</div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>