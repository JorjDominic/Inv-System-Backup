<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is a customer (role 2)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
  header('Location: index.php');
  exit;
}
session_regenerate_id(true);

// Get customer's recent orders

$customerOrdersQuery = "SELECT r.ReceiptID, r.TotalAmount, r.DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod
                      FROM Receipts r
                      JOIN Orders o ON r.OrderID = o.OrderID
                      JOIN OrderDetails od ON o.OrderID = od.OrderID
                      JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                      WHERE o.CustomerID = ?
                      GROUP BY r.ReceiptID
                      ORDER BY r.DateIssued DESC
                      LIMIT 5";
$customerOrdersStmt = $conn->prepare($customerOrdersQuery);
$customerOrdersStmt->execute([$_SESSION['user_id']]);
$customerOrders = $customerOrdersStmt->fetchAll(PDO::FETCH_ASSOC);

// Get customer's total spending
$totalSpendingQuery = "SELECT SUM(r.TotalAmount) as TotalSpent 
                     FROM Receipts r
                     JOIN Orders o ON r.OrderID = o.OrderID
                     WHERE o.CustomerID = ?";
$totalSpendingStmt = $conn->prepare($totalSpendingQuery);
$totalSpendingStmt->execute([$_SESSION['user_id']]);
$totalSpending = $totalSpendingStmt->fetch(PDO::FETCH_ASSOC)['TotalSpent'] ?? 0;

// Get popular products (for recommendations)
$popularProductsQuery = "SELECT p.ProductName, p.SellingPrice, c.CategoryName
                      FROM Product p
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      WHERE i.Quantity > 0
                      ORDER BY RAND()
                      LIMIT 5";
$popularProductsStmt = $conn->prepare($popularProductsQuery);
$popularProductsStmt->execute();
$popularProducts = $popularProductsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Customer Dashboard - Adriana's Marketing</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
      /* Customer Dashboard Styles */
      .dashboard-container {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
          padding: 20px;
      }
      
      .dashboard-card {
          background-color: white;
          border-radius: var(--border-radius);
          box-shadow: var(--shadow-sm);
          padding: 20px;
          position: relative;
          overflow: hidden;
      }
      
      .dashboard-card h3 {
          margin-top: 0;
          color: var(--text-dark);
          font-size: 1.2rem;
          font-weight: 600;
          margin-bottom: 15px;
          display: flex;
          align-items: center;
      }
      
      .dashboard-card h3 svg {
          margin-right: 10px;
          width: 24px;
          height: 24px;
      }
      
      .dashboard-card.orders {
          border-left: 4px solid #3498db;
      }
      
      .dashboard-card.products {
          border-left: 4px solid #2ecc71;
      }
      
      .dashboard-card.account {
          border-left: 4px solid #9b59b6;
      }
      
      .welcome-header {
          background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
          color: white;
          padding: 30px;
          border-radius: var(--border-radius);
          margin-bottom: 20px;
          box-shadow: var(--shadow-md);
      }
      
      .welcome-header h1 {
          margin: 0;
          font-size: 1.8rem;
          font-weight: 600;
          color:white;
      }
      
      .welcome-header p {
          margin: 10px 0 0;
          opacity: 0.9;
          font-size: 1rem;
      }
      
      .stat-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 15px;
          margin-top: 20px;
      }
      
      .stat-card {
          background-color: rgba(255, 255, 255, 0.1);
          padding: 15px;
          border-radius: var(--border-radius-sm);
          text-align: center;
      }
      
      .stat-card h3 {
          margin: 0;
          font-size: 1.8rem;
          font-weight: 700;
      }
      
      .stat-card p {
          margin: 5px 0 0;
          font-size: 0.9rem;
          opacity: 0.8;
      }
      
      .item-list {
          list-style: none;
          padding: 0;
          margin: 0;
      }
      
      .item-list li {
          padding: 10px 0;
          border-bottom: 1px solid #f0f0f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
      }
      
      .item-list li:last-child {
          border-bottom: none;
      }
      
      .item-name {
          font-weight: 500;
          color: var(--text-dark);
      }
      
      .item-detail {
          color: var(--text-medium);
          font-size: 0.9rem;
      }
      
      .badge {
          display: inline-block;
          padding: 3px 8px;
          border-radius: 12px;
          font-size: 0.75rem;
          font-weight: 500;
      }
      
      .badge-primary {
          background-color: #cce5ff;
          color: #004085;
      }
      
      .badge-success {
          background-color: #d4edda;
          color: #155724;
      }
      
      .badge-purple {
          background-color: #e8daef;
          color: #8e44ad;
      }
      
      .view-all {
          display: block;
          text-align: center;
          margin-top: 15px;
          color: var(--primary-color);
          text-decoration: none;
          font-size: 0.9rem;
          font-weight: 500;
      }
      
      .view-all:hover {
          text-decoration: underline;
      }
      
      .date-display {
          font-size: 1rem;
          color: rgba(255, 255, 255, 0.8);
          margin-top: 5px;
      }
      
      .empty-state {
          text-align: center;
          padding: 20px 0;
          color: var(--text-light);
          font-style: italic;
      }
      
      .product-card {
          display: flex;
          align-items: center;
          gap: 15px;
          padding: 10px 0;
      }
      
      .product-info {
          flex: 1;
      }
      
      .product-price {
          font-weight: 600;
          color: var(--primary-color);
      }
      
      .account-info {
          padding: 10px 0;
      }
      
      .account-info p {
          margin: 5px 0;
      }
      
      .account-label {
          font-weight: 500;
          color: var(--text-dark);
      }
      
      @media (max-width: 768px) {
          .dashboard-container {
              grid-template-columns: 1fr;
          }
          
          .welcome-header {
              padding: 20px;
          }
          
          .welcome-header h1 {
              font-size: 1.5rem;
          }
          
          .stat-grid {
              grid-template-columns: repeat(2, 1fr);
          }
      }
  </style>
</head>
<body>
  <?php include 'sidebar.php'; ?>
  <?php include 'navbar.php'; ?>

  <div class="main-content-wrapper">
      <main class="content">
          <!-- Welcome Header with Stats -->
          <div class="welcome-header">
              <h1>Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?></h1>
              <p class="date-display"><?= date('l, F j, Y') ?></p>
              
              <div class="stat-grid">
                  <div class="stat-card">
                      <h3>₱<?= number_format($totalSpending, 2) ?></h3>
                      <p>Total Spending</p>
                  </div>
                  <div class="stat-card">
                      <h3><?= count($customerOrders) ?></h3>
                      <p>Total Orders</p>
                  </div>
              </div>
          </div>
          
          <div class="dashboard-container">
              <!-- Recent Orders Card -->
              <div class="dashboard-card orders">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                          <line x1="3" y1="6" x2="21" y2="6"></line>
                          <path d="M16 10a4 4 0 0 1-8 0"></path>
                      </svg>
                      Recent Orders
                  </h3>
                  <?php if (count($customerOrders) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($customerOrders as $order): ?>
                              <li>
                                  <div>
                                      <span class="item-name">Order #<?= $order['ReceiptID'] ?></span>
                                      <div class="item-detail"><?= date('M d, Y', strtotime($order['DateIssued'])) ?> • <?= $order['ItemCount'] ?> items</div>
                                  </div>
                                  <span class="badge badge-primary">₱<?= number_format($order['TotalAmount'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="order_history.php" class="view-all">View All Orders</a>
                  <?php else: ?>
                      <div class="empty-state">You haven't placed any orders yet.</div>
                      <a href="products.php" class="view-all">Browse Products</a>
                  <?php endif; ?>
              </div>
              
              <!-- Recommended Products Card -->
              <div class="dashboard-card products">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2ecc71" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                          <line x1="7" y1="7" x2="7.01" y2="7"></line>
                      </svg>
                      Recommended Products
                  </h3>
                  <?php if (count($popularProducts) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($popularProducts as $product): ?>
                              <li class="product-card">
                                  <div class="product-info">
                                      <span class="item-name"><?= htmlspecialchars($product['ProductName']) ?></span>
                                      <div class="item-detail"><?= htmlspecialchars($product['CategoryName']) ?></div>
                                  </div>
                                  <span class="product-price">₱<?= number_format($product['SellingPrice'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="products.php" class="view-all">View All Products</a>
                  <?php else: ?>
                      <div class="empty-state">No products available at the moment.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Account Information Card -->
              <div class="dashboard-card account">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#9b59b6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                          <circle cx="12" cy="7" r="4"></circle>
                      </svg>
                      Account Information
                  </h3>
                  <div class="account-info">
                      <p><span class="account-label">Name:</span> <?= htmlspecialchars($_SESSION['user_name']) ?></p>
                      <p><span class="account-label">Email:</span> <?= htmlspecialchars($_SESSION['user_email']) ?></p>
                      <p><span class="account-label">Member Since:</span> <?= date('M d, Y', strtotime($_SESSION['created_at'])) ?></p>
                  </div>
                  <a href="account_settings.php" class="view-all">Update Account</a>
              </div>
          </div>
      </main>
  </div>

  <script>
      document.addEventListener('DOMContentLoaded', function() {
          // Add any customer-specific JavaScript here
      });
  </script>
</body>
</html>