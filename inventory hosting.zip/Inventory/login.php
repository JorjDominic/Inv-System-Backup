    <?php
    session_start();
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");

    require 'config/database.php';

    $login_error = '';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = htmlspecialchars(trim($_POST['username']));  // Trim username input
        $password = trim($_POST['password']); 
        
        // Prepare the query to fetch the user data
        $stmt = $conn->prepare("SELECT * FROM Users WHERE Username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

    
        // Check if the user exists
        if (!$user) {
            error_log("Login failed: Username '$username' not found.");
            header("Location: index.php?toast=error&msg=" . urlencode("Invalid username or password!"));
            exit;
        }
        
        // If the username exists, check if the password matches
        if (password_verify($password, $user['Password'])) {
            $_SESSION['user_id'] = $user['UserID'];
            $_SESSION['user_name'] = $user['Username'];
            $_SESSION['role'] = $user['RoleID'];

            $login_time = date('Y-m-d H:i:s');
            $log_query = "INSERT INTO audit_trail (affected_username, changed_by, action, timestamp) 
                        VALUES (:affected, :changer, 'login', :timestamp)";
            $log_stmt = $conn->prepare($log_query);
            $log_stmt->bindParam(':affected', $username); // the user being logged in
            $log_stmt->bindParam(':changer', $username);  // the same user performing the action
            $log_stmt->bindParam(':timestamp', $login_time);
            $log_stmt->execute();

            // Redirect based on RoleID
            if ($user['RoleID'] == 1) {
                header("Location: owner_dashboard.php?toast=success&msg=" . urlencode("Welcome back, " . $user['FirstName'] . "!"));
                exit;
            } elseif ($user['RoleID'] == 2) {
                header('Location: devdashboard.php?toast=success&msg=' . urlencode("Welcome back, " . $user['FirstName'] . "!"));
                exit;
            } elseif ($user['RoleID'] == 3) {
                header('Location: cashierdashboard.php?toast=success&msg=' . urlencode("Welcome back, " . $user['FirstName'] . "!"));
                exit;
            } elseif ($user['RoleID'] == 4) {
                header('Location: staff_dashboard.php?toast=success&msg=' . urlencode("Welcome back, " . $user['FirstName'] . "!"));
                exit;
            } elseif ($user['RoleID'] == 5) {
                header('Location: customer_dashboard.php?toast=success&msg=' . urlencode("Welcome back, " . $user['FirstName'] . "!"));
                exit;
            } else {
                echo "No dashboard assigned for your role.";
            }
        } else {
            header("Location: index.php?toast=error&msg=" . urlencode("Invalid username or password!"));
            exit;
        }
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - Adriana's Marketing</title>
        <?php include 'includes/toast-head.php'; ?>
    </head>
    <body>
        <!-- Your login form content here -->
    </body>
    </html>
