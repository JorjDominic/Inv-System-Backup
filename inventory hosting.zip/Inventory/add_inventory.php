<?php
session_start();
require_once 'config/database.php';
require_once 'notification.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php?toast=error&msg=' . urlencode("Unauthorized access"));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName    = $_POST['product_name'];
    $categoryID     = $_POST['category_id'];
    $quantity       = $_POST['quantity'];
    $purchasePrice  = $_POST['purchase_price'];
    $sellingPrice   = $_POST['selling_price'];
    $dateReceived   = $_POST['date_received'];
    $expiryDate     = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

    $userID = $_SESSION['user_id'];
    $username = $_SESSION['user_name'];  // For snapshot
    $logTime = date('Y-m-d H:i:s');
    
    // Handle image upload
    $imageURL = null;
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['product_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($ext), $allowed)) {
            // Create unique filename
            $newFilename = uniqid('product_') . '.' . $ext;
            $uploadDir = 'uploads/products/';
            
            // Create directory if it doesn't exist
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $destination = $uploadDir . $newFilename;
            
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $destination)) {
                $imageURL = $destination;
            } else {
                // Image upload failed, but continue with product creation
                $uploadError = "Image upload failed. Product will be created without an image.";
            }
        } else {
            // Invalid file type, but continue with product creation
            $uploadError = "Invalid file type. Only JPG, JPEG, PNG and GIF are allowed.";
        }
    }

    try {
        $conn->beginTransaction();

        // ✅ Step 1: Check if product already exists
        $checkStmt = $conn->prepare("SELECT ProductID FROM Product WHERE ProductName = ? AND CategoryID = ?");
        $checkStmt->execute([$productName, $categoryID]);
        $product = $checkStmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            $productID = $product['ProductID'];
            
            // Update existing product with new image if provided
            if ($imageURL) {
                $updateStmt = $conn->prepare("UPDATE Product SET PurchasePrice = ?, SellingPrice = ?, ImageURL = ? WHERE ProductID = ?");
                $updateStmt->execute([$purchasePrice, $sellingPrice, $imageURL, $productID]);
            } else {
                $updateStmt = $conn->prepare("UPDATE Product SET PurchasePrice = ?, SellingPrice = ? WHERE ProductID = ?");
                $updateStmt->execute([$purchasePrice, $sellingPrice, $productID]);
            }
        } else {
            // Create new product with image
            $productStmt = $conn->prepare("INSERT INTO Product (ProductName, CategoryID, PurchasePrice, SellingPrice, ImageURL)
                                           VALUES (?, ?, ?, ?, ?)");
            $productStmt->execute([$productName, $categoryID, $purchasePrice, $sellingPrice, $imageURL]);
            $productID = $conn->lastInsertId();
        }

        // ✅ Step 2: Insert stock into Inventory
        $inventoryStmt = $conn->prepare("INSERT INTO Inventory (ProductID, Quantity, DateReceived, ExpiryDate)
                                         VALUES (?, ?, ?, ?)");
        $inventoryStmt->execute([$productID, $quantity, $dateReceived, $expiryDate]);
        $inventoryID = $conn->lastInsertId();

        // ✅ Step 3: Log inventory action
        $logStmt = $conn->prepare("
        INSERT INTO InventoryLogs (
            UserID, UsernameSnapshot, InventoryID, ProductNameSnapshot,
            Action, QuantityChanged, Remarks, Timestamp
        ) VALUES (?, ?, ?, ?, 'add', ?, ?, ?)
        ");
    
        $remarks = "Added new stock for '$productName'";
        $logStmt->execute([
            $userID,
            $username,
            $inventoryID,
            $productName,
            $quantity,
            $remarks,
            $logTime
        ]);
        
        // ✅ Step 4: Create notification for admins and inventory managers
        $stmt = $conn->prepare("SELECT UserID FROM Users WHERE RoleID IN (1, 2)"); // Admins and inventory managers
        $stmt->execute();
        $notifyUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $notificationMessage = "Inventory updated: $quantity units of $productName added";
        foreach ($notifyUsers as $user) {
            if ($user['UserID'] != $userID) { // Don't notify the user who made the change
                createNotification($conn, $user['UserID'], 'inventory_update', $notificationMessage);
            }
        }

        $conn->commit();

        $successMsg = "Item added successfully";
        if (isset($uploadError)) {
            $successMsg .= ", but " . strtolower($uploadError);
        }
        
        header("Location: inventory.php?toast=success&msg=" . urlencode($successMsg));
        exit;

    } catch (PDOException $e) {
        $conn->rollBack();
        header("Location: inventory.php?toast=error&msg=" . urlencode("Error adding item: " . $e->getMessage()));
        exit;
    }
}
?>