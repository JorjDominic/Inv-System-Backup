<?php
// payment_failed.php
session_start();
require_once 'config/database.php';

// Enable error logging
error_reporting(E_ALL);
ini_set('display_errors', 0);
error_log('Payment failed page loaded');

// Check if we have an order ID from URL or session
$orderId = isset($_GET['order_id']) ? intval($_GET['order_id']) : ($_SESSION['current_order_id'] ?? null);

if (!$orderId) {
    error_log('No order ID found in URL or session');
    header('Location: catalog.php');
    exit;
}

error_log('Processing failed payment for order ID: ' . $orderId);

try {
    // Get order details
    $stmt = $conn->prepare("
        SELECT o.*, c.FirstName, c.LastName, c.Email, c.Phone
        FROM Orders o
        JOIN Customers c ON o.CustomerID = c.CustomerID
        WHERE o.OrderID = ?
    ");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        error_log('Order not found: ' . $orderId);
        header('Location: catalog.php');
        exit;
    }

    // Update order status to cancelled if it's still pending
    if ($order['OrderStatus'] === 'pending') {
        $conn->beginTransaction();
        
        // Update order status
        $stmt = $conn->prepare("UPDATE Orders SET OrderStatus = 'cancelled' WHERE OrderID = ? AND OrderStatus = 'pending'");
        $stmt->execute([$orderId]);
        
        // Update transaction status if it exists
        $stmt = $conn->prepare("
            UPDATE Transactions 
            SET Status = 'failed' 
            WHERE OrderID = ? AND Status = 'pending'
        ");
        $stmt->execute([$orderId]);
        
        // Update payment link status if it exists
        $stmt = $conn->prepare("
            UPDATE PaymentLinks 
            SET Status = 'failed' 
            WHERE OrderID = ? AND Status = 'pending'
        ");
        $stmt->execute([$orderId]);
        
        $conn->commit();
    }

    // Get order items
    $stmt = $conn->prepare("
        SELECT od.*, p.ProductName
        FROM OrderDetails od
        JOIN Product p ON od.ProductID = p.ProductID
        WHERE od.OrderID = ?
    ");
    $stmt->execute([$orderId]);
    $orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log('Error in payment_failed.php: ' . $e->getMessage());
    // Continue to show the page even if there's an error
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .failed-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 30px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .failed-icon {
            font-size: 5rem;
            color: #dc3545;
            margin-bottom: 20px;
        }
        
        .failed-title {
            font-size: 2rem;
            color: #333;
            margin-bottom: 15px;
        }
        
        .failed-message {
            font-size: 1.1rem;
            color: #666;
            margin-bottom: 30px;
        }
        
        .order-summary {
            background-color: #f9f9f9;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            text-align: left;
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        
        .buttons {
            margin-top: 30px;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4a934a;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            text-decoration: none;
            margin: 0 10px;
            transition: background-color 0.2s;
        }
        
        .btn:hover {
            background-color: #3a7a3a;
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid #4a934a;
            color: #4a934a;
        }
        
        .btn-outline:hover {
            background-color: #f0f8f0;
        }
        
        .btn-danger {
            background-color: #dc3545;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
    </style>
    <script>
        // Function to handle popup window for payment
        function openPaymentWindow() {
            // If we're in a popup, redirect the parent window
            if (window.opener && !window.opener.closed) {
                window.opener.location.href = 'payment.php';
                window.close();
            } else {
                // Otherwise just redirect this window
                window.location.href = 'payment.php';
            }
        }
    </script>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
    <main class="content">
        <div class="container">
            <div class="failed-container">
                <div class="failed-icon">
                    <i class="fas fa-times-circle"></i>
                </div>
                <h1 class="failed-title">Payment Failed</h1>
                <p class="failed-message">We're sorry, but your payment could not be processed at this time.</p>
                
                <div class="order-summary">
                    <div class="order-header">
                        <div>
                            <h2>Order #<?= $orderId ?></h2>
                            <p>Date: <?= isset($order['OrderDate']) ? date('F j, Y', strtotime($order['OrderDate'])) : 'N/A' ?></p>
                        </div>
                        <div>
                            <p>Status: <strong>Cancelled</strong></p>
                        </div>
                    </div>
                    
                    <p>Your order has been cancelled due to the payment failure. You can try again or contact our support team for assistance.</p>
                </div>
                
                <div class="buttons">
                    <a href="#" onclick="openPaymentWindow()" class="btn">Try Payment Again</a>
                    <a href="checkout.php" class="btn btn-outline">Return to Checkout</a>
                </div>
            </div>
        </div>
    </main>
</div>
</body>
</html>
