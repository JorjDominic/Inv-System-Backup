<?php
// payment.php
session_start();
require_once 'config/database.php';

// Check if order data exists
if (!isset($_SESSION['order_data'])) {
    header('Location: checkout.php');
    exit;
}

$orderData = $_SESSION['order_data'];

// Check if we're returning from a payment attempt
$isReturning = isset($_GET['order_id']);
$orderId = $isReturning ? intval($_GET['order_id']) : null;

// If returning, get the payment reference from session
$paymentReference = $_SESSION['payment_reference'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .payment-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .order-summary {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .order-summary h2 {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .summary-label {
            color: #666;
        }
        
        .summary-value {
            font-weight: 500;
        }
        
        .summary-total {
            font-size: 1.2rem;
            font-weight: 600;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .payment-options {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        
        .payment-options h2 {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .payment-option {
            text-align: center;
            padding: 20px;
        }
        
        .btn {
            display: inline-block;
            background-color: #4a934a;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 24px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .btn:hover {
            background-color: #3a7a3a;
        }
        
        .btn-primary {
            background-color: #4a934a;
        }
        
        .btn-primary:hover {
            background-color: #3a7a3a;
        }
        
        #payment-status {
            text-align: center;
            padding: 40px;
        }
        
        .spinner {
            display: inline-block;
            width: 50px;
            height: 50px;
            border: 3px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top-color: #4a934a;
            animation: spin 1s ease-in-out infinite;
            margin-bottom: 20px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-info {
            background-color: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
        }
        
        .alert-warning {
            background-color: #fff3cd;
            border: 1px solid #ffeeba;
            color: #856404;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>
    <div class="main-content-wrapper">
        <main class="content">
            <div class="container">
                <div class="header-container">
                    <h1>Complete Your Payment</h1>
                    <div class="link-container">
                        <a href="checkout.php" class="inventory-link">&lt;&lt; Back to Checkout</a>
                    </div>
                </div>
                
                <div class="payment-container">
                    <?php if ($isReturning && !empty($paymentReference)): ?>
                    <div class="alert alert-info">
                        <p><strong>Verifying your payment...</strong></p>
                        <p>Please wait while we check your payment status.</p>
                    </div>
                    
                    <div id="payment-status">
                        <div class="spinner"></div>
                        <p>Verifying payment...</p>
                        <p>Please do not close this window.</p>
                    </div>
                    <?php else: ?>
                    <div class="order-summary">
                        <h2>Order Summary</h2>
                        <div class="summary-row">
                            <div class="summary-label">Total Amount:</div>
                            <div class="summary-value">₱<?php echo number_format($orderData['total_amount'], 2); ?></div>
                        </div>
                        <div class="summary-row">
                            <div class="summary-label">Pickup Date:</div>
                            <div class="summary-value"><?php echo date('F j, Y', strtotime($orderData['pickup_date'])); ?></div>
                        </div>
                        <div class="summary-row">
                            <div class="summary-label">Pickup Code:</div>
                            <div class="summary-value"><?php echo $orderData['pickup_code']; ?></div>
                        </div>
                    </div>
                    
                    <div class="payment-options">
                        <h2>Choose Payment Method</h2>
                        
                        <div class="payment-option">
                            <p>You'll be redirected to a secure payment page where you can pay with your preferred method.</p>
                            <p>Available payment methods: Credit/Debit Card, GCash, Maya, GrabPay, and more.</p>
                            <button id="payWithLink" class="btn btn-primary">Proceed to Payment</button>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div id="payment-status" style="<?php echo (!$isReturning || empty($paymentReference)) ? 'display: none;' : ''; ?>">
                        <div class="spinner"></div>
                        <p>Processing your payment request...</p>
                        <p>Please do not close this window.</p>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script>
        $(document).ready(function() {
            let paymentWindow = null;
            let orderId = null;
            let referenceNumber = null;
            let verificationAttempts = 0;
            const maxVerificationAttempts = 5;
            
            $('#payWithLink').click(function() {
                // Show loading state
                $('#payment-status').show();
                $('.payment-options').hide();
                $('.order-summary').hide();
                
                // Create payment link
                $.ajax({
                    url: 'create_payment_link.php',
                    type: 'POST',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Response:', response);
                        if (response.success) {
                            // Store order ID and reference number
                            orderId = response.order_id;
                            referenceNumber = response.reference_number;
                            
                            // Open payment in new window
                            paymentWindow = window.open(response.checkout_url, 'PayMongo', 'width=800,height=600');
                            
                            // Hide loading state after a short delay
                            setTimeout(function() {
                                $('#payment-status').hide();
                                
                                // Show message about verification
                                Toastify({
                                    text: "Payment window opened. We'll automatically verify your payment when you complete it.",
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "center",
                                    backgroundColor: "#4a934a",
                                }).showToast();
                            }, 2000);
                            
                            // Check if window was closed
                            const checkWindowClosed = setInterval(function() {
                                if (paymentWindow && paymentWindow.closed) {
                                    clearInterval(checkWindowClosed);
                                    // Focus back on our window
                                    window.focus();
                                    
                                    // Show verification in progress
                                    $('#payment-status').show();
                                    
                                    // Auto-verify payment after window is closed
                                    verifyPayment(referenceNumber);
                                }
                            }, 1000);
                        } else {
                            Toastify({
                                text: "Error: " + response.message,
                                duration: 5000,
                                close: true,
                                gravity: "top",
                                position: "center",
                                backgroundColor: "#ff6b6b",
                            }).showToast();
                            
                            $('#payment-status').hide();
                            $('.payment-options').show();
                            $('.order-summary').show();
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr.responseText);
                        Toastify({
                            text: "An error occurred while processing your request.",
                            duration: 5000,
                            close: true,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#ff6b6b",
                        }).showToast();
                        
                        $('#payment-status').hide();
                        $('.payment-options').show();
                        $('.order-summary').show();
                    }
                });
            });
            
            // Function to verify payment
            function verifyPayment(reference) {
                if (!reference) {
                    Toastify({
                        text: "Missing reference number for verification",
                        duration: 3000,
                        close: true,
                        gravity: "top",
                        position: "center",
                        backgroundColor: "#ff6b6b",
                    }).showToast();
                    return;
                }
                
                // Show loading state if not already visible
                $('#payment-status').show();
                
                // Verify payment
                $.ajax({
                    url: 'verify_payment.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        reference_number: reference
                    },
                    success: function(response) {
                        if (response.success) {
                            // Redirect to success page
                            window.location.href = 'payment_success.php?order_id=' + response.order_id;
                        } else {
                            // If payment is still pending and we haven't reached max attempts, try again
                            if (response.status === 'unpaid' && verificationAttempts < maxVerificationAttempts) {
                                verificationAttempts++;
                                
                                // Show message about retrying
                                Toastify({
                                    text: "Payment still processing. Retrying verification in 3 seconds... (Attempt " + verificationAttempts + "/" + maxVerificationAttempts + ")",
                                    duration: 3000,
                                    close: true,
                                    gravity: "top",
                                    position: "center",
                                    backgroundColor: "#f59e0b",
                                }).showToast();
                                
                                // Try again after 3 seconds
                                setTimeout(function() {
                                    verifyPayment(reference);
                                }, 3000);
                            } else {
                                // Max attempts reached or payment failed
                                Toastify({
                                    text: "Payment verification failed: " + response.message,
                                    duration: 5000,
                                    close: true,
                                    gravity: "top",
                                    position: "center",
                                    backgroundColor: "#ff6b6b",
                                }).showToast();
                                
                                // Redirect to payment failed page after a delay
                                setTimeout(function() {
                                    window.location.href = 'payment_failed.php' + (orderId ? '?order_id=' + orderId : '');
                                }, 3000);
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr.responseText);
                        Toastify({
                            text: "An error occurred while verifying your payment.",
                            duration: 5000,
                            close: true,
                            gravity: "top",
                            position: "center",
                            backgroundColor: "#ff6b6b",
                        }).showToast();
                        
                        // If we haven't reached max attempts, try again
                        if (verificationAttempts < maxVerificationAttempts) {
                            verificationAttempts++;
                            
                            // Try again after 3 seconds
                            setTimeout(function() {
                                verifyPayment(reference);
                            }, 3000);
                        } else {
                            // Max attempts reached
                            $('#payment-status').hide();
                            
                            // Show retry button
                            $('<div class="payment-options" style="margin-top: 20px;">' +
                              '<div class="payment-option">' +
                              '<p>We\'re having trouble verifying your payment. Please try again.</p>' +
                              '<button id="retryVerification" class="btn btn-primary">Retry Verification</button>' +
                              '</div></div>').appendTo('.payment-container');
                            
                            $('#retryVerification').click(function() {
                                verificationAttempts = 0;
                                $('#payment-status').show();
                                $(this).closest('.payment-options').remove();
                                verifyPayment(reference);
                            });
                        }
                    }
                });
            }
            
            // Auto-verify if we have a reference number and we're returning from payment
            <?php if ($isReturning && !empty($paymentReference)): ?>
            // Start verification immediately
            verifyPayment('<?php echo $paymentReference; ?>');
            <?php endif; ?>
        });
    </script>
</body>
</html>
