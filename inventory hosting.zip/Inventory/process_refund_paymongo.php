<?php
// process_refund.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Add PHPMailer requirements
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Function to send email notification
function sendRefundEmail($to, $customerName, $orderId, $amount, $reason) {
    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'b6664253@gmail.com'; // Replace with your email
        $mail->Password   = 'wbbkxuoxrvguckjj'; // Replace with your app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        // Recipients
        $mail->setFrom('your-email@gmail.com', 'Your Store Name'); // Replace with your email and store name
        $mail->addAddress($to, $customerName);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Your Order #$orderId Has Been Refunded";
        
        // Email template with basic styling
        $emailBody = '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }
                .header {
                    background-color: #4a934a;
                    color: white;
                    padding: 10px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    padding: 20px;
                }
                .footer {
                    background-color: #f5f5f5;
                    padding: 10px;
                    text-align: center;
                    font-size: 12px;
                    border-radius: 0 0 5px 5px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Your Store Name</h2>
                </div>
                <div class="content">
                    <p>Dear ' . $customerName . ',</p>
                    <h3>Order Refund Confirmation</h3>
                    <p>We\'re writing to confirm that your Order #' . $orderId . ' has been refunded.</p>
                    <p><strong>Refund Details:</strong></p>
                    <ul>
                        <li>Order Number: #' . $orderId . '</li>
                        <li>Refund Amount: ₱' . number_format($amount, 2) . '</li>
                        <li>Reason: ' . htmlspecialchars($reason) . '</li>
                    </ul>
                    <p>The refunded amount should appear in your account within 3-5 business days, depending on your payment provider.</p>
                    <p>If you have any questions about this refund, please don\'t hesitate to contact our customer service team.</p>
                </div>
                <div class="footer">
                    <p>If you have any questions, please contact our customer service.</p>
                    <p>&copy; ' . date('Y') . ' Your Store Name. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ';
        
        $mail->Body = $emailBody;
        $mail->AltBody = strip_tags("Your Order #$orderId has been refunded for ₱" . number_format($amount, 2) . ". Reason: $reason"); // Plain text version
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], [1, 2, 3])) { // Only Owner, Developer, Cashier can process refunds
    header('Location: login.php');
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid request method';
    header('Location: order_processing.php');
    exit;
}

// Get form data
$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$transactionId = isset($_POST['transaction_id']) ? intval($_POST['transaction_id']) : 0;
$paymentMethod = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
$reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
$refundItems = isset($_POST['refund_items']) ? $_POST['refund_items'] : [];

// Validate input
if ($orderId <= 0 || $amount <= 0 || empty($reason)) {
    $_SESSION['error'] = 'Missing or invalid refund information';
    header('Location: order_details.php?id=' . $orderId);
    exit;
}

try {
    // Start transaction
    $conn->beginTransaction();
    
    // Get customer information for email notification
    $stmt = $conn->prepare("
        SELECT c.FirstName, c.LastName, c.Email
        FROM Orders o
        JOIN Customers c ON o.CustomerID = c.CustomerID
        WHERE o.OrderID = ?
    ");
    $stmt->execute([$orderId]);
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$customer) {
        throw new Exception('Customer information not found');
    }
    
    $customerName = $customer['FirstName'] . ' ' . $customer['LastName'];
    $customerEmail = $customer['Email'];
    
    // If transaction ID is 0, create a new transaction record
    if ($transactionId <= 0) {
        // Get order total amount
        $stmt = $conn->prepare("SELECT TotalAmount FROM Orders WHERE OrderID = ?");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            throw new Exception('Order not found');
        }
        
        // Get payment method ID (default to cash if not specified)
        $paymentMethodId = 1; // Assuming 1 is Cash
        if (!empty($paymentMethod) && $paymentMethod !== 'Cash') {
            $stmt = $conn->prepare("SELECT PaymentMethodID FROM PaymentMethods WHERE MethodName = ?");
            $stmt->execute([$paymentMethod]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($result) {
                $paymentMethodId = $result['PaymentMethodID'];
            }
        }
        
        // Create transaction record
        $stmt = $conn->prepare("
            INSERT INTO Transactions (
                OrderID, 
                PaymentMethodID, 
                Amount, 
                Status, 
                CreatedAt
            ) VALUES (?, ?, ?, 'completed', NOW())
        ");
        $stmt->execute([
            $orderId,
            $paymentMethodId,
            $order['TotalAmount']
        ]);
        
        $transactionId = $conn->lastInsertId();
    }
    
    // Get transaction details
    $stmt = $conn->prepare("
        SELECT t.*, o.TotalAmount, pm.MethodName 
        FROM Transactions t
        JOIN Orders o ON t.OrderID = o.OrderID
        JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
        WHERE t.TransactionID = ?
    ");
    $stmt->execute([$transactionId]);
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$transaction) {
        throw new Exception('Transaction not found');
    }
    
    // Check if amount is valid
    if ($amount > $transaction['Amount']) {
        throw new Exception('Refund amount cannot exceed the original transaction amount');
    }
    
    // Create refund record
    $stmt = $conn->prepare("
        INSERT INTO Refunds (
            TransactionID, 
            Amount, 
            Reason, 
            ProcessedBy, 
            Status
        ) VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $transactionId,
        $amount,
        $reason,
        $_SESSION['user_id'],
        'pending'
    ]);
    $refundId = $conn->lastInsertId();
    
    // Process refunded items if selected
    if (!empty($refundItems)) {
        foreach ($refundItems as $orderDetailId) {
            $quantityKey = 'refund_quantity_' . $orderDetailId;
            $refundQuantity = isset($_POST[$quantityKey]) ? intval($_POST[$quantityKey]) : 0;
            
            if ($refundQuantity <= 0) {
                continue;
            }
            
            // Get order detail information
            $stmt = $conn->prepare("
                SELECT od.*, p.ProductID 
                FROM OrderDetails od
                JOIN Product p ON od.ProductID = p.ProductID
                WHERE od.OrderDetailID = ?
            ");
            $stmt->execute([$orderDetailId]);
            $orderDetail = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$orderDetail) {
                continue;
            }
            
            // Validate refund quantity
            if ($refundQuantity > $orderDetail['Quantity']) {
                $refundQuantity = $orderDetail['Quantity'];
            }
            
            // Insert into RefundedItems
            $stmt = $conn->prepare("
                INSERT INTO RefundedItems (
                    OrderID, 
                    ProductID, 
                    QuantityRefunded, 
                    ItemCondition, 
                    ProcessedBy
                ) VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $orderId,
                $orderDetail['ProductID'],
                $refundQuantity,
                'PRISTINE', // Default condition, can be updated later
                $_SESSION['user_id']
            ]);
            
            // Optionally return items to inventory
            // This depends on your business logic - whether refunded items go back to inventory
            $stmt = $conn->prepare("
                INSERT INTO Inventory (
                    ProductID, 
                    Quantity, 
                    DateReceived
                ) VALUES (?, ?, CURRENT_DATE)
            ");
            $stmt->execute([
                $orderDetail['ProductID'],
                $refundQuantity
            ]);
            
            // Log inventory change
            $stmt = $conn->prepare("
                INSERT INTO InventoryLogs (
                    UserID, 
                    UsernameSnapshot, 
                    ProductNameSnapshot, 
                    Action, 
                    QuantityChanged, 
                    Remarks
                ) VALUES (
                    ?, 
                    (SELECT Username FROM Users WHERE UserID = ?), 
                    (SELECT ProductName FROM Product WHERE ProductID = ?), 
                    'REFUND_RETURN', 
                    ?, 
                    ?
                )
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $_SESSION['user_id'],
                $orderDetail['ProductID'],
                $refundQuantity,
                "Items returned to inventory from Order #$orderId refund"
            ]);
        }
    }
    
    // Process PayMongo refund if applicable
    if (in_array($transaction['MethodName'], ['GCash', 'Card', 'Maya', 'GrabPay'])) {
        // Check if there's a PayMongo transaction
        $stmt = $conn->prepare("
            SELECT * FROM PaymongoTransactions 
            WHERE TransactionID = ?
        ");
        $stmt->execute([$transactionId]);
        $paymongoTx = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($paymongoTx && !empty($paymongoTx['PaymentID'])) {
            // Add this code to check the payment ID column exists
            try {
                $checkColumnStmt = $conn->prepare("SHOW COLUMNS FROM PaymongoTransactions LIKE 'PaymentID'");
                $checkColumnStmt->execute();
                $columnExists = $checkColumnStmt->rowCount() > 0;
                
                if (!$columnExists) {
                    // The column might be named differently
                    $checkColumnStmt = $conn->prepare("SHOW COLUMNS FROM PaymongoTransactions LIKE 'payment_id'");
                    $checkColumnStmt->execute();
                    $columnExists = $checkColumnStmt->rowCount() > 0;
                    
                    if ($columnExists) {
                        // Use the correct column name
                        $stmt = $conn->prepare("
                            SELECT payment_id FROM PaymongoTransactions 
                            WHERE TransactionID = ?
                        ");
                        $stmt->execute([$transactionId]);
                        $result = $stmt->fetch(PDO::FETCH_ASSOC);
                        if ($result && !empty($result['payment_id'])) {
                            $paymentId = $result['payment_id'];
                        }
                    }
                }
            } catch (Exception $e) {
                error_log('Error checking PaymongoTransactions columns: ' . $e->getMessage());
            }
            // Load PayMongo API credentials
            $paymongoSecretKey = getenv('PAYMONGO_SECRET_KEY');
            
            if (empty($paymongoSecretKey)) {
                throw new Exception('PayMongo API credentials not configured');
            }
            
            // Prepare PayMongo API request
            $paymentId = $paymongoTx['PaymentID'];
            $refundData = [
                'data' => [
                    'attributes' => [
                        'amount' => intval($amount * 100), // Convert to cents
                        'reason' => 'requested_by_customer',
                        'notes' => $reason
                    ]
                ]
            ];
            
            // Initialize cURL session
            $ch = curl_init("https://api.paymongo.com/v1/payments/{$paymentId}/refunds");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($refundData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode($paymongoSecretKey . ':')
            ]);
            
            // Execute the request
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            // Process the response
            $responseData = json_decode($response, true);
            
            if ($httpCode >= 200 && $httpCode < 300 && isset($responseData['data']['id'])) {
                // Update refund record with PayMongo reference
                $stmt = $conn->prepare("
                    UPDATE Refunds 
                    SET Status = 'completed', RefundReference = ? 
                    WHERE RefundID = ?
                ");
                $stmt->execute([$responseData['data']['id'], $refundId]);
                
                // Update order status to refunded
                $stmt = $conn->prepare("
                    UPDATE Orders 
                    SET OrderStatus = 'refunded', UpdatedAt = NOW() 
                    WHERE OrderID = ?
                ");
                $stmt->execute([$orderId]);
                
                // Update transaction status
                $stmt = $conn->prepare("
                    UPDATE Transactions 
                    SET Status = 'refunded', UpdatedAt = NOW() 
                    WHERE TransactionID = ?
                ");
                $stmt->execute([$transactionId]);
                
                // Log the refund in audit trail
                $stmt = $conn->prepare("
                    INSERT INTO audit_trail (
                        affected_username, 
                        changed_by, 
                        action, 
                        timestamp
                    ) VALUES (
                        (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
                        (SELECT Username FROM Users WHERE UserID = ?),
                        ?, 
                        NOW()
                    )
                ");
                $stmt->execute([
                    $orderId,
                    $_SESSION['user_id'],
                    "Refunded ₱" . number_format($amount, 2) . " for Order #$orderId via PayMongo. Reason: $reason"
                ]);
                
                // Send email notification to customer
                if (!empty($customerEmail)) {
                    sendRefundEmail($customerEmail, $customerName, $orderId, $amount, $reason);
                }
                
                // Notify customer about the refund
                if ($customer && isset($customer['UserID'])) {
                    $notificationMessage = "Your Order #$orderId has been refunded ₱" . number_format($amount, 2) . ". Reason: $reason";
                    createNotification(
                        $conn,
                        $customer['UserID'],
                        'refund',
                        $notificationMessage
                    );
                }
                
                $conn->commit();
                $_SESSION['success'] = 'Refund processed successfully via PayMongo';
            } else {
                // PayMongo API error
                $errorMessage = isset($responseData['errors'][0]['detail']) 
                    ? $responseData['errors'][0]['detail'] 
                    : 'Unknown error from PayMongo API';
                
                // Update refund record with failed status
                $stmt = $conn->prepare("
                    UPDATE Refunds 
                    SET Status = 'failed' 
                    WHERE RefundID = ?
                ");
                $stmt->execute([$refundId]);
                
                throw new Exception('PayMongo refund failed: ' . $errorMessage);
            }
        } else {
            // Process as manual refund if PayMongo info not found
            // Update refund record
            $stmt = $conn->prepare("
                UPDATE Refunds 
                SET Status = 'completed'
                WHERE RefundID = ?
            ");
            $stmt->execute([$refundId]);
            
            // Update order status to refunded
            $stmt = $conn->prepare("
                UPDATE Orders 
                SET OrderStatus = 'refunded', UpdatedAt = NOW() 
                WHERE OrderID = ?
            ");
            $stmt->execute([$orderId]);
            
            // Update transaction status
            $stmt = $conn->prepare("
                UPDATE Transactions 
                SET Status = 'refunded', UpdatedAt = NOW() 
                WHERE TransactionID = ?
            ");
            $stmt->execute([$transactionId]);
            
            // Log the refund in audit trail
            $stmt = $conn->prepare("
                INSERT INTO audit_trail (
                    affected_username, 
                    changed_by, 
                    action, 
                    timestamp
                ) VALUES (
                    (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
                    (SELECT Username FROM Users WHERE UserID = ?),
                    ?, 
                    NOW()
                )
            ");
            $stmt->execute([
                $orderId,
                $_SESSION['user_id'],
                "Refunded ₱" . number_format($amount, 2) . " for Order #$orderId manually (PayMongo info not found). Reason: $reason"
            ]);
            
            // Send email notification to customer
            if (!empty($customerEmail)) {
                sendRefundEmail($customerEmail, $customerName, $orderId, $amount, $reason);
            }
            
            // Notify customer about the refund
            if ($customer && isset($customer['UserID'])) {
                $notificationMessage = "Your Order #$orderId has been refunded ₱" . number_format($amount, 2) . ". Reason: $reason";
                createNotification(
                    $conn,
                    $customer['UserID'],
                    'refund',
                    $notificationMessage
                );
            }
            
            $conn->commit();
            $_SESSION['success'] = 'Refund processed successfully (manual process)';
        }
    } else {
        // For non-PayMongo payments (Cash, Credit, etc.)
        // Update refund record
        $stmt = $conn->prepare("
            UPDATE Refunds 
            SET Status = 'completed'
            WHERE RefundID = ?
        ");
        $stmt->execute([$refundId]);
        
        // Update order status to refunded
        $stmt = $conn->prepare("
            UPDATE Orders 
            SET OrderStatus = 'refunded', UpdatedAt = NOW() 
            WHERE OrderID = ?
        ");
        $stmt->execute([$orderId]);
        
        // Update transaction status
        $stmt = $conn->prepare("
            UPDATE Transactions 
            SET Status = 'refunded', UpdatedAt = NOW() 
            WHERE TransactionID = ?
        ");
        $stmt->execute([$transactionId]);
        
        // Log the refund in audit trail
        $stmt = $conn->prepare("
            INSERT INTO audit_trail (
                affected_username, 
                changed_by, 
                action, 
                timestamp
            ) VALUES (
                (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
                (SELECT Username FROM Users WHERE UserID = ?),
                ?, 
                NOW()
            )
        ");
        $stmt->execute([
            $orderId,
            $_SESSION['user_id'],
            "Refunded ₱" . number_format($amount, 2) . " for Order #$orderId manually. Reason: $reason"
        ]);
        
        // Send email notification to customer
        if (!empty($customerEmail)) {
            sendRefundEmail($customerEmail, $customerName, $orderId, $amount, $reason);
        }
        
        // Notify customer about the refund
        if ($customer && isset($customer['UserID'])) {
            $notificationMessage = "Your Order #$orderId has been refunded ₱" . number_format($amount, 2) . ". Reason: $reason";
            createNotification(
                $conn,
                $customer['UserID'],
                'refund',
                $notificationMessage
            );
        }
        
        $conn->commit();
        $_SESSION['success'] = 'Refund processed successfully';
    }
    
    header('Location: order_details.php?id=' . $orderId);
    exit;
    
} catch (Exception $e) {
    $conn->rollBack();
    $_SESSION['error'] = 'Error processing refund: ' . $e->getMessage();
    error_log('Refund error: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
    header('Location: order_details.php?id=' . $orderId);
    exit;
}
?>
