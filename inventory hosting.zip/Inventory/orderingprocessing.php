<?php
// order_processing.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Add PHPMailer requirements
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], [1, 2, 3, 4])) { // Owner, Developer, Cashier, Staff
    header('Location: login.php');
    exit;
}

// Function to send email notification
function sendEmailNotification($to, $subject, $message, $customerName) {
    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'b6664253@gmail.com'; // Replace with your email
        $mail->Password   = 'wbbkxuoxrvguckjj'; // Replace with your app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        // Recipients
        $mail->setFrom('your-email@gmail.com', 'Your Store Name'); // Replace with your email and store name
        $mail->addAddress($to, $customerName);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        
        // Email template with basic styling
        $emailBody = '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }
                .header {
                    background-color: #4a934a;
                    color: white;
                    padding: 10px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    padding: 20px;
                }
                .footer {
                    background-color: #f5f5f5;
                    padding: 10px;
                    text-align: center;
                    font-size: 12px;
                    border-radius: 0 0 5px 5px;
                }
                .button {
                    display: inline-block;
                    padding: 10px 20px;
                    background-color: #4a934a;
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    margin-top: 15px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2>Your Store Name</h2>
                </div>
                <div class="content">
                    <p>Dear ' . $customerName . ',</p>
                    ' . $message . '
                </div>
                <div class="footer">
                    <p>If you have any questions, please contact our customer service.</p>
                    <p>&copy; ' . date('Y') . ' Your Store Name. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ';
        
        $mail->Body = $emailBody;
        $mail->AltBody = strip_tags($message); // Plain text version
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

// Process order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $orderId = $_POST['order_id'];
    $newStatus = $_POST['status'];
    $notes = $_POST['notes'] ?? '';
    
    // Validate status - Added 'refunded' to valid statuses
    $validStatuses = ['preparing', 'ready_for_pickup', 'completed', 'cancelled', 'refunded'];
    if (!in_array($newStatus, $validStatuses)) {
        $_SESSION['error'] = 'Invalid order status';
        header('Location: orders.php');
        exit;
    }
    
    try {
        // Start transaction
        $conn->beginTransaction();
        
        // Update order status
        $stmt = $conn->prepare("
            UPDATE Orders 
            SET OrderStatus = ?, UpdatedAt = NOW() 
            WHERE OrderID = ?
        ");
        $stmt->execute([$newStatus, $orderId]);
        
        // Log the status change
        $stmt = $conn->prepare("
            INSERT INTO audit_trail (
                affected_username, changed_by, action, timestamp
            ) VALUES (
                (SELECT CONCAT(c.FirstName, ' ', c.LastName) FROM Orders o JOIN Customers c ON o.CustomerID = c.CustomerID WHERE o.OrderID = ?),
                (SELECT Username FROM Users WHERE UserID = ?),
                ?, 
                NOW()
            )
        ");
        $stmt->execute([
            $orderId,
            $_SESSION['user_id'],
            "Updated Order #$orderId status to " . ucfirst(str_replace('_', ' ', $newStatus)) . ($notes ? ": $notes" : '')
        ]);
        
        // Get customer info
        $stmt = $conn->prepare("
            SELECT o.CustomerID, c.UserID, c.Email, c.FirstName, c.LastName, 
                   o.PickupDate, o.PickupTime, o.TotalAmount
            FROM Orders o
            JOIN Customers c ON o.CustomerID = c.CustomerID
            WHERE o.OrderID = ?
        ");
        $stmt->execute([$orderId]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Send notification based on new status
        if ($customer) {
            $notificationMessage = '';
            $notificationType = 'order_status';
            $link = 'order_details.php?id=' . $orderId;
            $emailSubject = '';
            $emailMessage = '';
            $sendEmail = false;
            $customerFullName = $customer['FirstName'] . ' ' . $customer['LastName'];
            
            switch ($newStatus) {
                case 'preparing':
                    $notificationMessage = "Your Order #$orderId is now being prepared. We'll notify you when it's ready for pickup.";
                    break;
                    
                case 'ready_for_pickup':
                    // Get pickup code
                    $stmt = $conn->prepare("SELECT PickupCode FROM Orders WHERE OrderID = ?");
                    $stmt->execute([$orderId]);
                    $order = $stmt->fetch(PDO::FETCH_ASSOC);
                    $pickupCode = $order['PickupCode'];
                    
                    $notificationMessage = "Your Order #$orderId is now ready for pickup. Your pickup code is: $pickupCode";
                    
                    // Prepare email for ready for pickup
                    $emailSubject = "Your Order #$orderId is Ready for Pickup";
                    $emailMessage = "
                        <h3>Your Order is Ready for Pickup!</h3>
                        <p>We're pleased to inform you that your Order #$orderId is now ready for pickup.</p>
                        <p><strong>Pickup Details:</strong></p>
                        <ul>
                            <li>Pickup Date: " . date('F j, Y', strtotime($customer['PickupDate'])) . "</li>
                            <li>Pickup Time: " . date('g:i A', strtotime($customer['PickupTime'])) . "</li>
                            <li>Pickup Code: <strong>$pickupCode</strong></li>
                        </ul>
                        <p>Please present this pickup code when you arrive to collect your order.</p>
                        <p>Thank you for your business!</p>
                    ";
                    $sendEmail = true;
                    break;
                    
                case 'completed':
                    $notificationMessage = "Your Order #$orderId has been completed. Thank you for your business!";
                    break;
                    
                case 'cancelled':
                    $notificationMessage = "Your Order #$orderId has been cancelled. " . ($notes ? "Reason: $notes" : "Please contact us for more information.");
                    break;
                    
                case 'refunded':
                    $notificationMessage = "Your Order #$orderId has been refunded. " . ($notes ? "Reason: $notes" : "Please contact us for more information.");
                    
                    // Prepare email for refund
                    $emailSubject = "Your Order #$orderId Has Been Refunded";
                    $emailMessage = "
                        <h3>Order Refund Confirmation</h3>
                        <p>We're writing to confirm that your Order #$orderId has been refunded.</p>
                        <p><strong>Refund Details:</strong></p>
                        <ul>
                            <li>Order Number: #$orderId</li>
                            <li>Refund Amount: ₱" . number_format($customer['TotalAmount'], 2) . "</li>
                            <li>Reason: " . ($notes ? htmlspecialchars($notes) : "Please contact us for more information.") . "</li>
                        </ul>
                        <p>The refunded amount should appear in your account within 3-5 business days, depending on your payment provider.</p>
                        <p>If you have any questions about this refund, please don't hesitate to contact our customer service team.</p>
                    ";
                    $sendEmail = true;
                    break;
            }
            
            // Send in-app notification if user has an account
            if (!empty($notificationMessage) && $customer['UserID']) {
                createNotification(
                    $conn,
                    $customer['UserID'],
                    $notificationType,
                    $notificationMessage
                );
            }
            
            // Send email notification if applicable
            if ($sendEmail && !empty($customer['Email'])) {
                sendEmailNotification(
                    $customer['Email'],
                    $emailSubject,
                    $emailMessage,
                    $customerFullName
                );
            }
        }
        
        $conn->commit();
        $_SESSION['success'] = 'Order status updated successfully';
        
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error'] = 'Error updating order status: ' . $e->getMessage();
    }
    
    header('Location: order_details.php?id=' . $orderId);
    exit;
}

// Get orders based on status filter
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'paid';
// Added 'refunded' to valid filters
$validFilters = ['pending', 'paid', 'preparing', 'ready_for_pickup', 'completed', 'cancelled', 'refunded', 'all'];

if (!in_array($statusFilter, $validFilters)) {
    $statusFilter = 'paid';
}

$sql = "
    SELECT 
        o.OrderID, 
        o.OrderDate, 
        o.OrderStatus,
        o.PickupDate,
        o.PickupTime,
        o.PickupCode,
        o.TotalAmount,
        CONCAT(c.FirstName, ' ', c.LastName) AS CustomerName,
        c.Email AS CustomerEmail,
        COUNT(od.OrderDetailID) AS ItemCount,
        t.Status AS PaymentStatus,
        COALESCE(t.TransactionID, 0) AS TransactionID,
        COALESCE(t.PaymentMethodID, 0) AS PaymentMethodID,
        COALESCE(pm.MethodName, 'Cash') AS PaymentMethod
    FROM Orders o
    JOIN Customers c ON o.CustomerID = c.CustomerID
    JOIN OrderDetails od ON o.OrderID = od.OrderID
    LEFT JOIN Transactions t ON o.OrderID = t.OrderID
    LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
    WHERE 1=1
";

if ($statusFilter !== 'all') {
    $sql .= " AND o.OrderStatus = :status";
}

$sql .= "
    GROUP BY o.OrderID, o.OrderDate, o.OrderStatus, o.PickupDate, o.PickupTime, 
             o.PickupCode, o.TotalAmount, CustomerName, CustomerEmail, PaymentStatus, t.TransactionID, t.PaymentMethodID, pm.MethodName
    ORDER BY 
        CASE 
            WHEN o.OrderStatus = 'paid' THEN 1
            WHEN o.OrderStatus = 'preparing' THEN 2
            WHEN o.OrderStatus = 'ready_for_pickup' THEN 3
            WHEN o.OrderStatus = 'pending' THEN 4
            WHEN o.OrderStatus = 'completed' THEN 5
            WHEN o.OrderStatus = 'refunded' THEN 6
            WHEN o.OrderStatus = 'cancelled' THEN 7
            ELSE 8
        END,
        o.OrderDate DESC
";

$stmt = $conn->prepare($sql);

if ($statusFilter !== 'all') {
    $stmt->bindParam(':status', $statusFilter);
}

$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Processing</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .order-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    
    .order-card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      transition: transform 0.2s;
    }
    
    .order-card:hover {
      transform: translateY(-5px);
    }
    
    .order-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .order-id {
      font-size: 1.2rem;
      font-weight: 600;
    }
    
    .order-status {
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 500;
    }
    
    .status-pending {
      background-color: #f0f0f0;
      color: #666;
    }
    
    .status-paid {
      background-color: #e3f2fd;
      color: #1976d2;
    }
    
    .status-preparing {
      background-color: #fff8e1;
      color: #f57f17;
    }
    
    .status-ready_for_pickup {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-completed {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-cancelled {
      background-color: #ffebee;
      color: #c62828;
    }
    
    .status-refunded {
      background-color: #e8eaf6;
      color: #3f51b5;
    }
    
    .order-info {
      margin-bottom: 15px;
    }
    
    .info-row {
      display: flex;
      margin-bottom: 8px;
    }
    
    .info-label {
      width: 120px;
      color: #666;
      font-size: 0.9rem;
    }
    
    .info-value {
      flex: 1;
      font-weight: 500;
    }
    
    .pickup-code {
      background-color: #f5f5f5;
      padding: 8px;
      border-radius: 4px;
      text-align: center;
      font-size: 1.2rem;
      font-weight: 600;
      letter-spacing: 2px;
      margin: 10px 0;
    }
    
    .order-actions {
      display: flex;
      gap: 10px;
      margin-top: 15px;
      flex-wrap: wrap;
    }
    
    .action-btn {
      flex: 1;
      padding: 8px;
      border: none;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
      text-decoration: none;
    }
    
    .action-btn i {
      margin-right: 5px;
    }
    
    .btn-view {
      background-color: #e3f2fd;
      color: #1976d2;
    }
    
    .btn-view:hover {
      background-color: #bbdefb;
    }
    
    .btn-process {
      background-color: #fff8e1;
      color: #f57f17;
    }
    
    .btn-process:hover {
      background-color: #ffecb3;
    }
    
    .btn-ready {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .btn-ready:hover {
      background-color: #c8e6c9;
    }
    
    .btn-complete {
      background-color: #4a934a;
      color: white;
    }
    
    .btn-complete:hover {
      background-color: #3a7a3a;
    }
    
    .btn-refund {
      background-color: #e8eaf6;
      color: #3f51b5;
    }
    
    .btn-refund:hover {
      background-color: #c5cae9;
    }
    
    .filter-tabs {
      display: flex;
      overflow-x: auto;
      gap: 10px;
      margin-bottom: 20px;
      padding-bottom: 10px;
    }
    
    .filter-tab {
      padding: 8px 16px;
      background-color: #f5f5f5;
      border-radius: 20px;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      transition: background-color 0.2s;
      text-decoration: none;
      color: #333;
    }
    
    .filter-tab.active {
      background-color: #4a934a;
      color: white;
    }
    
    .filter-tab:hover:not(.active) {
      background-color: #e0e0e0;
    }
    
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }
    
    .modal.active {
      display: flex;
    }
    
    .modal-content {
      background-color: white;
      border-radius: 8px;
      max-width: 500px;
      width: 100%;
      padding: 20px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .modal-title {
      font-size: 1.2rem;
      font-weight: 600;
    }
    
    .modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #666;
    }
    
    .modal-body {
      margin-bottom: 20px;
    }
    
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    
    .empty-state {
      text-align: center;
      padding: 40px 0;
    }
    
    .empty-state i {
      font-size: 3rem;
      color: #ccc;
      margin-bottom: 20px;
    }
    
    .empty-state h3 {
      font-size: 1.2rem;
      margin-bottom: 10px;
      color: #666;
    }
    
    .empty-state p {
      color: #888;
      max-width: 400px;
      margin: 0 auto;
    }
    
    .form-group {
      margin-bottom: 15px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 500;
    }
    
    .form-control {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
    }
    
    .btn {
      padding: 8px 16px;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      border: none;
    }
    
    .btn-primary {
      background-color: #4a934a;
      color: white;
    }
    
    .btn-primary:hover {
      background-color: #3a7a3a;
    }
    
    .btn-secondary {
      background-color: #f5f5f5;
      color: #333;
    }
    
    .btn-secondary:hover {
      background-color: #e0e0e0;
    }
    
    .alert {
      padding: 12px 16px;
      border-radius: 4px;
      margin-bottom: 20px;
    }
    
    .alert-success {
      background-color: #e8f5e9;
      border: 1px solid #c8e6c9;
      color: #2e7d32;
    }
    
    .alert-danger {
      background-color: #ffebee;
      border: 1px solid #ffcdd2;
      color: #c62828;
    }
    
    @media (max-width: 768px) {
      .order-container {
        grid-template-columns: 1fr;
      }
      
      .filter-tabs {
        padding-bottom: 15px;
      }
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>Order Processing</h1>
      </div>
      
      
      
      
      
      <div class="filter-tabs">
        <a href="?status=all" class="filter-tab <?= $statusFilter === 'all' ? 'active' : '' ?>">
          All Orders
        </a>
        <a href="?status=paid" class="filter-tab <?= $statusFilter === 'paid' ? 'active' : '' ?>">
          Paid
        </a>
        <a href="?status=preparing" class="filter-tab <?= $statusFilter === 'preparing' ? 'active' : '' ?>">
          Preparing
        </a>
        <a href="?status=ready_for_pickup" class="filter-tab <?= $statusFilter === 'ready_for_pickup' ? 'active' : '' ?>">
          Ready for Pickup
        </a>
        <a href="?status=completed" class="filter-tab <?= $statusFilter === 'completed' ? 'active' : '' ?>">
          Completed
        </a>
        <a href="?status=refunded" class="filter-tab <?= $statusFilter === 'refunded' ? 'active' : '' ?>">
          Refunded
        </a>
        <a href="?status=cancelled" class="filter-tab <?= $statusFilter === 'cancelled' ? 'active' : '' ?>">
          Cancelled
        </a>
      </div>
      
      <?php if (empty($orders)): ?>
        <div class="empty-state">
          <i class="fas fa-shopping-bag"></i>
          <h3>No orders found</h3>
          <p>There are no orders with the selected status at this time.</p>
        </div>
      <?php else: ?>
        <div class="order-container">
          <?php foreach ($orders as $order): ?>
            <div class="order-card">
              <div class="order-header">
                <div class="order-id">Order #<?= $order['OrderID'] ?></div>
                <div class="order-status status-<?= $order['OrderStatus'] ?>">
                  <?= ucfirst(str_replace('_', ' ', $order['OrderStatus'])) ?>
                </div>
              </div>
              
              <div class="order-info">
                <div class="info-row">
                  <div class="info-label">Customer:</div>
                  <div class="info-value"><?= htmlspecialchars($order['CustomerName']) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Email:</div>
                  <div class="info-value"><?= htmlspecialchars($order['CustomerEmail']) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Order Date:</div>
                  <div class="info-value"><?= date('M d, Y h:i A', strtotime($order['OrderDate'])) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Pickup Date:</div>
                  <div class="info-value"><?= date('M d, Y', strtotime($order['PickupDate'])) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Pickup Time:</div>
                  <div class="info-value"><?= date('h:i A', strtotime($order['PickupTime'])) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Items:</div>
                  <div class="info-value"><?= $order['ItemCount'] ?> items</div>
                </div>
                <div class="info-row">
                  <div class="info-label">Total:</div>
                  <div class="info-value">₱<?= number_format($order['TotalAmount'], 2) ?></div>
                </div>
                <div class="info-row">
                  <div class="info-label">Payment:</div>
                  <div class="info-value"><?= htmlspecialchars($order['PaymentMethod'] ?? 'N/A') ?></div>
                </div>
              </div>
              
              <?php if ($order['PickupCode']): ?>
                <div class="pickup-code"><?= $order['PickupCode'] ?></div>
              <?php endif; ?>
              
              <div class="order-actions">
                <a href="order_details.php?id=<?= $order['OrderID'] ?>" class="action-btn btn-view">
                  <i class="fas fa-eye"></i> View Details
                </a>
                
                <?php if ($order['OrderStatus'] === 'paid'): ?>
                  <button class="action-btn btn-process" onclick="updateStatus(<?= $order['OrderID'] ?>, 'preparing')">
                    <i class="fas fa-utensils"></i> Start Preparing
                  </button>
                <?php elseif ($order['OrderStatus'] === 'preparing'): ?>
                  <button class="action-btn btn-ready" onclick="updateStatus(<?= $order['OrderID'] ?>, 'ready_for_pickup')">
                    <i class="fas fa-check"></i> Mark Ready
                  </button>
                <?php elseif ($order['OrderStatus'] === 'ready_for_pickup'): ?>
                  <button class="action-btn btn-complete" onclick="updateStatus(<?= $order['OrderID'] ?>, 'completed')">
                    <i class="fas fa-check-double"></i> Complete
                  </button>
                  <?php elseif ($order['OrderStatus'] === 'completed'): ?>
  <button class="action-btn btn-refund" 
    data-order-id="<?= $order['OrderID'] ?>" 
    data-transaction-id="<?= $order['TransactionID'] ?>" 
    data-payment-method="<?= htmlspecialchars($order['PaymentMethod']) ?>" 
    data-amount="<?= $order['TotalAmount'] ?>"
    onclick="openRefundModal(<?= $order['OrderID'] ?>, <?= $order['TransactionID'] ?>, '<?= htmlspecialchars($order['PaymentMethod']) ?>', <?= $order['TotalAmount'] ?>)">
    <i class="fas fa-undo"></i> Refund
  </button>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </main>
</div>

<!-- Status Update Modal -->
<div id="statusModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 class="modal-title">Update Order Status</h2>
      <button class="modal-close" onclick="closeModal('statusModal')">&times;</button>
    </div>
    <form id="statusForm" method="post" action="">
      <input type="hidden" id="order_id" name="order_id">
      <input type="hidden" id="status" name="status">
      
      <div class="modal-body">
        <div class="form-group">
          <label for="notes">Additional Notes (Optional)</label>
          <textarea id="notes" name="notes" rows="3" class="form-control"></textarea>
        </div>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('statusModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Update Status</button>
      </div>
    </form>
  </div>
</div>

<!-- Refund Modal -->
<div id="refundModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 class="modal-title">Process Refund</h2>
      <button class="modal-close" onclick="closeModal('refundModal')">&times;</button>
    </div>
    <form id="refundForm" method="post" action="process_refund_paymongo.php">
      <input type="hidden" id="refund_order_id" name="order_id">
      <input type="hidden" id="refund_transaction_id" name="transaction_id">
      <input type="hidden" id="refund_payment_method" name="payment_method">
      
      <div class="modal-body">
        <div class="form-group">
          <label for="refund_amount">Refund Amount (₱)</label>
          <input type="number" id="refund_amount" name="amount" step="0.01" class="form-control" required>
        </div>
        
        <div class="form-group">
          <label for="refund_reason">Reason for Refund</label>
          <textarea id="refund_reason" name="reason" rows="3" class="form-control" required></textarea>
        </div>
        
        <div class="form-group">
          <label for="refund_items">Select Items to Refund</label>
          <div id="refund_items_container">
            <!-- Items will be loaded dynamically -->
            <p>Loading items...</p>
          </div>
        </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('refundModal')">Cancel</button>
        <button type="submit" class="btn btn-primary">Process Refund</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
  // Add this line to debug the click event
  console.log("Script loaded");
  
  function updateStatus(orderId, status) {
    document.getElementById('order_id').value = orderId;
    document.getElementById('status').value = status;
    
    // Set modal title based on status
    let title = 'Update Order Status';
    switch (status) {
      case 'preparing':
        title = 'Start Preparing Order';
        break;
      case 'ready_for_pickup':
        title = 'Mark Order as Ready for Pickup';
        break;
      case 'completed':
        title = 'Complete Order';
        break;
 
      case 'refunded':
        title = 'Refund Order';
        break;
    }
    
    document.querySelector('#statusModal .modal-title').textContent = title;
    document.getElementById('statusModal').classList.add('active');
  }
  
  // Debug the refund button click
  function openRefundModal(orderId, transactionId, paymentMethod, totalAmount) {
    console.log("Refund button clicked", {orderId, transactionId, paymentMethod, totalAmount});
    
    // If orderId is missing, show error
    if (!orderId) {
      console.error("Missing order ID for refund");
      alert("Error: Missing order information. Please try again.");
      return;
    }
    
    // Set default transaction ID if not provided
    if (!transactionId || transactionId <= 0) {
      console.log("No transaction ID found, will create one during processing");
      transactionId = 0; // We'll handle this in the PHP script
    }
    
    document.getElementById('refund_order_id').value = orderId;
    document.getElementById('refund_transaction_id').value = transactionId;
    document.getElementById('refund_payment_method').value = paymentMethod || 'Cash';
    document.getElementById('refund_amount').value = totalAmount;
    document.getElementById('refund_amount').max = totalAmount;
    
    // Load order items for refund selection
    fetch(`get_order_items_refund.php?order_id=${orderId}`)
      .then(response => {
        console.log("Fetch response status:", response.status);
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log("Fetch data:", data);
        const container = document.getElementById('refund_items_container');
        if (data.items && data.items.length > 0) {
          let html = '';
          data.items.forEach(item => {
            html += `
              <div class="form-group">
                <label>
                  <input type="checkbox" name="refund_items[]" value="${item.OrderDetailID}">
                  ${item.ProductName} (${item.Quantity} x ₱${parseFloat(item.Price).toFixed(2)})
                </label>
                <div style="margin-left: 25px;">
                  <label>Quantity to refund:
                    <input type="number" name="refund_quantity_${item.OrderDetailID}" min="1" max="${item.Quantity}" value="${item.Quantity}" class="form-control" style="width: 80px; display: inline-block;">
                  </label>
                </div>
              </div>
            `;
          });
          container.innerHTML = html;
        } else {
          container.innerHTML = '<p>No items found for this order.</p>';
        }
      })
      .catch(error => {
        console.error('Error loading order items:', error);
        document.getElementById('refund_items_container').innerHTML = 
          '<p class="text-danger">Error loading items. Please try again or refresh the page.</p>';
      });
    
    // Make sure the modal is shown
    document.getElementById('refundModal').classList.add('active');
  }
  
  function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
  }
  
  // Close modal when clicking outside
  window.addEventListener('click', function(event) {
    const statusModal = document.getElementById('statusModal');
    const refundModal = document.getElementById('refundModal');
    
    if (event.target === statusModal) {
      closeModal('statusModal');
    } else if (event.target === refundModal) {
      closeModal('refundModal');
    }
  });
  
  // Add direct event listeners to all refund buttons
  document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM fully loaded");
    
    // Validate refund form before submission
    const refundForm = document.getElementById('refundForm');
    if (refundForm) {
      refundForm.addEventListener('submit', function(e) {
        const amount = parseFloat(document.getElementById('refund_amount').value);
        const reason = document.getElementById('refund_reason').value.trim();
        
        if (isNaN(amount) || amount <= 0) {
          e.preventDefault();
          alert('Please enter a valid refund amount.');
          return false;
        }
        
        if (!reason) {
          e.preventDefault();
          alert('Please provide a reason for the refund.');
          return false;
        }
        
        // All validation passed
        return true;
      });
    }
    
    // Add click listeners to all refund buttons
    const refundButtons = document.querySelectorAll('.btn-refund');
    console.log("Found refund buttons:", refundButtons.length);
    
    refundButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default button behavior
        console.log("Refund button clicked via event listener");
        const orderId = this.getAttribute('data-order-id');
        const transactionId = this.getAttribute('data-transaction-id');
        const paymentMethod = this.getAttribute('data-payment-method');
        const totalAmount = this.getAttribute('data-amount');
        
        // Call the openRefundModal function with the data attributes
        openRefundModal(
          parseInt(orderId), 
          parseInt(transactionId), 
          paymentMethod || '', 
          parseFloat(totalAmount)
        );
      });
    });
  });

  // Display Toastify notifications
  <?php if (isset($_SESSION['success'])): ?>
    Toastify({
      text: "<?= $_SESSION['success'] ?>",
      duration: 3000,
      close: true,
      gravity: "top",
      position: "right",
      backgroundColor: "#4a934a",
      stopOnFocus: true
    }).showToast();
    <?php unset($_SESSION['success']); ?>
  <?php endif; ?>
  
  <?php if (isset($_SESSION['error'])): ?>
    Toastify({
      text: "<?= $_SESSION['error'] ?>",
      duration: 3000,
      close: true,
      gravity: "top",
      position: "right",
      backgroundColor: "#e74c3c",
      stopOnFocus: true
    }).showToast();
    <?php unset($_SESSION['error']); ?>
  <?php endif; ?>
</script>
