<?php
session_start();
require 'config/database.php';
require 'notification.php';

header('Content-Type: application/json');

try {
    if (!isset($_SESSION['user_id'])) {
        throw new Exception("Permission denied. Please login.");
    }

    $currentDate = date('Y-m-d');
    $conn->beginTransaction();

    // 1. Count and validate expired items
    $countStmt = $conn->prepare("
        SELECT COUNT(*) 
        FROM Inventory i
        JOIN Product p ON i.ProductID = p.ProductID
        WHERE i.ExpiryDate IS NOT NULL 
        AND i.ExpiryDate < ? 
        AND i.Quantity > 0
    ");
    $countStmt->execute([$currentDate]);
    $count = $countStmt->fetchColumn();

    $productsFlushed = []; // To hold affected product details

    if ($count > 0) {
        // Get details of expired items for notifications
        $expiredItemsStmt = $conn->prepare("
            SELECT p.ProductName, i.Quantity, i.ExpiryDate, i.InventoryID
            FROM Inventory i
            JOIN Product p ON i.ProductID = p.ProductID
            WHERE i.ExpiryDate IS NOT NULL 
            AND i.ExpiryDate < ? 
            AND i.Quantity > 0
        ");
        $expiredItemsStmt->execute([$currentDate]);
        $expiredItems = $expiredItemsStmt->fetchAll(PDO::FETCH_ASSOC);

        // 2. Move expired items to ExpiredItems table
        $moveStmt = $conn->prepare("
            INSERT INTO ExpiredItems (
                InventoryID,
                ProductID,
                Quantity,
                ExpiryDate,
                ReportedBy,
                PurchasePrice,
                Remarks
            )
            SELECT 
                i.InventoryID,
                i.ProductID, 
                i.Quantity, 
                i.ExpiryDate, 
                ?, 
                p.PurchasePrice,
                'Automatically processed by system'
            FROM Inventory i
            JOIN Product p ON i.ProductID = p.ProductID
            WHERE i.ExpiryDate IS NOT NULL 
            AND i.ExpiryDate < ? 
            AND i.Quantity > 0
        ");
        $moveStmt->execute([$_SESSION['user_id'], $currentDate]);

        // 3. Delete expired items from Inventory
        $deleteStmt = $conn->prepare("
            DELETE FROM Inventory 
            WHERE ExpiryDate IS NOT NULL 
            AND ExpiryDate < ? 
            AND Quantity > 0
        ");
        $deleteStmt->execute([$currentDate]);

        // Add product names to the flushed list for logging
        foreach ($expiredItems as $item) {
            $productsFlushed[] = [
                'ProductName' => $item['ProductName'],
                'Quantity' => $item['Quantity'],
                'ExpiryDate' => $item['ExpiryDate'],
                'InventoryID' => $item['InventoryID']
            ];
        }
    }
    
    $conn->commit();

    // Notify ALL users about expired items
    $stmt = $conn->prepare("SELECT UserID FROM Users");
    $stmt->execute();
    $allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $message = "System flushed $count expired item(s) from inventory";
    foreach ($allUsers as $user) {
        createNotification($conn, $user['UserID'], 'inventory_update', $message);
    }

    // Create detailed notifications for each flushed product
    if ($count > 0) {
        foreach ($productsFlushed as $item) {
            $detailMessage = sprintf(
                "EXPIRED: %d units of %s (Expired: %s)",
                $item['Quantity'],
                $item['ProductName'],
                date('M d, Y', strtotime($item['ExpiryDate']))
            );
            
            foreach ($allUsers as $user) {
                createNotification($conn, $user['UserID'], 'expiring_soon', $detailMessage);
            }
        }
    }

    // Log the flush action to InventoryLogs (with product details)
    $logStmt = $conn->prepare("
        INSERT INTO InventoryLogs (UserID, UsernameSnapshot, ProductNameSnapshot, InventoryID, Action, QuantityChanged, Remarks, Timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $action = 'expired_flush';  // Action to describe the type of change (edit, add, remove)
    $quantity_changed = $count;
    $remarks = "Processed and flushed $count expired items from inventory.";
    $username = $_SESSION['username'] ?? 'Unknown User';
    $logTime = date('Y-m-d H:i:s');

    // Insert the log record for the expired items processing
    $logStmt->execute([$_SESSION['user_id'], $username, implode(", ", array_column($productsFlushed, 'ProductName')), null, $action, $quantity_changed, $remarks, $logTime]);

    // Return success response with toast data
    echo json_encode([
        'status' => 'success',
        'count' => $count,
        'message' => $count ? "Processed $count expired items" : "No expired items found",
        'toast' => [
            'type' => 'success',
            'message' => $count ? "Processed $count expired items" : "No expired items found"
        ]
    ]);

} catch (PDOException $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    error_log("Database error processing expired items: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database operation failed',
        'debug' => $e->getMessage(),
        'toast' => [
            'type' => 'error',
            'message' => 'Database operation failed'
        ]
    ]);
} catch (Exception $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    error_log("Error processing expired items: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'toast' => [
            'type' => 'error',
            'message' => $e->getMessage()
        ]
    ]);
}
?>
