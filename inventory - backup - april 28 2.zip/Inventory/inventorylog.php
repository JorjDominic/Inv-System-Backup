<?php
session_start();
require('config/database.php');

// Only allow admin/staff access
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
  header('Location: index.php');
  exit;
}

// Initialize filters
$search = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$action = $_GET['action'] ?? '';
$user = $_GET['user'] ?? '';

// Build query conditions
$conditions = [];
$params = [];

if (!empty($search)) {
    $conditions[] = "(ProductNameSnapshot LIKE ? OR UsernameSnapshot LIKE ? OR Remarks LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($startDate)) {
    $conditions[] = "Timestamp >= ?";
    $params[] = $startDate . ' 00:00:00';
}

if (!empty($endDate)) {
    $conditions[] = "Timestamp <= ?";
    $params[] = $endDate . ' 23:59:59';
}

if (!empty($action)) {
    $conditions[] = "Action = ?";
    $params[] = $action;
}

if (!empty($user)) {
    $conditions[] = "UsernameSnapshot = ?";
    $params[] = $user;
}

// Build the WHERE clause
$whereClause = !empty($conditions) ? 'WHERE ' . implode(' AND ', $conditions) : '';

// Get total count for pagination
$countQuery = "SELECT COUNT(*) as total FROM InventoryLogs $whereClause";
$countStmt = $conn->prepare($countQuery);
$countStmt->execute($params);
$totalLogs = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];

// Pagination
$logsPerPage = 20;
$totalPages = ceil($totalLogs / $logsPerPage);
$page = isset($_GET['page']) ? max(1, min($totalPages, intval($_GET['page']))) : 1;
$offset = ($page - 1) * $logsPerPage;

// Get logs with pagination
$query = "
    SELECT 
        LogID,
        UsernameSnapshot,
        ProductNameSnapshot,
        Action,
        QuantityChanged,
        Remarks,
        Timestamp
    FROM InventoryLogs
    $whereClause
    ORDER BY Timestamp DESC
    LIMIT $logsPerPage OFFSET $offset
";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unique users for filter dropdown
$usersQuery = "SELECT DISTINCT UsernameSnapshot FROM InventoryLogs ORDER BY UsernameSnapshot";
$usersStmt = $conn->query($usersQuery);
$users = $usersStmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Logs</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <style>
        .log-id {
            font-weight: bold;
            color: #4a934a;
        }
        
        .action-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .action-add {
            background-color: #d4edda;
            color: #155724;
        }
        
        .action-remove {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .action-edit {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            gap: 5px;
        }
        
        .pagination a, .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
        }
        
        .pagination a:hover {
            background-color: #f5f5f5;
        }
        
        .pagination .active {
            background-color: #4a934a;
            color: white;
            border-color: #4a934a;
        }
        
        .pagination .disabled {
            color: #aaa;
            cursor: not-allowed;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }
        
        .filter-form select, 
        .filter-form input[type="text"],
        .filter-form input[type="date"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .filter-form button {
            padding: 8px 15px;
            background-color: #4a934a;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .filter-form button:hover {
            background-color: #3a7a3a;
        }
        
        .clear-filters {
            background-color: #6c757d !important;
        }
        
        .clear-filters:hover {
            background-color: #5a6268 !important;
        }
        
        .log-timestamp {
            white-space: nowrap;
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>
    
    <div class="main-content-wrapper">
        <main class="content">
            <div class="container">
                <h1>Inventory Logs</h1>
                
                <!-- Filter Form -->
                <form class="filter-form" method="GET">
                    <input type="hidden" name="page" value="1"> <!-- Reset to page 1 when filters change -->
                    
                    <div>
                        <label for="search">Search:</label>
                        <input type="text" id="search" name="search" placeholder="Product, user, or remarks..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    
                    <div>
                        <label for="start_date">From:</label>
                        <input type="date" id="start_date" name="start_date" value="<?= htmlspecialchars($startDate) ?>">
                    </div>
                    
                    <div>
                        <label for="end_date">To:</label>
                        <input type="date" id="end_date" name="end_date" value="<?= htmlspecialchars($endDate) ?>">
                    </div>
                    
                    <div>
                        <label for="action">Action:</label>
                        <select id="action" name="action">
                            <option value="">All Actions</option>
                            <option value="ADD" <?= $action === 'ADD' ? 'selected' : '' ?>>Add</option>
                            <option value="REMOVE" <?= $action === 'REMOVE' ? 'selected' : '' ?>>Remove</option>
                            <option value="edit" <?= $action === 'edit' ? 'selected' : '' ?>>Edit</option>
                        </select>
                    </div>
                    
                    <div>
                        <label for="user">User:</label>
                        <select id="user" name="user">
                            <option value="">All Users</option>
                            <?php foreach ($users as $username): ?>
                                <option value="<?= htmlspecialchars($username) ?>" <?= $user === $username ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($username) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <button type="submit">Apply Filters</button>
                    </div>
                    
                    <div>
                        <button type="button" class="clear-filters" onclick="window.location.href='inventory_logs.php'">Clear Filters</button>
                    </div>
                </form>
                
                <!-- Logs Table -->
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Log ID</th>
                                <th>User</th>
                                <th>Product</th>
                                <th>Action</th>
                                <th>Quantity</th>
                                <th>Remarks</th>
                                <th>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($logs) > 0): ?>
                                <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td class="log-id">#<?= $log['LogID'] ?></td>
                                        <td><?= htmlspecialchars($log['UsernameSnapshot']) ?></td>
                                        <td><?= htmlspecialchars($log['ProductNameSnapshot']) ?></td>
                                        <td>
                                            <?php 
                                            $actionClass = '';
                                            switch ($log['Action']) {
                                                case 'ADD':
                                                    $actionClass = 'action-add';
                                                    break;
                                                case 'REMOVE':
                                                    $actionClass = 'action-remove';
                                                    break;
                                                case 'edit':
                                                    $actionClass = 'action-edit';
                                                    break;
                                            }
                                            ?>
                                            <span class="action-badge <?= $actionClass ?>">
                                                <?= htmlspecialchars($log['Action']) ?>
                                            </span>
                                        </td>
                                        <td><?= $log['QuantityChanged'] ?></td>
                                        <td><?= htmlspecialchars($log['Remarks']) ?></td>
                                        <td class="log-timestamp"><?= date('M d, Y g:i A', strtotime($log['Timestamp'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" style="text-align: center;">No logs found matching your criteria.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?<?= 
                                http_build_query(array_merge(
                                    $_GET,
                                    ['page' => 1]
                                ))
                            ?>">First</a>
                            <a href="?<?= 
                                http_build_query(array_merge(
                                    $_GET,
                                    ['page' => $page - 1]
                                ))
                            ?>">Previous</a>
                        <?php else: ?>
                            <span class="disabled">First</span>
                            <span class="disabled">Previous</span>
                        <?php endif; ?>
                        
                        <?php
                        // Show page numbers around current page
                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);
                        
                        if ($startPage > 1): ?>
                            <span>...</span>
                        <?php endif;
                        
                        for ($i = $startPage; $i <= $endPage; $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="active"><?= $i ?></span>
                            <?php else: ?>
                                <a href="?<?= 
                                    http_build_query(array_merge(
                                        $_GET,
                                        ['page' => $i]
                                    ))
                                ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor;
                        
                        if ($endPage < $totalPages): ?>
                            <span>...</span>
                        <?php endif; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <a href="?<?= 
                                http_build_query(array_merge(
                                    $_GET,
                                    ['page' => $page + 1]
                                ))
                            ?>">Next</a>
                            <a href="?<?= 
                                http_build_query(array_merge(
                                    $_GET,
                                    ['page' => $totalPages]
                                ))
                            ?>">Last</a>
                        <?php else: ?>
                            <span class="disabled">Next</span>
                            <span class="disabled">Last</span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <div style="margin-top: 20px; text-align: center; color: #777;">
                    Showing <?= count($logs) ?> of <?= $totalLogs ?> logs
                </div>
            </div>
        </main>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Auto-submit form when select fields change
            document.getElementById('action').addEventListener('change', function() {
                document.querySelector('.filter-form').submit();
            });
            
            document.getElementById('user').addEventListener('change', function() {
                document.querySelector('.filter-form').submit();
            });
            
            // Reset page to 1 when date filters change
            document.getElementById('start_date').addEventListener('change', function() {
                document.querySelector('input[name="page"]').value = 1;
                document.querySelector('.filter-form').submit();
            });
            
            document.getElementById('end_date').addEventListener('change', function() {
                document.querySelector('input[name="page"]').value = 1;
                document.querySelector('.filter-form').submit();
            });
        });
    </script>
</body>
</html>