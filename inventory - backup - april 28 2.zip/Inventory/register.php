<?php
require 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and get input values
    $username   = htmlspecialchars(trim($_POST['username']));
    $firstname  = htmlspecialchars(trim($_POST['firstname']));
    $lastname   = htmlspecialchars(trim($_POST['lastname']));
    $email      = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password   = $_POST['password'];

    // Check if username already exists
    $stmt = $conn->prepare("SELECT UserID FROM Users WHERE Username = ?");
    $stmt->execute([$username]);
    if ($stmt->rowCount() > 0) {
        header("Location: index.php?toast=error&msg=" . urlencode("Username is already taken!"));
        exit;
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT UserID FROM Users WHERE Email = ?");
    $stmt->execute([$email]);
    if ($stmt->rowCount() > 0) {
        header("Location: index.php?toast=error&msg=" . urlencode("Email is already in use!"));
        exit;
    }

    // Validate password
    if (empty($password) || strlen($password) < 8 || 
        !preg_match('/[A-Z]/', $password) || 
        !preg_match('/[a-z]/', $password) || 
        !preg_match('/[0-9]/', $password)) {
        header("Location: index.php?toast=error&msg=" . urlencode("Password must be at least 8 characters long, include one uppercase letter, one lowercase letter, and one number."));
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Insert user into the database
        $stmt = $conn->prepare("INSERT INTO Users (Username, Email, Password, FirstName, LastName)
                                VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$username, $email, $hashedPassword, $firstname, $lastname]);

        // Log registration in audit trail
        $change_time = date('Y-m-d H:i:s');

        // If the user registered themselves (e.g. customer signup), use the same for both fields
        $log_query = "INSERT INTO audit_trail (affected_username, changed_by, action, timestamp) 
                      VALUES (:affected, :changer, 'Account Registered', :timestamp)";
        $log_stmt = $conn->prepare($log_query);
        $log_stmt->bindParam(':affected', $username); // new account
        $log_stmt->bindParam(':changer', $username);  // same person created it (self-registration)
        $log_stmt->bindParam(':timestamp', $change_time);
        $log_stmt->execute();

        header("Location: index.php?toast=success&msg=" . urlencode("Registration successful! Please login."));
        exit;
    } catch (PDOException $e) {
        header("Location: index.php?toast=error&msg=" . urlencode("Registration failed: " . $e->getMessage()));
        exit;
    }
}
?>
