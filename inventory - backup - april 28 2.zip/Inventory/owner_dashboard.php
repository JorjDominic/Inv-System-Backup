<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
  header('Location: index.php');
  exit;
}
session_regenerate_id(true);

// Get current date and time
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');

// Fetch low stock items
$lowStockThreshold = 10; // Define what "low stock" means
$lowStockQuery = "SELECT p.ProductName, SUM(i.Quantity) as TotalQuantity, c.CategoryName
               FROM Product p
               JOIN Inventory i ON p.ProductID = i.ProductID
               JOIN Category c ON p.CategoryID = c.CategoryID
               GROUP BY p.ProductID
               HAVING TotalQuantity <= ?
               ORDER BY TotalQuantity ASC
               LIMIT 5";
$lowStockStmt = $conn->prepare($lowStockQuery);
$lowStockStmt->execute([$lowStockThreshold]);
$lowStockItems = $lowStockStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent sales (last 7 days)
$recentSalesQuery = "SELECT r.ReceiptID, r.TotalAmount, r.DateIssued, 
                  COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod
                  FROM Receipts r
                  JOIN Orders o ON r.OrderID = o.OrderID
                  JOIN OrderDetails od ON o.OrderID = od.OrderID
                  JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                  WHERE r.DateIssued >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
                  GROUP BY r.ReceiptID
                  ORDER BY r.DateIssued DESC
                  LIMIT 5";
$recentSalesStmt = $conn->prepare($recentSalesQuery);
$recentSalesStmt->execute();
$recentSales = $recentSalesStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate gross revenue for current month (before refunds)
$grossRevenueQuery = "SELECT SUM(TotalAmount) as GrossRevenue 
                   FROM Receipts 
                   WHERE DateIssued BETWEEN ? AND CURRENT_DATE";
$grossRevenueStmt = $conn->prepare($grossRevenueQuery);
$grossRevenueStmt->execute([$firstDayOfMonth]);
$grossRevenue = $grossRevenueStmt->fetch(PDO::FETCH_ASSOC)['GrossRevenue'] ?? 0;

// Calculate total refunds for selected period (considering both order date and refund date)
$refundsQuery = "SELECT 
               SUM(od.Price * ri.QuantityRefunded) as TotalRefunds,
               SUM(CASE WHEN ri.ItemCondition = 'PRISTINE' THEN od.Price * ri.QuantityRefunded ELSE 0 END) as PristineRefunds,
               SUM(CASE WHEN ri.ItemCondition = 'DAMAGED' THEN od.Price * ri.QuantityRefunded ELSE 0 END) as DamagedRefunds
               FROM RefundedItems ri
               JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
               JOIN Orders o ON ri.OrderID = o.OrderID
               WHERE (ri.RefundedAt BETWEEN ? AND CURRENT_DATE OR o.OrderDate BETWEEN ? AND CURRENT_DATE)";
$refundsStmt = $conn->prepare($refundsQuery);
$refundsStmt->execute([$firstDayOfMonth, $firstDayOfMonth]);
$refundData = $refundsStmt->fetch(PDO::FETCH_ASSOC);

$totalRefunds = $refundData['TotalRefunds'] ?? 0;
$pristineRefunds = $refundData['PristineRefunds'] ?? 0;
$damagedRefunds = $refundData['DamagedRefunds'] ?? 0;
// Calculate net revenue (gross revenue minus refunds)
$netRevenue = $grossRevenue - $totalRefunds;

// Fetch recent activity from audit trail
$recentActivityQuery = "SELECT affected_username, changed_by, action, timestamp
                     FROM audit_trail
                     ORDER BY timestamp DESC
                     LIMIT 5";
$recentActivityStmt = $conn->prepare($recentActivityQuery);
$recentActivityStmt->execute();
$recentActivities = $recentActivityStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent expenses
$recentExpensesQuery = "SELECT e.ExpenseID, e.Description, e.Category, e.Amount, e.Date, u.Username
                     FROM Expenses e
                     JOIN Users u ON e.UserID = u.UserID
                     ORDER BY e.Date DESC
                     LIMIT 5";
$recentExpensesStmt = $conn->prepare($recentExpensesQuery);
$recentExpensesStmt->execute();
$recentExpenses = $recentExpensesStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate regular expenses for current month
$regularExpensesQuery = "SELECT SUM(Amount) as RegularExpenses 
                      FROM Expenses 
                      WHERE Date BETWEEN ? AND CURRENT_DATE";
$regularExpensesStmt = $conn->prepare($regularExpensesQuery);
$regularExpensesStmt->execute([$firstDayOfMonth]);
$regularExpenses = $regularExpensesStmt->fetch(PDO::FETCH_ASSOC)['RegularExpenses'] ?? 0;

// Calculate damaged items cost for current month
$damagedItemsQuery = "SELECT SUM(d.Quantity * p.PurchasePrice) as DamagedCost
                  FROM DamagedItems d
                  JOIN Product p ON d.ProductID = p.ProductID
                  WHERE d.ReportedAt BETWEEN ? AND CURRENT_DATE";
$damagedItemsStmt = $conn->prepare($damagedItemsQuery);
$damagedItemsStmt->execute([$firstDayOfMonth]);
$damagedItemsCost = $damagedItemsStmt->fetch(PDO::FETCH_ASSOC)['DamagedCost'] ?? 0;

// Calculate expired items cost for current month
// Correct - should filter by actual expiry date
$expiredItemsQuery = "SELECT SUM(LossValue) as ExpiredCost
                   FROM ExpiredItems
                   WHERE ExpiryDate BETWEEN ? AND CURRENT_DATE";
$expiredItemsStmt = $conn->prepare($expiredItemsQuery);
$expiredItemsStmt->execute([$firstDayOfMonth]);
$expiredItemsCost = $expiredItemsStmt->fetch(PDO::FETCH_ASSOC)['ExpiredCost'] ?? 0;

// Fetch recent expired items
$recentExpiredQuery = "SELECT e.ExpiredID, p.ProductName, e.Quantity, e.ExpiryDate, 
                    e.DateExpired, u.Username as ReportedBy, e.LossValue
                    FROM ExpiredItems e
                    JOIN Product p ON e.ProductID = p.ProductID
                    JOIN Users u ON e.ReportedBy = u.UserID
                    ORDER BY e.DateExpired DESC
                    LIMIT 5";
$recentExpiredStmt = $conn->prepare($recentExpiredQuery);
$recentExpiredStmt->execute();
$recentExpiredItems = $recentExpiredStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent damaged items
$recentDamagedQuery = "SELECT d.DamageID, p.ProductName, d.Quantity, d.Reason, 
                   d.ReportedAt, u.Username as ReportedBy, (d.Quantity * p.PurchasePrice) as LossAmount
                   FROM DamagedItems d
                   JOIN Product p ON d.ProductID = p.ProductID
                   JOIN Users u ON d.ReportedBy = u.UserID
                   ORDER BY d.ReportedAt DESC
                   LIMIT 5";
$recentDamagedStmt = $conn->prepare($recentDamagedQuery);
$recentDamagedStmt->execute();
$recentDamagedItems = $recentDamagedStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total expenses (regular expenses + damaged items cost + expired items cost + damaged refunds)
// Note: We add damaged refunds to expenses since they represent lost inventory value
$totalExpenses = $regularExpenses + $damagedItemsCost + $expiredItemsCost + $damagedRefunds;

// Calculate net profit (net revenue - total expenses)
$netProfit = $netRevenue - $totalExpenses;

// Get top selling products
$topProductsQuery = "SELECT p.ProductName, SUM(od.Quantity) as TotalSold, SUM(od.Price * od.Quantity) as Revenue
                  FROM OrderDetails od
                  JOIN Product p ON od.ProductID = p.ProductID
                  JOIN Orders o ON od.OrderID = o.OrderID
                  WHERE o.OrderDate BETWEEN ? AND CURRENT_DATE
                  GROUP BY p.ProductID
                  ORDER BY TotalSold DESC
                  LIMIT 5";
$topProductsStmt = $conn->prepare($topProductsQuery);
$topProductsStmt->execute([$firstDayOfMonth]);
$topProducts = $topProductsStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate product profit (accounting for refunds)
$productProfitQuery = "SELECT 
                    SUM((p.SellingPrice - p.PurchasePrice) * (od.Quantity - COALESCE(ri.RefundedQty, 0))) as TotalProfit,
                    SUM(p.PurchasePrice * (od.Quantity - COALESCE(ri.RefundedQty, 0))) as TotalCost,
                    SUM(p.SellingPrice * (od.Quantity - COALESCE(ri.RefundedQty, 0))) as ProductRevenue
                    FROM OrderDetails od
                    JOIN Product p ON od.ProductID = p.ProductID
                    JOIN Orders o ON od.OrderID = o.OrderID
                    LEFT JOIN (
                        SELECT OrderID, ProductID, SUM(QuantityRefunded) as RefundedQty
                        FROM RefundedItems
                        WHERE RefundedAt BETWEEN ? AND CURRENT_DATE
                        GROUP BY OrderID, ProductID
                    ) ri ON od.OrderID = ri.OrderID AND od.ProductID = ri.ProductID
                    WHERE o.OrderDate BETWEEN ? AND CURRENT_DATE";
$productProfitStmt = $conn->prepare($productProfitQuery);
$productProfitStmt->execute([$firstDayOfMonth, $firstDayOfMonth]);
$profitData = $productProfitStmt->fetch(PDO::FETCH_ASSOC);

$totalProductProfit = $profitData['TotalProfit'] ?? 0;
$totalCost = $profitData['TotalCost'] ?? 0;
$productRevenue = $profitData['ProductRevenue'] ?? 0;

// Calculate profit margin
$profitMargin = $productRevenue > 0 ? ($totalProductProfit / $productRevenue) * 100 : 0;

// Get most profitable products
$profitableProductsQuery = "SELECT 
                         p.ProductID,
                         p.ProductName,
                         p.SellingPrice,
                         p.PurchasePrice,
                         SUM(od.Quantity) as QuantitySold,
                         COALESCE(SUM(ri.QuantityRefunded), 0) as QuantityRefunded,
                         SUM((p.SellingPrice - p.PurchasePrice) * (od.Quantity - COALESCE(ri.QuantityRefunded, 0))) as Profit
                         FROM OrderDetails od
                         JOIN Product p ON od.ProductID = p.ProductID
                         JOIN Orders o ON od.OrderID = o.OrderID
                         LEFT JOIN (
                             SELECT OrderID, ProductID, SUM(QuantityRefunded) as QuantityRefunded
                             FROM RefundedItems
                             WHERE RefundedAt BETWEEN ? AND CURRENT_DATE
                             GROUP BY OrderID, ProductID
                         ) ri ON od.OrderID = ri.OrderID AND od.ProductID = ri.ProductID
                         WHERE o.OrderDate BETWEEN ? AND CURRENT_DATE
                         GROUP BY p.ProductID
                         ORDER BY Profit DESC
                         LIMIT 5";
$profitableProductsStmt = $conn->prepare($profitableProductsQuery);
$profitableProductsStmt->execute([$firstDayOfMonth, $firstDayOfMonth]);
$profitableProducts = $profitableProductsStmt->fetchAll(PDO::FETCH_ASSOC);

// Get refund statistics
$refundStatsQuery = "SELECT 
                   COUNT(*) as TotalRefunds,
                   SUM(CASE WHEN ItemCondition = 'PRISTINE' THEN 1 ELSE 0 END) as PristineRefunds,
                   SUM(CASE WHEN ItemCondition = 'DAMAGED' THEN 1 ELSE 0 END) as DamagedRefunds,
                   SUM(od.Price * ri.QuantityRefunded) as RefundValue,
                   SUM(CASE WHEN ItemCondition = 'PRISTINE' THEN od.Price * ri.QuantityRefunded ELSE 0 END) as PristineValue,
                   SUM(CASE WHEN ItemCondition = 'DAMAGED' THEN od.Price * ri.QuantityRefunded ELSE 0 END) as DamagedValue
                   FROM RefundedItems ri
                   JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                   WHERE ri.RefundedAt BETWEEN ? AND CURRENT_DATE";
$refundStatsStmt = $conn->prepare($refundStatsQuery);
$refundStatsStmt->execute([$firstDayOfMonth]);
$refundStats = $refundStatsStmt->fetch(PDO::FETCH_ASSOC);

// Get products nearing expiry (within next 30 days)
$nearExpiryQuery = "SELECT p.ProductName, i.Quantity, i.ExpiryDate, 
                 DATEDIFF(i.ExpiryDate, CURRENT_DATE) as DaysRemaining
                 FROM Inventory i
                 JOIN Product p ON i.ProductID = p.ProductID
                 WHERE i.ExpiryDate IS NOT NULL 
                 AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)
                 ORDER BY i.ExpiryDate ASC
                 LIMIT 5";
$nearExpiryStmt = $conn->prepare($nearExpiryQuery);
$nearExpiryStmt->execute();
$nearExpiryItems = $nearExpiryStmt->fetchAll(PDO::FETCH_ASSOC);

// Get expired items statistics by category
$expiredByCategoryQuery = "SELECT c.CategoryName, 
                        COUNT(e.ExpiredID) as ExpiredCount,
                        SUM(e.Quantity) as TotalQuantity,
                        SUM(e.LossValue) as TotalLoss
                        FROM ExpiredItems e
                        JOIN Product p ON e.ProductID = p.ProductID
                        JOIN Category c ON p.CategoryID = c.CategoryID
                        WHERE e.DateExpired BETWEEN ? AND CURRENT_DATE
                        GROUP BY c.CategoryID
                        ORDER BY TotalLoss DESC
                        LIMIT 5";
$expiredByCategoryStmt = $conn->prepare($expiredByCategoryQuery);
$expiredByCategoryStmt->execute([$firstDayOfMonth]);
$expiredByCategory = $expiredByCategoryStmt->fetchAll(PDO::FETCH_ASSOC);

// Get monthly expired items trend
$monthlyExpiredQuery = "SELECT 
                     DATE_FORMAT(e.DateExpired, '%Y-%m') as Month,
                     SUM(e.Quantity) as TotalQuantity,
                     SUM(e.LossValue) as TotalLoss
                     FROM ExpiredItems e
                     WHERE e.DateExpired >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
                     GROUP BY DATE_FORMAT(e.DateExpired, '%Y-%m')
                     ORDER BY Month";
$monthlyExpiredStmt = $conn->prepare($monthlyExpiredQuery);
$monthlyExpiredStmt->execute();
$monthlyExpired = $monthlyExpiredStmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total inventory value
$inventoryValueQuery = "SELECT SUM(i.Quantity * p.PurchasePrice) as TotalValue
                     FROM Inventory i
                     JOIN Product p ON i.ProductID = p.ProductID";
$inventoryValueStmt = $conn->prepare($inventoryValueQuery);
$inventoryValueStmt->execute();
$inventoryValue = $inventoryValueStmt->fetch(PDO::FETCH_ASSOC)['TotalValue'] ?? 0;

// Calculate inventory at risk (near expiry)
$inventoryAtRiskQuery = "SELECT SUM(i.Quantity * p.PurchasePrice) as RiskValue
                      FROM Inventory i
                      JOIN Product p ON i.ProductID = p.ProductID
                      WHERE i.ExpiryDate IS NOT NULL 
                      AND i.ExpiryDate BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)";
$inventoryAtRiskStmt = $conn->prepare($inventoryAtRiskQuery);
$inventoryAtRiskStmt->execute();
$inventoryAtRisk = $inventoryAtRiskStmt->fetch(PDO::FETCH_ASSOC)['RiskValue'] ?? 0;

// Calculate percentage of inventory at risk
$inventoryRiskPercentage = $inventoryValue > 0 ? ($inventoryAtRisk / $inventoryValue) * 100 : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Owner Dashboard - Adriana's Marketing</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
      /* Dashboard Styles */
      .dashboard-container {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
          padding: 20px;
      }
      
      .dashboard-card {
          background-color: white;
          border-radius: var(--border-radius);
          box-shadow: var(--shadow-sm);
          padding: 20px;
          position: relative;
          overflow: hidden;
      }
      
      .dashboard-card h3 {
          margin-top: 0;
          color: var(--text-dark);
          font-size: 1.2rem;
          font-weight: 600;
          margin-bottom: 15px;
          display: flex;
          align-items: center;
      }
      
      .dashboard-card h3 svg {
          margin-right: 10px;
          width: 24px;
          height: 24px;
      }
      
      .dashboard-card.low-stock {
          border-left: 4px solid #f39c12;
      }
      
      .dashboard-card.sales {
          border-left: 4px solid #27ae60;
      }
      
      .dashboard-card.recent-activity {
          border-left: 4px solid #3498db;
      }
      
      .dashboard-card.expenses {
          border-left: 4px solid #e74c3c;
      }
      
      .dashboard-card.summary {
          border-left: 4px solid #9b59b6;
      }
      
      .dashboard-card.top-products {
          border-left: 4px solid #2ecc71;
      }
      
      .dashboard-card.profit {
          border-left: 4px solid #9b59b6;
      }
      
      .dashboard-card.damaged {
          border-left: 4px solid #e67e22;
      }
      
      .dashboard-card.expired {
          border-left: 4px solid #c0392b;
      }
      
      .dashboard-card.near-expiry {
          border-left: 4px solid #f1c40f;
      }
      
      .dashboard-card.refunds {
          border-left: 4px solid #3498db;
      }
      
      .dashboard-card.inventory-risk {
          border-left: 4px solid #e67e22;
      }
      
      .welcome-header {
          background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
          color: white;
          padding: 30px;
          border-radius: var(--border-radius);
          margin-bottom: 20px;
          box-shadow: var(--shadow-md);
      }
      
      .welcome-header h1 {
          margin: 0;
          font-size: 1.8rem;
          font-weight: 600;
          color:white;
      }
      
      .welcome-header p {
          margin: 10px 0 0;
          opacity: 0.9;
          font-size: 1rem;
      }
      
      .stat-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 15px;
          margin-top: 20px;
      }
      
      .stat-card {
          background-color: rgba(255, 255, 255, 0.1);
          padding: 15px;
          border-radius: var(--border-radius-sm);
          text-align: center;
      }
      
      .stat-card h3 {
          margin: 0;
          font-size: 1.8rem;
          font-weight: 700;
      }
      
      .stat-card p {
          margin: 5px 0 0;
          font-size: 0.9rem;
          opacity: 0.8;
      }
      
      .stat-card-exp {
          color: #e74c3c;
      }
      
      .item-list {
          list-style: none;
          padding: 0;
          margin: 0;
      }
      
      .item-list li {
          padding: 10px 0;
          border-bottom: 1px solid #f0f0f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
      }
      
      .item-list li:last-child {
          border-bottom: none;
      }
      
      .item-name {
          font-weight: 500;
          color: var(--text-dark);
      }
      
      .item-detail {
          color: var(--text-medium);
          font-size: 0.9rem;
      }
      
      .badge {
          display: inline-block;
          padding: 3px 8px;
          border-radius: 12px;
          font-size: 0.75rem;
          font-weight: 500;
      }
      
      .badge-warning {
          background-color: #f39c12;
          color: #fff;
      }
      
      .badge-success {
          background-color: #d4edda;
          color: #155724;
      }
      
      .badge-info {
          background-color: #d1ecf1;
          color: #0c5460;
      }
      
      .badge-danger {
          background-color: #f8d7da;
          color: #721c24;
      }
      
      .badge-primary {
          background-color: #cce5ff;
          color: #004085;
      }
      
      .badge-orange {
          background-color: #ffe5d0;
          color: #d35400;
      }
      
      .badge-purple {
          background-color: #e8daef;
          color: #8e44ad;
      }
      
      .badge-red {
          background-color: #f5b7b1;
          color: #922b21;
      }
      
      .badge-yellow {
          background-color: #fdebd0;
          color: #b7950b;
      }
      
      .view-all {
          display: block;
          text-align: center;
          margin-top: 15px;
          color: var(--primary-color);
          text-decoration: none;
          font-size: 0.9rem;
          font-weight: 500;
      }
      
      .view-all:hover {
          text-decoration: underline;
      }
      
      .profit-positive {
          color: white;
      }
      
      .profit-negative {
          color: #e74c3c;
      }
      
      .date-display {
          font-size: 1rem;
          color: rgba(255, 255, 255, 0.8);
          margin-top: 5px;
      }
      
      .empty-state {
          text-align: center;
          padding: 20px 0;
          color: var(--text-light);
          font-style: italic;
      }
      
      .progress-bar-container {
          width: 100%;
          height: 8px;
          background-color: #f0f0f0;
          border-radius: 4px;
          margin-top: 10px;
          overflow: hidden;
      }
      
      .progress-bar {
          height: 100%;
          border-radius: 4px;
      }
      
      .progress-bar-success {
          background-color: #2ecc71;
      }
      
      .progress-bar-warning {
          background-color: #f39c12;
      }
      
      .progress-bar-danger {
          background-color: #e74c3c;
      }
      
      .progress-label {
          display: flex;
          justify-content: space-between;
          font-size: 0.8rem;
          color: var(--text-medium);
          margin-top: 5px;
      }
      
      .expense-breakdown {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-top: 15px;
      }
      
      .expense-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
      }
      
      .expense-label {
          display: flex;
          align-items: center;
          gap: 5px;
      }
      
      .expense-dot {
          width: 10px;
          height: 10px;
          border-radius: 50%;
      }
      
      .expense-dot-regular {
          background-color: #3498db;
      }
      
      .expense-dot-damaged {
          background-color: #e67e22;
      }
      
      .expense-dot-expired {
          background-color: #c0392b;
      }
      
      .expense-dot-refunds {
          background-color: #9b59b6;
      }
      
      @media (max-width: 768px) {
          .dashboard-container {
              grid-template-columns: 1fr;
          }
          
          .welcome-header {
              padding: 20px;
          }
          
          .welcome-header h1 {
              font-size: 1.5rem;
          }
          
          .stat-grid {
              grid-template-columns: repeat(2, 1fr);
          }
      }
  </style>
</head>
<body>
  <?php include 'sidebar.php'; ?>
  <?php include 'navbar.php'; ?>

  <div class="main-content-wrapper">
      <main class="content">
          <!-- Welcome Header with Stats -->
          <div class="welcome-header">
              <h1>Welcome, Owner  <?= htmlspecialchars($_SESSION['user_name']) ?></h1>
              <p class="date-display"><?= date('l, F j, Y') ?></p>
              
              <div class="stat-grid">
                  <div class="stat-card">
                      <h3>₱<?= number_format($netRevenue, 2) ?></h3>
                      <p>Net Revenue</p>
                  </div>
                  <div class="stat-card">
                      <h3 class="stat-card-exp">₱<?= number_format($totalExpenses, 2) ?></h3>
                      <p>Total Expenses</p>
                  </div>
                  <div class="stat-card">
                      <h3 class="<?= $totalProductProfit >= 0 ? 'profit-positive' : 'profit-negative' ?>">
                          ₱<?= number_format($totalProductProfit, 2) ?>
                      </h3>
                      <p>Product Profit</p>
                  </div>
                  <div class="stat-card">
                      <h3 class="<?= $netProfit >= 0 ? 'profit-positive' : 'profit-negative' ?>">
                          ₱<?= number_format($netProfit, 2) ?>
                      </h3>
                      <p>Net Profit</p>
                  </div>
              </div>
          </div>
          
          <div class="dashboard-container">
              <!-- Low Stock Card -->
              <div class="dashboard-card low-stock">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f39c12" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M16 16v1a2 2 0 0 1-2 2H3a2   stroke-linejoin="round">
                          <path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34"></path>
                          <path d="M3 7l9 6 9-6"></path>
                          <line x1="13" y1="17" x2="19" y2="11"></line>
                          <polyline points="19 17 19 11 13 11"></polyline>
                      </svg>
                      Low Stock Items
                  </h3>
                  <?php if (count($lowStockItems) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($lowStockItems as $item): ?>
                              <li>
                                  <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                                  <span class="badge badge-warning"><?= $item['TotalQuantity'] ?> left</span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="inventory.php" class="view-all">View All Inventory</a>
                  <?php else: ?>
                      <div class="empty-state">No low stock items at the moment.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Near Expiry Items Card -->
              <div class="dashboard-card near-expiry">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#f1c40f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <circle cx="12" cy="12" r="10"></circle>
                          <line x1="12" y1="6" x2="12" y2="12"></line>
                          <line x1="12" y1="16" x2="12.01" y2="16"></line>
                      </svg>
                      Items Nearing Expiry
                  </h3>
                  <?php if (count($nearExpiryItems) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($nearExpiryItems as $item): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                                      <div class="item-detail">
                                          Expires: <?= date('M d, Y', strtotime($item['ExpiryDate'])) ?> • 
                                          <?= $item['Quantity'] ?> units
                                      </div>
                                  </div>
                                  <span class="badge badge-yellow"><?= $item['DaysRemaining'] ?> days left</span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="expired_items.php" class="view-all">View All Expiring Items</a>
                  <?php else: ?>
                      <div class="empty-state">No items nearing expiry.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Recent Sales Card -->
              <div class="dashboard-card sales">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <line x1="12" y1="1" x2="12" y2="23"></line>
                          <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                      </svg>
                      Recent Sales
                  </h3>
                  <?php if (count($recentSales) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentSales as $sale): ?>
                              <li>
                                  <div>
                                      <span class="item-name">Receipt #<?= $sale['ReceiptID'] ?></span>
                                      <div class="item-detail"><?= date('M d, Y', strtotime($sale['DateIssued'])) ?> • <?= $sale['ItemCount'] ?> items</div>
                                  </div>
                                  <span class="badge badge-success">₱<?= number_format($sale['TotalAmount'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="transactions.php" class="view-all">View All Transactions</a>
                  <?php else: ?>
                      <div class="empty-state">No recent sales in the last 7 days.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Refunds Card -->
              <div class="dashboard-card refunds">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <polyline points="1 4 1 10 7 10"></polyline>
                          <polyline points="23 20 23 14 17 14"></polyline>
                          <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"></path>
                      </svg>
                      Monthly Refunds
                  </h3>
                  <ul class="item-list">
                      <li>
                          <span class="item-name">Total Refunds</span>
                          <span class="badge badge-info">₱<?= number_format($totalRefunds, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Pristine Returns</span>
                          <span class="badge badge-success">₱<?= number_format($pristineRefunds, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Damaged Returns</span>
                          <span class="badge badge-danger">₱<?= number_format($damagedRefunds, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Refund Count</span>
                          <span class="badge badge-primary"><?= $refundStats['TotalRefunds'] ?? 0 ?> items</span>
                      </li>
                  </ul>
                  <a href="transactions.php" class="view-all">View All Transactions</a>
              </div>
              
              <!-- Expired Items Card -->
              <div class="dashboard-card expired">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#c0392b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                          <line x1="16" y1="2" x2="16" y2="6"></line>
                          <line x1="8" y1="2" x2="8" y2="6"></line>
                          <line x1="3" y1="10" x2="21" y2="10"></line>
                          <line x1="10" y1="14" x2="14" y2="18"></line>
                          <line x1="14" y1="14" x2="10" y2="18"></line>
                      </svg>
                      Expired Inventory
                  </h3>
                  <?php if (count($recentExpiredItems) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentExpiredItems as $item): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                                      <div class="item-detail">
                                          Expired: <?= date('M d, Y', strtotime($item['ExpiryDate'])) ?> • 
                                          <?= $item['Quantity'] ?> units
                                      </div>
                                  </div>
                                  <span class="badge badge-red">₱<?= number_format($item['LossValue'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="expired_items.php" class="view-all">View All Expired Items</a>
                  <?php else: ?>
                      <div class="empty-state">No expired items reported recently.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Damaged Items Card -->
              <div class="dashboard-card damaged">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e67e22" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M3 3l18 18"></path>
                          <path d="M10.5 4.75L12 3l7 6 1 9-1.5 1"></path>
                          <path d="M8 20l-5-6 2-3.5"></path>
                          <path d="M13.75 8L21 14.25"></path>
                          <path d="M6 12.5l3-2.5 3.5 3"></path>
                      </svg>
                      Damaged Inventory
                  </h3>
                  <?php if (count($recentDamagedItems) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentDamagedItems as $item): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($item['ProductName']) ?></span>
                                      <div class="item-detail">
                                          <?= date('M d, Y', strtotime($item['ReportedAt'])) ?> • 
                                          <?= $item['Quantity'] ?> units
                                      </div>
                                  </div>
                                  <span class="badge badge-orange">₱<?= number_format($item['LossAmount'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="damaged_inventory.php" class="view-all">View All Damaged Items</a>
                  <?php else: ?>
                      <div class="empty-state">No damaged items reported recently.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Inventory Risk Card -->
              <div class="dashboard-card inventory-risk">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e67e22" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                          <line x1="12" y1="9" x2="12" y2="13"></line>
                          <line x1="12" y1="17" x2="12.01" y2="17"></line>
                      </svg>
                      Inventory Risk Assessment
                  </h3>
                  <ul class="item-list">
                      <li>
                          <span class="item-name">Total Inventory Value</span>
                          <span class="badge badge-primary">₱<?= number_format($inventoryValue, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">At Risk (Expiring Soon)</span>
                          <span class="badge badge-warning">₱<?= number_format($inventoryAtRisk, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Risk Percentage</span>
                          <span class="badge badge-<?= $inventoryRiskPercentage > 10 ? 'danger' : 'warning' ?>"><?= number_format($inventoryRiskPercentage, 1) ?>%</span>
                      </li>
                  </ul>
                  <div class="progress-bar-container">
                      <div class="progress-bar progress-bar-<?= $inventoryRiskPercentage > 10 ? 'danger' : 'warning' ?>" style="width: <?= min($inventoryRiskPercentage, 100) ?>%"></div>
                  </div>
                  <div class="progress-label">
                      <span>0%</span>
                      <span>Risk Level</span>
                      <span>100%</span>
                  </div>
                  <a href="inventory.php" class="view-all">View Inventory</a>
              </div>
              
              <!-- Top Products Card -->
              <div class="dashboard-card top-products">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#2ecc71" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                          <polyline points="17 6 23 6 23 12"></polyline>
                      </svg>
                      Top Selling Products
                  </h3>
                  <?php if (count($topProducts) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($topProducts as $product): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($product['ProductName']) ?></span>
                                      <div class="item-detail">Revenue: ₱<?= number_format($product['Revenue'], 2) ?></div>
                                  </div>
                                  <span class="badge badge-primary"><?= $product['TotalSold'] ?> sold</span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="inventory.php" class="view-all">View All Products</a>
                  <?php else: ?>
                      <div class="empty-state">No sales data available for this month.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Most Profitable Products Card -->
              <div class="dashboard-card profit">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#9b59b6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <line x1="12" y1="1" x2="12" y2="23"></line>
                          <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                      </svg>
                      Most Profitable Products
                  </h3>
                  <?php if (count($profitableProducts) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($profitableProducts as $product): ?>
                              <?php 
                                  $margin = ($product['SellingPrice'] > 0) ? 
                                      (($product['SellingPrice'] - $product['PurchasePrice']) / $product['SellingPrice']) * 100 : 0;
                              ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($product['ProductName']) ?></span>
                                      <div class="item-detail">
                                          Cost: ₱<?= number_format($product['PurchasePrice'], 2) ?> | 
                                          Price: ₱<?= number_format($product['SellingPrice'], 2) ?> | 
                                          Margin: <?= number_format($margin, 1) ?>%
                                      </div>
                                  </div>
                                  <span class="badge badge-success">₱<?= number_format($product['Profit'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="inventory.php" class="view-all">View All Products</a>
                  <?php else: ?>
                      <div class="empty-state">No profit data available for this month.</div>
                  <?php endif; ?>
              </div>
              
            
              <!-- Recent Expenses Card -->
              <div class="dashboard-card expenses">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e74c3c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <rect x="2" y="5" width="20" height="14" rx="2"></rect>
                          <line x1="2" y1="10" x2="22" y2="10"></line>
                      </svg>
                      Recent Expenses
                  </h3>
                  <?php if (count($recentExpenses) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentExpenses as $expense): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($expense['Description']) ?></span>
                                      <div class="item-detail"><?= date('M d, Y', strtotime($expense['Date'])) ?> • <?= htmlspecialchars($expense['Category']) ?></div>
                                  </div>
                                  <span class="badge badge-danger">₱<?= number_format($expense['Amount'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="expenses.php" class="view-all">View All Expenses</a>
                  <?php else: ?>
                      <div class="empty-state">No recent expenses recorded.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Recent Activity Card -->
              <div class="dashboard-card recent-activity">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                      </svg>
                      Recent Activity
                  </h3>
                  <?php if (count($recentActivities) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentActivities as $activity): ?>
                              <li>
                                  <div>
                                      <span class="item-name"><?= htmlspecialchars($activity['action']) ?></span>
                                      <div class="item-detail">
                                          By <?= htmlspecialchars($activity['changed_by']) ?> • 
                                          <?= date('M d, g:i A', strtotime($activity['timestamp'])) ?>
                                      </div>
                                  </div>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="audit_trail.php" class="view-all">View Audit Trail</a>
                  <?php else: ?>
                      <div class="empty-state">No recent activity recorded.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Expense Breakdown Card -->
              <div class="dashboard-card expenses">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#e74c3c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <circle cx="12" cy="12" r="10"></circle>
                          <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                          <line x1="12" y1="17" x2="12.01" y2="17"></line>
                      </svg>
                      Expense Breakdown
                  </h3>
                  <div class="expense-breakdown">
                      <div class="expense-item">
                          <div class="expense-label">
                              <div class="expense-dot expense-dot-regular"></div>
                              <span>Regular Expenses</span>
                          </div>
                          <span>₱<?= number_format($regularExpenses, 2) ?></span>
                      </div>
                      <div class="expense-item">
                          <div class="expense-label">
                              <div class="expense-dot expense-dot-damaged"></div>
                              <span>Damaged Items</span>
                          </div>
                          <span>₱<?= number_format($damagedItemsCost, 2) ?></span>
                      </div>
                      <div class="expense-item">
                          <div class="expense-label">
                              <div class="expense-dot expense-dot-expired"></div>
                              <span>Expired Items</span>
                          </div>
                          <span>₱<?= number_format($expiredItemsCost, 2) ?></span>
                      </div>
                      <div class="expense-item">
                          <div class="expense-label">
                              <div class="expense-dot expense-dot-refunds"></div>
                              <span>Damaged Refunds</span>
                          </div>
                          <span>₱<?= number_format($damagedRefunds, 2) ?></span>
                      </div>
                  </div>
                  <div class="progress-bar-container" style="margin-top: 20px;">
                      <?php
                          $totalExpensesNonZero = max($totalExpenses, 0.01); // Avoid division by zero
                          $regularPercentage = ($regularExpenses / $totalExpensesNonZero) * 100;
                          $damagedPercentage = ($damagedItemsCost / $totalExpensesNonZero) * 100;
                          $expiredPercentage = ($expiredItemsCost / $totalExpensesNonZero) * 100;
                          $refundsPercentage = ($damagedRefunds / $totalExpensesNonZero) * 100;
                      ?>
                      <div class="progress-bar" style="width: <?= $regularPercentage ?>%; background-color: #3498db;"></div>
                      <div class="progress-bar" style="width: <?= $damagedPercentage ?>%; background-color: #e67e22; margin-left: -3px;"></div>
                      <div class="progress-bar" style="width: <?= $expiredPercentage ?>%; background-color: #c0392b; margin-left: -3px;"></div>
                      <div class="progress-bar" style="width: <?= $refundsPercentage ?>%; background-color: #9b59b6; margin-left: -3px;"></div>
                  </div>
                  <a href="expenses.php" class="view-all">View Expense Reports</a>
              </div>
              
              <!-- Summary Card -->
              <div class="dashboard-card summary">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#9b59b6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path>
                          <path d="M22 12A10 10 0 0 0 12 2v10z"></path>
                      </svg>
                      Monthly Summary
                  </h3>
                  <ul class="item-list">
                      <li>
                          <span class="item-name">Gross Revenue</span>
                          <span class="badge badge-success">₱<?= number_format($grossRevenue, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Total Refunds</span>
                          <span class="badge badge-warning">₱<?= number_format($totalRefunds, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Net Revenue</span>
                          <span class="badge badge-success">₱<?= number_format($netRevenue, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Regular Expenses</span>
                          <span class="badge badge-danger">₱<?= number_format($regularExpenses, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Damaged Inventory</span>
                          <span class="badge badge-orange">₱<?= number_format($damagedItemsCost, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Expired Inventory</span>
                          <span class="badge badge-red">₱<?= number_format($expiredItemsCost, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Damaged Refunds</span>
                          <span class="badge badge-orange">₱<?= number_format($damagedRefunds, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Total Expenses</span>
                          <span class="badge badge-danger">₱<?= number_format($totalExpenses, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Net Profit</span>
                          <span class="badge <?= $netProfit >= 0 ? 'badge-success' : 'badge-danger' ?>">
                              ₱<?= number_format($netProfit, 2) ?>
                          </span>
                      </li>
                  </ul>
                  <a href="reports.php" class="view-all">Generate Reports</a>
              </div>
          </div>
      </main>
  </div>

  <script>
      // Add any JavaScript functionality here
      document.addEventListener('DOMContentLoaded', function() {
          // Example: Auto-refresh the dashboard every 5 minutes
          // setTimeout(function() { location.reload(); }, 300000);
      });
  </script>
</body>
</html>
