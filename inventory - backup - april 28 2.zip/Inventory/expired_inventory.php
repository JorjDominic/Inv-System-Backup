<?php
session_start();
require('config/database.php');

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 3)) {
    header("Location: index.php");
    exit;
}

// Initialize search and filter variables
$search = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$category = $_GET['category'] ?? '';

// Build query conditions
$conditions = [];
$params = [];

if (!empty($search)) {
    $conditions[] = "(p.ProductName LIKE ? OR p.ProductID LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($startDate)) {
    $conditions[] = "e.ReportedAt >= ?";
    $params[] = $startDate;
}

if (!empty($endDate)) {
    $conditions[] = "e.ReportedAt <= ?";
    $params[] = $endDate;
}

if (!empty($category)) {
    $conditions[] = "c.CategoryID = ?";
    $params[] = $category;
}

$whereClause = !empty($conditions) ? "WHERE " . implode(' AND ', $conditions) : "";

// Fetch categories for filter dropdown
$categoryQuery = "SELECT CategoryID, CategoryName FROM Category ORDER BY CategoryName";
$categoryStmt = $conn->prepare($categoryQuery);
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch expired items with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$itemsPerPage = 10;
$offset = ($page - 1) * $itemsPerPage;

$query = "SELECT e.ExpiredID, p.ProductName, e.Quantity, e.ExpiryDate, e.ReportedAt, 
          u.Username as ReportedBy, c.CategoryName, p.PurchasePrice,
          (e.Quantity * p.PurchasePrice) as LossAmount
          FROM ExpiredItems e
          JOIN Product p ON e.ProductID = p.ProductID
          JOIN Category c ON p.CategoryID = c.CategoryID
          JOIN Users u ON e.ReportedBy = u.UserID
          $whereClause
          ORDER BY e.ReportedAt DESC
          LIMIT $itemsPerPage OFFSET $offset";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$expiredItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count total items for pagination
$countQuery = "SELECT COUNT(*) as total FROM ExpiredItems e
              JOIN Product p ON e.ProductID = p.ProductID
              JOIN Category c ON p.CategoryID = c.CategoryID
              $whereClause";
$countStmt = $conn->prepare($countQuery);
$countStmt->execute($params);
$totalItems = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPages = ceil($totalItems / $itemsPerPage);

// Calculate summary statistics
$summaryQuery = "SELECT 
                SUM(e.Quantity) as TotalQuantity,
                SUM(e.Quantity * p.PurchasePrice) as TotalLoss,
                COUNT(DISTINCT e.ProductID) as UniqueProducts,
                COUNT(DISTINCT DATE(e.ReportedAt)) as ReportDays
                FROM ExpiredItems e
                JOIN Product p ON e.ProductID = p.ProductID
                JOIN Category c ON p.CategoryID = c.CategoryID
                $whereClause";
$summaryStmt = $conn->prepare($summaryQuery);
$summaryStmt->execute($params);
$summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);

// Get top categories with expired items
$topCategoriesQuery = "SELECT c.CategoryName, 
                     COUNT(e.ExpiredID) as ItemCount,
                     SUM(e.Quantity) as TotalQuantity,
                     SUM(e.Quantity * p.PurchasePrice) as TotalLoss
                     FROM ExpiredItems e
                     JOIN Product p ON e.ProductID = p.ProductID
                     JOIN Category c ON p.CategoryID = c.CategoryID
                     $whereClause
                     GROUP BY c.CategoryID
                     ORDER BY TotalLoss DESC
                     LIMIT 5";
$topCategoriesStmt = $conn->prepare($topCategoriesQuery);
$topCategoriesStmt->execute($params);
$topCategories = $topCategoriesStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expired Inventory - Adriana's Marketing</title>
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link rel="stylesheet" href="css/records.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .summary-section {
            margin-bottom: 30px;
        }
        
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .summary-card {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            color: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
        }
        
        .summary-card h3 {
            margin-top: 0;
            font-size: 1rem;
            opacity: 0.9;
        }
        
        .summary-card p {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 10px 0 0;
        }
        
        .export-btn {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-left: 10px;
        }
        
        .export-btn:hover {
            background-color: #219653;
        }
        
        .add-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .add-btn:hover {
            background-color: var(--primary-dark);
        }
        
        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .badge-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .badge-warning {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .badge-info {
            background-color: #d1ecf1;
            color: #0c5460;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 500px;
            box-shadow: var(--shadow-md);
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-sm);
            font-family: inherit;
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <h1>Expired Inventory Management</h1>
            
            <!-- Summary Section -->
            <div class="summary-section">
                <h2>Summary</h2>
                <div class="summary-cards">
                    <div class="summary-card">
                        <h3>Total Expired Items</h3>
                        <p><?= number_format($summary['TotalQuantity'] ?? 0) ?> units</p>
                    </div>
                    <div class="summary-card">
                        <h3>Total Loss Value</h3>
                        <p>₱<?= number_format($summary['TotalLoss'] ?? 0, 2) ?></p>
                    </div>
                    <div class="summary-card">
                        <h3>Unique Products</h3>
                        <p><?= number_format($summary['UniqueProducts'] ?? 0) ?></p>
                    </div>
                    <div class="summary-card">
                        <h3>Report Days</h3>
                        <p><?= number_format($summary['ReportDays'] ?? 0) ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Top Categories with Expired Items -->
            <div class="container">
                <h2>Top Categories with Expired Items</h2>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Item Count</th>
                                <th>Total Quantity</th>
                                <th>Total Loss</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($topCategories) > 0): ?>
                                <?php foreach ($topCategories as $category): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($category['CategoryName']) ?></td>
                                        <td><?= number_format($category['ItemCount']) ?></td>
                                        <td><?= number_format($category['TotalQuantity']) ?> units</td>
                                        <td>₱<?= number_format($category['TotalLoss'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4">No data available</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Expired Items List -->
            <div class="container">
                <div class="header-actions">
                    <h2>Expired Items List</h2>
                    <div class="action-buttons">
                        <button id="openAddExpiredModal" class="add-btn">Report Expired Item</button>
                        <a href="export_expired.php<?= !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '' ?>" class="export-btn">Export to CSV</a>
                    </div>
                </div>
                
                <!-- Search and Filter Form -->
                <form method="GET" class="search-sort-container">
                    <input type="text" name="search" placeholder="Search by product name or ID..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                    
                    <label>Category:
                        <select name="category">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['CategoryID'] ?>" <?= $category == $cat['CategoryID'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['CategoryName']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    
                    <label>From: <input type="date" name="start_date" value="<?= $_GET['start_date'] ?? '' ?>"></label>
                    <label>To: <input type="date" name="end_date" value="<?= $_GET['end_date'] ?? '' ?>"></label>
                    
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='expired_inventory.php'">Reset</button>
                </form>
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Expiry Date</th>
                                <th>Reported Date</th>
                                <th>Reported By</th>
                                <th>Loss Amount</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($expiredItems) > 0): ?>
                                <?php foreach ($expiredItems as $item): ?>
                                    <tr>
                                        <td><?= $item['ExpiredID'] ?></td>
                                        <td><?= htmlspecialchars($item['ProductName']) ?></td>
                                        <td><?= htmlspecialchars($item['CategoryName']) ?></td>
                                        <td><?= $item['Quantity'] ?></td>
                                        <td><?= date('M d, Y', strtotime($item['ExpiryDate'])) ?></td>
                                        <td><?= date('M d, Y', strtotime($item['ReportedAt'])) ?></td>
                                        <td><?= htmlspecialchars($item['ReportedBy']) ?></td>
                                        <td>₱<?= number_format($item['LossAmount'], 2) ?></td>
                                        <td>
                                            <button class="btn btn-edit" onclick="openEditModal(<?= $item['ExpiredID'] ?>)">Edit</button>
                                            <button class="btn btn-danger" onclick="confirmDelete(<?= $item['ExpiredID'] ?>)">Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9">No expired items found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <?php 
                                $queryParams = $_GET;
                                $queryParams['page'] = $i;
                                $queryString = http_build_query($queryParams);
                            ?>
                            <a href="?<?= $queryString ?>" class="<?= $page == $i ? 'active' : '' ?>"><?= $i ?></a>
                        <?php endfor; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    
    <!-- Add Expired Item Modal -->
    <div id="addExpiredModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addExpiredModal')">&times;</span>
            <h2>Report Expired Item</h2>
            <form id="addExpiredForm" action="process_expired.php" method="POST">
                <div class="form-group">
                    <label for="product_id">Product</label>
                    <select id="product_id" name="product_id" required>
                        <option value="">Select a product</option>
                        <?php
                        $productQuery = "SELECT p.ProductID, p.ProductName FROM Product p ORDER BY p.ProductName";
                        $productStmt = $conn->prepare($productQuery);
                        $productStmt->execute();
                        $products = $productStmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        foreach ($products as $product) {
                            echo '<option value="' . $product['ProductID'] . '">' . htmlspecialchars($product['ProductName']) . '</option>';
                        }
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="number" id="quantity" name="quantity" min="1" required>
                </div>
                
                <div class="form-group">
                    <label for="expiry_date">Expiry Date</label>
                    <input type="date" id="expiry_date" name="expiry_date" required>
                </div>
                
                <div class="form-group">
                    <label for="notes">Notes (Optional)</label>
                    <textarea id="notes" name="notes" rows="3"></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('addExpiredModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Report</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Expired Item Modal -->
    <div id="editExpiredModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editExpiredModal')">&times;</span>
            <h2>Edit Expired Item</h2>
            <form id="editExpiredForm" action="process_expired.php" method="POST">
                <input type="hidden" id="edit_expired_id" name="expired_id">
                <input type="hidden" name="action" value="update">
                
                <div class="form-group">
                    <label for="edit_product_id">Product</label>
                    <select id="edit_product_id" name="product_id" required>
                        <option value="">Select a product</option>
                        <?php
                        foreach ($products as $product) {
                            echo '<option value="' . $product['ProductID'] . '">' . htmlspecialchars($product['ProductName']) . '</option>';
                        }
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="edit_quantity">Quantity</label>
                    <input type="number" id="edit_quantity" name="quantity" min="1" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_expiry_date">Expiry Date</label>
                    <input type="date" id="edit_expiry_date" name="expiry_date" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_notes">Notes (Optional)</label>
                    <textarea id="edit_notes" name="notes" rows="3"></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editExpiredModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Report</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('deleteModal')">&times;</span>
            <h2>Confirm Deletion</h2>
            <p>Are you sure you want to delete this expired item report? This action cannot be undone.</p>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
            </div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Add event listener for the add expired item button
            document.getElementById('openAddExpiredModal').addEventListener('click', function() {
                document.getElementById('addExpiredModal').classList.add('show');
            });
            
            // Set up the delete confirmation button
            document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
                const expiredId = this.getAttribute('data-id');
                window.location.href = `process_expired.php?action=delete&expired_id=${expiredId}`;
            });
        });
        
        // Close modal function
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }
        
        // Open edit modal function
        function openEditModal(expiredId) {
            // Fetch expired item details via AJAX
            fetch(`get_expired.php?id=${expiredId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    // Populate the edit form with expired item data
                    document.getElementById('edit_expired_id').value = data.ExpiredID;
                    document.getElementById('edit_product_id').value = data.ProductID;
                    document.getElementById('edit_quantity').value = data.Quantity;
                    document.getElementById('edit_expiry_date').value = data.ExpiryDate;
                    document.getElementById('edit_notes').value = data.Notes || '';
                    
                    // Show the edit modal
                    document.getElementById('editExpiredModal').classList.add('show');
                })
                .catch(error => {
                    console.error('Error fetching expired item data:', error);
                    alert('Failed to load expired item data');
                });
        }
        
        // Confirm delete function
        function confirmDelete(expiredId) {
            // Set the expired item ID on the confirm button
            document.getElementById('confirmDeleteBtn').setAttribute('data-id', expiredId);
            
            // Show the delete confirmation modal
            document.getElementById('deleteModal').classList.add('show');
        }
    </script>
</body>
</html>
