<?php
session_start();
require('config/database.php');

// Add this after session_start() and require('config/database.php');
// Uncomment for debugging
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

// Define report types
$reportTypes = [
    'sales' => 'Sales Report',
    'refunds' => 'Refunds Report',
    'cancellations' => 'Cancellations Report',
    'inventory' => 'Inventory Report'
];

// Get current date
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

// Default date range (current month)
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : $firstDayOfMonth;
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : $currentDate;

// Process form submission for report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportType = $_POST['report_type'] ?? 'sales';
    $startDate = $_POST['start_date'] ?? $firstDayOfMonth;
    $endDate = $_POST['end_date'] ?? $currentDate;
    
    // If export to PDF is requested
    if (isset($_POST['action']) && $_POST['action'] === 'export_pdf') {
        // Redirect to PDF generator with parameters
        header("Location: generate_pdf.php?report_type=$reportType&start_date=$startDate&end_date=$endDate");
        exit;
    }
}

// Function to get report data based on type and date range
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            // Sales report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status IN ('paid', 'cancelled', 'refunded') 
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
            
        case 'refunds':
            // Refunds report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'refunded' 
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;

        case 'cancellations':
            // Cancellations report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'cancelled' 
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
        case 'inventory':
            // Inventory report query
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        default:
            $data = [];
            return $data;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        // Bind parameters based on report type
        switch ($reportType) {
            case 'inventory':
                $stmt->execute();
                break;
                
            default:
                $stmt->execute([$startDate, $endDate]);
                break;
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary data for certain report types
        if ($reportType === 'sales') {
            $totalSales = 0;
            foreach ($data as $sale) {
                if (isset($sale['TotalAmount'])) {
                    $totalSales += $sale['TotalAmount'];
                }
            }
            $data['summary'] = [
                'totalSales' => $totalSales,
                'transactionCount' => count($data)
            ];
        } elseif ($reportType === 'refunds') {
            $totalRefunds = 0;
            foreach ($data as $refund) {
                if (isset($refund['RefundAmount'])) {
                    $totalRefunds += $refund['RefundAmount'];
                }
            }
            $data['summary'] = [
                'totalRefunds' => $totalRefunds,
                'refundCount' => count($data)
            ];
        } elseif ($reportType === 'cancellations') {
            $totalCancellations = 0;
            foreach ($data as $cancellation) {
                if (isset($cancellation['TotalAmount'])) {
                    $totalCancellations += $cancellation['TotalAmount'];
                }
            }
            $data['summary'] = [
                'totalCancellations' => $totalCancellations,
                'cancellationCount' => count($data)
            ];
        } elseif ($reportType === 'inventory') {
            $totalValue = 0;
            $totalItems = 0;
            foreach ($data as $item) {
                if (isset($item['TotalValue'])) {
                    $totalValue += $item['TotalValue'];
                }
                if (isset($item['TotalQuantity'])) {
                    $totalItems += $item['TotalQuantity'];
                }
            }
            $data['summary'] = [
                'totalValue' => $totalValue,
                'totalItems' => $totalItems
            ];
        }
        
    } catch (PDOException $e) {
        // Handle error
        echo "Error: " . $e->getMessage();
    }
    
    return $data;
}

// Get report data if a report type is selected
$reportData = [];
$selectedReportType = $_POST['report_type'] ?? 'sales';

// Check if form was submitted (either for generating report or exporting PDF)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reportData = getReportData($conn, $selectedReportType, $startDate, $endDate);
}

// Get chart data for the selected report type
$chartData = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($selectedReportType) {
        case 'sales':
            // Get daily sales for chart
            $dailySalesQuery = "SELECT DATE(CreatedAt) as SaleDate, SUM(Amount) as DailyRevenue
                             FROM Transactions
                             WHERE Status = 'completed' AND CreatedAt BETWEEN ? AND ?
                             GROUP BY DATE(CreatedAt)
                             ORDER BY SaleDate";
            break;
            
        case 'refunds':
            // Get daily refunds for chart
            $dailyRefundsQuery = "SELECT DATE(RefundedAt) as RefundDate, SUM(Amount) as DailyRefunds
                             FROM Refunds
                             WHERE RefundDate BETWEEN ? AND ?
                             GROUP BY DATE(RefundDate)
                             ORDER BY RefundDate";
            break;
            
        case 'cancellations':
            // Get daily cancellations for chart
            $dailyCancellationsQuery = "SELECT DATE(CreatedAt) as CancellationDate, SUM(Amount) as DailyCancellations
                             FROM Transactions
                             WHERE Status = 'cancelled' AND CreatedAt BETWEEN ? AND ?
                             GROUP BY DATE(CreatedAt)
                             ORDER BY CancellationDate";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reports - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .reports-container {
            padding: 20px;
        }
        
        .report-form {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-sm);
            font-family: 'Poppins', sans-serif;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        
        .report-results {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            overflow-x: auto;
        }
        
        .report-title {
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--text-dark);
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .report-table th, .report-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .report-table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .report-table tr:last-child td {
            border-bottom: none;
        }
        
        .report-summary {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .summary-label {
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .summary-value {
            font-weight: 600;
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: var(--text-medium);
            font-style: italic;
        }
        
        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
            }
            
            .btn-group {
                flex-direction: column;
            }
        }
    </style>
    
    <!-- Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="reports-container">
                <h1 class="report-title">Generate Reports</h1>
                <a href="business_analytics.php">Go to Business Analytics</a>
                <div class="report-form">
                    <form method="POST" action="">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="report_type">Report Type</label>
                                <select name="report_type" id="report_type" class="form-control">
                                    <?php foreach ($reportTypes as $value => $label): ?>
                                        <option value="<?= $value ?>" <?= ($selectedReportType === $value) ? 'selected' : '' ?>>
                                            <?= $label ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="start_date">Start Date</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" 
                                       value="<?= $startDate ?>" max="<?= $currentDate ?>">
                            </div>
                            <div class="form-group">
                                <label for="end_date">End Date</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" 
                                       value="<?= $endDate ?>" max="<?= $currentDate ?>">
                            </div>
                        </div>
                        <div class="btn-group">
                            <button type="submit" name="action" value="generate_report" class="btn btn-primary">Generate Report</button>
                            <button type="submit" name="action" value="export_pdf" class="btn btn-success">Export to PDF</button>
                        </div>
                    </form>
                </div>
                
                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($reportData)): ?>
                    <div class="report-results">
                        <h2 class="report-title"><?= $reportTypes[$selectedReportType] ?></h2>
                        <p>Period: <?= date('F d, Y', strtotime($startDate)) ?> to <?= date('F d, Y', strtotime($endDate)) ?></p>
                        
                        <?php if ($selectedReportType === 'sales'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Date</th>
                                            <th>Items</th>
                                            <th>Payment Method</th>
                                            <th>User</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalAmount = 0;
                                        foreach ($reportData as $key => $sale): 
                                            if ($key !== 'summary' && isset($sale['TransactionID'])):
                                                if (isset($sale['TotalAmount'])) {
                                                    $totalAmount += $sale['TotalAmount'];
                                                }
                                        ?>
                                            <tr>
                                                <td><?= isset($sale['TransactionID']) ? $sale['TransactionID'] : 'N/A' ?></td>
                                                <td><?= isset($sale['DateIssued']) ? date('M d, Y', strtotime($sale['DateIssued'])) : 'N/A' ?></td>
                                                <td><?= isset($sale['ItemCount']) ? $sale['ItemCount'] : 'N/A' ?></td>
                                                <td><?= isset($sale['PaymentMethod']) ? $sale['PaymentMethod'] : 'N/A' ?></td>
                                                <td><?= isset($sale['Cashier']) ? $sale['Cashier'] : 'N/A' ?></td>
                                                <td>₱<?= isset($sale['TotalAmount']) ? number_format($sale['TotalAmount'], 2) : '0.00' ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Sales:</span>
                                    <span class="summary-value">₱<?= number_format($totalAmount, 2) ?></span>
                                </div>
                                <div class="summary-item">
                     
                                </div>
                            </div>
                            
      
                            <?php elseif ($selectedReportType === 'refunds'): ?>
                                <?php 
    // Initialize total refund amount
    $totalRefundAmount = 0;
    // Calculate total refund amount from report data
    foreach ($reportData as $key => $refund) {
        if ($key !== 'summary' && isset($refund['TotalAmount'])) {
            $totalRefundAmount += $refund['TotalAmount'];
        }
    }
    ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Date</th>
                                            <th>Payment Method</th>
                                            <th>Cashier</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalCancellationAmount = 0;
                                        foreach ($reportData as $key => $cancellation): 
                                            if ($key !== 'summary' && isset($cancellation['TransactionID'])):
                                                if (isset($cancellation['TotalAmount'])) {
                                                    $totalCancellationAmount += $cancellation['TotalAmount'];
                                                }
                                        ?>
                                            <tr>
                                                <td><?= isset($cancellation['TransactionID']) ? $cancellation['TransactionID'] : 'N/A' ?></td>
                                                <td><?= isset($cancellation['DateIssued']) ? date('M d, Y', strtotime($cancellation['DateIssued'])) : 'N/A' ?></td>
                                                <td><?= isset($cancellation['PaymentMethod']) ? $cancellation['PaymentMethod'] : 'N/A' ?></td>
                                                <td><?= isset($cancellation['Cashier']) ? $cancellation['Cashier'] : 'N/A' ?></td>
                                                <td>₱<?= isset($cancellation['TotalAmount']) ? number_format($cancellation['TotalAmount'], 2) : '0.00' ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
        <div class="summary-item">
            <span class="summary-label">Total Refund Amount:</span>
            <span class="summary-value">₱<?= number_format($totalRefundAmount, 2) ?></span>
        </div>

                                <div class="summary-item">
                 
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'cancellations'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Transaction ID</th>
                                            <th>Date</th>
                                            <th>Payment Method</th>
                                            <th>Cashier</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalCancellationAmount = 0;
                                        foreach ($reportData as $key => $cancellation): 
                                            if ($key !== 'summary' && isset($cancellation['TransactionID'])):
                                                if (isset($cancellation['TotalAmount'])) {
                                                    $totalCancellationAmount += $cancellation['TotalAmount'];
                                                }
                                        ?>
                                            <tr>
                                                <td><?= isset($cancellation['TransactionID']) ? $cancellation['TransactionID'] : 'N/A' ?></td>
                                                <td><?= isset($cancellation['DateIssued']) ? date('M d, Y', strtotime($cancellation['DateIssued'])) : 'N/A' ?></td>
                                                <td><?= isset($cancellation['PaymentMethod']) ? $cancellation['PaymentMethod'] : 'N/A' ?></td>
                                                <td><?= isset($cancellation['Cashier']) ? $cancellation['Cashier'] : 'N/A' ?></td>
                                                <td>₱<?= isset($cancellation['TotalAmount']) ? number_format($cancellation['TotalAmount'], 2) : '0.00' ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Cancellation Amount:</span>
                                    <span class="summary-value">₱<?= number_format($totalCancellationAmount, 2) ?></span>
                                </div>
                                <div class="summary-item">
   
                                </div>
                            </div>
                            
                        <?php elseif ($selectedReportType === 'inventory'): ?>
                            <div class="table-responsive">
                                <table class="report-table">
                                    <thead>
                                        <tr>
                                            <th>Product ID</th>
                                            <th>Product Name</th>
                                            <th>Category</th>
                                            <th>Quantity</th>
                                            <th>Purchase Price</th>
                                            <th>Selling Price</th>
                                            <th>Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $totalValue = 0;
                                        $totalItems = 0;
                                        foreach ($reportData as $key => $item): 
                                            if ($key !== 'summary' && isset($item['ProductID'])):
                                                if (isset($item['TotalValue'])) {
                                                    $totalValue += $item['TotalValue'];
                                                }
                                                if (isset($item['TotalQuantity'])) {
                                                    $totalItems += $item['TotalQuantity'];
                                                }
                                        ?>
                                            <tr>
                                                <td><?= isset($item['ProductID']) ? $item['ProductID'] : 'N/A' ?></td>
                                                <td><?= isset($item['ProductName']) ? htmlspecialchars($item['ProductName']) : 'N/A' ?></td>
                                                <td><?= isset($item['CategoryName']) ? htmlspecialchars($item['CategoryName']) : 'N/A' ?></td>
                                                <td><?= isset($item['TotalQuantity']) ? $item['TotalQuantity'] : '0' ?></td>
                                                <td>₱<?= isset($item['PurchasePrice']) ? number_format($item['PurchasePrice'], 2) : '0.00' ?></td>
                                                <td>₱<?= isset($item['SellingPrice']) ? number_format($item['SellingPrice'], 2) : '0.00' ?></td>
                                                <td>₱<?= isset($item['TotalValue']) ? number_format($item['TotalValue'], 2) : '0.00' ?></td>
                                            </tr>
                                        <?php 
                                            endif;
                                        endforeach; 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="report-summary">
                                <div class="summary-item">
                                    <span class="summary-label">Total Inventory Value:</span>
                                    <span class="summary-value">₱<?= number_format($totalValue, 2) ?></span>
                                </div>
                                <div class="summary-item">
                                    <span class="summary-label">Total Items:</span>
                                    <span class="summary-value"><?= $totalItems ?></span>
                                </div>
                            </div>
                            
                        <?php else: ?>
                            <div class="no-data">No data available for the selected criteria.</div>
                        <?php endif; ?>
                    </div>
                <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="report-results">
                        <div class="no-data">No data available for the selected criteria.</div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
