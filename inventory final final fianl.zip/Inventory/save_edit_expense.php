<?php
session_start();
require('config/database.php');

// Check if user is logged in and has appropriate permissions
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
    header('Location: index.php');
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $expense_id = $_POST['expense_id'];
    $description = trim($_POST['description']);
    $category = $_POST['category'];
    $amount = floatval($_POST['amount']);
    $date = $_POST['date'];
    $user_id = $_SESSION['user_id'];

    // Validate input
    if (empty($expense_id) || empty($description) || empty($category) || $amount <= 0 || empty($date)) {
        header('Location: expenses.php?msg_error=' . urlencode('All fields are required and amount must be greater than zero.'));
        exit;
    }

    try {
        // Begin transaction
        $conn->beginTransaction();

        // Get the original expense data for logging
        $stmt = $conn->prepare("SELECT * FROM Expenses WHERE ExpenseID = ?");
        $stmt->execute([$expense_id]);
        $original_expense = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$original_expense) {
            throw new Exception("Expense not found");
        }

        // Update the expense record
        $stmt = $conn->prepare("
            UPDATE Expenses 
            SET ExpenseType = ?, 
                Amount = ?, 
                DateIncurred = ?, 
                Description = ?, 
                UserID = ?
            WHERE ExpenseID = ?
        ");
        
        $stmt->execute([
            $category,
            $amount,
            $date,
            $description,
            $user_id,
            $expense_id
        ]);

        // Log the action in audit trail
        $action = "Updated expense #$expense_id: " . 
                 "Description: {$original_expense['Description']} → $description, " .
                 "Category: {$original_expense['Category']} → $category, " .
                 "Amount: {$original_expense['Amount']} → $amount, " .
                 "Date: {$original_expense['Date']} → $date";
        
        $log_stmt = $conn->prepare("
            INSERT INTO audit_trail (affected_username, changed_by, action, timestamp)
            VALUES (?, ?, ?, NOW())
        ");
        
        $log_stmt->execute([
            'Expense Record',
            $_SESSION['user_name'],
            $action
        ]);

        // Commit transaction
        $conn->commit();

        // Redirect with success message
        header('Location: expenses.php?msg_success=' . urlencode('Expense updated successfully!'));
        exit;
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollBack();
        
        // Redirect with error message
        header('Location: expenses.php?msg_error=' . urlencode('Error updating expense: ' . $e->getMessage()));
        exit;
    }
} else {
    // If not a POST request, redirect to expenses page
    header('Location: expenses.php');
    exit;
}
