<?php
// config/paymongo.php

// Test keys
define('PAYMONGO_PUBLIC_KEY', 'pk_test_RDzEkkiy6aUHsyQdg4x4MH7S');
define('PAYMONGO_SECRET_KEY', 'sk_test_RsSUome4bJfSRFwPfYn7rtWt');

// Production keys (uncomment when going live)
// define('PAYMONGO_PUBLIC_KEY', 'pk_live_xxxxxxxxxxxxxxxxxxxxxxxx');
// define('PAYMONGO_SECRET_KEY', 'sk_live_xxxxxxxxxxxxxxxxxxxxxxxx');

// Helper function for API requests
function paymongo_request($endpoint, $method = 'POST', $data = []) {
    $url = "https://api.paymongo.com/v1/$endpoint";
    $curl = curl_init();
    
    $headers = [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Basic ' . base64_encode(PAYMONGO_SECRET_KEY . ':')
    ];
    
    $curl_options = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
    ];
    
    if ($method !== 'GET' && !empty($data)) {
        $curl_options[CURLOPT_POSTFIELDS] = json_encode($data);
    }
    
    curl_setopt_array($curl, $curl_options);
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        return ['error' => $err];
    }
    
    return json_decode($response, true);
}

function generate_pickup_code() {
    // Generate a random 6-character alphanumeric code
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    for ($i = 0; $i < 6; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}
function generate_order_reference() {
    $prefix = 'PAY-';
    $date = date('Ymd-His');
    $random = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 6);
    return $prefix . $date . '-' . $random;
}