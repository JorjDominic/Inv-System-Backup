<?php
session_start();
include('config/database.php');

$username = $_SESSION['user_name']; // the user who is logging out

$logout_time = date('Y-m-d H:i:s');
$log_query = "INSERT INTO audit_trail (affected_username, changed_by, action, timestamp) 
              VALUES (:affected, :changer, 'logout', :timestamp)";
$log_stmt = $conn->prepare($log_query);
$log_stmt->bindParam(':affected', $username);
$log_stmt->bindParam(':changer', $username);
$log_stmt->bindParam(':timestamp', $logout_time);
$log_stmt->execute();


session_destroy();

header('Location: index.php');

?>