<?php
// cancel_order.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?toast=error&msg=' . urlencode("Please login to cancel your order"));
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: customer_orders.php?toast=error&msg=' . urlencode("Invalid request"));
    exit;
}

// Get form data
$orderId = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';

// Validate input
if ($orderId <= 0 || empty($reason)) {
    header('Location: customer_orders.php?toast=error&msg=' . urlencode("Missing order information"));
    exit;
}

try {
    // Start transaction
    $conn->beginTransaction();
    
    // Check if order belongs to the logged-in user
    $stmt = $conn->prepare("
        SELECT o.*, c.UserID, c.Email, c.FirstName, c.LastName
        FROM Orders o
        JOIN Customers c ON o.CustomerID = c.CustomerID
        WHERE o.OrderID = ? AND c.UserID = ?
    ");
    $stmt->execute([$orderId, $_SESSION['user_id']]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        throw new Exception("Order not found or does not belong to you");
    }
    
    // Check if order can be cancelled (paid or processing)
    if (!in_array($order['OrderStatus'], ['paid', 'processing'])) {
        throw new Exception("Only paid or processing orders can be cancelled");
    }
    
    // Update order status to cancelled
    $stmt = $conn->prepare("
        UPDATE Orders 
        SET OrderStatus = 'cancelled', UpdatedAt = NOW() 
        WHERE OrderID = ?
    ");
    $stmt->execute([$orderId]);
    
    // Log the cancellation in audit trail
    $stmt = $conn->prepare("
        INSERT INTO audit_trail (
            affected_username, 
            changed_by, 
            action, 
            timestamp
        ) VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([
        $order['FirstName'] . ' ' . $order['LastName'],
        $order['FirstName'] . ' ' . $order['LastName'] . ' (Customer)',
        "Cancelled Order #$orderId. Reason: $reason",
    ]);
    
    // Check if there's a transaction associated with this order
    $stmt = $conn->prepare("
        SELECT TransactionID, Amount, PaymentMethodID
        FROM Transactions
        WHERE OrderID = ? AND Status IN ('completed', 'paid')
    ");
    $stmt->execute([$orderId]);
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // If there's a transaction, update its status to cancelled
    if ($transaction) {
        // Update transaction status to cancelled
        $stmt = $conn->prepare("
            UPDATE Transactions
            SET Status = 'cancelled', UpdatedAt = NOW()
            WHERE TransactionID = ?
        ");
        $stmt->execute([$transaction['TransactionID']]);
        
        // Create a refund record if payment was made
        if (in_array($transaction['Status'], ['completed', 'paid'])) {
            $stmt = $conn->prepare("
                INSERT INTO Refunds (
                    TransactionID,
                    Amount,
                    Reason,
                    Status,
                    CreatedAt
                ) VALUES (?, ?, ?, 'pending', NOW())
            ");
            $stmt->execute([
                $transaction['TransactionID'],
                $transaction['Amount'],
                "Order cancelled by customer. Reason: $reason"
            ]);
        }
    }
    
    // Notify store owner/admin about the cancellation
    $stmt = $conn->prepare("
        SELECT UserID FROM Users WHERE RoleID IN (1, 2, 3) LIMIT 10
    ");
    $stmt->execute();
    $admins = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($admins as $adminId) {
        createNotification(
            $conn,
            $adminId,
            'order_cancelled',
            "Order #$orderId has been cancelled by the customer. Reason: $reason"
        );
    }
    
    // Notify customer about the cancellation
    createNotification(
        $conn,
        $_SESSION['user_id'],
        'order_status',
        "Your Order #$orderId has been cancelled. If you paid for this order, a refund will be processed according to our refund policy."
    );
    
    // Commit transaction
    $conn->commit();
    
    // Redirect with success message
    header('Location: customer_orders.php?toast=success&msg=' . urlencode("Your order has been cancelled successfully. If you paid for this order, a refund will be processed."));
    exit;
    
} catch (Exception $e) {
    // Rollback transaction
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    
    // Log error
    error_log("Order cancellation error: " . $e->getMessage());
    
    // Redirect with error message
    header('Location: customer_orders.php?toast=error&msg=' . urlencode("Error cancelling order: " . $e->getMessage()));
    exit;
}
?>