<?php
// customer_orders.php
session_start();
require_once 'config/database.php';
require_once 'notification.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Get customer ID
$stmt = $conn->prepare("SELECT CustomerID FROM Customers WHERE UserID = ?");
$stmt->execute([$_SESSION['user_id']]);
$customer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$customer) {
    // Check if Users table has Phone column
    $stmt = $conn->query("SHOW COLUMNS FROM Users LIKE 'Phone'");
    $hasPhoneColumn = $stmt->rowCount() > 0;
    
    // Create customer record if it doesn't exist
    if ($hasPhoneColumn) {
        $stmt = $conn->prepare("
            INSERT INTO Customers (UserID, FirstName, LastName, Email, Phone)
            SELECT UserID, FirstName, LastName, Email, Phone FROM Users WHERE UserID = ?
        ");
    } else {
        $stmt = $conn->prepare("
            INSERT INTO Customers (UserID, FirstName, LastName, Email)
            SELECT UserID, FirstName, LastName, Email FROM Users WHERE UserID = ?
        ");
    }
    
    $stmt->execute([$_SESSION['user_id']]);
    $customerId = $conn->lastInsertId();
} else {
    $customerId = $customer['CustomerID'];
}

// Get status filter
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';
$validStatuses = ['all', 'pending', 'paid', 'preparing', 'ready_for_pickup', 'completed', 'cancelled'];

if (!in_array($statusFilter, $validStatuses)) {
    $statusFilter = 'all';
}

// Get customer orders
$sql = "
    SELECT 
        o.OrderID, 
        o.OrderDate, 
        o.OrderStatus,
        o.PickupDate,
        o.PickupTime,
        o.PickupCode,
        o.TotalAmount,
        COUNT(od.OrderDetailID) AS ItemCount
    FROM Orders o
    JOIN OrderDetails od ON o.OrderID = od.OrderID
    WHERE o.CustomerID = ?
";

if ($statusFilter !== 'all') {
    $sql .= " AND o.OrderStatus = ?";
}

$sql .= "
    GROUP BY o.OrderID, o.OrderDate, o.OrderStatus, o.PickupDate, o.PickupTime, o.PickupCode, o.TotalAmount
    ORDER BY o.OrderDate DESC
";

$stmt = $conn->prepare($sql);

if ($statusFilter !== 'all') {
    $stmt->execute([$customerId, $statusFilter]);
} else {
    $stmt->execute([$customerId]);
}

$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unread notifications count
$unreadCount = countUnreadNotifications($conn, $_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Orders</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .orders-container {
      max-width: 1000px;
      margin: 0 auto;
    }
    
    .filter-tabs {
      display: flex;
      overflow-x: auto;
      gap: 10px;
      margin-bottom: 20px;
      padding-bottom: 10px;
    }
    
    .filter-tab {
      padding: 8px 16px;
      background-color: #f5f5f5;
      border-radius: 20px;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      transition: background-color 0.2s;
      text-decoration: none;
      color: #333;
    }
    
    .filter-tab.active {
      background-color: #4a934a;
      color: white;
    }
    
    .filter-tab:hover:not(.active) {
      background-color: #e0e0e0;
    }
    
    .order-card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 20px;
      transition: transform 0.2s;
    }
    
    .order-card:hover {
      transform: translateY(-3px);
    }
    
    .order-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .order-id {
      font-size: 1.2rem;
      font-weight: 600;
    }
    
    .order-status {
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 500;
    }
    
    .status-pending {
      background-color: #f0f0f0;
      color: #666;
    }
    
    .status-paid {
      background-color: #e3f2fd;
      color: #1976d2;
    }
    
    .status-preparing {
      background-color: #fff8e1;
      color: #f57f17;
    }
    
    .status-ready_for_pickup {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-completed {
      background-color: #e8f5e9;
      color: #2e7d32;
    }
    
    .status-cancelled {
      background-color: #ffebee;
      color: #c62828;
    }
    
    .order-info {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
      margin-bottom: 15px;
    }
    
    .info-group {
      margin-bottom: 10px;
    }
    
    .info-label {
      font-size: 0.8rem;
      color: #666;
      margin-bottom: 5px;
    }
    
    .info-value {
      font-weight: 500;
    }
    
    .pickup-code {
      background-color: #f5f5f5;
      padding: 10px;
      border-radius: 4px;
      text-align: center;
      margin: 15px 0;
    }
    
    .pickup-code-label {
      font-size: 0.8rem;
      color: #666;
      margin-bottom: 5px;
    }
    
    .pickup-code-value {
      font-size: 1.5rem;
      font-weight: 700;
      letter-spacing: 3px;
    }
    
    .order-actions {
      display: flex;
      gap: 10px;
      margin-top: 15px;
    }
    
    .btn {
      padding: 8px 16px;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      text-decoration: none;
      text-align: center;
      display: inline-block;
    }
    
    .btn-primary {
      background-color: #4a934a;
      color: white;
      border: none;
    }
    
    .btn-primary:hover {
      background-color: #3a7a3a;
    }
    
    .btn-outline {
      background-color: transparent;
      border: 1px solid #4a934a;
      color: #4a934a;
    }
    
    .btn-outline:hover {
      background-color: #f0f8f0;
    }
    
    .empty-state {
      text-align: center;
      padding: 40px 0;
    }
    
    .empty-state i {
      font-size: 3rem;
      color: #ccc;
      margin-bottom: 20px;
    }
    
    .empty-state h3 {
      font-size: 1.2rem;
      margin-bottom: 10px;
      color: #666;
    }
    
    .empty-state p {
      color: #888;
      max-width: 400px;
      margin: 0 auto;
    }
    
    .notification-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      background-color: #e53935;
      color: white;
      border-radius: 50%;
      font-size: 0.75rem;
      margin-left: 5px;
    }
    
    @media (max-width: 768px) {
      .order-info {
        grid-template-columns: 1fr;
      }
      
      .order-actions {
        flex-direction: column;
      }
      
      .btn {
        width: 100%;
      }
    }
    
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }
    
    .modal.active {
      display: flex;
    }
    
    .modal-content {
      background-color: white;
      border-radius: 8px;
      max-width: 500px;
      width: 100%;
      padding: 20px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }
    
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .modal-title {
      font-size: 1.2rem;
      font-weight: 600;
    }
    
    .modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #666;
    }
    
    .modal-body {
      margin-bottom: 20px;
    }
    
    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
    
    .form-group {
      margin-bottom: 15px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 500;
    }
    
    .form-control {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
    }
    
    .star-rating {
      display: flex;
      flex-direction: row-reverse;
      justify-content: center;
      margin-bottom: 20px;
    }
    
    .star-rating input {
      display: none;
    }
    
    .star-rating label {
      cursor: pointer;
      font-size: 2rem;
      color: #ddd;
      padding: 0 5px;
    }
    
    .star-rating label:hover,
    .star-rating label:hover ~ label,
    .star-rating input:checked ~ label {
      color: #ffb400;
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="header-container">
        <h1>My Orders</h1>
        <div class="link-container">
          <a href="notifications.php" class="inventory-link">
            Notifications
            <?php if ($unreadCount > 0): ?>
              <span class="notification-badge"><?= $unreadCount ?></span>
            <?php endif; ?>
          </a>
        </div>
      </div>
      
      <div class="orders-container">
        <div class="filter-tabs">
          <a href="?status=all" class="filter-tab <?= $statusFilter === 'all' ? 'active' : '' ?>">
            All Orders
          </a>
          <a href="?status=pending" class="filter-tab <?= $statusFilter === 'pending' ? 'active' : '' ?>">
            Pending
          </a>
          <a href="?status=paid" class="filter-tab <?= $statusFilter === 'paid' ? 'active' : '' ?>">
            Paid
          </a>
          <a href="?status=preparing" class="filter-tab <?= $statusFilter === 'preparing' ? 'active' : '' ?>">
            Preparing
          </a>
          <a href="?status=ready_for_pickup" class="filter-tab <?= $statusFilter === 'ready_for_pickup' ? 'active' : '' ?>">
            Ready for Pickup
          </a>
          <a href="?status=completed" class="filter-tab <?= $statusFilter === 'completed' ? 'active' : '' ?>">
            Completed
          </a>
          <a href="?status=cancelled" class="filter-tab <?= $statusFilter === 'cancelled' ? 'active' : '' ?>">
            Cancelled
          </a>
        </div>
        
        <?php if (empty($orders)): ?>
          <div class="empty-state">
            <i class="fas fa-shopping-bag"></i>
            <h3>No orders found</h3>
            <p>You don't have any orders with the selected status.</p>
            <a href="catalog.php" class="btn btn-primary" style="margin-top: 20px;">Start Shopping</a>
          </div>
        <?php else: ?>
          <?php foreach ($orders as $order): ?>
            <div class="order-card">
              <div class="order-header">
                <div class="order-id">Order #<?= $order['OrderID'] ?></div>
                <div class="order-status status-<?= $order['OrderStatus'] ?>">
                  <?= ucfirst(str_replace('_', ' ', $order['OrderStatus'])) ?>
                </div>
              </div>
              
              <div class="order-info">
                <div>
                  <div class="info-group">
                    <div class="info-label">Order Date</div>
                    <div class="info-value"><?= date('M d, Y h:i A', strtotime($order['OrderDate'])) ?></div>
                  </div>
                  <div class="info-group">
                    <div class="info-label">Items</div>
                    <div class="info-value"><?= $order['ItemCount'] ?> items</div>
                  </div>
                </div>
                
                <div>
                  <div class="info-group">
                    <div class="info-label">Pickup Date</div>
                    <div class="info-value"><?= date('M d, Y', strtotime($order['PickupDate'])) ?></div>
                  </div>
                  <div class="info-group">
                    <div class="info-label">Pickup Time</div>
                    <div class="info-value"><?= date('h:i A', strtotime($order['PickupTime'])) ?></div>
                  </div>
                </div>
                
                <div>
                  <div class="info-group">
                    <div class="info-label">Total Amount</div>
                    <div class="info-value">₱<?= number_format($order['TotalAmount'], 2) ?></div>
                  </div>
                </div>
              </div>
              
              <?php if (in_array($order['OrderStatus'], ['ready_for_pickup', 'preparing']) && $order['PickupCode']): ?>
                <div class="pickup-code">
                  <div class="pickup-code-label">Your Pickup Code</div>
                  <div class="pickup-code-value"><?= $order['PickupCode'] ?></div>
                  <p>Please present this code when picking up your order</p>
                </div>
              <?php endif; ?>
              
              <div class="order-actions">
                <a href="order_details.php?id=<?= $order['OrderID'] ?>" class="btn btn-primary">
                  <i class="fas fa-eye"></i> View Details
                </a>
                
                <?php if ($order['OrderStatus'] === 'pending'): ?>
                  <a href="payment.php?order_id=<?= $order['OrderID'] ?>" class="btn btn-outline">
                    <i class="fas fa-credit-card"></i> Complete Payment
                  </a>
                <?php endif; ?>
                
                <?php if ($order['OrderStatus'] === 'paid'): ?>
                    <button onclick="confirmCancel(<?= $order['OrderID'] ?>)" class="btn btn-warning">
                        <i class="fas fa-times"></i> Cancel Order
                    </button>
                <?php endif; ?>
                
                <?php if ($order['OrderStatus'] === 'completed'): ?>
                  <a href="#" onclick="rateOrder(<?= $order['OrderID'] ?>)" class="btn btn-outline">
                    <i class="fas fa-star"></i> Rate Order
                  </a>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </main>
</div>

<!-- Rating Modal -->
<div id="ratingModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 class="modal-title">Rate Your Order</h2>
      <button class="modal-close" onclick="closeRatingModal()">&times;</button>
    </div>
    <form id="ratingForm" method="post" action="submit_rating.php">
      <input type="hidden" id="rating_order_id" name="order_id">
      
      <div class="modal-body">
        <div class="rating-stars">
          <div class="star-rating">
            <input type="radio" id="star5" name="rating" value="5" />
            <label for="star5" title="5 stars"><i class="fas fa-star"></i></label>
            <input type="radio" id="star4" name="rating" value="4" />
            <label for="star4" title="4 stars"><i class="fas fa-star"></i></label>
            <input type="radio" id="star3" name="rating" value="3" />
            <label for="star3" title="3 stars"><i class="fas fa-star"></i></label>
            <input type="radio" id="star2" name="rating" value="2" />
            <label for="star2" title="2 stars"><i class="fas fa-star"></i></label>
            <input type="radio" id="star1" name="rating" value="1" />
            <label for="star1" title="1 star"><i class="fas fa-star"></i></label>
          </div>
        </div>
        
        <div class="form-group">
          <label for="comments">Comments (Optional)</label>
          <textarea id="comments" name="comments" rows="3" class="form-control"></textarea>
        </div>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeRatingModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Submit Rating</button>
      </div>
    </form>
  </div>
</div>

<!-- Cancel Order Modal -->
<div id="cancelModal" class="modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center;">
    <div class="modal-content" style="background-color: white; padding: 20px; border-radius: 8px; max-width: 500px; width: 90%;">
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="font-size: 1.5rem; margin: 0;">Cancel Order</h2>
            <button onclick="closeModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <div class="modal-body">
            <p>Are you sure you want to cancel this order? This action cannot be undone.</p>
            <p style="color: #e74c3c; font-weight: 500;">Note: Refunds will be processed according to our refund policy.</p>
            
            <form id="cancelForm" action="cancel_order.php" method="post" style="margin-top: 20px;">
                <input type="hidden" id="cancel_order_id" name="order_id">
                <div style="margin-bottom: 15px;">
                    <label for="cancel_reason" style="display: block; margin-bottom: 5px; font-weight: 500;">Reason for cancellation:</label>
                    <textarea id="cancel_reason" name="reason" rows="3" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" required></textarea>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" onclick="closeModal()" style="padding: 10px 15px; background-color: #f5f5f5; border: none; border-radius: 4px; cursor: pointer;">Cancel</button>
                    <button type="submit" style="padding: 10px 15px; background-color: #e74c3c; color: white; border: none; border-radius: 4px; cursor: pointer;">Confirm Cancellation</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
  function rateOrder(orderId) {
    document.getElementById('rating_order_id').value = orderId;
    document.getElementById('ratingModal').classList.add('active');
  }
  
  function closeRatingModal() {
    document.getElementById('ratingModal').classList.remove('active');
  }
  
  // Close modal when clicking outside
  window.addEventListener('click', function(event) {
    const modal = document.getElementById('ratingModal');
    if (event.target === modal) {
      closeRatingModal();
    }
  });
</script>

<script>
    function confirmCancel(orderId) {
        document.getElementById('cancel_order_id').value = orderId;
        document.getElementById('cancelModal').style.display = 'flex';
    }
    
    function closeModal() {
        document.getElementById('cancelModal').style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('cancelModal');
        if (event.target === modal) {
            closeModal();
        }
    });
</script>
</body>
</html>
