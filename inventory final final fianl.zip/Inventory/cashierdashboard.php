<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
session_regenerate_id(true);

// Get current date and time
$currentDate = date('Y-m-d');

// Fetch recent transactions (last 24 hours)
$recentTransactionsQuery = "SELECT r.ReceiptID, r.TotalAmount, r.DateIssued, 
                         COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod
                         FROM Receipts r
                         JOIN Orders o ON r.OrderID = o.OrderID
                         JOIN OrderDetails od ON o.OrderID = od.OrderID
                         JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                         WHERE r.DateIssued >= DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY)
                         GROUP BY r.ReceiptID
                         ORDER BY r.DateIssued DESC
                         LIMIT 5";
$recentTransactionsStmt = $conn->prepare($recentTransactionsQuery);
$recentTransactionsStmt->execute();
$recentTransactions = $recentTransactionsStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch quick sale products (remove IsActive filter)
$quickSaleQuery = "SELECT p.ProductID, p.ProductName, p.SellingPrice, c.CategoryName
                FROM Product p
                JOIN Category c ON p.CategoryID = c.CategoryID
                ORDER BY p.ProductName ASC
                LIMIT 12";
$quickSaleStmt = $conn->prepare($quickSaleQuery);
$quickSaleStmt->execute();
$quickSaleProducts = $quickSaleStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch today's summary (all transactions)
$todaySummaryQuery = "SELECT 
                    COUNT(*) as TransactionCount,
                    SUM(TotalAmount) as TotalSales,
                    SUM(CASE WHEN PaymentMethodID = 1 THEN TotalAmount ELSE 0 END) as CashSales,
                    SUM(CASE WHEN PaymentMethodID = 2 THEN TotalAmount ELSE 0 END) as CardSales
                    FROM Receipts
                    WHERE DATE(DateIssued) = CURRENT_DATE";
$todaySummaryStmt = $conn->prepare($todaySummaryQuery);
$todaySummaryStmt->execute();
$todaySummary = $todaySummaryStmt->fetch(PDO::FETCH_ASSOC);


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Cashier Dashboard - Adriana's Marketing</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
      /* Dashboard Styles */
      .dashboard-container {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
          padding: 20px;
      }
      
      .dashboard-card {
          background-color: white;
          border-radius: var(--border-radius);
          box-shadow: var(--shadow-sm);
          padding: 20px;
          position: relative;
          overflow: hidden;
      }
      
      .dashboard-card h3 {
          margin-top: 0;
          color: var(--text-dark);
          font-size: 1.2rem;
          font-weight: 600;
          margin-bottom: 15px;
          display: flex;
          align-items: center;
      }
      
      .dashboard-card h3 svg {
          margin-right: 10px;
          width: 24px;
          height: 24px;
      }
      
      .dashboard-card.transactions {
          border-left: 4px solid #27ae60;
      }
      
      .dashboard-card.quick-sale {
          border-left: 4px solid #3498db;
      }
      
      .dashboard-card.summary {
          border-left: 4px solid #9b59b6;
      }
      
      .dashboard-card.customers {
          border-left: 4px solid #e67e22;
      }
      
      .welcome-header {
          background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
          color: white;
          padding: 20px;
          border-radius: var(--border-radius);
          margin-bottom: 20px;
          box-shadow: var(--shadow-md);
          display: flex;
          justify-content: space-between;
          align-items: center;
      }
      
      .welcome-header h1 {
          margin: 0;
          font-size: 1.5rem;
          font-weight: 600;
      }
      
      .welcome-header .quick-actions {
          display: flex;
          gap: 10px;
      }
      
      .quick-action-btn {
          background-color: rgba(255, 255, 255, 0.2);
          color: white;
          border: none;
          padding: 8px 15px;
          border-radius: var(--border-radius-sm);
          font-size: 0.9rem;
          cursor: pointer;
          transition: background-color 0.2s;
      }
      
      .quick-action-btn:hover {
          background-color: rgba(255, 255, 255, 0.3);
      }
      
      .date-display {
          font-size: 1rem;
          color: rgba(255, 255, 255, 0.8);
          margin-top: 5px;
      }
      
      .stat-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 15px;
          margin-top: 15px;
      }
      
      .stat-card {
          background-color: rgba(255, 255, 255, 0.1);
          padding: 15px;
          border-radius: var(--border-radius-sm);
          text-align: center;
      }
      
      .stat-card h3 {
          margin: 0;
          font-size: 1.5rem;
          font-weight: 700;
      }
      
      .stat-card p {
          margin: 5px 0 0;
          font-size: 0.9rem;
          opacity: 0.8;
      }
      
      .item-list {
          list-style: none;
          padding: 0;
          margin: 0;
      }
      
      .item-list li {
          padding: 10px 0;
          border-bottom: 1px solid #f0f0f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
      }
      
      .item-list li:last-child {
          border-bottom: none;
      }
      
      .item-name {
          font-weight: 500;
          color: var(--text-dark);
      }
      
      .item-detail {
          color: var(--text-medium);
          font-size: 0.9rem;
      }
      
      .badge {
          display: inline-block;
          padding: 3px 8px;
          border-radius: 12px;
          font-size: 0.75rem;
          font-weight: 500;
      }
      
      .badge-success {
          background-color: #d4edda;
          color: #155724;
      }
      
      .badge-primary {
          background-color: #cce5ff;
          color: #004085;
      }
      
      .badge-orange {
          background-color: #ffe5d0;
          color: #d35400;
      }
      
      .view-all {
          display: block;
          text-align: center;
          margin-top: 15px;
          color: var(--primary-color);
          text-decoration: none;
          font-size: 0.9rem;
          font-weight: 500;
      }
      
      .view-all:hover {
          text-decoration: underline;
      }
      
      .empty-state {
          text-align: center;
          padding: 20px 0;
          color: var(--text-light);
          font-style: italic;
      }
      
      .quick-sale-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
          gap: 10px;
          margin-top: 15px;
      }
      
      .quick-sale-item {
          border: 1px solid #e0e0e0;
          border-radius: var(--border-radius-sm);
          padding: 10px;
          text-align: center;
          cursor: pointer;
          transition: transform 0.2s, box-shadow 0.2s;
      }
      
      .quick-sale-item:hover {
          transform: translateY(-2px);
          box-shadow: var(--shadow-sm);
      }
      
      .quick-sale-item h4 {
          margin: 5px 0;
          font-size: 0.9rem;
          color: var(--text-dark);
      }
      
      .quick-sale-item p {
          margin: 0;
          font-size: 0.8rem;
          color: var(--text-medium);
      }
      
      .quick-sale-price {
          font-weight: 600;
          color: var(--primary-color);
          margin-top: 5px;
      }
      
      @media (max-width: 768px) {
          .dashboard-container {
              grid-template-columns: 1fr;
          }
          
          .welcome-header {
              flex-direction: column;
              align-items: flex-start;
              gap: 10px;
          }
          
          .welcome-header .quick-actions {
              width: 100%;
              justify-content: space-between;
          }
          
          .quick-sale-grid {
              grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
          }
      }
      h1{
        color:white;
      }
  </style>
</head>
<body>
  <?php include 'sidebar.php'; ?>
  <?php include 'navbar.php'; ?>

  <div class="main-content-wrapper">
      <main class="content">
          <!-- Welcome Header with Quick Actions -->
          <div class="welcome-header">
              <div>
                  <h1>Welcome, Cashier <?= htmlspecialchars($_SESSION['user_name']) ?></h1>
                  <p class="date-display"><?= date('l, F j, Y') ?></p>
              </div>

          </div>
          
          <!-- Today's Summary -->
          <div class="stat-grid">
              <div class="stat-card">
                  <h3><?= $todaySummary['TransactionCount'] ?? 0 ?></h3>
                  <p>Transactions Today</p>
              </div>
              <div class="stat-card">
                  <h3>₱<?= number_format($todaySummary['TotalSales'] ?? 0, 2) ?></h3>
                  <p>Total Sales</p>
              </div>
              <div class="stat-card">
                  <h3>₱<?= number_format($todaySummary['CashSales'] ?? 0, 2) ?></h3>
                  <p>Cash Sales</p>
              </div>
              <div class="stat-card">
                  <h3>₱<?= number_format($todaySummary['CardSales'] ?? 0, 2) ?></h3>
                  <p>Card Sales</p>
              </div>
          </div>
          
          <div class="dashboard-container">
              <!-- Quick Sale Products -->
              <div class="dashboard-card quick-sale">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#3498db" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <circle cx="9" cy="21" r="1"></circle>
                          <circle cx="20" cy="21" r="1"></circle>
                          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                      </svg>
                      Quick Sale Products
                  </h3>
                  <?php if (count($quickSaleProducts) > 0): ?>
                      <div class="quick-sale-grid">
                          <?php foreach ($quickSaleProducts as $product): ?>
                            <div class="quick-sale-item" onclick="window.location.href='orderingpage.php?product_id=<?= $product['ProductID'] ?>'">
                                  <h4><?= htmlspecialchars($product['ProductName']) ?></h4>
                                  <p><?= htmlspecialchars($product['CategoryName']) ?></p>
                                  <div class="quick-sale-price">₱<?= number_format($product['SellingPrice'], 2) ?></div>
                              </div>
                          <?php endforeach; ?>
                      </div>
                      <a href="products.php" class="view-all">View All Products</a>
                  <?php else: ?>
                      <div class="empty-state">No products available for quick sale.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Recent Transactions -->
              <div class="dashboard-card transactions">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <line x1="12" y1="1" x2="12" y2="23"></line>
                          <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                      </svg>
                      Recent Transactions
                  </h3>
                  <?php if (count($recentTransactions) > 0): ?>
                      <ul class="item-list">
                          <?php foreach ($recentTransactions as $transaction): ?>
                              <li>
                                  <div>
                                      <span class="item-name">Receipt #<?= $transaction['ReceiptID'] ?></span>
                                      <div class="item-detail"><?= date('g:i A', strtotime($transaction['DateIssued'])) ?> • <?= $transaction['ItemCount'] ?> items</div>
                                  </div>
                                  <span class="badge badge-success">₱<?= number_format($transaction['TotalAmount'], 2) ?></span>
                              </li>
                          <?php endforeach; ?>
                      </ul>
                      <a href="transactions.php" class="view-all">View All Transactions</a>
                  <?php else: ?>
                      <div class="empty-state">No transactions processed today.</div>
                  <?php endif; ?>
              </div>
              
              <!-- Customer Activity -->
          
              
              <!-- Today's Summary Card -->
              <div class="dashboard-card summary">
                  <h3>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#9b59b6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path>
                          <path d="M22 12A10 10 0 0 0 12 2v10z"></path>
                      </svg>
                      Today's Summary
                  </h3>
                  <ul class="item-list">
                      <li>
                          <span class="item-name">Total Transactions</span>
                          <span class="badge badge-primary"><?= $todaySummary['TransactionCount'] ?? 0 ?></span>
                      </li>
                      <li>
                          <span class="item-name">Total Sales</span>
                          <span class="badge badge-success">₱<?= number_format($todaySummary['TotalSales'] ?? 0, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Cash Payments</span>
                          <span class="badge badge-success">₱<?= number_format($todaySummary['CashSales'] ?? 0, 2) ?></span>
                      </li>
                      <li>
                          <span class="item-name">Card Payments</span>
                          <span class="badge badge-primary">₱<?= number_format($todaySummary['CardSales'] ?? 0, 2) ?></span>
                      </li>
                  </ul>
                  <a href="reports.php?daily" class="view-all">View Daily Report</a>
              </div>
          </div>
      </main>
  </div>

  <script>
      // Function to add product to cart
      function addToCart(productId) {
          // In a real implementation, this would add the product to the cart
          // For now, we'll just redirect to the new sale page with the product pre-selected
          window.location.href = 'new_sale.php?product_id=' + productId;
      }
      
      document.addEventListener('DOMContentLoaded', function() {
          // Any initialization code for the cashier dashboard
      });
  </script>
</body>
</html>