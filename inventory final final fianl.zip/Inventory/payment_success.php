<?php
// payment_success.php
session_start();
require_once 'config/database.php';

// Enable error logging
error_reporting(E_ALL);
ini_set('display_errors', 0);
error_log('Payment success page loaded');

// Check if we have an order ID from URL or session
$orderId = isset($_GET['order_id']) ? intval($_GET['order_id']) : ($_SESSION['current_order_id'] ?? null);

if (!$orderId) {
    error_log('No order ID found in URL or session');
    header('Location: catalog.php');
    exit;
}

error_log('Processing success for order ID: ' . $orderId);

// Get order details
$stmt = $conn->prepare("
    SELECT o.*, c.FirstName, c.LastName, c.Email, c.Phone
    FROM Orders o
    JOIN Customers c ON o.CustomerID = c.CustomerID
    WHERE o.OrderID = ?
");
$stmt->execute([$orderId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    error_log('Order not found: ' . $orderId);
    header('Location: catalog.php');
    exit;
}

// Get order items
$stmt = $conn->prepare("
    SELECT od.*, p.ProductName, p.ImageURL
    FROM OrderDetails od
    JOIN Product p ON od.ProductID = p.ProductID
    WHERE od.OrderID = ?
");
$stmt->execute([$orderId]);
$orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$subtotal = 0;
foreach ($orderItems as $item) {
    $subtotal += $item['Price'] * $item['Quantity'];
}
$taxRate = 0.12; // 12% tax
$tax = $subtotal * $taxRate;
$total = $subtotal + $tax;

// Clear cart and order data from session
$_SESSION['cart'] = [];
unset($_SESSION['order_data']);
unset($_SESSION['current_order_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Successful</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .success-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 30px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    
    .success-icon {
      font-size: 5rem;
      color: #4a934a;
      margin-bottom: 20px;
    }
    
    .success-title {
      font-size: 2rem;
      color: #333;
      margin-bottom: 15px;
    }
    
    .success-message {
      font-size: 1.1rem;
      color: #666;
      margin-bottom: 30px;
    }
    
    .pickup-details {
      background-color: #f9f9f9;
      border-radius: 8px;
      padding: 20px;
      margin-bottom: 30px;
      text-align: left;
    }
    
    .pickup-header {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 15px;
      color: #333;
    }
    
    .pickup-info {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      margin-bottom: 20px;
    }
    
    .pickup-item {
      flex: 1;
      min-width: 200px;
    }
    
    .pickup-label {
      font-size: 0.9rem;
      color: #666;
      margin-bottom: 5px;
    }
    
    .pickup-value {
      font-size: 1.1rem;
      font-weight: 500;
    }
    
    .pickup-code {
      background-color: #e8f5e9;
      border: 1px dashed #4a934a;
      padding: 15px;
      border-radius: 8px;
      text-align: center;
      margin-top: 20px;
    }
    
    .pickup-code-label {
      font-size: 0.9rem;
      color: #4a934a;
      margin-bottom: 5px;
    }
    
    .pickup-code-value {
      font-size: 2rem;
      font-weight: 700;
      color: #4a934a;
      letter-spacing: 5px;
    }
    
    .order-details {
      background-color: #f9f9f9;
      border-radius: 8px;
      padding: 20px;
      margin-top: 30px;
      text-align: left;
    }
    
    .order-header {
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #eee;
      padding-bottom: 15px;
      margin-bottom: 15px;
    }
    
    .order-items {
      margin-bottom: 20px;
    }
    
    .order-item {
      display: flex;
      margin-bottom: 10px;
      padding-bottom: 10px;
      border-bottom: 1px solid #eee;
    }
    
    .item-image {
      width: 60px;
      height: 60px;
      margin-right: 15px;
    }
    
    .item-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 4px;
    }
    
    .item-details {
      flex: 1;
    }
    
    .item-name {
      font-weight: 600;
    }
    
    .item-price {
      color: #666;
      font-size: 0.9rem;
    }
    
    .item-quantity {
      color: #666;
      font-size: 0.9rem;
    }
    
    .item-total {
      font-weight: 600;
      text-align: right;
      min-width: 100px;
    }
    
    .order-summary {
      margin-top: 20px;
      text-align: right;
    }
    
    .summary-row {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 5px;
    }
    
    .summary-label {
      width: 100px;
      color: #666;
      text-align: left;
      margin-right: 20px;
    }
    
    .summary-value {
      width: 100px;
      font-weight: 500;
    }
    
    .total-row {
      font-size: 1.2rem;
      font-weight: 600;
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid #ddd;
    }
    
    .buttons {
      margin-top: 30px;
    }
    
    .btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: #4a934a;
      color: white;
      border: none;
      border-radius: 4px;
      font-size: 1rem;
      text-decoration: none;
      margin: 0 10px;
      transition: background-color 0.2s;
    }
    
    .btn:hover {
      background-color: #3a7a3a;
    }
    
    .btn-outline {
      background-color: transparent;
      border: 1px solid #4a934a;
      color: #4a934a;
    }
    
    .btn-outline:hover {
      background-color: #f0f8f0;
    }
    
    .no-image {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #f0f0f0;
      color: #aaa;
      font-size: 1.5rem;
    }
    
    @media print {
      .btn, .navbar, .sidebar {
        display: none !important;
      }
      
      body {
        background-color: white !important;
      }
      
      .success-container {
        box-shadow: none !important;
        padding: 0 !important;
      }
    }
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>
<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <div class="success-container">
        <div class="success-icon">
          <i class="fas fa-check-circle"></i>
        </div>
        <h1 class="success-title">Payment Successful!</h1>
        <p class="success-message">Thank you for your order. Your payment has been processed successfully.</p>
        
        <div class="pickup-details">
          <h2 class="pickup-header">Pickup Information</h2>
          <div class="pickup-info">
            <div class="pickup-item">
              <div class="pickup-label">Pickup Date</div>
              <div class="pickup-value"><?= date('l, F j, Y', strtotime($order['PickupDate'])) ?></div>
            </div>
            <?php if (!empty($order['PickupTime'])): ?>
            <div class="pickup-item">
              <div class="pickup-label">Pickup Time</div>
              <div class="pickup-value"><?= date('h:i A', strtotime($order['PickupTime'])) ?></div>
            </div>
            <?php endif; ?>
          </div>
          
          <div class="pickup-code">
            <div class="pickup-code-label">Your Pickup Code</div>
            <div class="pickup-code-value"><?= $order['PickupCode'] ?></div>
            <p>Please present this code when picking up your order</p>
          </div>
        </div>
        
        <div class="order-details">
          <div class="order-header">
            <div>
              <h2>Order #<?= $orderId ?></h2>
              <p>Date: <?= date('F j, Y', strtotime($order['OrderDate'])) ?></p>
            </div>
            <div>
              <p>Status: <strong><?= ucfirst(str_replace('_', ' ', $order['OrderStatus'])) ?></strong></p>
            </div>
          </div>
          
          <div class="order-items">
            <?php foreach ($orderItems as $item): ?>
              <div class="order-item">
                <div class="item-image">
                  <?php if (!empty($item['ImageURL'])): ?>
                    <img src="<?= htmlspecialchars($item['ImageURL']) ?>" alt="<?= htmlspecialchars($item['ProductName']) ?>">
                  <?php else: ?>
                    <div class="no-image"><i class="fas fa-image"></i></div>
                  <?php endif; ?>
                </div>
                <div class="item-details">
                  <div class="item-name"><?= htmlspecialchars($item['ProductName']) ?></div>
                  <div class="item-price">₱<?= number_format($item['Price'], 2) ?> each</div>
                  <div class="item-quantity">Quantity: <?= $item['Quantity'] ?></div>
                </div>
                <div class="item-total">₱<?= number_format($item['Price'] * $item['Quantity'], 2) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
          
          <div class="order-summary">
            <div class="summary-row">
              <div class="summary-label">Subtotal:</div>
              <div class="summary-value">₱<?= number_format($subtotal, 2) ?></div>
            </div>
            <div class="summary-row">
              <div class="summary-label">Tax (12%):</div>
              <div class="summary-value">₱<?= number_format($tax, 2) ?></div>
            </div>
            <div class="summary-row total-row">
              <div class="summary-label">Total:</div>
              <div class="summary-value">₱<?= number_format($total, 2) ?></div>
            </div>
          </div>
        </div>
        
        <div class="buttons">
          <a href="catalog.php" class="btn">Continue Shopping</a>
          <a href="#" onclick="window.print()" class="btn btn-outline">Print Receipt</a>
        </div>
      </div>
    </div>
  </main>
</div>
</body>
</html>
