<?php
session_start();
require('config/database.php');

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
    header('Location: index.php');
    exit;
}

// Include TCPDF library
require_once('includes/tcpdf/tcpdf/tcpdf.php');

// Get parameters from URL
$reportType = $_GET['report_type'] ?? 'sales';
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Define report types
$reportTypes = [
    'sales' => 'Sales Report',
    'refunds' => 'Refunds Report',
    'cancellations' => 'Cancellations Report',
    'inventory' => 'Inventory Report'
];

// Create new PDF document
class MYPDF extends TCPDF {
    // Page header
    public function Header() {
        // Logo
        $image_file = 'images/logo.png';
        if (file_exists($image_file)) {
            $this->Image($image_file, 10, 10, 30, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        }
        
        // Set font
        $this->SetFont('helvetica', 'B', 16);
        // Title
        $this->Cell(0, 15, 'Adriana\'s Marketing', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        
        // Line break
        $this->Ln(20);
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

// Create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Adriana\'s Marketing');
$pdf->SetTitle($reportTypes[$reportType]);
$pdf->SetSubject($reportTypes[$reportType]);
$pdf->SetKeywords('Report, PDF, Inventory, Sales, Refunds, Cancellations');

// Set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', 'B', 14);

// Report title
$pdf->Cell(0, 10, $reportTypes[$reportType], 0, 1, 'C');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 10, 'Period: ' . date('F d, Y', strtotime($startDate)) . ' to ' . date('F d, Y', strtotime($endDate)), 0, 1, 'C');
$pdf->Ln(5);

// Function to get report data based on type and date range
function getReportData($conn, $reportType, $startDate, $endDate) {
    $data = [];
    
    switch ($reportType) {
        case 'sales':
            // Sales report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status IN ('paid', 'cancelled', 'refunded')
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
            
        case 'refunds':
            // Refunds report query using Transactions table
            $query = "SELECT ri.RefundID, p.ProductName, ri.QuantityRefunded, 
                      ri.ItemCondition, ri.RefundedAt, 
                      CONCAT(u.FirstName, ' ', u.LastName) as ProcessedBy,
                      (od.Price * ri.QuantityRefunded) as RefundAmount,
                      t.TransactionID as ReceiptID, t.Amount as OriginalAmount
                      FROM RefundedItems ri
                      JOIN Product p ON ri.ProductID = p.ProductID
                      JOIN Users u ON ri.ProcessedBy = u.UserID
                      JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
                      JOIN Orders o ON ri.OrderID = o.OrderID
                      JOIN Transactions t ON o.OrderID = t.OrderID
                      WHERE ri.RefundedAt BETWEEN ? AND ?
                      ORDER BY ri.RefundedAt DESC";
            break;

        case 'cancellations':
            // Cancellations report query using Transactions table
            $query = "SELECT t.TransactionID, t.Amount as TotalAmount, t.CreatedAt as DateIssued, 
                      COUNT(od.OrderDetailID) as ItemCount, pm.MethodName as PaymentMethod,
                      CONCAT(u.FirstName, ' ', u.LastName) as Cashier
                      FROM Transactions t
                      LEFT JOIN Orders o ON t.OrderID = o.OrderID
                      LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
                      LEFT JOIN PaymentMethods pm ON t.PaymentMethodID = pm.PaymentMethodID
                      LEFT JOIN Users u ON o.UserID = u.UserID
                      WHERE t.Status = 'cancelled' 
                      AND t.CreatedAt >= ? 
                      AND t.CreatedAt < DATE_ADD(?, INTERVAL 1 DAY)
                      GROUP BY t.TransactionID
                      ORDER BY t.CreatedAt DESC";
            break;
        case 'inventory':
            // Inventory report query
            $query = "SELECT p.ProductID, p.ProductName, c.CategoryName, 
                      SUM(i.Quantity) as TotalQuantity, 
                      p.PurchasePrice, p.SellingPrice,
                      (SUM(i.Quantity) * p.PurchasePrice) as TotalValue
                      FROM Product p
                      JOIN Inventory i ON p.ProductID = i.ProductID
                      JOIN Category c ON p.CategoryID = c.CategoryID
                      GROUP BY p.ProductID
                      ORDER BY c.CategoryName, p.ProductName";
            break;
            
        default:
            $data = [];
            return $data;
    }
    
    try {
        $stmt = $conn->prepare($query);
        
        // Bind parameters based on report type
        switch ($reportType) {
            case 'inventory':
                $stmt->execute();
                break;
                
            default:
                $stmt->execute([$startDate, $endDate]);
                break;
        }
        
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate summary data for certain report types
        if ($reportType === 'sales') {
            $totalSales = 0;
            foreach ($data as $sale) {
                if (isset($sale['TotalAmount'])) {
                    $totalSales += $sale['TotalAmount'];
                }
            }
            $data['summary'] = [
                'totalSales' => $totalSales,
                'transactionCount' => count($data)
            ];
        } elseif ($reportType === 'refunds') {
            $totalRefunds = 0;
            foreach ($data as $refund) {
                if (isset($refund['RefundAmount'])) {
                    $totalRefunds += $refund['RefundAmount'];
                }
            }
            $data['summary'] = [
                'totalRefunds' => $totalRefunds,
                'refundCount' => count($data)
            ];
        } elseif ($reportType === 'cancellations') {
            $totalCancellations = 0;
            foreach ($data as $cancellation) {
                if (isset($cancellation['TotalAmount'])) {
                    $totalCancellations += $cancellation['TotalAmount'];
                }
            }
            $data['summary'] = [
                'totalCancellations' => $totalCancellations,
                'cancellationCount' => count($data)
            ];
        } elseif ($reportType === 'inventory') {
            $totalValue = 0;
            $totalItems = 0;
            foreach ($data as $item) {
                if (isset($item['TotalValue'])) {
                    $totalValue += $item['TotalValue'];
                }
                if (isset($item['TotalQuantity'])) {
                    $totalItems += $item['TotalQuantity'];
                }
            }
            $data['summary'] = [
                'totalValue' => $totalValue,
                'totalItems' => $totalItems
            ];
        }
        
    } catch (PDOException $e) {
        // Handle error
        error_log("PDF Generation Error: " . $e->getMessage());
    }
    
    return $data;
}

// Get report data
$reportData = getReportData($conn, $reportType, $startDate, $endDate);

// Generate report content based on report type
switch ($reportType) {
    case 'sales':
        // Sales report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(20, 7, 'Trans. ID', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Date', 1, 0, 'C');
        $pdf->Cell(15, 7, 'Items', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Payment Method', 1, 0, 'C');
        $pdf->Cell(50, 7, 'Cashier', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalAmount = 0;
        $transactionCount = 0;
        
        foreach ($reportData as $key => $sale) {
            if ($key !== 'summary' && isset($sale['TransactionID'])) {
                $pdf->Cell(20, 6, $sale['TransactionID'], 1, 0, 'C');
                $pdf->Cell(30, 6, date('M d, Y', strtotime($sale['DateIssued'])), 1, 0, 'C');
                $pdf->Cell(15, 6, $sale['ItemCount'], 1, 0, 'C');
                $pdf->Cell(30, 6, $sale['PaymentMethod'], 1, 0, 'C');
                $pdf->Cell(50, 6, $sale['Cashier'], 1, 0, 'L');
                $pdf->Cell(30, 6, 'PHP' . number_format($sale['TotalAmount'], 2), 1, 1, 'R');
                $totalAmount += $sale['TotalAmount'];
                $transactionCount++;
            }
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(145, 7, 'Total Sales:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalAmount, 2), 1, 1, 'R');
        $pdf->Cell(145, 7, 'Transaction Count:', 1, 0, 'R');
        $pdf->Cell(30, 7, $transactionCount, 1, 1, 'R');
        break;
        
    case 'refunds':
        // Refunds report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'Refund ID', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Receipt ID', 1, 0, 'C');
        $pdf->Cell(50, 7, 'Product', 1, 0, 'C');
        $pdf->Cell(15, 7, 'Qty', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Condition', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Processed By', 1, 0, 'C');
        $pdf->Cell(25, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalRefundAmount = 0;
        $refundCount = 0;
        
        foreach ($reportData as $key => $refund) {
            if ($key !== 'summary' && isset($refund['RefundID'])) {
                $pdf->Cell(15, 6, $refund['RefundID'], 1, 0, 'C');
                $pdf->Cell(20, 6, $refund['ReceiptID'], 1, 0, 'C');
                $pdf->Cell(50, 6, $refund['ProductName'], 1, 0, 'L');
                $pdf->Cell(15, 6, $refund['QuantityRefunded'], 1, 0, 'C');
                $pdf->Cell(20, 6, $refund['ItemCondition'], 1, 0, 'C');
                $pdf->Cell(30, 6, $refund['ProcessedBy'], 1, 0, 'L');
                $pdf->Cell(25, 6, 'PHP' . number_format($refund['RefundAmount'], 2), 1, 1, 'R');
                $totalRefundAmount += $refund['RefundAmount'];
                $refundCount++;
            }
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(150, 7, 'Total Refund Amount:', 1, 0, 'R');
        $pdf->Cell(25, 7, 'PHP' . number_format($totalRefundAmount, 2), 1, 1, 'R');
        $pdf->Cell(150, 7, 'Total Refunds:', 1, 0, 'R');
        $pdf->Cell(25, 7, $refundCount, 1, 1, 'R');
        break;
        
    case 'cancellations':
        // Cancellations report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(20, 7, 'Trans. ID', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Date', 1, 0, 'C');
        $pdf->Cell(15, 7, 'Items', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Payment Method', 1, 0, 'C');
        $pdf->Cell(50, 7, 'Cashier', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Amount', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalCancellationAmount = 0;
        $cancellationCount = 0;
        
        foreach ($reportData as $key => $cancellation) {
            if ($key !== 'summary' && isset($cancellation['TransactionID'])) {
                $pdf->Cell(20, 6, $cancellation['TransactionID'], 1, 0, 'C');
                $pdf->Cell(30, 6, date('M d, Y', strtotime($cancellation['DateIssued'])), 1, 0, 'C');
                $pdf->Cell(15, 6, $cancellation['ItemCount'], 1, 0, 'C');
                $pdf->Cell(30, 6, $cancellation['PaymentMethod'], 1, 0, 'C');
                $pdf->Cell(50, 6, $cancellation['Cashier'], 1, 0, 'L');
                $pdf->Cell(30, 6, 'PHP' . number_format($cancellation['TotalAmount'], 2), 1, 1, 'R');
                $totalCancellationAmount += $cancellation['TotalAmount'];
                $cancellationCount++;
            }
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(145, 7, 'Total Cancellation Amount:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalCancellationAmount, 2), 1, 1, 'R');
        $pdf->Cell(145, 7, 'Cancellation Count:', 1, 0, 'R');
        $pdf->Cell(30, 7, $cancellationCount, 1, 1, 'R');
        break;
        
    case 'inventory':
        // Inventory report
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(15, 7, 'ID', 1, 0, 'C');
        $pdf->Cell(60, 7, 'Product Name', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Category', 1, 0, 'C');
        $pdf->Cell(20, 7, 'Quantity', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Purchase Price', 1, 0, 'C');
        $pdf->Cell(30, 7, 'Total Value', 1, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 9);
        $totalValue = 0;
        $totalItems = 0;
        
        foreach ($reportData as $key => $item) {
            if ($key !== 'summary' && isset($item['ProductID'])) {
                $pdf->Cell(15, 6, $item['ProductID'], 1, 0, 'C');
                $pdf->Cell(60, 6, $item['ProductName'], 1, 0, 'L');
                $pdf->Cell(30, 6, $item['CategoryName'], 1, 0, 'C');
                $pdf->Cell(20, 6, $item['TotalQuantity'], 1, 0, 'C');
                $pdf->Cell(30, 6, 'PHP' . number_format($item['PurchasePrice'], 2), 1, 0, 'R');
                $pdf->Cell(30, 6, 'PHP' . number_format($item['TotalValue'], 2), 1, 1, 'R');
                $totalValue += $item['TotalValue'];
                $totalItems += $item['TotalQuantity'];
            }
        }
        
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(125, 7, 'Total Inventory Value:', 1, 0, 'R');
        $pdf->Cell(30, 7, 'PHP' . number_format($totalValue, 2), 1, 1, 'R');
        $pdf->Cell(125, 7, 'Total Items:', 1, 0, 'R');
        $pdf->Cell(30, 7, $totalItems, 1, 1, 'R');
        break;
        
    default:
        $pdf->Cell(0, 10, 'No data available for the selected report type.', 0, 1, 'C');
        break;
}

// Add generation timestamp
$pdf->Ln(10);
$pdf->SetFont('helvetica', 'I', 8);
$pdf->Cell(0, 10, 'Report generated on: ' . date('F d, Y h:i A'), 0, 1, 'R');

// Output the PDF
$pdf->Output('Adrianas_Marketing_' . $reportTypes[$reportType] . '_' . date('Y-m-d') . '.pdf', 'D');
?>