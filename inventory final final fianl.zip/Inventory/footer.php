<?php
// footer.php
?>

<!-- Footer Section -->
<footer class="footer">
    <div class="footer-container">
        <p>&copy; <?= date('Y') ?> Adriana's Marketing. All Rights Reserved.</p>
        <div class="social-icons">

        </div>
    </div>
</footer>

<style>




/* Footer styles */
.footer {
    background-color: #c8e6b9;
    padding: 2rem 1rem;
    margin-top: auto;  /* Push the footer to the bottom */
    text-align: center;
    font-size: 0.9rem;
    color: #333;
}
    .footer-container {
        max-width: 1200px;
        margin: 0 auto;
    }

    .footer p {
        margin: 0;
        color: #777;
    }



    /* Media Queries for responsiveness */
    @media (max-width: 768px) {
        .footer-container {
            text-align: center;
        }
    }
    @media (max-width: 768px) {
    .footer-container {
        text-align: center;
    }
}
</style>
