document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle functionality
    const toggleButton = document.getElementById('toggle-btn');
    const sidebar = document.getElementById('sidebar');

    if (toggleButton && sidebar) {
        toggleButton.addEventListener('click', function() {
            sidebar.classList.toggle('close');
            toggleButton.classList.toggle('rotate');

            Array.from(sidebar.getElementsByClassName('show')).forEach(ul => {
                ul.classList.remove('show');
                ul.previousElementSibling.classList.remove('rotate');
            });
        });
    }

    // Logout modal functions
    window.toggleSubMenu = function(button) {
        const submenu = button.nextElementSibling;
        submenu.classList.toggle('show');
        button.classList.toggle('rotate');

        if (sidebar && sidebar.classList.contains('close')) {
            sidebar.classList.toggle('close');
            if (toggleButton) toggleButton.classList.toggle('rotate');
        }
    };
    
    window.showLogoutModal = function(e) {
        e.preventDefault();
        const modal = document.getElementById('logoutModal');
        if (modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    }

    window.hideLogoutModal = function() {
        const modal = document.getElementById('logoutModal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    }
    
    // Close modal when clicking outside
    const logoutModal = document.getElementById('logoutModal');
    if (logoutModal) {
        logoutModal.addEventListener('click', function(e) {
            if (e.target === this) {
                hideLogoutModal();
            }
        });
    }
});
