// Add this to your existing inventory.js file

// Process toast notifications from AJAX responses
function processAjaxToast(response) {
    if (response && response.toast) {
      showToast(response.toast.message, response.toast.type || "info")
    }
  }
  
  // Example usage in your AJAX calls:
  function flushExpiredItems() {
    fetch("flush_expired_items.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => {
        processAjaxToast(data)
        // Rest of your code to handle the response
      })
      .catch((error) => {
        showToast("Error: " + error.message, "error")
      })
  }
  
  // Mock showToast function for demonstration purposes.
  // In a real application, this would be replaced with your actual toast notification implementation.
  function showToast(message, type) {
    console.log(`Toast: ${message} (Type: ${type})`)
  }
  