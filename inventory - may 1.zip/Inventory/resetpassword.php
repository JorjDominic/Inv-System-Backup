<?php
require 'config/database.php';
$alert = '';
$alertType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $email = strtolower(trim($_POST['email']));
    $code = trim($_POST['code']);
    $newPassword = trim($_POST['new_password']);

    try {
        // Fetch the user matching email and reset code
        $stmt = $conn->prepare("SELECT * FROM Users WHERE Email = ? AND ResetCode = ?");
        $stmt->execute([$email, $code]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            // Invalid email or reset code
            $alert = 'Invalid email or reset code';
            $alertType = 'error';
        } elseif (password_verify($newPassword, $user['Password'])) {
            // Check if the new password is the same as the old password
            $alert = 'New password cannot match current password';
            $alertType = 'error';
        } else {
            // Hash the new password and update the user record
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $conn->prepare("UPDATE Users SET Password = ?, ResetCode = NULL WHERE Email = ?")
                 ->execute([$hashedPassword, $email]);
            
            // Set success message and redirect to login
            $alert = 'Password reset successfully!';
            $alertType = 'success';
            
            // Log the password change
            $username = $user['Username'];  // The username of the user whose password is being reset
            $changer = $user['Username'];  // The username of the user themselves, as they are changing their own password

            $change_time = date('Y-m-d H:i:s');
            $log_query = "INSERT INTO audit_trail (affected_username, changed_by, action, timestamp)
                        VALUES (:affected, :changer, 'Password Changed', :timestamp)";
            $log_stmt = $conn->prepare($log_query);
            $log_stmt->bindParam(':affected', $username);  // User whose password is changed
            $log_stmt->bindParam(':changer', $changer);  // User performing the change (same as the affected user)
            $log_stmt->bindParam(':timestamp', $change_time);
            $log_stmt->execute();

            // Redirect after showing toast
            echo '<script>
                  sessionStorage.setItem("toastMessage", JSON.stringify({
                      type: "success",
                      message: "Password reset successfully!"
                  }));
                  window.location.href = "index.php";
                  </script>';
            exit();
        }
    } catch (PDOException $e) {
        // Handle any database errors
        $alert = 'System error - try again later';
        $alertType = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/resetpass.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
</head>
<body>
    <div class="container">
        <div class="screen">
            <!-- Background Shapes -->
            <div class="screen__background">
                <span class="screen__background__shape screen__background__shape4"></span>
                <span class="screen__background__shape screen__background__shape3"></span>
                <span class="screen__background__shape screen__background__shape2"></span>
                <span class="screen__background__shape screen__background__shape1"></span>
            </div>
            
            <!-- Reset Password Form -->
            <div class="screen__content">
                <form class="reset-form" method="POST">
                    <h2>Reset Password</h2>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-envelope"></i>
                        <input type="email" name="email" class="login__input" placeholder="Your Email" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-key"></i>
                        <input type="text" name="code" class="login__input" placeholder="Reset Code" required>
                    </div>
                    
                    <div class="login__field">
                        <i class="login__icon fas fa-lock"></i>
                        <input type="password" name="new_password" id="new_password" class="login__input" placeholder="New Password" required>
                        <span id="passwordToggle" class="password-toggle" onclick="togglePassword()"></span>
                    </div>
                    
                    <div id="passwordStrength" class="strength-message">
                        <ul>
                            <li id="length" class="invalid"><span>✗</span> At least 8 characters</li>
                            <li id="lowercase" class="invalid"><span>✗</span> A lowercase letter</li>
                            <li id="uppercase" class="invalid"><span>✗</span> An uppercase letter</li>
                            <li id="number" class="invalid"><span>✗</span> A number</li>
                        </ul>
                    </div>
                    
                    <button type="submit" class="login__submit">
                        <span class="button__text">Reset Password</span>
                        <i class="button__icon fas fa-chevron-right"></i>
                    </button>
                    
                    <p class="back-link">
                        <a href="index.php">← Back to Login</a>
                    </p>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script>
        // Show toast notification if there's an alert
        <?php if ($alert && $alertType): ?>
            Toastify({
                text: "<?= addslashes($alert) ?>",
                duration: 3000,
                gravity: "top",
                position: "center",
                backgroundColor: "<?= $alertType === 'success' ? '#4CAF50' : '#F44336' ?>",
                stopOnFocus: true
            }).showToast();
        <?php endif; ?>

        // Function to toggle password visibility
        function togglePassword() {
            const passwordInput = document.getElementById('new_password');
            const toggleIcon = document.getElementById('passwordToggle');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';  // Show password
                toggleIcon.classList.add('show');
            } else {
                passwordInput.type = 'password';  // Hide password
                toggleIcon.classList.remove('show');
            }
        }
        
        // Password strength indicator
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            updatePasswordStrength(password);
        });

        function updatePasswordStrength(password) {
            // Check each requirement
            const hasMinLength = password.length >= 8;
            const hasLowercase = /[a-z]/.test(password);
            const hasUppercase = /[A-Z]/.test(password);
            const hasNumber = /\d/.test(password);
            
            // Update UI for each requirement
            updateRequirement('length', hasMinLength);
            updateRequirement('lowercase', hasLowercase);
            updateRequirement('uppercase', hasUppercase);
            updateRequirement('number', hasNumber);
        }

        function updateRequirement(id, isValid) {
            const element = document.getElementById(id);
            if (isValid) {
                element.classList.remove('invalid');
                element.classList.add('valid');
                element.querySelector('span').textContent = '✓';
            } else {
                element.classList.remove('valid');
                element.classList.add('invalid');
                element.querySelector('span').textContent = '✗';
            }
        }
        
        // Form validation with Toastify notification
        document.querySelector('form').addEventListener('submit', function(e) {
            const pw = document.getElementById('new_password').value;
            const hasUppercase = /[A-Z]/.test(pw);
            const hasLowercase = /[a-z]/.test(pw);
            const hasNumber = /[0-9]/.test(pw);

            if (pw.length < 8 || !hasUppercase || !hasLowercase || !hasNumber) {
                e.preventDefault(); // Stop form submission
                
                Toastify({
                    text: "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one number.",
                    duration: 4000,
                    gravity: "top",
                    position: "center",
                    backgroundColor: "#F44336",
                    stopOnFocus: true
                }).showToast();
            }
        });

        // Check for toast message from session storage (for redirects)
        document.addEventListener('DOMContentLoaded', function() {
            const toastData = sessionStorage.getItem('toastMessage');
            if (toastData) {
                try {
                    const { type, message } = JSON.parse(toastData);
                    Toastify({
                        text: message,
                        duration: 3000,
                        gravity: "top",
                        position: "center",
                        backgroundColor: type === "success" ? "#4CAF50" : "#F44336",
                        stopOnFocus: true
                    }).showToast();
                } catch (e) {
                    console.error("Failed to parse toast message:", e);
                } finally {
                    sessionStorage.removeItem('toastMessage');
                }
            }
        });
    </script>
</body>
</html>
