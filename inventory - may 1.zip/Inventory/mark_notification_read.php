<?php
session_start();
require('config/database.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

$userID = $_SESSION['user_id'];

if (isset($_POST['notification_id'])) {
    $notificationID = $_POST['notification_id'];
    
    // Update notification status in database
    $stmt = $conn->prepare("UPDATE Notifications SET IsRead = 1 WHERE NotificationID = ? AND UserID = ?");
    $stmt->execute([$notificationID, $userID]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No notifications updated']);
    }
    exit;
} elseif (isset($_POST['mark_all'])) {
    // Mark all notifications as read
    $stmt = $conn->prepare("UPDATE Notifications SET IsRead = 1 WHERE UserID = ?");
    $stmt->execute([$userID]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No notifications updated']);
    }
    exit;
}
?>