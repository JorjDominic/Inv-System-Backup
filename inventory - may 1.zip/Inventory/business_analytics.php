<?php
session_start();
require('config/database.php');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Check if user is logged in and is an owner
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 1) {
  header('Location: index.php');
  exit;
}
session_regenerate_id(true);

// Get current date and time
$currentDate = date('Y-m-d');
$currentMonth = date('m');
$currentYear = date('Y');
$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

// Default date range (current month)
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : $firstDayOfMonth;
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : $currentDate;

// Calculate gross revenue for selected period
$grossRevenueQuery = "SELECT SUM(TotalAmount) as GrossRevenue 
                   FROM Receipts 
                   WHERE DateIssued BETWEEN ? AND ?";
$grossRevenueStmt = $conn->prepare($grossRevenueQuery);
$grossRevenueStmt->execute([$startDate, $endDate]);
$grossRevenue = $grossRevenueStmt->fetch(PDO::FETCH_ASSOC)['GrossRevenue'] ?? 0;

// Fix the refunds query to ensure all refunds are captured
$refundsQuery = "SELECT 
               SUM(od.Price * ri.QuantityRefunded) as TotalRefunds,
               SUM(CASE WHEN ri.ItemCondition = 'PRISTINE' THEN od.Price * ri.QuantityRefunded ELSE 0 END) as PristineRefunds,
               SUM(CASE WHEN ri.ItemCondition = 'DAMAGED' THEN od.Price * ri.QuantityRefunded ELSE 0 END) as DamagedRefunds
               FROM RefundedItems ri
               JOIN OrderDetails od ON ri.OrderID = od.OrderID AND ri.ProductID = od.ProductID
               JOIN Orders o ON ri.OrderID = o.OrderID
               WHERE (ri.RefundedAt BETWEEN ? AND ? OR o.OrderDate BETWEEN ? AND ?)";
$refundsStmt = $conn->prepare($refundsQuery);
$refundsStmt->execute([$startDate, $endDate, $startDate, $endDate]);
$refundData = $refundsStmt->fetch(PDO::FETCH_ASSOC);

$totalRefunds = $refundData['TotalRefunds'] ?? 0;
$pristineRefunds = $refundData['PristineRefunds'] ?? 0;
$damagedRefunds = $refundData['DamagedRefunds'] ?? 0;

// Calculate net revenue (gross revenue minus refunds)
$netRevenue = $grossRevenue - $totalRefunds;

// Calculate regular expenses for selected period
$regularExpensesQuery = "SELECT SUM(Amount) as RegularExpenses 
                      FROM Expenses 
                      WHERE Date BETWEEN ? AND ?";
$regularExpensesStmt = $conn->prepare($regularExpensesQuery);
$regularExpensesStmt->execute([$startDate, $endDate]);
$regularExpenses = $regularExpensesStmt->fetch(PDO::FETCH_ASSOC)['RegularExpenses'] ?? 0;

// Calculate damaged items cost for selected period
$damagedItemsQuery = "SELECT SUM(d.Quantity * p.PurchasePrice) as DamagedCost
                  FROM DamagedItems d
                  JOIN Product p ON d.ProductID = p.ProductID
                  WHERE d.ReportedAt BETWEEN ? AND ?";
$damagedItemsStmt = $conn->prepare($damagedItemsQuery);
$damagedItemsStmt->execute([$startDate, $endDate]);
$damagedItemsCost = $damagedItemsStmt->fetch(PDO::FETCH_ASSOC)['DamagedCost'] ?? 0;

// Replace the existing expired items query with this updated version
$expiredItemsQuery = "SELECT SUM(LossValue) as ExpiredCost
                   FROM ExpiredItems
                   WHERE ExpiryDate BETWEEN ? AND CURRENT_DATE";
$expiredItemsStmt = $conn->prepare($expiredItemsQuery);
$expiredItemsStmt->execute([$firstDayOfMonth]);
$expiredItemsCost = $expiredItemsStmt->fetch(PDO::FETCH_ASSOC)['ExpiredCost'] ?? 0;


// Add debugging output to verify the expired items cost
echo "<!-- DEBUG: Expired Items Cost: " . $expiredItemsCost . " -->";

// Make sure the total expenses calculation includes the expired items cost
$totalExpenses = $regularExpenses + $damagedItemsCost + $expiredItemsCost + $damagedRefunds;

// Calculate net profit (net revenue - total expenses)
$netProfit = $netRevenue - $totalExpenses;

// Update the profit margin calculation to use the correct formula
$profitMargin = $netRevenue > 0 ? ($netProfit / $netRevenue) * 100 : 0;

// Get expense breakdown by category
$expenseCategoriesQuery = "SELECT Category, SUM(Amount) as TotalAmount
                        FROM Expenses
                        WHERE Date BETWEEN ? AND ?
                        GROUP BY Category
                        ORDER BY TotalAmount DESC";
$expenseCategoriesStmt = $conn->prepare($expenseCategoriesQuery);
$expenseCategoriesStmt->execute([$startDate, $endDate]);
$expenseCategories = $expenseCategoriesStmt->fetchAll(PDO::FETCH_ASSOC);

// Get monthly sales trend for the past 12 months
$monthlySalesQuery = "SELECT 
                    DATE_FORMAT(DateIssued, '%Y-%m') as Month,
                    SUM(TotalAmount) as Revenue
                    FROM Receipts
                    WHERE DateIssued >= DATE_SUB(?, INTERVAL 12 MONTH)
                    GROUP BY DATE_FORMAT(DateIssued, '%Y-%m')
                    ORDER BY Month";
$monthlySalesStmt = $conn->prepare($monthlySalesQuery);
$monthlySalesStmt->execute([$endDate]);
$monthlySales = $monthlySalesStmt->fetchAll(PDO::FETCH_ASSOC);

// Format monthly sales data for chart
$monthLabels = [];
$revenueData = [];
foreach ($monthlySales as $month) {
    $monthLabels[] = date('M Y', strtotime($month['Month'] . '-01'));
    $revenueData[] = $month['Revenue'];
}

// Get top selling products
$topProductsQuery = "SELECT p.ProductName, SUM(od.Quantity) as TotalSold, SUM(od.Price * od.Quantity) as Revenue
                  FROM OrderDetails od
                  JOIN Product p ON od.ProductID = p.ProductID
                  JOIN Orders o ON od.OrderID = o.OrderID
                  WHERE o.OrderDate BETWEEN ? AND ?
                  GROUP BY p.ProductID
                  ORDER BY TotalSold DESC
                  LIMIT 10";
$topProductsStmt = $conn->prepare($topProductsQuery);
$topProductsStmt->execute([$startDate, $endDate]);
$topProducts = $topProductsStmt->fetchAll(PDO::FETCH_ASSOC);

// Format top products data for chart
$productLabels = [];
$productSales = [];
foreach ($topProducts as $product) {
    $productLabels[] = $product['ProductName'];
    $productSales[] = $product['TotalSold'];
}

// Get payment method distribution
$paymentMethodsQuery = "SELECT pm.MethodName, COUNT(r.ReceiptID) as TransactionCount, SUM(r.TotalAmount) as TotalAmount
                     FROM Receipts r
                     JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
                     WHERE r.DateIssued BETWEEN ? AND ?
                     GROUP BY pm.PaymentMethodID
                     ORDER BY TotalAmount DESC";
$paymentMethodsStmt = $conn->prepare($paymentMethodsQuery);
$paymentMethodsStmt->execute([$startDate, $endDate]);
$paymentMethods = $paymentMethodsStmt->fetchAll(PDO::FETCH_ASSOC);

// Format payment methods data for chart
$methodLabels = [];
$methodAmounts = [];
foreach ($paymentMethods as $method) {
    $methodLabels[] = $method['MethodName'];
    $methodAmounts[] = $method['TotalAmount'];
}

// Get daily sales for the selected period
$dailySalesQuery = "SELECT DATE(DateIssued) as SaleDate, SUM(TotalAmount) as DailyRevenue
                 FROM Receipts
                 WHERE DateIssued BETWEEN ? AND ?
                 GROUP BY DATE(DateIssued)
                 ORDER BY SaleDate";
$dailySalesStmt = $conn->prepare($dailySalesQuery);
$dailySalesStmt->execute([$startDate, $endDate]);
$dailySales = $dailySalesStmt->fetchAll(PDO::FETCH_ASSOC);

// Format daily sales data for chart
$dateLabels = [];
$dailyRevenue = [];
foreach ($dailySales as $day) {
    $dateLabels[] = date('M d', strtotime($day['SaleDate']));
    $dailyRevenue[] = $day['DailyRevenue'];
}

// Calculate average transaction value
$avgTransactionQuery = "SELECT AVG(TotalAmount) as AvgTransaction
                     FROM Receipts
                     WHERE DateIssued BETWEEN ? AND ?";
$avgTransactionStmt = $conn->prepare($avgTransactionQuery);
$avgTransactionStmt->execute([$startDate, $endDate]);
$avgTransaction = $avgTransactionStmt->fetch(PDO::FETCH_ASSOC)['AvgTransaction'] ?? 0;

// Get total transaction count
$transactionCountQuery = "SELECT COUNT(*) as TransactionCount
                       FROM Receipts
                       WHERE DateIssued BETWEEN ? AND ?";
$transactionCountStmt = $conn->prepare($transactionCountQuery);
$transactionCountStmt->execute([$startDate, $endDate]);
$transactionCount = $transactionCountStmt->fetch(PDO::FETCH_ASSOC)['TransactionCount'] ?? 0;

// Get sales by hour of day
$hourlyDistributionQuery = "SELECT HOUR(DateIssued) as Hour, COUNT(*) as TransactionCount, SUM(TotalAmount) as Revenue
                         FROM Receipts
                         WHERE DateIssued BETWEEN ? AND ?
                         GROUP BY HOUR(DateIssued)
                         ORDER BY Hour";
$hourlyDistributionStmt = $conn->prepare($hourlyDistributionQuery);
$hourlyDistributionStmt->execute([$startDate, $endDate]);
$hourlyDistribution = $hourlyDistributionStmt->fetchAll(PDO::FETCH_ASSOC);

// Format hourly distribution data for chart
$hourLabels = [];
$hourlyRevenue = [];
foreach ($hourlyDistribution as $hour) {
    $hourLabels[] = sprintf('%02d:00', $hour['Hour']);
    $hourlyRevenue[] = $hour['Revenue'];
}

// Get sales by day of week
$weekdayDistributionQuery = "SELECT WEEKDAY(DateIssued) as Weekday, COUNT(*) as TransactionCount, SUM(TotalAmount) as Revenue
                          FROM Receipts
                          WHERE DateIssued BETWEEN ? AND ?
                          GROUP BY WEEKDAY(DateIssued)
                          ORDER BY Weekday";
$weekdayDistributionStmt = $conn->prepare($weekdayDistributionQuery);
$weekdayDistributionStmt->execute([$startDate, $endDate]);
$weekdayDistribution = $weekdayDistributionStmt->fetchAll(PDO::FETCH_ASSOC);

// Format weekday distribution data for chart
$weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
$weekdayLabels = array_fill(0, 7, 0); // Initialize with zeros
$weekdayRevenue = array_fill(0, 7, 0); // Initialize with zeros

foreach ($weekdayDistribution as $day) {
    $weekdayLabels[$day['Weekday']] = $weekdays[$day['Weekday']];
    $weekdayRevenue[$day['Weekday']] = $day['Revenue'];
}

// Remove any remaining zeros from the arrays
$weekdayLabels = array_filter($weekdayLabels, function($value) { return $value !== 0; });
$weekdayRevenue = array_values(array_filter($weekdayRevenue, function($key) use ($weekdayLabels) { 
    return array_key_exists($key, $weekdayLabels); 
}, ARRAY_FILTER_USE_KEY));
$weekdayLabels = array_values($weekdayLabels);

// Get inventory value and turnover
$inventoryValueQuery = "SELECT SUM(i.Quantity * p.PurchasePrice) as TotalValue
                     FROM Inventory i
                     JOIN Product p ON i.ProductID = p.ProductID";
$inventoryValueStmt = $conn->prepare($inventoryValueQuery);
$inventoryValueStmt->execute();
$inventoryValue = $inventoryValueStmt->fetch(PDO::FETCH_ASSOC)['TotalValue'] ?? 0;

// Calculate inventory turnover (COGS / Average Inventory Value)
// For simplicity, we'll use the current inventory value as the average
$cogsQuery = "SELECT SUM(od.Quantity * p.PurchasePrice) as COGS
           FROM OrderDetails od
           JOIN Product p ON od.ProductID = p.ProductID
           JOIN Orders o ON od.OrderID = o.OrderID
           WHERE o.OrderDate BETWEEN ? AND ?";
$cogsStmt = $conn->prepare($cogsQuery);
$cogsStmt->execute([$startDate, $endDate]);
$cogs = $cogsStmt->fetch(PDO::FETCH_ASSOC)['COGS'] ?? 0;

$inventoryTurnover = $inventoryValue > 0 ? $cogs / $inventoryValue : 0;

// Calculate days of inventory on hand
$daysOfInventory = $inventoryTurnover > 0 ? 
    round((strtotime($endDate) - strtotime($startDate)) / 86400 / $inventoryTurnover) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Business Analytics - Adriana's Marketing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sidebar.css">
    <link rel="stylesheet" href="css/inventory.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .analytics-container {
            padding: 20px;
        }
        
        .date-filter {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: var(--text-dark);
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius-sm);
            font-family: 'Poppins', sans-serif;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--border-radius-sm);
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .dashboard-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            padding: 20px;
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-card h3 {
            margin-top: 0;
            color: var(--text-dark);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .metric-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .metric-card {
            background-color: #f8f9fa;
            border-radius: var(--border-radius-sm);
            padding: 15px;
            text-align: center;
        }
        
        .metric-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .metric-label {
            font-size: 0.9rem;
            color: var(--text-medium);
        }
        
        .positive {
            color: #28a745;
        }
        
        .negative {
            color: #dc3545;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            margin-top: 15px;
        }
        
        .chart-container.half-height {
            height: 200px;
        }
        
        .summary-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .summary-table th, .summary-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .summary-table th {
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .summary-table tr:last-child td {
            border-bottom: none;
        }
        
        .card-footer {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            text-align: right;
            font-size: 0.9rem;
        }
        
        .card-footer a {
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .card-footer a:hover {
            text-decoration: underline;
        }
        
        .tab-container {
            margin-bottom: 20px;
        }
        
        .tabs {
            display: flex;
            overflow-x: auto;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            font-weight: 500;
            white-space: nowrap;
        }
        
        .tab.active {
            border-bottom-color: var(--primary-color);
            color: var(--primary-color);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        @media (max-width: 768px) {
            .filter-form {
                flex-direction: column;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .metric-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        .damaged-items-link {
    font-size: 1rem;
    color: #3498db;
    font-weight: 600;
    text-decoration: none;
    display: block;
}

.damaged-items-link:hover {
    text-decoration: underline;
    color: #2980b9;
}
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="main-content-wrapper">
        <main class="content">
            <div class="analytics-container">
                <h1>Business Analytics</h1>
                <a href="reports.php" class="damaged-items-link">View Business Analytics<<</a>
                <!-- Date Filter -->
                <div class="date-filter">
                    <form method="GET" class="filter-form">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" id="start_date" name="start_date" class="form-control" 
                                   value="<?= $startDate ?>" max="<?= $currentDate ?>">
                        </div>
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" id="end_date" name="end_date" class="form-control" 
                                   value="<?= $endDate ?>" max="<?= $currentDate ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Apply Filter</button>
                    </form>
                </div>
                
                <!-- Tabs Navigation -->
                <div class="tab-container">
                    <div class="tabs">
                        <div class="tab active" onclick="openTab('financial')">Financial Overview</div>
                       
                      
                        <div class="tab" onclick="openTab('expenses')">Expense Analysis</div>
                        
                    </div>
                    
                    <!-- Financial Overview Tab -->
                    <div id="financial" class="tab-content active">
                        <div class="dashboard-grid">
                            <!-- Key Financial Metrics -->
                            <div class="dashboard-card">
                                <h3>Key Financial Metrics</h3>
                                <div class="metric-grid">
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($grossRevenue, 2) ?></div>
                                        <div class="metric-label">Gross Revenue</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($netRevenue, 2) ?></div>
                                        <div class="metric-label">Net Revenue</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($totalExpenses, 2) ?></div>
                                        <div class="metric-label">Total Expenses</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value <?= $netProfit >= 0 ? 'positive' : 'negative' ?>">
                                            ₱<?= number_format($netProfit, 2) ?>
                                        </div>
                                        <div class="metric-label">Net Profit</div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="reports.php?report_type=profit&start_date=<?= $startDate ?>&end_date=<?= $endDate ?>">View Detailed Profit & Loss Report</a>
                                </div>
                            </div>
                            
                            <!-- Profit & Loss Summary -->
                            <div class="dashboard-card">
                                <h3>Profit & Loss Summary</h3>
                                <table class="summary-table">
                                    <tr>
                                        <td>Gross Revenue</td>
                                        <td class="positive">₱<?= number_format($grossRevenue, 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td>Total Refunds</td>
                                        <td class="negative">₱<?= number_format($totalRefunds, 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Net Revenue</strong></td>
                                        <td class="positive"><strong>₱<?= number_format($netRevenue, 2) ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Regular Expenses</td>
                                        <td class="negative">₱<?= number_format($regularExpenses, 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td>Damaged Inventory</td>
                                        <td class="negative">₱<?= number_format($damagedItemsCost, 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td>Expired Inventory</td>
                                        <td class="negative">₱<?= number_format($expiredItemsCost, 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td>Damaged Refunds</td>
                                        <td class="negative">₱<?= number_format($damagedRefunds, 2) ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Total Expenses</strong></td>
                                        <td class="negative"><strong>₱<?= number_format($totalExpenses, 2) ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Net Profit</strong></td>
                                        <td class="<?= $netProfit >= 0 ? 'positive' : 'negative' ?>">
                                            <strong>₱<?= number_format($netProfit, 2) ?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Profit Margin</td>
                                        <td class="<?= $profitMargin >= 0 ? 'positive' : 'negative' ?>">
                                            <?= number_format($profitMargin, 2) ?>%
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            
                            <!-- Monthly Revenue Trend -->
                            <div class="dashboard-card">
                                <h3>Monthly Revenue Trend</h3>
                                <div class="chart-container">
                                    <canvas id="monthlySalesChart"></canvas>
                                </div>
                                <div class="card-footer">
                                    <a href="reports.php?report_type=sales&start_date=<?= date('Y-m-d', strtotime('-12 months', strtotime($endDate))) ?>&end_date=<?= $endDate ?>">View Detailed Sales Report</a>
                                </div>
                            </div>
                            
                            <!-- Expense Breakdown -->
                            <div class="dashboard-card">
                                <h3>Expense Breakdown</h3>
                                <div class="chart-container">
                                    <canvas id="expenseBreakdownChart"></canvas>
                                </div>
                                <div class="card-footer">
                                    <a href="expenses.php?start_date=<?= $startDate ?>&end_date=<?= $endDate ?>">View Detailed Expenses</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Sales Analysis Tab -->
                    <div id="sales" class="tab-content">
                        <div class="dashboard-grid">
                            <!-- Sales Metrics -->
                            <div class="dashboard-card">
                                <h3>Sales Metrics</h3>
                                <div class="metric-grid">
                                    <div class="metric-card">
                                        <div class="metric-value"><?= number_format($transactionCount) ?></div>
                                        <div class="metric-label">Total Transactions</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($avgTransaction, 2) ?></div>
                                        <div class="metric-label">Avg. Transaction Value</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= $transactionCount > 0 ? number_format($grossRevenue / $transactionCount, 2) : '0.00' ?></div>
                                        <div class="metric-label">Avg. Daily Sales</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value"><?= number_format($totalRefunds / $grossRevenue * 100, 2) ?>%</div>
                                        <div class="metric-label">Refund Rate</div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Daily Sales Trend -->
                            <div class="dashboard-card">
                                <h3>Daily Sales Trend</h3>
                                <div class="chart-container">
                                    <canvas id="dailySalesChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Payment Methods -->
                            <div class="dashboard-card">
                                <h3>Payment Methods</h3>
                                <div class="chart-container">
                                    <canvas id="paymentMethodsChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Sales by Hour -->
                            <div class="dashboard-card">
                                <h3>Sales by Hour of Day</h3>
                                <div class="chart-container">
                                    <canvas id="hourlySalesChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Sales by Day of Week -->
                            <div class="dashboard-card">
                                <h3>Sales by Day of Week</h3>
                                <div class="chart-container">
                                    <canvas id="weekdaySalesChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product Performance Tab -->
                    <div id="products" class="tab-content">
                        <div class="dashboard-grid">
                            <!-- Top Selling Products -->
                            <div class="dashboard-card">
                                <h3>Top Selling Products</h3>
                                <div class="chart-container">
                                    <canvas id="topProductsChart"></canvas>
                                </div>
                                <div class="card-footer">
                                    <a href="reports.php?report_type=inventory&start_date=<?= $startDate ?>&end_date=<?= $endDate ?>">View Inventory Report</a>
                                </div>
                            </div>
                            
                            <!-- Top Products Table -->
                            <div class="dashboard-card">
                                <h3>Top Products by Revenue</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Units Sold</th>
                                            <th>Revenue</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($topProducts as $product): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($product['ProductName']) ?></td>
                                                <td><?= number_format($product['TotalSold']) ?></td>
                                                <td>₱<?= number_format($product['Revenue'], 2) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Product Categories Performance -->
                            <div class="dashboard-card">
                                <h3>Product Categories Performance</h3>
                                <div class="chart-container">
                                    <canvas id="categoriesChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Product Profit Margin Analysis -->
                            <div class="dashboard-card">
                                <h3>Product Profit Margin Analysis</h3>
                                <div class="chart-container">
                                    <canvas id="profitMarginChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Expense Analysis Tab -->
                    <div id="expenses" class="tab-content">
                        <div class="dashboard-grid">
                            <!-- Expense Summary -->
                            <div class="dashboard-card">
                                <h3>Expense Summary</h3>
                                <div class="metric-grid">
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($regularExpenses, 2) ?></div>
                                        <div class="metric-label">Regular Expenses</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($damagedItemsCost, 2) ?></div>
                                        <div class="metric-label">Damaged Inventory</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($expiredItemsCost, 2) ?></div>
                                        <div class="metric-label">Expired Inventory</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($damagedRefunds, 2) ?></div>
                                        <div class="metric-label">Damaged Refunds</div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="expenses.php?start_date=<?= $startDate ?>&end_date=<?= $endDate ?>">View Detailed Expenses</a>
                                </div>
                            </div>
                            
                            <!-- Expense Categories -->
                            <div class="dashboard-card">
                                <h3>Expense Categories</h3>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Amount</th>
                                            <th>% of Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($expenseCategories as $category): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($category['Category']) ?></td>
                                                <td>₱<?= number_format($category['TotalAmount'], 2) ?></td>
                                                <td><?= number_format($category['TotalAmount'] / $regularExpenses * 100, 2) ?>%</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Expense Trend -->
                            <div class="dashboard-card">
                                <h3>Monthly Expense Trend</h3>
                                <div class="chart-container">
                                    <canvas id="expenseTrendChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Expense to Revenue Ratio -->
                            <div class="dashboard-card">
                                <h3>Expense to Revenue Ratio</h3>
                                <div class="chart-container half-height">
                                    <canvas id="expenseRatioChart"></canvas>
                                </div>
                                <div class="card-footer">
                                    <p>Current Expense Ratio: <?= number_format($totalExpenses / $grossRevenue * 100, 2) ?>% of Revenue</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Inventory Metrics Tab -->
                    <div id="inventory" class="tab-content">
                        <div class="dashboard-grid">
                            <!-- Inventory Summary -->
                            <div class="dashboard-card">
                                <h3>Inventory Summary</h3>
                                <div class="metric-grid">
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($inventoryValue, 2) ?></div>
                                        <div class="metric-label">Total Inventory Value</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value"><?= number_format($inventoryTurnover, 2) ?>x</div>
                                        <div class="metric-label">Inventory Turnover</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value"><?= $daysOfInventory ?> days</div>
                                        <div class="metric-label">Days of Inventory</div>
                                    </div>
                                    <div class="metric-card">
                                        <div class="metric-value">₱<?= number_format($expiredItemsCost + $damagedItemsCost, 2) ?></div>
                                        <div class="metric-label">Inventory Loss</div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <a href="reports.php?report_type=inventory">View Inventory Report</a>
                                </div>
                            </div>
                            
                            <!-- Low Stock Items -->
                            <div class="dashboard-card">
                                <h3>Low Stock Items</h3>
                                <div class="chart-container">
                                    <canvas id="lowStockChart"></canvas>
                                </div>
                                <div class="card-footer">
                                    <a href="reports.php?report_type=low_stock">View Low Stock Report</a>
                                </div>
                            </div>
                            
                            <!-- Inventory Loss Analysis -->
                            <div class="dashboard-card">
                                <h3>Inventory Loss Analysis</h3>
                                <div class="chart-container">
                                    <canvas id="inventoryLossChart"></canvas>
                                </div>
                            </div>
                            
                            <!-- Inventory Age Distribution -->
                            <div class="dashboard-card">
                                <h3>Inventory Age Distribution</h3>
                                <div class="chart-container">
                                    <canvas id="inventoryAgeChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Function to open tab
        function openTab(tabName) {
            // Hide all tab contents
            const tabContents = document.querySelectorAll('.tab-content');
            tabContents.forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active class from all tabs
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show the selected tab content
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to the clicked tab
            event.currentTarget.classList.add('active');
        }
        
        // Chart.js Configuration
        Chart.defaults.font.family = "'Poppins', sans-serif";
        Chart.defaults.color = '#666';
        
        // Monthly Sales Chart
        const monthlySalesCtx = document.getElementById('monthlySalesChart').getContext('2d');
        new Chart(monthlySalesCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode($monthLabels) ?>,
                datasets: [{
                    label: 'Monthly Revenue',
                    data: <?= json_encode($revenueData) ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₱' + context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Expense Breakdown Chart
        const expenseBreakdownCtx = document.getElementById('expenseBreakdownChart').getContext('2d');
        new Chart(expenseBreakdownCtx, {
            type: 'pie',
            data: {
                labels: ['Regular Expenses', 'Damaged Inventory', 'Expired Inventory', 'Damaged Refunds'],
                datasets: [{
                    data: [
                        <?= $regularExpenses ?>, 
                        <?= $damagedItemsCost ?>, 
                        <?= $expiredItemsCost ?>, 
                        <?= $damagedRefunds ?>
                    ],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 159, 64, 0.7)',
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(153, 102, 255, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                                const percentage = (context.raw / <?= $totalExpenses ?> * 100).toFixed(1);
                                return `${context.label}: ₱${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Daily Sales Chart
        const dailySalesCtx = document.getElementById('dailySalesChart').getContext('2d');
        new Chart(dailySalesCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($dateLabels) ?>,
                datasets: [{
                    label: 'Daily Revenue',
                    data: <?= json_encode($dailyRevenue) ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.7)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₱' + context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Payment Methods Chart
        const paymentMethodsCtx = document.getElementById('paymentMethodsChart').getContext('2d');
        new Chart(paymentMethodsCtx, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode($methodLabels) ?>,
                datasets: [{
                    data: <?= json_encode($methodAmounts) ?>,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(255, 206, 86, 0.7)',
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(153, 102, 255, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                                const percentage = (context.raw / <?= $grossRevenue ?> * 100).toFixed(1);
                                return `${context.label}: ₱${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Hourly Sales Chart
        const hourlySalesCtx = document.getElementById('hourlySalesChart').getContext('2d');
        new Chart(hourlySalesCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($hourLabels) ?>,
                datasets: [{
                    label: 'Revenue by Hour',
                    data: <?= json_encode($hourlyRevenue) ?>,
                    backgroundColor: 'rgba(153, 102, 255, 0.7)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Weekday Sales Chart
        const weekdaySalesCtx = document.getElementById('weekdaySalesChart').getContext('2d');
        new Chart(weekdaySalesCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($weekdayLabels) ?>,
                datasets: [{
                    label: 'Revenue by Day of Week',
                    data: <?= json_encode($weekdayRevenue) ?>,
                    backgroundColor: 'rgba(255, 159, 64, 0.7)',
                    borderColor: 'rgba(255, 159, 64, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Top Products Chart
        const topProductsCtx = document.getElementById('topProductsChart').getContext('2d');
        new Chart(topProductsCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($productLabels) ?>,
                datasets: [{
                    label: 'Units Sold',
                    data: <?= json_encode($productSales) ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.7)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // Initialize other charts as needed
        // These are placeholders for charts that would require additional data queries
        
        // Categories Chart placeholder
        const categoriesCtx = document.getElementById('categoriesChart').getContext('2d');
        new Chart(categoriesCtx, {
            type: 'pie',
            data: {
                labels: ['Category 1', 'Category 2', 'Category 3', 'Category 4', 'Category 5'],
                datasets: [{
                    data: [30, 25, 20, 15, 10],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 206, 86, 0.7)',
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(153, 102, 255, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        // Profit Margin Chart placeholder
        const profitMarginCtx = document.getElementById('profitMarginChart').getContext('2d');
        new Chart(profitMarginCtx, {
            type: 'bar',
            data: {
                labels: ['Product 1', 'Product 2', 'Product 3', 'Product 4', 'Product 5'],
                datasets: [{
                    label: 'Profit Margin %',
                    data: [45, 38, 32, 28, 25],
                    backgroundColor: 'rgba(75, 192, 192, 0.7)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
        
        // Expense Trend Chart placeholder
        const expenseTrendCtx = document.getElementById('expenseTrendChart').getContext('2d');
        new Chart(expenseTrendCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Monthly Expenses',
                    data: [12000, 15000, 13500, 14200, 16000, 15500],
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 2,
                    tension: 0.1,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Expense Ratio Chart placeholder
        const expenseRatioCtx = document.getElementById('expenseRatioChart').getContext('2d');
        new Chart(expenseRatioCtx, {
            type: 'bar',
            data: {
                labels: ['Revenue', 'Expenses'],
                datasets: [{
                    label: 'Amount',
                    data: [<?= $grossRevenue ?>, <?= $totalExpenses ?>],
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(255, 99, 132, 0.7)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₱' + context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString('en-PH');
                            }
                        }
                    }
                }
            }
        });
        
        // Low Stock Chart placeholder
        const lowStockCtx = document.getElementById('lowStockChart').getContext('2d');
        new Chart(lowStockCtx, {
            type: 'bar',
            data: {
                labels: ['Product A', 'Product B', 'Product C', 'Product D', 'Product E'],
                datasets: [{
                    label: 'Current Stock',
                    data: [5, 7, 3, 8, 4],
                    backgroundColor: 'rgba(255, 159, 64, 0.7)',
                    borderColor: 'rgba(255, 159, 64, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // Inventory Loss Chart placeholder
        const inventoryLossCtx = document.getElementById('inventoryLossChart').getContext('2d');
        new Chart(inventoryLossCtx, {
            type: 'pie',
            data: {
                labels: ['Expired Items', 'Damaged Items'],
                datasets: [{
                    data: [<?= $expiredItemsCost ?>, <?= $damagedItemsCost ?>],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(255, 159, 64, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                });
                                const total = <?= $expiredItemsCost + $damagedItemsCost ?>;
                                const percentage = total > 0 ? (context.raw / total * 100).toFixed(1) : 0;
                                return `${context.label}: ₱${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Inventory Age Chart placeholder
        const inventoryAgeCtx = document.getElementById('inventoryAgeChart').getContext('2d');
        new Chart(inventoryAgeCtx, {
            type: 'doughnut',
            data: {
                labels: ['0-30 days', '31-60 days', '61-90 days', '90+ days'],
                datasets: [{
                    data: [60, 25, 10, 5],
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(255, 206, 86, 0.7)',
                        'rgba(255, 159, 64, 0.7)',
                        'rgba(255, 99, 132, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script>
</body>
</html>
