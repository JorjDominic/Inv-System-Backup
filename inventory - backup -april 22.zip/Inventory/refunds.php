
<?php
session_start();
require('config/database.php');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
  header("Location: index.php");
  exit;
}

try {
  $stmt = $conn->prepare("
    SELECT 
      o.OrderID,
      p.ProductName,
      od.ProductID,
      od.Quantity AS QtyOrdered,
      COALESCE(SUM(ri.QuantityRefunded), 0) AS QtyRefunded,
      MAX(ri.RefundedAt) AS LastRefundDate
    FROM OrderDetails od
    JOIN Orders o ON od.OrderID = o.OrderID
    JOIN Product p ON od.ProductID = p.ProductID
    LEFT JOIN RefundedItems ri ON od.OrderID = ri.OrderID AND od.ProductID = ri.ProductID
    GROUP BY od.OrderID, od.ProductID, p.ProductName, od.Quantity
    ORDER BY o.OrderID DESC, p.ProductName
  ");
  $stmt->execute();
  $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  die("❌ Error loading refund data: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Refunded Items</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>

<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <h1>Refunded Items Overview</h1>
      <table class="table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Product Name</th>
            <th>Qty Ordered</th>
            <th>Qty Refunded</th>
            <th>Refundable Qty</th>
            <th>Last Refund Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $row): ?>
            <?php
              $refundable = $row['QtyOrdered'] - $row['QtyRefunded'];
              $disabled = $refundable <= 0 ? 'disabled' : '';
              $status = $refundable <= 0 ? 'Fully Refunded' : 'Refund';
            ?>
            <tr>
              <td><?= htmlspecialchars($row['OrderID']) ?></td>
              <td><?= htmlspecialchars($row['ProductName']) ?></td>
              <td><?= $row['QtyOrdered'] ?></td>
              <td><?= $row['QtyRefunded'] ?></td>
              <td><?= $refundable ?></td>
              <td><?= $row['LastRefundDate'] ?? '—' ?></td>
              <td>
                <form action="process_refund.php" method="POST" style="display:inline;">
                  <input type="hidden" name="order_id" value="<?= $row['OrderID'] ?>">
                  <input type="hidden" name="product_id" value="<?= $row['ProductID'] ?>">
                  <input type="number" name="refund_quantity" min="1" max="<?= $refundable ?>" value="1" <?= $disabled ?> required>
                  <select name="item_condition" <?= $disabled ?> required>
                    <option value="PRISTINE">Pristine</option>
                    <option value="DAMAGED">Damaged</option>
                  </select>
                  <button type="submit" class="btn btn-danger" <?= $disabled ?>><?= $status ?></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
