<?php
session_start();
require_once 'config/database.php';

try {
  $stmt = $conn->prepare("
  SELECT 
    l.Timestamp,
    u.Username AS User,
    l.ProductNameSnapshot AS Product,
    l.Action,
    l.QuantityChanged,
    l.Remarks
  FROM InventoryLogs l
  LEFT JOIN Users u ON l.UserID = u.UserID
  ORDER BY l.Timestamp DESC
");
  $stmt->execute();
  $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  die("❌ Error fetching logs: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Inventory Logs</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>

<div class="main-content-wrapper">
  <main class="content">
    <div class="container">
      <h1>Inventory Logs</h1>

      <table class="table">
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>User</th>
            <th>Product</th>
            <th>Action</th>
            <th>Qty Changed</th>
            <th>Remarks</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($logs): ?>
            <?php foreach ($logs as $log): ?>
              <tr>
                <td><?= htmlspecialchars($log['Timestamp']) ?></td>
                <td><?= htmlspecialchars($log['User'] ?? '—') ?></td>
                <td><?= htmlspecialchars($log['Product'] ?? '—') ?></td>
                <td><?= htmlspecialchars($log['Action']) ?></td>
                <td><?= htmlspecialchars($log['QuantityChanged']) ?></td>
                <td><?= htmlspecialchars($log['Remarks']) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="6">No logs available.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
