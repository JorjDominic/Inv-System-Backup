<?php
session_start();
require_once 'config/database.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName    = $_POST['product_name'];
    $categoryID     = $_POST['category_id'];
    $quantity       = $_POST['quantity'];
    $purchasePrice  = $_POST['purchase_price'];
    $sellingPrice   = $_POST['selling_price'];
    $dateReceived   = $_POST['date_received'];
    $expiryDate     = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;

    $userID = $_SESSION['user_id'];
    $username = $_SESSION['user_name'];  // For snapshot
    $logTime = date('Y-m-d H:i:s');

    try {
        $conn->beginTransaction();

        // ✅ Step 1: Check if product already exists
        $checkStmt = $conn->prepare("SELECT ProductID FROM Product WHERE ProductName = ? AND CategoryID = ?");
        $checkStmt->execute([$productName, $categoryID]);
        $product = $checkStmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            $productID = $product['ProductID'];
        } else {
            $productStmt = $conn->prepare("INSERT INTO Product (ProductName, CategoryID, PurchasePrice, SellingPrice)
                                           VALUES (?, ?, ?, ?)");
            $productStmt->execute([$productName, $categoryID, $purchasePrice, $sellingPrice]);
            $productID = $conn->lastInsertId();
        }

        // ✅ Step 2: Insert stock into Inventory
        $inventoryStmt = $conn->prepare("INSERT INTO Inventory (ProductID, Quantity, DateReceived, ExpiryDate)
                                         VALUES (?, ?, ?, ?)");
        $inventoryStmt->execute([$productID, $quantity, $dateReceived, $expiryDate]);
        $inventoryID = $conn->lastInsertId();

        // ✅ Step 3: Log inventory action
        $logStmt = $conn->prepare("
        INSERT INTO InventoryLogs (
            UserID, UsernameSnapshot, InventoryID, ProductNameSnapshot,
            Action, QuantityChanged, Remarks, Timestamp
        ) VALUES (?, ?, ?, ?, 'add', ?, ?, ?)
    ");
    
    $remarks = "Added new stock for '$productName'";
    $logStmt->execute([
        $userID,
        $username,
        $inventoryID,
        $productName,
        $quantity,
        $remarks,
        $logTime
    ]);

        $conn->commit();

        header("Location: inventory.php?toast=success&msg=Item added successfully");;
        exit;

    } catch (PDOException $e) {
        $conn->rollBack();
        echo "❌ Error: " . $e->getMessage();
        exit;
    }
}
?>
