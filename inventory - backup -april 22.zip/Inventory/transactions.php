<?php
session_start();
require('config/database.php');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 1 && $_SESSION['role'] != 2)) {
  header("Location: index.php");
  exit;
}

$search = $_GET['search'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

$conditions = [];
$params = [];

try {
  if (!empty($search)) {
    // 🔍 Find OrderIDs by username or product name
    $searchStmt = $conn->prepare("
      SELECT DISTINCT r.OrderID
      FROM Receipts r
      JOIN Orders o ON r.OrderID = o.OrderID
      JOIN Users u ON o.UserID = u.UserID
      JOIN OrderDetails od ON od.OrderID = o.OrderID
      JOIN Product p ON od.ProductID = p.ProductID
      WHERE u.Username LIKE ? OR p.ProductName LIKE ?
    ");
    $searchStmt->execute(["%$search%", "%$search%"]);
    $matchedOrders = $searchStmt->fetchAll(PDO::FETCH_COLUMN);

    if ($matchedOrders) {
      $placeholders = implode(',', array_fill(0, count($matchedOrders), '?'));
      $conditions[] = "r.OrderID IN ($placeholders)";
      $params = array_merge($params, $matchedOrders);
    } else {
      $conditions[] = "1 = 0"; // No matches, force empty result
    }
  }

  if (!empty($startDate)) {
    $conditions[] = "r.DateIssued >= ?";
    $params[] = $startDate;
  }
  if (!empty($endDate)) {
    $conditions[] = "r.DateIssued <= ?";
    $params[] = $endDate;
  }

  $whereClause = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

  $stmt = $conn->prepare("
    SELECT 
      r.ReceiptID,
      r.OrderID,
      r.TotalAmount,
      r.Discount,
      pm.MethodName AS PaymentMethod,
      r.DateIssued,
      u.Username AS ProcessedBy,
      (SELECT SUM(od.Price * od.Quantity) 
       FROM OrderDetails od 
       WHERE od.OrderID = o.OrderID) AS Subtotal
    FROM Receipts r
    JOIN Orders o ON r.OrderID = o.OrderID
    JOIN Users u ON o.UserID = u.UserID
    JOIN PaymentMethods pm ON r.PaymentMethodID = pm.PaymentMethodID
    $whereClause
    GROUP BY r.ReceiptID
    ORDER BY r.DateIssued DESC
  ");
  $stmt->execute($params);
  $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
  die("❌ Error loading transactions: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transaction Records</title>
  <link rel="stylesheet" href="css/sidebar.css">
  <link rel="stylesheet" href="css/inventory.css">
  <link rel="stylesheet" href="css/toast-notifications.css">
  <!-- Toastify CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
  <style>
    .discount-cell {
      color: #e74c3c;
      font-weight: bold;
    }
    .subtotal-cell {
      color: #3498db;
    }
    .transaction-row {
      cursor: pointer;
    }
    .transaction-row:hover {
      background-color: #f5f5f5;
    }
    .item-details-row {
      background-color: #f9f9f9;
    }
    .item-details-content {
      padding: 15px;
    }
    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.4);
    }
    .modal.show {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .modal-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      width: 80%;
      max-width: 500px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    .close:hover {
      color: black;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .form-group label {
      display: block;
      margin-bottom: 5px;
    }
    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 20px;
    }
    #refundItemsTable {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    #refundItemsTable th, #refundItemsTable td {
      padding: 8px;
      border: 1px solid #ddd;
      text-align: left;
    }
    #refundItemsTable th {
      background-color: #f2f2f2;
    }
    .refund-qty-input {
      width: 60px;
    }
    .topcon{
      position: sticky;
      top: 100px;
      background: white;
      z-index: 1000;
      padding: 10px;
      border-bottom: 1px solid #ccc;
    }
    .refund-btn {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 5px 10px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.9rem;
    }
    .refund-btn:hover {
      background-color: #c0392b;
    }
    /* Button Styles */
.btn-export-pdf {
  background-color: #28a745; /* Green background */
  color: white; /* White text */
  font-size: 0.875rem; /* Medium text size */
  padding: 8px 16px; /* Padding around the text */
  border-radius: 5px; /* Rounded corners */
  border: none; /* Remove border */
  cursor: pointer; /* Pointer cursor on hover */
  transition: background-color 0.3s ease, transform 0.3s ease; /* Smooth hover effects */
  text-align: center; /* Center text inside the button */
  display: inline-block; /* Ensure it behaves like a block element, but allows other elements on the same line */
}

.btn-export-pdf:hover {
  background-color: #218838; /* Darker green on hover */
  transform: scale(1.05); /* Slightly enlarge button on hover */
}

.btn-export-pdf:active {
  background-color: #1e7e34; /* Even darker green when clicked */
}

.btn-export-pdf:focus {
  outline: none; /* Remove focus outline */
}

/* Button for small screens */
@media (max-width: 576px) {
  .btn-export-pdf {
    font-size: 0.75rem; /* Smaller font size for small screens */
    padding: 6px 12px; /* Adjust padding */
  }
}
  </style>
</head>

<body>
<?php include 'sidebar.php'; ?>
<?php include 'navbar.php'; ?>

<div class="main-content-wrapper">
  <main class="content">
    <div class="topcon">
      <h1>Transaction Records</h1>

      <form method="GET" class="search-sort-container" style="margin-bottom: 20px;">
        <input type="text" name="search" placeholder="Search by user or product..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        
        <label>From: <input type="date" name="start_date" value="<?= $_GET['start_date'] ?? '' ?>"></label>
        <label>To: <input type="date" name="end_date" value="<?= $_GET['end_date'] ?? '' ?>"></label>
        
        <button type="submit" class="btn btn-primary">Filter</button>
      </form>
    </div>
    
    <div class="container">
      <table class="table">
        <thead>
          <tr>
            <th>Processed By</th>
            <th>Receipt ID</th>
            <th>Order ID</th>
            <th>Subtotal</th>
            <th>Discount</th>
            <th>Total</th>
            <th>Payment Method</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($transactions): ?>
            <?php foreach ($transactions as $row): ?>
              <tr class="transaction-row" data-order-id="<?= $row['OrderID'] ?>">
                <td><?= htmlspecialchars($row['ProcessedBy']) ?></td>
                <td><?= htmlspecialchars($row['ReceiptID']) ?></td>
                <td><?= htmlspecialchars($row['OrderID']) ?></td>
                <td class="subtotal-cell">₱<?= number_format($row['Subtotal'], 2) ?></td>
                <td class="discount-cell">-₱<?= number_format($row['Discount'], 2) ?></td>
                <td>₱<?= number_format($row['TotalAmount'], 2) ?></td>
                <td><?= htmlspecialchars($row['PaymentMethod']) ?></td>
                <td><?= date('M d, Y', strtotime($row['DateIssued'])) ?></td>
                <td>
                  <!-- Export Button -->
                  <a href="generate_receipt.php?order_id=<?= $row['OrderID'] ?>" class="btn-export-pdf" target="_blank">
                    Export 
                  </a>
                </td>
              </tr>
              <tr class="item-details-row" style="display:none;">
                <td colspan="9">
                  <div class="item-details-content">
                    <table class="item-table" style="width:100%">
                      <thead>
                        <tr>
                          <th>Product</th>
                          <th>Price</th>
                          <th>Qty</th>
                          <th>Refunded</th>
                          <th>Subtotal</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody id="items-<?= $row['OrderID'] ?>">
                        <!-- Items will be loaded here -->
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="9">No transactions found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>


<!-- Refund Modal -->
<!-- Replace the refund modal in transactions.php with this -->
<div class="modal" id="refundModal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('refundModal')">&times;</span>
    <h2>Refund Item</h2>
    <form id="refundForm" method="POST" action="process_refund.php">
      <input type="hidden" name="order_id" id="refund_order_id">
      <input type="hidden" name="product_id" id="refund_product_id">

      <p><strong>Product:</strong> <span id="refund_product_name"></span></p>
      <p><strong>Ordered:</strong> <span id="ordered_qty"></span> | <strong>Already Refunded:</strong> <span id="refunded_qty"></span></p>

      <div class="form-group">
        <label for="refund_qty">Quantity to Refund</label>
        <input type="number" id="refund_qty" name="refund_qty" min="1" value="1" required>
      </div>

      <div class="form-group">
        <label for="condition">Condition</label>
        <select name="condition" id="condition" required>
          <option value="">Select</option>
          <option value="PRISTINE">Pristine</option>
          <option value="DAMAGED">Damaged</option>
        </select>
      </div>

      <div class="form-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal('refundModal')">Cancel</button>
        <button onclick="window.location.href='process_refund.php'" class="btn btn-danger">
  Confirm Refund
</button><!-- this button does  work albeit error message -->\
      </div>
    </form>
  </div>
</div>



<!-- Toast container will be created by the JS -->
<script src="js/toast-notifications.js"></script>

<!-- Keep the existing HTML, just replace the script part at the bottom -->

<!-- Toast container will be created by the JS -->
<script src="js/toast-notifications.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  console.log('Page loaded, initializing scripts...');
  
  // Close modal function
  window.closeModal = function(modalId) {
    console.log('Closing modal:', modalId);
    document.getElementById(modalId).classList.remove('show');
  };

  // Toggle item details
  document.querySelectorAll('.transaction-row').forEach(row => {
    row.addEventListener('click', function(e) {
      // Don't toggle if clicking on a button
      if (e.target.tagName === 'BUTTON') return;
      
      const orderId = this.dataset.orderId;
      console.log('Toggling details for order:', orderId);
      const detailsRow = this.nextElementSibling;
      const detailsContainer = detailsRow.querySelector('.item-details-content');

      // Toggle visibility
      if (detailsRow.style.display === 'none') {
        detailsRow.style.display = 'table-row';

        // Fetch items only if not already loaded
        if (!detailsContainer.dataset.loaded) {
          console.log('Loading items for order:', orderId);
          fetch(`get_order_items.php?order_id=${orderId}`)
            .then(res => res.text())
            .then(html => {
              detailsContainer.querySelector('tbody').innerHTML = html;
              detailsContainer.dataset.loaded = true;
              
              // Add event listeners to refund buttons
              detailsContainer.querySelectorAll('.refund-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                  e.preventDefault();
                  e.stopPropagation();
                  const { orderId, productId, orderedQty, refundedQty, productName } = this.dataset;
                  openItemRefundModal(orderId, productId, orderedQty, refundedQty, productName);
                });
              });
            })
            .catch(err => {
              console.error('Error loading items:', err);
              detailsContainer.querySelector('tbody').innerHTML = "<tr><td colspan='5'>❌ Failed to load items.</td></tr>";
            });
        }
      } else {
        detailsRow.style.display = 'none';
      }
    });
  });

  // Open refund modal
  window.openItemRefundModal = function(orderId, productId, orderedQty, refundedQty, productName) {
    console.log('Opening refund modal for:', { orderId, productId, productName });
    
    const maxRefundable = parseInt(orderedQty) - parseInt(refundedQty);
    
    if (maxRefundable <= 0) {
      toast.warning("This item has already been fully refunded.");
      return;
    }

    document.getElementById('refund_order_id').value = orderId;
    document.getElementById('refund_product_id').value = productId;
    document.getElementById('refund_product_name').textContent = productName;
    document.getElementById('ordered_qty').textContent = orderedQty;
    document.getElementById('refunded_qty').textContent = refundedQty;

    const qtyInput = document.getElementById('refund_qty');
    qtyInput.value = 1;
    qtyInput.max = maxRefundable;

    // Show modal
    document.getElementById('refundModal').classList.add('show');
  };

  // Direct form submission handler - this should fix the issue
  const refundForm = document.getElementById('refundForm');
  const submitButton = refundForm ? refundForm.querySelector('button[type="submit"]') : null;
  
  if (submitButton) {
    console.log('Found submit button, attaching click handler');
    
    submitButton.addEventListener('click', function(e) {
      e.preventDefault();
      console.log('Submit button clicked');
      
      // Show loading toast
      toast.info('Processing refund...', 'Please wait');
      
      // Get form data
      const formData = new FormData(refundForm);
      
      // Log form data for debugging
      console.log('Form data:');
      for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
      }
      
      // Send AJAX request
      fetch('process_refund.php', {
        method: 'POST',
        body: formData
      })
      .then(response => {
        console.log('Response status:', response.status);
        return response.json();
      })
      .then(data => {
        console.log('Refund response:', data);
        if (data.success) {
          // Show success message
          toast.success(data.message, 'Refund Successful');
          
          // Close modal
          closeModal('refundModal');
          
          // Reload page after a short delay
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        } else {
          // Show error message
          toast.error(data.message || 'Unknown error occurred', 'Refund Failed');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        toast.error('An unexpected error occurred. Please try again.', 'System Error');
      });
    });
  } else {
    console.error('Refund form or submit button not found!');
    // Add debug info to help identify the issue
    console.log('Form element:', refundForm);
    if (refundForm) {
      console.log('Form HTML:', refundForm.outerHTML);
    }
  }
  
  // Add a test function to check if the toast notifications are working
  window.testToast = function() {
    toast.success('Test success message');
    setTimeout(() => toast.error('Test error message'), 1000);
    setTimeout(() => toast.info('Test info message'), 2000);
  };
  
  // Add a button to test toast notifications
  const container = document.querySelector('.container');
 
});

</script>
</script>
</body>
</html>