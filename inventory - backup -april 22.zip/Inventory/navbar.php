<?php
// Access session
if (!isset($_SESSION)) {
    session_start();
}

// Optional: fallback roleID if not set
$role = $_SESSION['role'] ?? null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="css/navbar.css">
    <script>
        window.onload = function () {
            // Sidebar toggle functionality
            const toggleButton = document.getElementById('toggle-btn');
            const sidebar = document.getElementById('sidebar');

            toggleButton.addEventListener('click', function () {
                sidebar.classList.toggle('close');
                toggleButton.classList.toggle('rotate');
                
                // Adjust navbar position when sidebar is toggled
                const navbar = document.getElementById('navbar');
                if (sidebar.classList.contains('close')) {
                    navbar.classList.add('sidebar-collapsed');
                } else {
                    navbar.classList.remove('sidebar-collapsed');
                }

                Array.from(sidebar.getElementsByClassName('show')).forEach(ul => {
                    ul.classList.remove('show');
                    ul.previousElementSibling.classList.remove('rotate');
                });
            });

            window.toggleSubMenu = function (button) {
                const submenu = button.nextElementSibling;
                submenu.classList.toggle('show');
                button.classList.toggle('rotate');

                if (sidebar.classList.contains('close')) {
                    sidebar.classList.toggle('close');
                    toggleButton.classList.toggle('rotate');
                }
            };
            
            // Logout modal functionality
            window.showLogoutModal = function(e) {
                e.preventDefault();
                document.getElementById('logoutModal').style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }

            window.hideLogoutModal = function() {
                document.getElementById('logoutModal').style.display = 'none';
                document.body.style.overflow = 'auto';
            }
            
            document.getElementById('logoutModal').addEventListener('click', function(e) {
                if (e.target === this) {
                    hideLogoutModal();
                }
            });

            // Notification dropdown functionality
            const notificationIcon = document.getElementById('notification-icon');
            const notificationDropdown = document.getElementById('notification-dropdown');
            
            notificationIcon.addEventListener('click', function() {
                notificationDropdown.classList.toggle('show');
            });

            // Close notification dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
                    notificationDropdown.classList.remove('show');
                }
            });

            // Profile dropdown functionality
            const profilePic = document.getElementById('profile-pic');
            const profileDropdown = document.getElementById('profile-dropdown-menu');
            
            profilePic.addEventListener('click', function() {
                profileDropdown.classList.toggle('show');
            });

            // Close profile dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!profilePic.contains(e.target) && !profileDropdown.contains(e.target)) {
                    profileDropdown.classList.remove('show');
                }
            });
        };
    </script>
</head>
<body>
    <!-- Logout Modal -->
    <div id="logoutModal" class="logout-modal">
        <div class="logout-modal-content">
            <h2>Confirm Logout</h2>
            <p>Are you sure you want to log out?</p>
            <div class="logout-modal-actions">
                <button onclick="hideLogoutModal()" class="logout-btn-cancel">Cancel</button>
                <a href="logout.php" class="logout-btn-confirm">Logout</a>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
   
      
    <!-- Navbar -->
    <div id="navbar" class="navbar">
        <div class="brand">
            <div class="logo-placeholder"> <img src="logo.jpg" alt="Logo"></div>
            <div class="company-name">Adriana's Marketing</div>
        </div>
        <div class="nav-items">
            <div class="notification-wrapper">
                <div id="notification-icon" class="notification-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#718096">
                        <path d="M160-200v-80h80v-280q0-83 50-147.5T420-792v-28q0-25 17.5-42.5T480-880q25 0 42.5 17.5T540-820v28q80 20 130 84.5T720-560v280h80v80H160Zm320-300Zm0 420q-33 0-56.5-23.5T400-160h160q0 33-23.5 56.5T480-80ZM320-280h320v-280q0-66-47-113t-113-47q-66 0-113 47t-47 113v280Z"/>
                    </svg>
                    <span class="notification-badge"></span>
                </div>
                <div id="notification-dropdown" class="dropdown-menu notification-dropdown">
                    <div class="dropdown-header">
                        <h3>Notifications</h3>
                        <a href="#" class="mark-all-read">Mark all as read</a>
                    </div>
                    <div class="dropdown-divider"></div>
                    <div class="notification-item">
                        <div class="notification-icon-wrapper">
                            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#9fce88">
                                <path d="M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z"/>
                            </svg>
                        </div>
                        <div class="notification-content">
                            <p>New inventory items have been added</p>
                            <span class="notification-time">2 hours ago</span>
                        </div>
                    </div>
                    <div class="notification-item">
                        <div class="notification-icon-wrapper">
                            <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#9fce88">
                                <path d="M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z"/>
                            </svg>
                        </div>
                        <div class="notification-content">
                            <p>Monthly report is ready to view</p>
                            <span class="notification-time">1 day ago</span>
                        </div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="view-all">View all notifications</a>
                </div>
            </div>
            <div class="profile-wrapper">
      
                    <div id="profile-pic" class="profile-pic"></div>
                <div id="profile-dropdown-menu" class="dropdown-menu profile-dropdown">
                    <div class="dropdown-header profile-header">
                        <div class="profile-info">
                            <h3>John Doe</h3>
                            <p>Administrator</p>
                        </div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item">
                        <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#718096">
                            <path d="M480-120q-75 0-140.5-28.5t-114-77q-48.5-48.5-77-114T120-480q0-75 28.5-140.5t77-114q48.5-48.5 114-77T480-840q75 0 140.5 28.5t114 77q48.5 48.5 77 114T840-480q0 75-28.5 140.5t-77 114q-48.5 48.5-114 77T480-120Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Zm-40 120v-240h80v240h-80Zm40 80q17 0 28.5-11.5T520-360q0-17-11.5-28.5T480-400q-17 0-28.5 11.5T440-360q0 17 11.5 28.5T480-320Z"/>
                        </svg>
                        <span>My Profile</span>
                    </a>
                    <a href="#" class="dropdown-item">
                        <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#718096">
                            <path d="M440-120v-240h80v80h320v80H520v80h-80Zm-320-80v-80h240v80H120Zm160-160v-80H120v-80h160v-80h80v240h-80Zm160-80v-80h400v80H440Zm160-160v-240h80v80h160v80H680v80h-80Zm-480-80v-80h400v80H120Z"/>
                        </svg>
                        <span>Settings</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" onclick="showLogoutModal(event)" class="dropdown-item">
                        <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#718096">
                            <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/>
                        </svg>
                        <span>Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
